# -*- coding: utf-8 -*-
"""EnigmaPlay Plugin Package"""
__version__ = "1.0.1"
