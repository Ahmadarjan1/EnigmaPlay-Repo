# -*- coding: utf-8 -*-
"""EnigmaPlay Plugin Package"""
__version__ = "1.1.0"
