# -*- coding: utf-8 -*-
"""
EnigmaPlay - Enigma2 Plugin Entry Point
======================================
"""

from __future__ import print_function, unicode_literals, absolute_import, division
import os
import sys

from Plugins.Plugin import PluginDescriptor

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
if PLUGIN_DIR not in sys.path:
    sys.path.insert(0, PLUGIN_DIR)

import catalog
import ui

GLOBAL_CATALOG = None


def get_catalog():
    global GLOBAL_CATALOG
    if GLOBAL_CATALOG is None:
        data_dir = os.path.join(PLUGIN_DIR, "data")
        try:
            # 1) Fresh cache (TTL = 1 hour)
            try:
                import settings as ep_settings
                ttl = int(ep_settings.get("catalog_ttl"))
            except Exception:
                ttl = 3600
            if catalog.is_cache_valid(ttl=ttl):
                GLOBAL_CATALOG = catalog.load_cached_catalog()

            # 2) Download index.json from EnigmaPlay-Repo (falls back to stale cache offline)
            if GLOBAL_CATALOG is None:
                remote_cat, online, msg = catalog.fetch_remote_index()
                if remote_cat is not None:
                    GLOBAL_CATALOG = remote_cat

            # 3) Last resort: local data/ files shipped with the plugin
            if GLOBAL_CATALOG is None:
                GLOBAL_CATALOG = catalog.load(data_dir)
        except Exception as e:
            print("[EnigmaPlay] Error loading catalog: %s" % e)
            GLOBAL_CATALOG = catalog.Catalog()
    return GLOBAL_CATALOG


def main(session, **kwargs):
    if os.path.exists("/tmp/enigmaplay_font_test"):
        session.open(ui.FontTestScreen)
        return
    cat = get_catalog()
    session.open(ui.EnigmaPlayScreen, cat)


def Plugins(**kwargs):
    icon_path = os.path.join(PLUGIN_DIR, "icon.png")
    if not os.path.exists(icon_path):
        icon_path = None

    return [
        PluginDescriptor(
            name="EnigmaPlay",
            description="متجر ومكتبة إضافات الإنيجما الشاملة (EnigmaPlay Store)",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon=icon_path if icon_path else "icon.png",
            fnc=main
        ),
        PluginDescriptor(
            name="EnigmaPlay",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main
        ),
    ]


