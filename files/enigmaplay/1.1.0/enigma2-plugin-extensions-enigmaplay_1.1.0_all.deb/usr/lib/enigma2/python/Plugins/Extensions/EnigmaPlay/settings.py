# -*- coding: utf-8 -*-
"""EnigmaPlay user settings (/etc/enigma2/enigmaplay/settings.json)."""
from __future__ import print_function, unicode_literals, absolute_import, division
import io
import json
import os

SETTINGS_FILE = "/etc/enigma2/enigmaplay/settings.json"

# key -> (default, [(value, Arabic label), ...], Arabic title)
OPTIONS = {
    "restart_after_install": ("ask", [("ask", "اسألني"), ("auto", "تلقائياً"), ("never", "لا")],
                              "إعادة التشغيل بعد التثبيت"),
    "catalog_ttl": (3600, [(3600, "كل ساعة"), (21600, "كل 6 ساعات"), (86400, "يومياً")],
                    "تحديث قائمة البلجنات"),
    "show_incompatible": (False, [(False, "لا"), (True, "نعم")],
                          "إظهار غير المتوافق مع جهازي"),
    "auto_sync": (True, [(True, "تشغيل"), (False, "إيقاف")],
                  "المزامنة التلقائية مع حسابي"),
}
ORDER = ["restart_after_install", "catalog_ttl", "show_incompatible", "auto_sync"]

_cache = {}


def _load():
    if _cache:
        return _cache
    data = {}
    try:
        with io.open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        pass
    for k, (default, choices, _) in OPTIONS.items():
        v = data.get(k, default)
        if v not in [c[0] for c in choices]:
            v = default
        _cache[k] = v
    return _cache


def get(key):
    return _load().get(key, OPTIONS[key][0])


def set(key, value):
    _load()[key] = value
    try:
        d = os.path.dirname(SETTINGS_FILE)
        if not os.path.isdir(d):
            os.makedirs(d)
        with io.open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            f.write(json.dumps(_cache, ensure_ascii=False, indent=2))
    except Exception:
        pass


def cycle(key):
    """Move to the next choice and return it."""
    choices = [c[0] for c in OPTIONS[key][1]]
    cur = get(key)
    nxt = choices[(choices.index(cur) + 1) % len(choices)] if cur in choices else choices[0]
    set(key, nxt)
    return nxt


def label(key):
    """'Title: value-label' for the settings menu."""
    default, choices, title = OPTIONS[key]
    cur = get(key)
    val = dict(choices).get(cur, str(cur))
    return "%s: %s" % (title, val)
