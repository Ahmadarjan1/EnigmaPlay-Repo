# -*- coding: utf-8 -*-
"""
EnigmaPlay account client (Cloudflare Worker API).
Stdlib only; works on Python 2.7 and 3.x. Falls back to curl/wget when the
image's Python SSL cannot reach the API.
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import io
import json
import os
import subprocess
import threading
try:
    from i18n import _
except Exception:
    _ = lambda t: t

API_BASE = "https://enigmaplay-api.ahmadalarjan2.workers.dev"
LINK_URL = API_BASE + "/link"
ACCOUNT_FILE = "/etc/enigma2/enigmaplay/account.json"
TIMEOUT = 12

_lock = threading.Lock()


# ---------------------------------------------------------------- session file
def load_session():
    try:
        with io.open(ACCOUNT_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        if d.get("token") and d.get("username"):
            return d
    except Exception:
        pass
    return None


def save_session(token, username):
    d = os.path.dirname(ACCOUNT_FILE)
    if not os.path.isdir(d):
        os.makedirs(d)
    tmp = ACCOUNT_FILE + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        f.write(json.dumps({"token": token, "username": username}, ensure_ascii=False))
    try:
        os.chmod(tmp, 0o600)
    except Exception:
        pass
    os.rename(tmp, ACCOUNT_FILE)


def clear_session():
    try:
        os.remove(ACCOUNT_FILE)
    except Exception:
        pass


def is_logged_in():
    return load_session() is not None


def username():
    s = load_session()
    return s["username"] if s else ""


# ---------------------------------------------------------------- device info
def device_info():
    info = {}
    try:
        import sys, struct
        info["python"] = "%d.%d" % sys.version_info[:2]
        info["arch"] = os.uname()[4]
    except Exception:
        pass
    try:
        from boxbranding import getMachineName, getImageDistro, getImageVersion
        info["model"] = getMachineName()
        info["image"] = "%s %s" % (getImageDistro(), getImageVersion())
    except Exception:
        for f in ("/proc/stb/info/vumodel", "/proc/stb/info/model", "/etc/hostname"):
            try:
                with open(f) as fh:
                    info["model"] = fh.read().strip()
                break
            except Exception:
                continue
    try:
        from __init__ import __version__
        info["plugin_version"] = __version__
    except Exception:
        pass
    return info


# ---------------------------------------------------------------- HTTP
class ApiError(Exception):
    def __init__(self, status, code, message):
        Exception.__init__(self, message)
        self.status = status
        self.code = code
        self.message = message


def _http_urllib(method, url, data, headers):
    try:
        from urllib.request import Request, urlopen
        from urllib.error import HTTPError
    except ImportError:
        from urllib2 import Request, urlopen, HTTPError
    req = Request(url, data=data, headers=headers)
    req.get_method = lambda: method
    try:
        resp = urlopen(req, timeout=TIMEOUT)
        return resp.getcode(), resp.read()
    except HTTPError as e:
        return e.code, e.read()


def _http_curl(method, url, data, headers):
    cmd = ["curl", "-s", "-k", "-m", str(TIMEOUT), "-X", method, "-w", "\n%{http_code}"]
    for k, v in headers.items():
        cmd += ["-H", "%s: %s" % (k, v)]
    if data is not None:
        cmd += ["--data-binary", "@-"]
    cmd.append(url)
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, _ = p.communicate(data)
    if p.returncode != 0 or not out:
        raise IOError("curl failed (%s)" % p.returncode)
    body, _, code = out.rpartition(b"\n")
    return int(code or 0), body


def request(method, path, body=None, token=None):
    """JSON request -> dict. Raises ApiError (server said no) or IOError (no connection)."""
    url = API_BASE + path
    headers = {"Content-Type": "application/json", "User-Agent": "EnigmaPlay/1.0", "Accept": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    data = json.dumps(body).encode("utf-8") if body is not None else None
    try:
        status, raw = _http_urllib(method, url, data, headers)
    except Exception:
        status, raw = _http_curl(method, url, data, headers)   # old SSL on the image
    try:
        payload = json.loads(raw.decode("utf-8")) if raw else {}
    except Exception:
        payload = {}
    if status >= 400 or status == 0:
        raise ApiError(status, payload.get("error", "http_%s" % status),
                       payload.get("message") or _("خطأ من الخادم (%s)") % status)
    return payload


def _authed(method, path, body=None):
    s = load_session()
    if not s:
        raise ApiError(401, "unauthorized", _("غير مسجّل الدخول"))
    try:
        return request(method, path, body, token=s["token"])
    except ApiError as e:
        if e.status == 401:
            clear_session()
        raise


# ---------------------------------------------------------------- API calls
def login(user, password):
    d = request("POST", "/v1/login", {"username": user, "password": password, "device": device_info()})
    save_session(d["token"], d["user"]["username"])
    return d["user"]["username"]


def register(user, password):
    d = request("POST", "/v1/register", {"username": user, "password": password, "device": device_info()})
    save_session(d["token"], d["user"]["username"])
    return d["user"]["username"]


def logout():
    try:
        _authed("POST", "/v1/logout")
    except Exception:
        pass
    clear_session()


def pair_start():
    return request("POST", "/v1/pair/start", {"device": device_info()})


def pair_poll(poll):
    """-> ("pending"|"expired"|"done", username)"""
    d = request("GET", "/v1/pair/poll?poll=" + poll)
    if d.get("status") == "done" and d.get("token"):
        save_session(d["token"], d["user"]["username"])
        return "done", d["user"]["username"]
    return d.get("status", "pending"), ""


def get_plugins():
    return _authed("GET", "/v1/me").get("plugins", [])


def push_plugins(items):
    """items: [{"id", "name", "version"}] -> server list after merge"""
    if not items:
        return get_plugins()
    return _authed("PUT", "/v1/plugins", {"plugins": items}).get("plugins", [])


def remove_plugin(plugin_id):
    return _authed("DELETE", "/v1/plugins/" + plugin_id)
