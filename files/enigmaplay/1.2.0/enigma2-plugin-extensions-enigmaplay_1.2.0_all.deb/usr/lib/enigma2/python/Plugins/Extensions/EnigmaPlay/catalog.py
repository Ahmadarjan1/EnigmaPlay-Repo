# -*- coding: utf-8 -*-
"""
EnigmaPlay Data Layer - Catalog Parser
======================================
Robust catalog parser for Enigma2 plugins and extensions data files.
Compatible with Python 2.7 and Python 3.x.
Standard library only (zero external dependencies).
"""

from __future__ import print_function, unicode_literals, absolute_import, division
import io
import os
import re
import json
try:
    from i18n import _
except Exception:
    _ = lambda t: t
from collections import defaultdict, Counter

# Python 2 and 3 string compatibility
try:
    string_types = (basestring,)
    text_type = unicode
except NameError:
    string_types = (str,)
    text_type = str

# ---------------------------------------------------------------------------
# STEP 5 - ARABIC NAME MAPS & CONSTANTS
# ---------------------------------------------------------------------------

CATEGORIES = {
}

SUBCODES = {
    "Uti": _("أدوات"),
    "Sub": _("ترجمة"),
    "Ipt": "IPTV",
    "Aud": _("صوتيات"),
    "Enc": _("تشفير"),
    "Qur": _("إسلاميات"),
    "Games": _("ألعاب"),
    "Mul": _("ملتي بوت"),
    "Epg": _("دليل البرامج"),
    "Pic": _("بيكونات"),
    "Set": _("ملفات قنوات"),
    "Free": _("مجاني"),
    "Spo": _("رياضة"),
    "Wea": _("طقس"),
    "Rad": _("راديو"),
    "Bac": _("باكآب"),
    "Sys": _("نظام"),
    "Nov": _("نوفالر"),
    "Pan": _("بانلات"),
}

IMAGE_CODES = {
    "Satv": "OpenATV",
    "Sobh": "OpenBH",
    "Spli3": "OpenPLi",
    "Svix": "OpenViX",
    "Segami": "Egami",
    "Sspa": "OpenSPA",
    "Spure": "Pure2",
    "Soebased": "OE-based",
}

DANGER_WORDS = [
    "حذف",
    "فرمطة",
    "ضبط مصنع",
]

# Regular expressions
_URL_REGEX = re.compile(r"https?://\S+?\.sh(\?[^'\s]*)?")
_GROUP_REGEX = re.compile(r"^-{3,}\s*(.+?)\s*-+$")
_DATE_REGEX = re.compile(r"^\b(\d{2}\.\d{2}\.\d{4})\b$")
_BULLET_REGEX = re.compile(r"^[○•]\s*(.*)$")


import datetime

def _clean_str(s):
    """Normalize string by removing non-alphanumeric characters and converting to lowercase."""
    if not s:
        return ""
    return re.sub(r'[^a-z0-9]', '', s.lower())


def _normalize_search(s):
    """Normalize Arabic search text by removing diacritics and unifying letters."""
    if not s:
        return ""
    s = text_type(s).lower()
    s = re.sub(r'[\u064B-\u065F\u0670\u0640]', '', s)
    s = re.sub(r'[إأآا]', 'ا', s)
    s = re.sub(r'ة', 'ه', s)
    s = re.sub(r'ى', 'ي', s)
    return s.strip()


def _is_future_date(d_str):
    """Check if date is later than today + 1 day (e.g. data typo like 2027)."""
    if not d_str:
        return False
    try:
        parts = d_str.split('.')
        d = datetime.date(int(parts[2]), int(parts[1]), int(parts[0]))
        max_allowed = datetime.date.today() + datetime.timedelta(days=1)
        return d > max_allowed
    except Exception:
        return False


def _parse_date(d_str):
    """Parse dd.mm.yyyy string into a sortable tuple (yyyy, mm, dd)."""
    if not d_str or _is_future_date(d_str):
        return (0, 0, 0)
    try:
        parts = d_str.split('.')
        return (int(parts[2]), int(parts[1]), int(parts[0]))
    except Exception:
        return (0, 0, 0)


# ---------------------------------------------------------------------------
# STEP 3 - ITEM DATA STRUCTURE
# ---------------------------------------------------------------------------

class Item(object):
    """Represents a single catalog entry."""

    def __init__(self, id, category, group, name, version, description,
                 updated, status_codes, url, host, dangerous, line_no, changelog=None,
                 sha256=None, restart=False, icon_url=None,
                 downloads=None, python=None, package=None, author=None, screenshots=None):
        self.id = id
        self.screenshots = [u for u in (screenshots or []) if u]
        # schema 2 (EnigmaPlay-Repo index.json)
        self.downloads = list(downloads) if downloads else []
        self.python = [str(x) for x in python] if python else ["2", "3"]
        self.package = package
        self.author = author
        self.category = category
        self.group = group
        self.name = name
        self.version = version
        self.description = description
        self.updated = updated
        self.status_codes = list(status_codes) if status_codes else []
        self.url = url
        self.host = host
        self.dangerous = bool(dangerous)
        self.line_no = int(line_no)
        self.changelog = list(changelog) if changelog else []
        self.sha256 = sha256.strip().lower() if sha256 else None
        self.restart = bool(restart)
        self.icon_url = icon_url

    @property
    def key(self):
        return self.id

    @property
    def subcode(self):
        for sc in self.status_codes:
            if sc in SUBCODES:
                return sc
        return None

    def to_dict(self):
        """Serialize item to a dictionary."""
        return {
            "id": self.id,
            "category": self.category,
            "group": self.group,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "updated": self.updated,
            "status_codes": list(self.status_codes),
            "url": self.url,
            "host": self.host,
            "dangerous": self.dangerous,
            "line_no": self.line_no,
            "changelog": list(self.changelog),
            "sha256": self.sha256,
            "restart": self.restart,
            "icon_url": self.icon_url,
            "downloads": list(self.downloads),
            "python": list(self.python),
            "package": self.package,
            "author": self.author,
            "screenshots": list(self.screenshots)
        }

    @classmethod
    def from_dict(cls, d):
        """Reconstruct item from a dictionary."""
        d = dict(d)
        try:
            from i18n import LANG as _lang
            loc = (d.get("i18n") or {}).get(_lang) or {}
            if loc.get("description"):
                d["description"] = loc["description"]
        except Exception:
            pass
        return cls(
            id=d.get("id", ""),
            category=d.get("category", ""),
            group=d.get("group"),
            name=d.get("name", ""),
            version=d.get("version", ""),
            description=d.get("description", ""),
            updated=d.get("updated"),
            status_codes=d.get("status_codes", []),
            url=d.get("url", ""),
            host=d.get("host", "other"),
            dangerous=d.get("dangerous", False),
            line_no=d.get("line_no", 0),
            changelog=d.get("changelog", []),
            sha256=d.get("sha256"),
            restart=d.get("restart", False),
            icon_url=d.get("icon_url"),
            downloads=d.get("downloads"),
            python=d.get("python"),
            package=d.get("package"),
            author=d.get("author"),
            screenshots=d.get("screenshots")
        )

    def __repr__(self):
        return "<Item id=%r name=%r cat=%r ver=%r sha256=%r restart=%r dangerous=%r>" % (
            self.id, self.name, self.category, self.version, self.sha256, self.restart, self.dangerous
        )


# ---------------------------------------------------------------------------
# STEP 6 - CATALOG CLASS & API
# ---------------------------------------------------------------------------

class Catalog(object):
    """In-memory searchable catalog holding all items and parsed metadata."""

    def __init__(self, items=None, warnings=None, unmatched_changelog=None,
                 is_offline=False, offline_message="", categories=None):
        self.items = list(items) if items else []
        # [{"id","name","order","color"}] from index.json, in display order
        self.categories = list(categories) if categories else []
        self.warnings = list(warnings) if warnings else []
        self.unmatched_changelog = list(unmatched_changelog) if unmatched_changelog else []
        self.is_offline = bool(is_offline)
        self.offline_message = offline_message
        self._reindex()

    def category_list(self):
        """[(id, arabic_name)] of categories that actually contain items, in display order."""
        used = set(it.category for it in self.items)
        out = [(c["id"], _(c.get("name", c["id"]))) for c in self.categories if c["id"] in used]
        known = set(cid for cid, _ in out)
        for cid in sorted(used - known):
            if cid:
                out.append((cid, CATEGORIES.get(cid, cid)))
        return out

    def _reindex(self):
        """Build internal lookup dictionaries for fast indexing."""
        self._by_id = {}
        self._by_category = defaultdict(list)
        self._by_subcode = defaultdict(list)

        for item in self.items:
            self._by_id[item.id] = item
            # Also allow fallback lookup by original key if this item has a disambiguated key (category:KEY:N)
            if ":" in item.id:
                parts = item.id.split(":")
                if len(parts) == 3:
                    orig_key = parts[1]
                    if orig_key not in self._by_id:
                        self._by_id[orig_key] = item
            self._by_category[item.category].append(item)
            for sc in item.status_codes:
                self._by_subcode[sc.lower()].append(item)

    def by_category(self, cat):
        """Return list of items in the specified category."""
        return list(self._by_category.get(cat, []))

    def by_subcode(self, code):
        """
        Return list of items matching the given subcode.
        Accepts short code (e.g. 'Uti', 'Sub') or Arabic name (e.g. 'أدوات').
        """
        if not code:
            return []
        code_str = text_type(code).strip()
        code_low = code_str.lower()
        if code_low in self._by_subcode:
            return list(self._by_subcode[code_low])

        # Check Arabic translation
        for eng_code, ar_name in SUBCODES.items():
            if code_str == ar_name or code_low == eng_code.lower():
                return list(self._by_subcode.get(eng_code.lower(), []))
        return []

    def search(self, text):
        """
        Search catalog items across name, description, category, group,
        status codes, and Arabic name mappings (case-insensitive & Arabic normalized).
        """
        if not text:
            return []
        raw_q = text_type(text).strip().lower()
        norm_q = _normalize_search(text)
        if not raw_q and not norm_q:
            return []

        results = []
        for item in self.items:
            match = False
            item_name_norm = _normalize_search(item.name)
            item_desc_norm = _normalize_search(item.description or "")

            if raw_q in item.name.lower() or (norm_q and norm_q in item_name_norm):
                match = True
            elif item.description and (raw_q in item.description.lower() or (norm_q and norm_q in item_desc_norm)):
                match = True
            elif item.category and (raw_q in item.category.lower() or (norm_q and norm_q in _normalize_search(item.category))):
                match = True
            elif item.group and (raw_q in item.group.lower() or (norm_q and norm_q in _normalize_search(item.group))):
                match = True
            elif any(raw_q in sc.lower() for sc in item.status_codes):
                match = True
            elif item.category in CATEGORIES and (raw_q in CATEGORIES[item.category].lower() or (norm_q and norm_q in _normalize_search(CATEGORIES[item.category]))):
                match = True
            elif any(sc in SUBCODES and (raw_q in SUBCODES[sc].lower() or (norm_q and norm_q in _normalize_search(SUBCODES[sc]))) for sc in item.status_codes):
                match = True

            if match:
                results.append(item)
        return results

    def recent(self, n=10):
        """Return the top n items sorted by updated date (newest first)."""
        items_with_date = [it for it in self.items if it.updated]
        items_with_date.sort(key=lambda it: _parse_date(it.updated), reverse=True)
        return items_with_date[:n]

    def get(self, id):
        """Retrieve an item by its unique ID (or fallback KEY)."""
        if not id:
            return None
        return self._by_id.get(id)

    def to_json(self, path):
        """Serialize catalog to a JSON file."""
        data = {
            "items": [it.to_dict() for it in self.items],
            "warnings": [list(w) for w in self.warnings],
            "unmatched_changelog": [list(u) for u in self.unmatched_changelog],
            "categories": list(self.categories)
        }
        with io.open(path, 'w', encoding='utf-8') as f:
            dumped = json.dumps(data, ensure_ascii=False, indent=2)
            f.write(dumped)

    @classmethod
    def from_json(cls, path_or_data, is_offline=False, offline_message=""):
        """Load catalog from a cached JSON file or loaded dict/list."""
        if isinstance(path_or_data, (dict, list)):
            data = path_or_data
        else:
            with io.open(path_or_data, 'r', encoding='utf-8') as f:
                data = json.load(f)

        if isinstance(data, list):
            items = [Item.from_dict(d) for d in data if isinstance(d, dict)]
            warnings = []
            unmatched = []
        elif isinstance(data, dict):
            raw_items = data.get("items", [])
            items = [Item.from_dict(d) for d in raw_items if isinstance(d, dict)]
            warnings = [tuple(w) for w in data.get("warnings", [])]
            unmatched = [tuple(u) for u in data.get("unmatched_changelog", [])]
            categories = [c for c in data.get("categories", []) if isinstance(c, dict) and c.get("id")]
        else:
            items, warnings, unmatched = [], [], []
        if not isinstance(data, dict):
            categories = []

        cat = cls(items=items, warnings=warnings, unmatched_changelog=unmatched,
                  is_offline=is_offline, offline_message=offline_message, categories=categories)
        apply_categories(cat)
        return cat


# ---------------------------------------------------------------------------
# CACHE MANAGEMENT (TTL = 1 HOUR, SCHEMA VERSION 1) & OFFLINE FALLBACK
# ---------------------------------------------------------------------------
SCHEMA_VERSION = 1
DEFAULT_TTL = 3600  # 1 hour in seconds
REPO_INDEX_URL = "https://raw.githubusercontent.com/Ahmadarjan1/EnigmaPlay-Repo/main/index.json"
REMOTE_TIMEOUT = 10
MAX_ICON_SIZE = 512 * 1024  # 512 KB

CACHE_DIR = "/etc/enigma2/enigmaplay/cache"
FALLBACK_CACHE_DIR = "/tmp/enigmaplay/cache"


def get_cache_dir():
    for d in (CACHE_DIR, FALLBACK_CACHE_DIR):
        try:
            if not os.path.exists(d):
                os.makedirs(d, mode=0o755, exist_ok=True)
            test_f = os.path.join(d, ".test_write")
            with open(test_f, "w") as f:
                f.write("ok")
            os.remove(test_f)
            return d
        except Exception:
            continue
    return "/tmp"


def get_index_cache_path():
    return os.path.join(get_cache_dir(), "index.json")


def get_cache_meta_path():
    return os.path.join(get_cache_dir(), "cache_meta.json")


def is_cache_valid(data_dir=None, ttl=DEFAULT_TTL):
    """
    Check if cached index is valid:
    - schema version must match SCHEMA_VERSION
    - age must be within TTL
    - if data_dir provided, cache must not be older than any file in data_dir
    """
    idx_path = get_index_cache_path()
    meta_path = get_cache_meta_path()
    if not os.path.isfile(idx_path) or not os.path.isfile(meta_path):
        return False
    try:
        import time
        with io.open(meta_path, 'r', encoding='utf-8') as f:
            meta = json.load(f)

        # Check schema version
        if meta.get("version") != SCHEMA_VERSION:
            return False

        cached_at = meta.get("cached_at", 0)
        # Check TTL
        if (time.time() - cached_at) >= ttl:
            return False

        # Invalidate when data/ files are newer than the cache
        if data_dir and os.path.isdir(data_dir):
            latest_mtime = 0
            for fname in os.listdir(data_dir):
                if not fname.startswith('.'):
                    fpath = os.path.join(data_dir, fname)
                    if os.path.isfile(fpath):
                        m = os.path.getmtime(fpath)
                        if m > latest_mtime:
                            latest_mtime = m
            if latest_mtime > cached_at:
                return False

        return True
    except Exception:
        return False


def save_cache(catalog_instance, repo_url=None, data_dir=None):
    """Save catalog cache atomically using a temporary file and rename."""
    try:
        import time
        c_dir = get_cache_dir()
        idx_path = get_index_cache_path()
        meta_path = get_cache_meta_path()

        pid = os.getpid()
        tmp_idx = idx_path + ".tmp.%d" % pid
        tmp_meta = meta_path + ".tmp.%d" % pid

        catalog_instance.to_json(tmp_idx)

        cached_time = time.time()
        meta = {
            "version": SCHEMA_VERSION,
            "cached_at": cached_time,
            "repo_url": repo_url or "",
            "item_count": len(catalog_instance.items)
        }
        with io.open(tmp_meta, 'w', encoding='utf-8') as f:
            f.write(text_type(json.dumps(meta, indent=2, ensure_ascii=False)))

        # Atomic replacement
        if hasattr(os, "replace"):
            os.replace(tmp_idx, idx_path)
            os.replace(tmp_meta, meta_path)
        else:
            if os.path.exists(idx_path):
                os.remove(idx_path)
            os.rename(tmp_idx, idx_path)
            if os.path.exists(meta_path):
                os.remove(meta_path)
            os.rename(tmp_meta, meta_path)

        return True
    except Exception as e:
        print("[EnigmaPlay] Error saving cache: %s" % e)
        return False


def load_cached_catalog(is_offline=False, offline_message=""):
    idx_path = get_index_cache_path()
    if os.path.isfile(idx_path):
        try:
            return Catalog.from_json(idx_path, is_offline=is_offline, offline_message=offline_message)
        except Exception as e:
            print("[EnigmaPlay] Error loading cache: %s" % e)
    return None


def apply_categories(catalog_instance):
    """Refresh the global CATEGORIES map (id -> Arabic name) from a catalog's categories."""
    try:
        for c in getattr(catalog_instance, "categories", []) or []:
            if c.get("id"):
                CATEGORIES[c["id"]] = _(c.get("name") or c["id"])
    except Exception:
        pass


def _download_text_with_tools(url, timeout=REMOTE_TIMEOUT):
    import subprocess
    for cmd in (["wget", "-q", "-T", str(timeout), "-O", "-", url],
                ["wget", "-q", "--no-check-certificate", "-T", str(timeout), "-O", "-", url],
                ["curl", "-s", "-k", "-L", "-m", str(timeout), url]):
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, _ = proc.communicate()
            if proc.returncode == 0 and out:
                return out.decode("utf-8")
        except Exception:
            continue
    return None


def fetch_remote_index(url=REPO_INDEX_URL, timeout=REMOTE_TIMEOUT):
    """
    Fetch remote index JSON with timeout.
    Returns tuple: (catalog_instance, is_online, message)
    """
    try:
        try:
            from urllib.request import Request, urlopen
        except ImportError:
            from urllib2 import Request, urlopen

        content = None
        try:
            req = Request(url, headers={"User-Agent": "EnigmaPlay/1.0"})
            resp = urlopen(req, timeout=timeout)
            content = resp.read().decode('utf-8')
        except Exception as e_url:
            # Old images (Python 2 / outdated SSL): fall back to the system wget/curl
            content = _download_text_with_tools(url, timeout)
            if content is None:
                raise e_url
        data = json.loads(content)
        cat = Catalog.from_json(data)
        save_cache(cat, repo_url=url)
        return cat, True, _("تم تحديث الفهرس بنجاح.")
    except Exception as e:
        # Network failed -> fallback to cache
        cached = load_cached_catalog(is_offline=True, offline_message=_("تعذر الاتصال بالخادم. تم استخدام النسخة المخزنة مؤقتاً."))
        if cached:
            return cached, False, _("تعذر الاتصال بالخادم. تم استخدام النسخة المخزنة مؤقتاً.")
        return None, False, _("خطأ: لا يوجد اتصال بالإنترنت ولا توجد نسخة مخزنة مؤقتاً.")


def download_icon(icon_url, item_id, timeout=5, max_size=MAX_ICON_SIZE):
    """Download icon file in background with size and timeout restrictions."""
    if not icon_url:
        return None
    icons_dir = os.path.join(get_cache_dir(), "icons")
    try:
        if not os.path.exists(icons_dir):
            os.makedirs(icons_dir, mode=0o755, exist_ok=True)
        safe_name = re.sub(r'[^a-zA-Z0-9_-]', '_', item_id) + ".png"
        target_path = os.path.join(icons_dir, safe_name)
        if os.path.isfile(target_path) and os.path.getsize(target_path) > 0:
            return target_path

        try:
            from urllib.request import Request, urlopen
        except ImportError:
            from urllib2 import Request, urlopen

        req = Request(icon_url, headers={"User-Agent": "EnigmaPlay/1.0"})
        resp = urlopen(req, timeout=timeout)
        data = resp.read(max_size + 1)
        if len(data) > max_size:
            return None  # Icon too large, abort

        tmp_path = target_path + ".tmp.%d" % os.getpid()
        with open(tmp_path, "wb") as f:
            f.write(data)
        if hasattr(os, "replace"):
            os.replace(tmp_path, target_path)
        else:
            if os.path.exists(target_path):
                os.remove(target_path)
            os.rename(tmp_path, target_path)
        return target_path
    except Exception:
        return None


MAX_SHOT_SIZE = 4 * 1024 * 1024
_SHOT_DOWNLOADING = set()


def _shot_path(url, item_id, n):
    ext = ".jpg" if url.lower().split("?")[0].endswith((".jpg", ".jpeg")) else ".png"
    safe = re.sub(r'[^a-zA-Z0-9_-]', '_', item_id)
    # include a short hash of the URL so a replaced screenshot is downloaded again
    import hashlib
    h = hashlib.md5(url.encode("utf-8")).hexdigest()[:8]
    return os.path.join(get_cache_dir(), "shots", "%s_%d_%s%s" % (safe, n, h, ext))


def _download_shot(url, target_path):
    try:
        try:
            from urllib.request import Request, urlopen
        except ImportError:
            from urllib2 import Request, urlopen
        d = os.path.dirname(target_path)
        if not os.path.isdir(d):
            os.makedirs(d)
        data = None
        try:
            resp = urlopen(Request(url, headers={"User-Agent": "EnigmaPlay/1.0"}), timeout=15)
            data = resp.read(MAX_SHOT_SIZE + 1)
        except Exception:
            import subprocess
            tmp = target_path + ".wget"
            for cmd in (["wget", "-q", "-T", "15", "-O", tmp, url],
                        ["wget", "-q", "--no-check-certificate", "-T", "15", "-O", tmp, url]):
                try:
                    if subprocess.call(cmd) == 0 and os.path.getsize(tmp) > 0:
                        with open(tmp, "rb") as f:
                            data = f.read(MAX_SHOT_SIZE + 1)
                        break
                except Exception:
                    continue
            try:
                os.remove(tmp)
            except Exception:
                pass
        if not data or len(data) > MAX_SHOT_SIZE:
            return
        tmp_path = target_path + ".tmp.%d" % os.getpid()
        with open(tmp_path, "wb") as f:
            f.write(data)
        os.rename(tmp_path, target_path)
    except Exception:
        pass
    finally:
        _SHOT_DOWNLOADING.discard(target_path)


def get_cached_screenshot(url, item_id, n):
    """Local path of screenshot n of an item, or None (download starts in background)."""
    if not url:
        return None
    target = _shot_path(url, item_id, n)
    if os.path.isfile(target) and os.path.getsize(target) > 0:
        return target
    if target not in _SHOT_DOWNLOADING:
        _SHOT_DOWNLOADING.add(target)
        import threading
        t = threading.Thread(target=_download_shot, args=(url, target))
        t.daemon = True
        t.start()
    return None


def get_cached_icon(icon_url, item_id):
    """Retrieve local cached icon path or trigger background download."""
    if not icon_url:
        return None
    icons_dir = os.path.join(get_cache_dir(), "icons")
    safe_name = re.sub(r'[^a-zA-Z0-9_-]', '_', item_id) + ".png"
    target_path = os.path.join(icons_dir, safe_name)
    if os.path.isfile(target_path) and os.path.getsize(target_path) > 0:
        return target_path

    # Trigger background download without blocking UI thread
    import threading
    t = threading.Thread(target=download_icon, args=(icon_url, item_id))
    t.daemon = True
    t.start()
    return None


# ---------------------------------------------------------------------------
# STEP 1, 2, 4 - PARSER ENGINE
# ---------------------------------------------------------------------------

def load(data_dir):
    """
    Parse the 12 data files inside data_dir and return a Catalog instance.
    Handles broken formatting, extracts changelog, fuzzy matches updates,
    and records all warnings without crashing.
    """
    all_items = []
    all_warnings = []

    # Collect category files (all files except info.txt and hidden files)
    files = sorted(os.listdir(data_dir))
    cat_files = [f for f in files if f != 'info.txt' and not f.startswith('.')]

    for cat_name in cat_files:
        file_path = os.path.join(data_dir, cat_name)
        if not os.path.isfile(file_path):
            continue

        with io.open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.read().splitlines()

        current_group = None
        cur_name = None
        cur_version = ""
        cur_desc = ""
        cur_updated = None
        cur_status = []
        cur_sha256 = None
        cur_restart = False
        cur_icon_url = None
        cur_lno = 0
        key_counts = {}

        for lno, raw_line in enumerate(lines, 1):
            s = raw_line.strip()
            if not s:
                continue

            # STEP 1: Lines starting with ### are headers -> ignore
            if s.startswith('###'):
                continue

            # STEP 1: Lines like --------------xxx-------------- are sub-groups
            m_group = _GROUP_REGEX.match(s)
            if m_group:
                current_group = m_group.group(1).strip()
                continue

            # STEP 2: Package line handling (a: no space after colon, b: leading dot)
            is_pkg = False
            pkg_str = None
            if s.startswith('.Package:') or s.startswith('.Package :'):
                is_pkg = True
                all_warnings.append((cat_name, lno, "Leading dot in Package: '%s'" % raw_line))
                pkg_str = s.split(':', 1)[1].strip()
            elif s.startswith('Package:') or s.startswith('Package :'):
                is_pkg = True
                if not (raw_line.startswith('Package: ') or raw_line.startswith('Package : ')):
                    all_warnings.append((cat_name, lno, "No space after colon in Package: '%s'" % raw_line))
                pkg_str = s.split(':', 1)[1].strip()

            if is_pkg:
                cur_name = pkg_str
                cur_version = ""
                cur_desc = ""
                cur_updated = None
                cur_status = []
                cur_sha256 = None
                cur_restart = False
                cur_icon_url = None
                cur_lno = lno
                continue

            # STEP 1 & 3: Version line handling
            if s.startswith('Version:') or s.startswith('Version :'):
                val = s.split(':', 1)[1].strip()
                # Special case: skins file has a date embedded after version
                if cat_name == 'skins':
                    m_date = re.search(r'\b(\d{2}\.\d{2}\.\d{4})\b', val)
                    if m_date:
                        d_found = m_date.group(1)
                        if _is_future_date(d_found):
                            all_warnings.append((cat_name, lno, "Ignored future date: '%s'" % d_found))
                            cur_updated = None
                        else:
                            cur_updated = d_found
                        ver_part = val[:m_date.start()].strip()
                        desc_part = val[m_date.end():].strip()
                        parts = re.split(r'[ \t]{2,}', ver_part, maxsplit=1)
                        cur_version = parts[0].strip()
                        cur_desc = desc_part if desc_part else (parts[1].strip() if len(parts) > 1 else "")
                    else:
                        parts = re.split(r'[ \t]{2,}', val, maxsplit=1)
                        cur_version = parts[0].strip()
                        cur_desc = parts[1].strip() if len(parts) > 1 else ""
                else:
                    parts = re.split(r'[ \t]{2,}', val, maxsplit=1)
                    cur_version = parts[0].strip()
                    cur_desc = parts[1].strip() if len(parts) > 1 else ""
                continue

            # STEP 1: Status line handling
            if s.startswith('Status:') or s.startswith('Status :'):
                val = s.split(':', 1)[1].strip()
                cur_status = val.split()
                continue

            # Sha256 line handling
            if s.startswith('Sha256:') or s.startswith('Sha256 :') or s.startswith('SHA256:') or s.startswith('SHA256 :'):
                val = s.split(':', 1)[1].strip()
                cur_sha256 = val.lower() if val else None
                continue

            # Restart line handling
            if s.startswith('Restart:') or s.startswith('Restart :'):
                val = s.split(':', 1)[1].strip().lower()
                cur_restart = val in ('true', '1', 'yes', 'y', 'نعم')
                continue

            # Icon line handling
            if s.startswith('Icon:') or s.startswith('Icon :') or s.startswith('Icon_url:') or s.startswith('Icon_url :'):
                cur_icon_url = s.split(':', 1)[1].strip()
                continue

            # STEP 1 & 2: KEY='URL' line handling
            if '=' in s and ('http' in s or '.sh' in s):
                # c) URL with a missing closing quote
                if not s.endswith("'"):
                    all_warnings.append((cat_name, lno, "Missing closing quote on URL line: '%s'" % raw_line))

                # d) Two URLs glued on same line -> take the first valid one
                all_matches = [m.group(0) for m in _URL_REGEX.finditer(s)]
                if len(all_matches) > 1:
                    all_warnings.append((cat_name, lno, "Multiple glued URLs on line: '%s'" % raw_line))

                m_url = _URL_REGEX.search(s)
                if not m_url:
                    all_warnings.append((cat_name, lno, "Invalid URL on line: '%s'" % raw_line))
                    continue

                extracted_url = m_url.group(0)
                key = s.split('=', 1)[0].strip()

                if not cur_name:
                    all_warnings.append((cat_name, lno, "URL found without preceding Package line: '%s'" % raw_line))
                    continue

                # Skip items whose name is "test"
                if cur_name.lower() == 'test':
                    all_warnings.append((cat_name, cur_lno, "Skipped item with name 'test'"))
                    cur_name = None
                    continue

                # Check duplicate KEY in the same file
                key_counts[key] = key_counts.get(key, 0) + 1
                if key_counts[key] == 1:
                    item_id = key
                else:
                    item_id = "%s:%s:%d" % (cat_name, key, key_counts[key])
                    all_warnings.append((cat_name, lno, "Duplicate KEY '%s' in category '%s' (assigned id '%s')" % (key, cat_name, item_id)))

                # Determine host: github / gitlab / other
                u_low = extracted_url.lower()
                if 'github' in u_low:
                    host = "github"
                elif 'gitlab' in u_low:
                    host = "gitlab"
                else:
                    host = "other"

                # Dangerous flag computation
                dangerous = False
                if cat_name == 'imagesd':
                    dangerous = True
                elif cur_name.startswith('Rm-') or cur_name.startswith('Hdd-'):
                    dangerous = True
                elif any(dw in cur_desc for dw in DANGER_WORDS):
                    dangerous = True

                item = Item(
                    id=item_id,
                    category=cat_name,
                    group=current_group,
                    name=cur_name,
                    version=cur_version,
                    description=cur_desc,
                    updated=cur_updated,
                    status_codes=cur_status,
                    url=extracted_url,
                    host=host,
                    dangerous=dangerous,
                    line_no=cur_lno,
                    sha256=cur_sha256,
                    restart=cur_restart,
                    icon_url=cur_icon_url
                )
                all_items.append(item)

                # Reset item accumulator
                cur_name = None
                cur_version = ""
                cur_desc = ""
                cur_updated = None
                cur_status = []
                cur_sha256 = None
                cur_restart = False
                cur_icon_url = None
                cur_lno = 0
                continue

            # e) Junk lines after last item or unrecognized line
            all_warnings.append((cat_name, lno, "Junk or unrecognized line: '%s'" % raw_line))

    # STEP 4: Parse info.txt (CHANGELOG)
    unmatched_changelog = []
    info_path = os.path.join(data_dir, 'info.txt')
    if os.path.isfile(info_path):
        with io.open(info_path, 'r', encoding='utf-8', errors='ignore') as f:
            info_lines = f.read().splitlines()

        cur_date = None
        changelog_entries = []

        for lno, raw_line in enumerate(info_lines, 1):
            s = raw_line.strip()
            if not s or s.startswith('='):
                continue
            m_date = _DATE_REGEX.match(s)
            if m_date:
                cur_date = m_date.group(1)
                continue
            m_bullet = _BULLET_REGEX.match(s)
            if m_bullet:
                raw_text = m_bullet.group(1).strip()
                tokens = raw_text.split()
                raw_name = raw_text
                version = None
                if len(tokens) > 1:
                    if re.match(r'^[vV]?\d', tokens[-1]):
                        version = tokens[-1]
                        raw_name = ' '.join(tokens[:-1])
                    elif len(tokens) > 2 and re.match(r'^[vV]?\d', tokens[-2]) and tokens[-1].startswith('py'):
                        version = ' '.join(tokens[-2:])
                        raw_name = ' '.join(tokens[:-2])
                changelog_entries.append((cur_date, raw_name, version, raw_text))

        # Tightened matching (D3): a changelog line matches an item only if the
        # normalized changelog name EQUALS the normalized item name, or starts
        # with it followed by a non-letter.
        def _norm_str(s):
            if not s:
                return ""
            return re.sub(r'\s+', ' ', s.strip().lower())

        for date, raw_name, version, raw_text in changelog_entries:
            norm_raw = _norm_str(raw_name)
            norm_full = _norm_str(raw_text)

            matched_item = None
            # Pass 1: exact match
            for it in all_items:
                norm_it = _norm_str(it.name)
                if norm_it and (norm_raw == norm_it or norm_full == norm_it):
                    matched_item = it
                    break

            # Pass 2: starts with normalized item name followed by non-letter
            if not matched_item:
                candidates = []
                for it in all_items:
                    norm_it = _norm_str(it.name)
                    if not norm_it:
                        continue
                    if norm_raw.startswith(norm_it):
                        rem = norm_raw[len(norm_it):]
                        if rem and not rem[0].isalpha():
                            candidates.append(it)
                    elif norm_full.startswith(norm_it):
                        rem = norm_full[len(norm_it):]
                        if rem and not rem[0].isalpha():
                            candidates.append(it)
                if candidates:
                    candidates.sort(key=lambda x: len(_norm_str(x.name)), reverse=True)
                    matched_item = candidates[0]

            if matched_item:
                if not _is_future_date(date):
                    if matched_item.updated is None:
                        matched_item.updated = date
                    # D3: If the changelog line has no version, show the date ONLY. Never show the item name as the version.
                    ver_desc = version.strip() if (version and version.strip()) else ""
                    entry = (date, ver_desc)
                    if entry not in matched_item.changelog:
                        matched_item.changelog.append(entry)
                else:
                    all_warnings.append(("info.txt", lno, "Ignored future date in changelog: '%s'" % date))
            else:
                unmatched_changelog.append((date, raw_text))

    catalog = Catalog(items=all_items, warnings=all_warnings, unmatched_changelog=unmatched_changelog)
    return catalog
