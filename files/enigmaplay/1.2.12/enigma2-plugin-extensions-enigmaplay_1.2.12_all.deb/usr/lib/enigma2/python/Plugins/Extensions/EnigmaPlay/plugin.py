# -*- coding: utf-8 -*-
"""
EnigmaPlay - Enigma2 Plugin Entry Point
======================================
"""

from __future__ import print_function, unicode_literals, absolute_import, division
import os
import sys

from Plugins.Plugin import PluginDescriptor

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
# Our modules are imported relative to this package (from . import catalog ...). The plugin dir is
# NOT added to sys.path: generic names like installer/settings/catalog clash with other modules
# on some images (e.g. the "installer" package of pip on OpenATV 8).

from . import catalog
try:
    from .i18n import _
except Exception:
    _ = lambda t: t
from . import ui

GLOBAL_CATALOG = None


def get_catalog():
    global GLOBAL_CATALOG
    if GLOBAL_CATALOG is None:
        data_dir = os.path.join(PLUGIN_DIR, "data")
        try:
            # 1) Fresh cache (TTL = 1 hour)
            try:
                from . import settings as ep_settings
                ttl = int(ep_settings.get("catalog_ttl"))
            except Exception:
                ttl = 3600
            if catalog.is_cache_valid(ttl=ttl):
                GLOBAL_CATALOG = catalog.load_cached_catalog()

            # 2) Download index.json from EnigmaPlay-Repo (falls back to stale cache offline)
            if GLOBAL_CATALOG is None:
                remote_cat, online, msg = catalog.fetch_remote_index()
                if remote_cat is not None:
                    GLOBAL_CATALOG = remote_cat

            # 3) Last resort: local data/ files shipped with the plugin
            if GLOBAL_CATALOG is None:
                GLOBAL_CATALOG = catalog.load(data_dir)
        except Exception as e:
            print("[EnigmaPlay] Error loading catalog: %s" % e)
            GLOBAL_CATALOG = catalog.Catalog()
    return GLOBAL_CATALOG


def main(session, start_view=None, **kwargs):
    if os.path.exists("/tmp/enigmaplay_font_test"):
        session.open(ui.FontTestScreen)
        return
    cat = get_catalog()
    session.open(ui.EnigmaPlayScreen, cat, start_view=start_view)


# ---------------------------------------------------------------------------
# Background update check: shortly after boot and then every 12 hours the
# store index is downloaded; when plugins installed on the box have a newer
# version the user gets a notification (once per set of updates).
# ---------------------------------------------------------------------------
NOTIFIED_FILE = "/etc/enigma2/enigmaplay/notified_updates.json"
FIRST_CHECK_MS = 90 * 1000
CHECK_EVERY_MS = 12 * 3600 * 1000


class UpdateNotifier(object):
    def __init__(self, session):
        import threading
        from enigma import eTimer
        self.session = session
        self.lock = threading.Lock()
        self.result = None
        self.check_timer = eTimer()
        self.check_timer.callback.append(self.start_check)
        self.poll_timer = eTimer()
        self.poll_timer.callback.append(self.poll)
        self.check_timer.start(FIRST_CHECK_MS, True)

    def start_check(self):
        import threading
        self.check_timer.start(CHECK_EVERY_MS, True)
        t = threading.Thread(target=self.worker)
        t.daemon = True
        t.start()
        self.poll_timer.start(2000, False)

    def worker(self):
        global GLOBAL_CATALOG
        found = []
        try:
            from . import account
            account.ping_daily()             # anonymous "this box is active today" for the store statistics
        except Exception as e:
            print("[EnigmaPlay] ping failed: %s" % e)
        try:
            from . import installer
            cat, online, _msg = catalog.fetch_remote_index()
            # automatic crash reports (anonymous) for plugins installed from the store
            try:
                from . import settings as ep_settings
                if cat is not None and ep_settings.get("crash_reports"):
                    from . import crashreport
                    crashreport.run(cat.items)
            except Exception as e:
                print("[EnigmaPlay] crash report failed: %s" % e)
            if cat is not None and online:
                GLOBAL_CATALOG = None          # next open uses the fresh index
                for it in cat.items:
                    try:
                        if installer.get_item_state(it)[0] == "update":
                            found.append((it.key, it.name, it.version))
                    except Exception:
                        continue
        except Exception as e:
            print("[EnigmaPlay] update check failed: %s" % e)
        with self.lock:
            self.result = found

    def poll(self):
        with self.lock:
            found, self.result = self.result, None
        if found is None:
            return
        self.poll_timer.stop()
        try:
            from . import settings as ep_settings
            if not ep_settings.get("notify_updates"):
                return
        except Exception:
            pass
        if not found:
            return
        sig = sorted("%s:%s" % (k, v) for k, _n, v in found)
        try:
            import io, json
            with io.open(NOTIFIED_FILE, "r", encoding="utf-8") as f:
                if json.load(f) == sig:
                    return                      # already told the user about exactly these
        except Exception:
            pass
        try:
            import io, json
            with io.open(NOTIFIED_FILE, "w", encoding="utf-8") as f:
                f.write(json.dumps(sig))
        except Exception:
            pass
        names = ", ".join(n for _k, n, _v in found[:4]) + ("…" if len(found) > 4 else "")
        if len(found) == 1:
            head = _("يوجد تحديث لـ %s") % names
        else:
            head = _("يوجد %d تحديثات: %s") % (len(found), names)
        text = "EnigmaPlay\n\n%s\n\n%s" % (head, _("فتح قائمة التحديثات الآن؟"))
        try:
            from Tools import Notifications
            from Screens.MessageBox import MessageBox
            Notifications.AddNotificationWithCallback(self.answer, MessageBox, text, MessageBox.TYPE_YESNO, timeout=30)
        except Exception as e:
            print("[EnigmaPlay] notification failed: %s" % e)

    def answer(self, yes):
        if yes:
            try:
                main(self.session, start_view="updates")
            except Exception as e:
                print("[EnigmaPlay] open updates failed: %s" % e)


_notifier = None


def sessionstart(reason, session=None, **kwargs):
    global _notifier
    if reason == 0 and session is not None and _notifier is None:
        try:
            _notifier = UpdateNotifier(session)
        except Exception as e:
            print("[EnigmaPlay] notifier not started: %s" % e)
        try:
            from . import remote
            remote.start(session)
        except Exception as e:
            print("[EnigmaPlay] remote install agent not started: %s" % e)
        try:
            from . import announcements
            announcements.start(session, open_store=lambda: main(session, start_view="updates"))
        except Exception as e:
            print("[EnigmaPlay] announcements not started: %s" % e)


def menu(menuid, **kwargs):
    """Entry in the image's Main Menu."""
    if menuid == "mainmenu":
        return [("EnigmaPlay", main, "enigmaplay", 45)]
    return []


def Plugins(**kwargs):
    icon_path = os.path.join(PLUGIN_DIR, "icon.png")
    if not os.path.exists(icon_path):
        icon_path = None

    return [
        PluginDescriptor(
            name="EnigmaPlay",
            description=_("متجر ومكتبة إضافات الإنيجما الشاملة (EnigmaPlay Store)"),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon=icon_path if icon_path else "icon.png",
            fnc=main
        ),
        PluginDescriptor(
            name="EnigmaPlay",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main
        ),
        PluginDescriptor(
            name="EnigmaPlay",
            description=_("متجر ومكتبة إضافات الإنيجما الشاملة (EnigmaPlay Store)"),
            where=PluginDescriptor.WHERE_MENU,
            fnc=menu
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=sessionstart
        ),
    ]


