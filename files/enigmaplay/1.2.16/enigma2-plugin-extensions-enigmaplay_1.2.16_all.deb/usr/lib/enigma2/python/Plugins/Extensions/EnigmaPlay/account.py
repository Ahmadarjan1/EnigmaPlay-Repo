# -*- coding: utf-8 -*-
"""
EnigmaPlay account client (Cloudflare Worker API).
Stdlib only; works on Python 2.7 and 3.x. Falls back to curl/wget when the
image's Python SSL cannot reach the API.
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import io
import json
import os
import subprocess
import threading
try:
    from .i18n import _
except Exception:
    _ = lambda t: t

API_BASE = "https://enigmaplay-api.ahmadalarjan2.workers.dev"
LINK_URL = API_BASE + "/link"
ACCOUNT_FILE = "/etc/enigma2/enigmaplay/account.json"
TIMEOUT = 12

_lock = threading.Lock()


# ---------------------------------------------------------------- session file
def load_session():
    try:
        with io.open(ACCOUNT_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        if d.get("token") and d.get("username"):
            return d
    except Exception:
        pass
    return None


def save_session(token, username):
    d = os.path.dirname(ACCOUNT_FILE)
    if not os.path.isdir(d):
        os.makedirs(d)
    tmp = ACCOUNT_FILE + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        f.write(json.dumps({"token": token, "username": username}, ensure_ascii=False))
    try:
        os.chmod(tmp, 0o600)
    except Exception:
        pass
    os.rename(tmp, ACCOUNT_FILE)


def clear_session():
    try:
        os.remove(ACCOUNT_FILE)
    except Exception:
        pass


def is_logged_in():
    return load_session() is not None


def username():
    s = load_session()
    return s["username"] if s else ""


# ---------------------------------------------------------------- device info
def device_info():
    info = {}
    try:
        import sys, struct
        info["python"] = "%d.%d" % sys.version_info[:2]
        info["arch"] = os.uname()[4]
    except Exception:
        pass
    try:
        from boxbranding import getMachineName, getImageDistro, getImageVersion
        info["model"] = getMachineName()
        info["image"] = "%s %s" % (getImageDistro(), getImageVersion())
    except Exception:
        for f in ("/proc/stb/info/vumodel", "/proc/stb/info/model", "/etc/hostname"):
            try:
                with open(f) as fh:
                    info["model"] = fh.read().strip()
                break
            except Exception:
                continue
    try:
        from . import __version__
        info["plugin_version"] = __version__
    except Exception:
        pass
    return info


# ---------------------------------------------------------------- HTTP
class ApiError(Exception):
    def __init__(self, status, code, message):
        Exception.__init__(self, message)
        self.status = status
        self.code = code
        self.message = message


def _http_urllib(method, url, data, headers):
    try:
        from urllib.request import Request, urlopen
        from urllib.error import HTTPError
    except ImportError:
        from urllib2 import Request, urlopen, HTTPError
    req = Request(url, data=data, headers=headers)
    req.get_method = lambda: method
    try:
        resp = urlopen(req, timeout=TIMEOUT)
        return resp.getcode(), resp.read()
    except HTTPError as e:
        return e.code, e.read()


def _http_curl(method, url, data, headers):
    cmd = ["curl", "-s", "-k", "-m", str(TIMEOUT), "-X", method, "-w", "\n%{http_code}"]
    for k, v in headers.items():
        cmd += ["-H", "%s: %s" % (k, v)]
    if data is not None:
        cmd += ["--data-binary", "@-"]
    cmd.append(url)
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, _ = p.communicate(data)
    if p.returncode != 0 or not out:
        raise IOError("curl failed (%s)" % p.returncode)
    body, _, code = out.rpartition(b"\n")
    return int(code or 0), body


def request(method, path, body=None, token=None):
    """JSON request -> dict. Raises ApiError (server said no) or IOError (no connection)."""
    url = API_BASE + path
    headers = {"Content-Type": "application/json", "User-Agent": "EnigmaPlay/1.0", "Accept": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    data = json.dumps(body).encode("utf-8") if body is not None else None
    try:
        status, raw = _http_urllib(method, url, data, headers)
    except Exception:
        status, raw = _http_curl(method, url, data, headers)   # old SSL on the image
    try:
        payload = json.loads(raw.decode("utf-8")) if raw else {}
    except Exception:
        payload = {}
    if status >= 400 or status == 0:
        raise ApiError(status, payload.get("error", "http_%s" % status),
                       payload.get("message") or _("خطأ من الخادم (%s)") % status)
    return payload


def _authed(method, path, body=None):
    s = load_session()
    if not s:
        raise ApiError(401, "unauthorized", _("غير مسجّل الدخول"))
    try:
        return request(method, path, body, token=s["token"])
    except ApiError as e:
        if e.status == 401:
            clear_session()
        raise


# ---------------------------------------------------------------- API calls
def login(user, password):
    d = request("POST", "/v1/login", {"username": user, "password": password, "device": device_info()})
    save_session(d["token"], d["user"]["username"])
    return d["user"]["username"]


def register(user, password):
    d = request("POST", "/v1/register", {"username": user, "password": password, "device": device_info()})
    save_session(d["token"], d["user"]["username"])
    return d["user"]["username"]


def logout():
    try:
        _authed("POST", "/v1/logout")
    except Exception:
        pass
    clear_session()
    clear_avatar()


def pair_start():
    return request("POST", "/v1/pair/start", {"device": device_info()})


def pair_poll(poll):
    """-> ("pending"|"expired"|"done", username)"""
    d = request("GET", "/v1/pair/poll?poll=" + poll)
    if d.get("status") == "done" and d.get("token"):
        save_session(d["token"], d["user"]["username"])
        return "done", d["user"]["username"]
    return d.get("status", "pending"), ""


def get_plugins():
    return _authed("GET", "/v1/me").get("plugins", [])


def push_plugins(items):
    """items: [{"id", "name", "version"}] -> server list after merge"""
    if not items:
        return get_plugins()
    return _authed("PUT", "/v1/plugins", {"plugins": items}).get("plugins", [])


def remove_plugin(plugin_id):
    return _authed("DELETE", "/v1/plugins/" + plugin_id)


# ---------------------------------------------------------------- downloads & ratings
DEVICE_ID_FILE = "/etc/enigma2/enigmaplay/device_id"
STATS_FILE = "/etc/enigma2/enigmaplay/stats.json"
STATS_TTL = 30 * 60


def device_id():
    """Random, anonymous id of this box (used only to count each install once)."""
    try:
        with io.open(DEVICE_ID_FILE, "r", encoding="utf-8") as f:
            v = f.read().strip()
        if 16 <= len(v) <= 64:
            return v
    except Exception:
        pass
    import binascii
    v = binascii.hexlify(os.urandom(16)).decode("ascii")
    try:
        d = os.path.dirname(DEVICE_ID_FILE)
        if not os.path.isdir(d):
            os.makedirs(d)
        with io.open(DEVICE_ID_FILE, "w", encoding="utf-8") as f:
            f.write(v)
    except Exception:
        pass
    return v


def _stats_log(msg):
    try:
        import time
        with io.open("/tmp/enigmaplay_stats.log", "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (time.strftime("%H:%M:%S"), msg))
    except Exception:
        pass


def report_install(plugin_id):
    try:
        d = request("POST", "/v1/stats/install", {"id": plugin_id, "device": device_id()})
        _stats_log("install %s -> %s" % (plugin_id, d))
    except Exception as e:
        _stats_log("install %s FAILED: %r" % (plugin_id, e))


def report_install_async(plugin_id):
    t = threading.Thread(target=report_install, args=(plugin_id,))
    t.daemon = True
    t.start()


def cached_stats():
    """(stats dict, age seconds) from the local cache; ({}, None) when missing."""
    try:
        import time
        with io.open(STATS_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d.get("stats", {}), time.time() - d.get("saved", 0)
    except Exception:
        return {}, None


def fetch_stats():
    """{id: {installs, rating, votes}} from the server (saved to the cache)."""
    import time
    d = request("GET", "/v1/stats")
    stats = d.get("stats", {}) or {}
    mine = {}
    if is_logged_in():
        try:
            mine = _authed("GET", "/v1/ratings/mine").get("ratings", {}) or {}
        except Exception:
            mine = cached_my_ratings()
    try:
        tmp = STATS_FILE + ".tmp"
        with io.open(tmp, "w", encoding="utf-8") as f:
            f.write(json.dumps({"saved": time.time(), "stats": stats, "mine": mine}, ensure_ascii=False))
        os.rename(tmp, STATS_FILE)
    except Exception:
        pass
    return stats


def cached_my_ratings():
    try:
        with io.open(STATS_FILE, "r", encoding="utf-8") as f:
            return json.load(f).get("mine", {}) or {}
    except Exception:
        return {}


def rate(plugin_id, stars):
    """-> {rating, votes}; updates the local cache."""
    d = _authed("POST", "/v1/rate", {"id": plugin_id, "stars": int(stars)})
    try:
        with io.open(STATS_FILE, "r", encoding="utf-8") as f:
            c = json.load(f)
    except Exception:
        c = {"saved": 0, "stats": {}, "mine": {}}
    c.setdefault("stats", {}).setdefault(plugin_id, {"installs": 0})
    c["stats"][plugin_id]["rating"] = d.get("rating", 0)
    c["stats"][plugin_id]["votes"] = d.get("votes", 0)
    c.setdefault("mine", {})[plugin_id] = int(stars)
    try:
        with io.open(STATS_FILE, "w", encoding="utf-8") as f:
            f.write(json.dumps(c, ensure_ascii=False))
    except Exception:
        pass
    return d


# ---------------------------------------------------------------- settings backups
def list_backups():
    return _authed("GET", "/v1/backup").get("backups", [])


def get_backup(plugin_id):
    return _authed("GET", "/v1/backup/" + plugin_id).get("data")


def put_backup(plugin_id, data):
    return _authed("PUT", "/v1/backup/" + plugin_id, {"data": data})


# ---------------------------------------------------------------- profile picture
AVATAR_FILE = "/etc/enigma2/enigmaplay/avatar.jpg"
AVATAR_VER_FILE = "/etc/enigma2/enigmaplay/avatar.ver"


def avatar_file():
    """Local copy of the user's profile picture, or None."""
    if load_session() and os.path.isfile(AVATAR_FILE) and os.path.getsize(AVATAR_FILE) > 0:
        return AVATAR_FILE
    return None


def avatar_version():
    try:
        with io.open(AVATAR_VER_FILE, "r", encoding="utf-8") as f:
            return int(f.read().strip() or 0)
    except Exception:
        return 0


def clear_avatar():
    for p in (AVATAR_FILE, AVATAR_VER_FILE):
        try:
            os.remove(p)
        except Exception:
            pass


def sync_avatar():
    """Download the profile picture when it changed on the account. Returns True if it changed."""
    s = load_session()
    if not s:
        return False
    ver = int((_authed("GET", "/v1/me").get("user") or {}).get("avatar") or 0)
    if ver == avatar_version() and (ver == 0 or os.path.isfile(AVATAR_FILE)):
        return False
    if ver == 0:
        clear_avatar()
        return True
    try:
        from urllib.parse import quote
    except ImportError:
        from urllib import quote
    url = "%s/v1/avatar/%s?v=%d" % (API_BASE, quote(s["username"]), ver)
    try:
        from urllib.request import Request, urlopen
        data = urlopen(Request(url, headers={"User-Agent": "EnigmaPlay/1.0"}), timeout=TIMEOUT).read(300 * 1024)
    except Exception:
        p = subprocess.Popen(["curl", "-s", "-k", "-f", "-m", str(TIMEOUT), url], stdout=subprocess.PIPE)
        data, _err = p.communicate()
    if not data or data[:2] not in (b"\xff\xd8", b"\x89P"):
        return False
    tmp = AVATAR_FILE + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    os.rename(tmp, AVATAR_FILE)
    with io.open(AVATAR_VER_FILE, "w", encoding="utf-8") as f:
        f.write(str(ver))
    return True


# ---------------------------------------------------------------- daily usage ping
PING_FILE = "/etc/enigma2/enigmaplay/last_ping"


def ping_daily():
    """Once a day: tell the store this box is active (anonymous id, model, image, python, version).
    Used only for the store statistics; no IP address is stored on the server."""
    import time
    today = time.strftime("%Y-%m-%d", time.gmtime())
    try:
        with io.open(PING_FILE, "r", encoding="utf-8") as f:
            if f.read().strip() == today:
                return False
    except Exception:
        pass
    info = device_info()
    request("POST", "/v1/ping", {
        "device": device_id(), "model": info.get("model", ""), "image": info.get("image", ""),
        "python": info.get("python", ""), "plugin_version": info.get("plugin_version", ""),
    })
    try:
        with io.open(PING_FILE, "w", encoding="utf-8") as f:
            f.write(today)
    except Exception:
        pass
    return True
