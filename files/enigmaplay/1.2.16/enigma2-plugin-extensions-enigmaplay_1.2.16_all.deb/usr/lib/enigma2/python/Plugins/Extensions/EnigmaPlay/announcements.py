# -*- coding: utf-8 -*-
"""
Messages from the store (sent from the admin console) shown on the TV.

The box asks GET /v1/announcements a little after boot, then every few hours, and also when the
store opens or a wake-up arrives from the phone channel. Each message is shown once per box:
the server remembers it after POST /v1/announcements/<id>/seen and we also keep the ids locally.
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import io
import json
import threading
import time

from . import account
try:
    from .i18n import _
except Exception:
    _ = lambda t: t

SEEN_FILE = "/etc/enigma2/enigmaplay/seen_announcements.json"
FIRST_CHECK_MS = 120 * 1000
CHECK_EVERY_MS = 3 * 3600 * 1000
MIN_GAP = 60                          # seconds between two checks
AGENT = None

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote


def _log(msg):
    try:
        with io.open("/tmp/enigmaplay_announce.log", "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (time.strftime("%H:%M:%S"), msg))
    except Exception:
        pass


def enabled():
    try:
        from . import settings
        return bool(settings.get("show_announcements"))
    except Exception:
        return True


def _load_seen():
    try:
        with io.open(SEEN_FILE, "r", encoding="utf-8") as f:
            return [int(x) for x in json.load(f)]
    except Exception:
        return []


def _save_seen(ids):
    try:
        with io.open(SEEN_FILE, "w", encoding="utf-8") as f:
            f.write(json.dumps(sorted(set(ids))[-300:]))
    except Exception:
        pass


def fetch():
    """List of new messages for this box (runs in a worker thread)."""
    info = account.device_info()
    path = "/v1/announcements?device=%s&image=%s&model=%s&v=%s" % (
        quote(account.device_id()), quote(info.get("image", "") or ""), quote(info.get("model", "") or ""),
        quote(info.get("plugin_version", "") or ""))
    s = account.load_session()
    try:
        d = account.request("GET", path, token=s["token"] if s else None)
    except account.ApiError as e:
        if e.status != 401 or not s:
            raise
        d = account.request("GET", path)             # expired login: still get the public ones
    seen = set(_load_seen())
    return [a for a in d.get("announcements", []) if int(a.get("id", 0)) not in seen]


def mark_seen(ann_id):
    _save_seen(_load_seen() + [int(ann_id)])

    def run():
        try:
            account.request("POST", "/v1/announcements/%d/seen" % int(ann_id), {"device": account.device_id()})
        except Exception as e:
            _log("seen failed: %r" % e)
    t = threading.Thread(target=run)
    t.daemon = True
    t.start()


def poke():
    if AGENT is not None:
        AGENT.request_check()


class Announcer(object):
    def __init__(self, session, open_store=None):
        from enigma import eTimer
        self.session = session
        self.open_store = open_store
        self.lock = threading.Lock()
        self.result = None
        self.busy = False
        self.showing = False
        self.queue = []
        self.last_check = 0
        self.want = False
        self.timer = eTimer()
        self.timer.callback.append(self.start_check)
        self.timer.start(FIRST_CHECK_MS, True)
        self.poll_timer = eTimer()
        self.poll_timer.callback.append(self.poll)
        self.poll_timer.start(3000, False)

    def request_check(self):
        with self.lock:
            self.want = True

    def start_check(self):
        self.timer.start(CHECK_EVERY_MS, True)
        self.request_check()

    def worker(self):
        try:
            res = fetch()
        except Exception as e:
            _log("fetch failed: %r" % e)
            res = []
        with self.lock:
            self.result = res

    def poll(self):
        with self.lock:
            res, self.result = self.result, None
            want = self.want
        if res is not None:
            self.busy = False
            known = set(int(a["id"]) for a in self.queue)
            self.queue += [a for a in res if int(a["id"]) not in known]
            if res:
                _log("received %d message(s)" % len(res))
        if want and not self.busy and enabled() and time.time() - self.last_check >= MIN_GAP:
            with self.lock:
                self.want = False
            self.busy = True
            self.last_check = time.time()
            t = threading.Thread(target=self.worker)
            t.daemon = True
            t.start()
        elif want and not enabled():
            with self.lock:
                self.want = False
        if self.queue and not self.showing:
            self.show(self.queue.pop(0))

    def show(self, a):
        try:
            from Tools import Notifications
            from Screens.MessageBox import MessageBox
        except Exception as e:
            _log("no notifications: %r" % e)
            return
        level = a.get("level", "info")
        text = "  EnigmaPlay - %s  \n\n%s" % (a.get("title", ""), a.get("body", ""))
        self.showing = True
        ann_id = a.get("id")

        def done(answer=None):
            self.showing = False
            mark_seen(ann_id)
            if level == "update" and answer and self.open_store:
                try:
                    self.open_store()
                except Exception as e:
                    _log("open store failed: %r" % e)
        try:
            if level == "update":
                text += "\n\n" + _("فتح المتجر الآن؟")
                Notifications.AddNotificationWithCallback(done, MessageBox, text, MessageBox.TYPE_YESNO)
            else:
                kind = MessageBox.TYPE_WARNING if level == "warning" else MessageBox.TYPE_INFO
                Notifications.AddNotificationWithCallback(done, MessageBox, text, kind)
        except Exception as e:
            self.showing = False
            _log("show failed: %r" % e)


def start(session, open_store=None):
    global AGENT
    if AGENT is None:
        AGENT = Announcer(session, open_store)
    return AGENT
