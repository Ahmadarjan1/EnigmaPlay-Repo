# -*- coding: utf-8 -*-
"""
EnigmaPlay Installer Engine
Handles script downloading, background execution, log polling, and registry management.
"""

from __future__ import print_function, unicode_literals, absolute_import, division
import os
import sys
import time
import json
import re
import hashlib
import subprocess
try:
    from .i18n import _
except Exception:
    _ = lambda t: t
from datetime import datetime

try:
    from urllib.parse import urlparse
except ImportError:
    from urlparse import urlparse

try:
    import shlex
    quote = shlex.quote
except (ImportError, AttributeError):
    import pipes
    quote = pipes.quote

# Enigma2 imports (guarded for non-E2 environments)
try:
    from enigma import eConsoleAppContainer, eTimer
    from Components.PluginComponent import plugins
    from Plugins.Plugin import PluginDescriptor
    HAS_E2 = True
except ImportError:
    HAS_E2 = False

REGISTRY_DIR = "/etc/enigma2/enigmaplay"
INSTALLED_FILE = os.path.join(REGISTRY_DIR, "installed.json")
PENDING_FILE = os.path.join(REGISTRY_DIR, "pending.json")
MAIN_LOG_FILE = "/tmp/enigmaplay.log"
MAX_LOG_SIZE = 256 * 1024  # Cap log at 256 KB

WHITELISTED_DOMAINS = ("raw.githubusercontent.com", "github.com",
                       "objects.githubusercontent.com", "release-assets.githubusercontent.com",
                       "gitlab.com")
INVALID_URL_CHARS_RE = re.compile(r'[\s"\'`$;|&<>\\\n\r]')

DEBUG = False
DEBUG_OVERRIDE_URL = None  # Can override url for testing


def get_work_dir():
    """Create secure work directory with chmod 0700 permissions."""
    for base in ("/etc/enigma2/enigmaplay/work", "/tmp/enigmaplay/work"):
        try:
            if not os.path.exists(base):
                os.makedirs(base, mode=0o700, exist_ok=True)
            try:
                os.chmod(base, 0o700)
            except Exception:
                pass
            test_f = os.path.join(base, ".test_write")
            with open(test_f, "w") as f:
                f.write("ok")
            os.remove(test_f)
            return base
        except Exception:
            continue
    return "/tmp/enigmaplay/work"


WORK_DIR = get_work_dir()


def append_to_main_log(msg):
    """Append message to /tmp/enigmaplay.log and cap log size at ~256KB by truncating oldest entries."""
    try:
        if os.path.exists(MAIN_LOG_FILE) and os.path.getsize(MAIN_LOG_FILE) > MAX_LOG_SIZE:
            with open(MAIN_LOG_FILE, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            keep = content[-131072:]  # Keep newest ~128KB
            first_nl = keep.find("\n")
            if first_nl != -1:
                keep = keep[first_nl + 1:]
            with open(MAIN_LOG_FILE, "w", encoding="utf-8") as f:
                f.write(_("[سجل مدور - تم اقتطاع السجلات الأقدم لحفظ المساحة]\n") + keep)

        with open(MAIN_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(msg + "\n")
    except Exception:
        pass


def log_debug(msg):
    try:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = "[%s] %s" % (timestamp, msg)
        append_to_main_log(entry)
    except Exception:
        pass


def log_security_event(event_type, msg):
    """Log security-related events and rejections to /tmp/enigmaplay.log."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    entry = "[%s] [SECURITY_ALERT] [%s] %s" % (timestamp, event_type, msg)
    log_debug(entry)


def is_url_whitelisted(url):
    """
    Allow only whitelisted domains for script URLs:
    - Reject URLs containing dangerous characters (command injection prevention)
    - Require scheme == 'https'
    - Local paths and file:// allowed ONLY when DEBUG is True
    - Exact hostname match in WHITELISTED_DOMAINS
    """
    if not url:
        return False

    # 1. Reject command injection characters: whitespace, quotes, backticks, $, ;, |, &, <, >, \, newline
    if INVALID_URL_CHARS_RE.search(url):
        log_security_event("REJECT_INJECTION", "Rejected URL with dangerous/illegal characters: %r" % url)
        return False

    # 2. Local paths and file:// allowed ONLY when DEBUG is True
    if url.startswith("/") or url.startswith("file://"):
        if DEBUG:
            return True
        log_security_event("REJECT_LOCAL_URL", "Local file path rejected (DEBUG is False): %s" % url)
        return False

    # 3. Parse URL and verify scheme and hostname
    try:
        parsed = urlparse(url)
        scheme = (parsed.scheme or "").lower()
        if scheme != "https":
            log_security_event("REJECT_NON_HTTPS", "Rejected non-HTTPS URL scheme (%s): %s" % (scheme, url))
            return False

        hostname = (parsed.hostname or "").lower()
        if hostname in WHITELISTED_DOMAINS:
            return True

        log_security_event("REJECT_UNTRUSTED_HOST", "Hostname not in whitelist (%s): %s" % (hostname, url))
        return False
    except Exception as e:
        log_security_event("REJECT_PARSE_FAIL", "URL parsing failed: %s (%s)" % (url, e))
        return False


def calc_file_sha256(filepath):
    """Compute sha256 checksum of a file."""
    if not os.path.isfile(filepath):
        return None
    h = hashlib.sha256()
    try:
        with open(filepath, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest().lower()
    except Exception as e:
        log_debug("Failed to calculate SHA-256 for %s: %s" % (filepath, e))
        return None


def get_safe_id(item_key):
    return re.sub(r'[^a-zA-Z0-9_-]', '_', item_key)


def load_installed_registry():
    try:
        if os.path.exists(INSTALLED_FILE):
            with open(INSTALLED_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as e:
        log_debug("Failed to load installed registry: %s" % e)
    return {}


def save_installed_record(item_key, item_name, version, rc=0):
    try:
        os.makedirs(REGISTRY_DIR, exist_ok=True)
        registry = load_installed_registry()
        today = datetime.now().strftime("%d.%m.%Y")
        registry[item_key] = {
            "name": item_name,
            "version": version or "",
            "date": today,
            "rc": rc
        }
        with open(INSTALLED_FILE, "w", encoding="utf-8") as f:
            json.dump(registry, f, indent=2, ensure_ascii=False)
        log_debug("Saved record for %s (v%s) to %s" % (item_key, version, INSTALLED_FILE))
        return True
    except Exception as e:
        log_debug("Failed to save installed record: %s" % e)
        return False


HISTORY_FILE = os.path.join(REGISTRY_DIR, "history.json")
MAX_HISTORY = 200


def load_history():
    try:
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return []


def add_history(item, action, rc, version=""):
    try:
        os.makedirs(REGISTRY_DIR, exist_ok=True)
        hist = load_history()
        hist.insert(0, {
            "time": int(time.time()),
            "id": getattr(item, "key", ""),
            "name": getattr(item, "name", ""),
            "version": version or getattr(item, "version", "") or "",
            "action": action,   # install | update | remove
            "rc": rc,
        })
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(hist[:MAX_HISTORY], f, ensure_ascii=False, indent=1)
    except Exception as e:
        log_debug("history write failed: %s" % e)


def remove_installed_record(item_key):
    try:
        reg = load_installed_registry()
        if item_key in reg:
            del reg[item_key]
            with open(INSTALLED_FILE, "w", encoding="utf-8") as f:
                json.dump(reg, f, indent=2, ensure_ascii=False)
    except Exception as e:
        log_debug("Failed to remove installed record: %s" % e)


def load_pending():
    try:
        if os.path.exists(PENDING_FILE):
            with open(PENDING_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as e:
        log_debug("Failed to load pending.json: %s" % e)
    return None


def write_pending(data):
    try:
        os.makedirs(REGISTRY_DIR, exist_ok=True)
        with open(PENDING_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        log_debug("Wrote pending job for %s" % data.get("id"))
    except Exception as e:
        log_debug("Failed to write pending.json: %s" % e)


def clear_pending():
    try:
        if os.path.exists(PENDING_FILE):
            os.remove(PENDING_FILE)
            log_debug("Cleared pending.json")
    except Exception as e:
        log_debug("Failed to remove pending.json: %s" % e)


def is_pid_alive(pid):
    if not pid or pid <= 0:
        return False
    try:
        if os.path.exists("/proc/%d" % pid):
            return True
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def find_matching_plugin(item_name, item=None):
    """The installed PluginDescriptor (plugins menu) that belongs to a store item.
    1) by the plugin folder installed by the item's package, 2) exact name, 3) closest name."""
    if not HAS_E2:
        return None
    try:
        candidates = []
        for where in (PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU):
            plist = plugins.getPlugins(where)
            if plist:
                candidates.extend(plist)

        if item is not None:
            pkg = find_installed_package(item)[0]
            try:
                from .backup import _plugin_dirs
                dirs = set(d.lower() for d in _plugin_dirs(pkg))
            except Exception:
                dirs = set()
            if dirs:
                for p in candidates:
                    pdir = os.path.basename((getattr(p, "path", "") or "").rstrip("/")).lower()
                    if pdir and pdir in dirs:
                        return p

        clean_target = re.sub(r'[^a-z0-9]', '', (item_name or "").lower())
        if not clean_target:
            return None
        best, best_len = None, 0
        for p in candidates:
            clean_p = re.sub(r'[^a-z0-9]', '', (getattr(p, "name", "") or "").lower())
            if not clean_p:
                continue
            if clean_p == clean_target:
                return p
            if clean_target in clean_p or clean_p in clean_target:
                # never let the store itself match another item whose name only contains "EnigmaPlay"
                if clean_p == "enigmaplay" and clean_target != "enigmaplay":
                    continue
                if len(clean_p) > best_len:
                    best, best_len = p, len(clean_p)
        return best
    except Exception as e:
        log_debug("find_matching_plugin error: %s" % e)
    return None


# ---------------------------------------------------------------------------
# INSTALLED-PACKAGE DETECTION (reads the image's opkg / dpkg database)
# ---------------------------------------------------------------------------
PKG_STATUS_FILES = (
    "/var/lib/opkg/status",
    "/usr/lib/opkg/status",
    "/var/lib/dpkg/status",
)
_SYS_PKG_CACHE = {"key": None, "pkgs": {}}


def load_system_packages():
    """{package_name: version} for every package installed on the image (cached by file mtime)."""
    files = [f for f in PKG_STATUS_FILES if os.path.isfile(f)]
    try:
        key = tuple((f, os.path.getmtime(f)) for f in files)
    except Exception:
        key = None
    if key is not None and key == _SYS_PKG_CACHE["key"]:
        return _SYS_PKG_CACHE["pkgs"]
    pkgs = {}
    for f in files:
        try:
            with open(f, "r", encoding="utf-8", errors="replace") as fh:
                name = ver = status = None
                for line in fh.read().splitlines() + [""]:
                    if not line.strip():
                        if name and status and "installed" in status and "not-installed" not in status \
                                and "deinstall" not in status and "config-files" not in status:
                            pkgs[name] = ver or ""
                        name = ver = status = None
                    elif line.startswith("Package:"):
                        name = line.split(":", 1)[1].strip()
                    elif line.startswith("Version:"):
                        ver = line.split(":", 1)[1].strip()
                    elif line.startswith("Status:"):
                        status = line.split(":", 1)[1].strip()
        except Exception as e:
            log_debug("Failed to read %s: %s" % (f, e))
    _SYS_PKG_CACHE["key"] = key
    _SYS_PKG_CACHE["pkgs"] = pkgs
    return pkgs


def version_tuple(v):
    """'1:2.5.1-r0' / 'v2.5.1 Beta' / '2.5.1+git123' -> (2, 5, 1). Non-numeric -> ()."""
    if not v:
        return ()
    v = str(v).strip().lower()
    if ":" in v.split(".")[0]:
        v = v.split(":", 1)[1]
    v = v.lstrip("v")
    v = re.split(r"[-+~ _]", v, 1)[0]
    return tuple(int(x) for x in re.findall(r"\d+", v)[:4])


def compare_versions(a, b):
    """-1 if a<b, 0 if equal/unknown, 1 if a>b."""
    ta, tb = version_tuple(a), version_tuple(b)
    if not ta or not tb:
        return 0
    n = max(len(ta), len(tb))
    ta += (0,) * (n - len(ta))
    tb += (0,) * (n - len(tb))
    return (ta > tb) - (ta < tb)


def _norm(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def find_installed_package(item):
    """(package_name, installed_version) of the item on this image, or (None, None)."""
    pkgs = load_system_packages()
    pkg = getattr(item, "package", None)
    if pkg and pkg in pkgs:
        return pkg, pkgs[pkg]
    # Heuristic for items without a "package" field: enigma2-plugin-<type>-<name>
    target = _norm(getattr(item, "name", ""))
    if len(target) >= 4:
        for name, ver in pkgs.items():
            if not name.startswith("enigma2-plugin-"):
                continue
            tail = _norm(name.split("-", 3)[-1])
            if tail == target:
                return name, ver
    return None, None


_STATE_LOGGED = set()


def _log_state_once(item, pkg, inst_v):
    key = getattr(item, "key", "")
    if key in _STATE_LOGGED:
        return
    _STATE_LOGGED.add(key)
    files = [f for f in PKG_STATUS_FILES if os.path.isfile(f)]
    log_debug("[state] %s: repo_ver=%r package=%r -> found=%r installed_ver=%r (status files: %s, %d pkgs)" % (
        key, getattr(item, "version", ""), getattr(item, "package", None), pkg, inst_v,
        ",".join(files) or "none", len(load_system_packages())))


def get_item_state(item):
    """
    ("none" | "installed" | "update", installed_version_or_empty)
    Order: image package DB -> EnigmaPlay registry -> plugin present in the menu.
    """
    pkg, inst_v = find_installed_package(item)
    _log_state_once(item, pkg, inst_v)
    if pkg:
        if compare_versions(getattr(item, "version", ""), inst_v) > 0:
            return "update", inst_v
        return "installed", inst_v
    reg = load_installed_registry()
    key = getattr(item, "key", None)
    if key in reg:
        inst_v = reg[key].get("version", "")
        if inst_v and compare_versions(getattr(item, "version", ""), inst_v) > 0:
            return "update", inst_v
        return "installed", inst_v
    if find_matching_plugin(getattr(item, "name", "")):
        return "installed", ""
    return "none", ""


# ---------------------------------------------------------------------------
# SYSTEM DETECTION & DOWNLOAD SELECTION (ipk / deb / sh, python + CPU aware)
# ---------------------------------------------------------------------------
_SYSINFO = {}


def get_system_info():
    """{'py': '3.12', 'py_major': '3', 'arch': 'arm|aarch64|mipsel|x86', 'pm': 'opkg|dpkg|None'}"""
    if _SYSINFO:
        return _SYSINFO
    import struct
    py = "%d.%d" % sys.version_info[:2]
    bits = struct.calcsize("P") * 8
    try:
        machine = os.uname()[4].lower()
    except Exception:
        machine = ""
    if machine in ("aarch64", "arm64"):
        arch = "aarch64" if bits == 64 else "arm"   # 64-bit kernel with 32-bit userland -> arm
    elif machine.startswith("arm"):
        arch = "arm"
    elif machine.startswith("mips"):
        arch = "mipsel"
    elif machine in ("x86_64", "amd64", "i386", "i486", "i586", "i686"):
        arch = "x86"
    else:
        arch = machine or "unknown"
    pm = None
    for path in ("/usr/bin/opkg", "/bin/opkg", "/usr/sbin/opkg"):
        if os.path.exists(path):
            pm = "opkg"
            break
    if pm is None and (os.path.exists("/usr/bin/dpkg") or os.path.exists("/usr/bin/apt-get")):
        pm = "dpkg"
    _SYSINFO.update({"py": py, "py_major": py.split(".")[0], "arch": arch, "bits": bits, "pm": pm})
    log_debug("[system] python=%s arch=%s (%s, %d-bit) package manager=%s" % (py, arch, machine, bits, pm))
    return _SYSINFO


_ARCH_ALIASES = {
    "arm": ("arm", "armv7", "armv7a", "armv7ahf", "armhf", "cortexa15hf", "cortexa9hf", "cortexa7hf", "arm32"),
    "aarch64": ("aarch64", "arm64", "armv8"),
    "mipsel": ("mipsel", "mips", "mips32el", "mips32"),
    "x86": ("x86", "x86_64", "amd64", "i686", "i386"),
}


def _arch_ok(dl_arch, sys_arch):
    if not dl_arch:
        return True
    a = str(dl_arch).lower()
    if a in ("all", "any", "noarch"):
        return True
    for alias in _ARCH_ALIASES.get(sys_arch, (sys_arch,)):
        if a == alias or a.startswith(alias):
            return True
    return False


def _python_ok(dl_py, si):
    if not dl_py:
        return True
    vals = dl_py if isinstance(dl_py, (list, tuple)) else [dl_py]
    for v in vals:
        v = str(v)
        if v == si["py"] or v == si["py_major"]:
            return True
    return False


def select_download(item):
    """First compatible entry of item.downloads (order = author's preference), or None."""
    si = get_system_info()
    downloads = list(getattr(item, "downloads", None) or [])
    if not downloads:
        url = getattr(item, "url", "")
        return {"type": "sh", "url": url, "sha256": getattr(item, "sha256", None)} if url else None
    for d in downloads:
        t = d.get("type")
        if t == "ipk" and si["pm"] != "opkg":
            continue
        if t == "deb" and si["pm"] != "dpkg":
            continue
        if t not in ("ipk", "deb", "sh"):
            continue
        if not _python_ok(d.get("python"), si) or not _arch_ok(d.get("arch"), si["arch"]):
            continue
        return d
    return None


def is_item_compatible(item):
    si = get_system_info()
    pys = [str(x) for x in (getattr(item, "python", None) or ["2", "3"])]
    if si["py_major"] not in pys and si["py"] not in pys:
        return False
    return select_download(item) is not None


def filter_compatible(catalog_instance):
    """Remove items that cannot be installed on this box (python / CPU / package manager)."""
    try:
        before = len(catalog_instance.items)
        catalog_instance.items = [it for it in catalog_instance.items if is_item_compatible(it)]
        catalog_instance._reindex()
        hidden = before - len(catalog_instance.items)
        if hidden:
            log_debug("[compat] hidden %d incompatible item(s)" % hidden)
    except Exception as e:
        log_debug("filter_compatible error: %s" % e)
    return catalog_instance


class InstallJob(object):
    """Represents the single active installation or download job."""
    def __init__(self, item, on_log_update=None, on_progress=None, on_finish=None, on_unverified=None, action="install"):
        self.item = item
        self.action = action            # "install" | "update" | "remove"
        self.safe_id = get_safe_id(item.key)
        self.work_dir = get_work_dir()
        self.script_path = os.path.join(self.work_dir, "%s.sh" % self.safe_id)
        self.log_path = os.path.join(self.work_dir, "%s.log" % self.safe_id)
        self.rc_path = os.path.join(self.work_dir, "%s.rc" % self.safe_id)
        self.download = select_download(item)
        self.pkg_type = (self.download or {}).get("type", "sh")
        self.expected_sha = (self.download or {}).get("sha256")
        self.wrapper_ready = False
        if self.pkg_type in ("ipk", "deb"):
            # package is downloaded here; a small wrapper .sh is generated after verification
            self.script_path = os.path.join(self.work_dir, "%s.%s" % (self.safe_id, self.pkg_type))
        self.phase = "idle"  # "download", "unverified_prompt", "install", "finished", "error", "cancelled"
        self.percent = 0
        self.pid = None
        self.rc = None
        self.downloaded_sha = None
        self.on_log_update = on_log_update
        self.on_progress = on_progress
        self.on_finish = on_finish
        self.on_unverified = on_unverified
        self.log_lines = []
        self.cancelled = False
        self.poll_timer = None
        self.wget_container = None
        self.e2_timer = None

    def start(self):
        """Convenience entry point to begin installation lifecycle."""
        if self.action == "remove":
            self._start_remove()
        else:
            self.start_download()

    def _start_remove(self):
        """Uninstall through the image's package manager (only for packages we can identify)."""
        pkg, _ver = find_installed_package(self.item)
        if not pkg or not re.match(r"^[A-Za-z0-9.+_-]+$", pkg):
            self.phase = "error"
            if self.on_finish:
                self.on_finish(self, -7, _("تعذر تحديد حزمة هذا البلجن لإزالتها"))
            return
        for p in (self.log_path, self.rc_path):
            try:
                os.remove(p)
            except Exception:
                pass
        q = quote(pkg)
        pm = get_system_info()["pm"]
        if pm == "dpkg":
            body = ('export DEBIAN_FRONTEND=noninteractive\n'
                    'apt-get remove -y %(q)s || dpkg -r %(q)s\n'
                    'if dpkg-query -W -f=\'${Status}\' %(q)s 2>/dev/null | grep -q "install ok installed"; then RC=1; else RC=0; fi\n') % {"q": q}
        else:
            body = ('opkg remove --force-depends %(q)s\n'
                    'if opkg status %(q)s 2>/dev/null | grep -q "^Status:.* installed"; then RC=1; else RC=0; fi\n') % {"q": q}
        wrapper = os.path.join(self.work_dir, "%s_remove.sh" % self.safe_id)
        with open(wrapper, "w") as f:
            f.write("#!/bin/sh\n# generated by EnigmaPlay\necho \"Removing %s ...\"\n%sexit $RC\n" % (pkg, body))
        os.chmod(wrapper, 0o700)
        self.script_path = wrapper
        self.pkg_type = "remove"
        self.downloaded_sha = calc_file_sha256(wrapper)
        self.wrapper_ready = True
        self.start_install()

    def get_last_log_lines(self, count=6):
        try:
            if os.path.exists(self.log_path):
                with open(self.log_path, "r", encoding="utf-8", errors="replace") as f:
                    lines = [l.rstrip() for l in f.readlines() if l.strip()]
                    return lines[-count:]
        except Exception:
            pass
        return self.log_lines[-count:] if self.log_lines else []

    def start_download(self):
        self.phase = "download"
        self.cancelled = False
        self.work_dir = get_work_dir()

        # Clear old files
        for p in (self.script_path, self.log_path, self.rc_path):
            if os.path.exists(p):
                try:
                    os.remove(p)
                except Exception:
                    pass

        if not self.download:
            self.phase = "error"
            si = get_system_info()
            err_msg = _("هذا البلجن غير متوافق مع جهازك (Python %s / %s).") % (si["py"], si["arch"])
            try:
                with open(self.log_path, "w", encoding="utf-8") as f:
                    f.write(err_msg + "\n")
            except Exception:
                pass
            if self.on_finish:
                self.on_finish(self, -5, err_msg)
            return
        url = self.download.get("url") or self.item.url
        log_debug("Selected %s download for %s: %s" % (self.pkg_type, self.item.key, url))
        # Check debug override file
        debug_file = os.path.join(self.work_dir, "debug_url.txt")
        if os.path.exists(debug_file):
            try:
                with open(debug_file, "r", encoding="utf-8") as f:
                    ov = f.read().strip()
                if ov:
                    url = ov
            except Exception:
                pass
        elif DEBUG and DEBUG_OVERRIDE_URL:
            url = DEBUG_OVERRIDE_URL

        # PHASE 1 & 1.1: Security & Whitelist check
        if not is_url_whitelisted(url):
            self.phase = "error"
            err_msg = _("تم رفض الرابط: النطاق غير موثوق به أو يحتوي على محارف غير صالحة.")
            log_security_event("REJECT_DOWNLOAD", "Download blocked for item '%s': %r" % (self.item.key, url))
            try:
                with open(self.log_path, "w", encoding="utf-8") as f:
                    f.write(_("خطأ أمني:\nرابط السكربت غير مصرح به أو يحتوي على محارف غير آمنة.\n%s\n") % url)
            except Exception:
                pass
            if self.on_finish:
                self.on_finish(self, -3, err_msg)
            return

        log_debug("Starting download for %s from %s" % (self.item.key, url))

        # Check if local file in debug
        if url.startswith("/") or url.startswith("file://"):
            local_src = url.replace("file://", "")
            try:
                import shutil
                shutil.copyfile(local_src, self.script_path)
                os.chmod(self.script_path, 0o700)
                self.phase = "downloaded"
                self._on_download_complete()
                return
            except Exception as e:
                self._handle_download_failed("Local copy error: %s" % e)
                return

        # Redirect control:
        # raw.githubusercontent.com serves raw content directly and does not redirect: use --max-redirect=0
        # github.com might redirect to raw.githubusercontent.com: allow at most 1 redirect
        try:
            h = (urlparse(url).hostname or "").lower()
        except Exception:
            h = ""
        # GitHub Releases: github.com -> objects/release-assets.githubusercontent.com (2-3 hops)
        max_redirect = "0" if "raw.githubusercontent.com" in h else "5"

        if HAS_E2:
            # Enforce shlex.quote on all interpolated arguments
            # GNU wget first; then BusyBox wget (EGAMI & co. reject the long options), curl and
            # finally Python itself, so the download works whatever tools the image ships.
            qp, qu = quote(self.script_path), quote(url)
            py_get = ("import sys,urllib.request as u;"
                      "open(sys.argv[2],'wb').write(u.urlopen(u.Request(sys.argv[1],"
                      "headers={'User-Agent':'EnigmaPlay'}),timeout=60).read())")
            wget_cmd = ("sh -c %s" % quote(
                "wget --timeout=20 --tries=2 --max-redirect=%s -O %s %s 2>/dev/null"
                " || { rm -f %s; wget -q -T 30 -O %s %s; }"
                " || { rm -f %s; curl -fsSL -m 60 -o %s %s; }"
                " || { rm -f %s; python3 -c %s %s %s; }"
                % (max_redirect, qp, qu, qp, qp, qu, qp, qp, qu, qp, quote(py_get), qu, qp)))
            self.wget_container = eConsoleAppContainer()
            self.wget_container.dataAvail.append(self._on_wget_data)
            self.wget_container.appClosed.append(self._on_wget_closed)
            res = self.wget_container.execute(wget_cmd)
            if res < 0:
                self._handle_download_failed("wget execute failed")
        else:
            # Subprocess without shell (arguments list)
            try:
                cmd_list = ["wget", "--timeout=20", "--tries=2", "--max-redirect=%s" % max_redirect, "-O", self.script_path, url]
                proc = subprocess.Popen(cmd_list, shell=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                stdout, stderr = proc.communicate()
                if proc.returncode == 0 and os.path.exists(self.script_path) and os.path.getsize(self.script_path) > 0:
                    os.chmod(self.script_path, 0o700)
                    self._on_download_complete()
                else:
                    self._handle_download_failed(stderr.decode('utf-8', errors='ignore'))
            except Exception as e:
                self._handle_download_failed(str(e))

    def _on_wget_data(self, data):
        pass

    def _on_wget_closed(self, exit_code):
        if self.cancelled:
            return
        if exit_code == 0 and os.path.exists(self.script_path) and os.path.getsize(self.script_path) > 0:
            try:
                os.chmod(self.script_path, 0o700)
            except Exception:
                pass
            self._on_download_complete()
        else:
            err_msg = "Download failed (code %s)" % exit_code
            self._handle_download_failed(err_msg)

    def _on_download_complete(self):
        """PHASE 1.1: Verify sha256 checksum or request confirmation if unverified."""
        self.downloaded_sha = calc_file_sha256(self.script_path)
        expected_sha = self.expected_sha
        if expected_sha:
            expected_sha = str(expected_sha).strip().lower()

        log_debug("Downloaded script SHA-256 for %s: %s (expected: %s)" % (self.item.key, self.downloaded_sha, expected_sha))

        if expected_sha:
            if self.downloaded_sha == expected_sha:
                log_debug("SHA-256 verified successfully for %s" % self.item.key)
                self.start_install()
            else:
                self.phase = "error"
                err_msg = _("فشل التحقق الأمني: تجزئة SHA-256 غير متطابقة. تم إلغاء التثبيت لحماية الجهاز.")
                log_security_event("SHA256_MISMATCH", "Item %s hash mismatch: got %s, expected %s" % (self.item.key, self.downloaded_sha, expected_sha))
                try:
                    with open(self.log_path, "w", encoding="utf-8") as f:
                        f.write(_("خطأ أمني:\nتجزئة SHA-256 للسكربت لا تتطابق مع القيمة المسجلة في الفهرس.\n"))
                except Exception:
                    pass
                if self.on_finish:
                    self.on_finish(self, -2, err_msg)
        else:
            # sha256 is absent in index -> unverified confirmation warning
            log_debug("Script for %s has no sha256 hash. Requesting unverified confirmation." % self.item.key)
            if self.on_unverified:
                self.phase = "unverified_prompt"
                self.on_unverified(
                    self,
                    on_confirm=self._on_unverified_confirmed,
                    on_cancel=self._on_unverified_cancelled
                )
            else:
                self.start_install()

    def _on_unverified_confirmed(self):
        log_debug("User confirmed unverified execution for %s" % self.item.key)
        self.start_install()

    def _on_unverified_cancelled(self):
        log_security_event("UNVERIFIED_CANCELLED", "User cancelled installation of unverified script: %s" % self.item.key)
        self.cancel_download()

    def cancel_download(self):
        if self.phase in ("download", "unverified_prompt"):
            self.cancelled = True
            log_debug("Cancelling download for %s" % self.item.key)
            if self.wget_container:
                try:
                    self.wget_container.kill()
                except Exception:
                    pass
                self.wget_container = None
            if os.path.exists(self.script_path):
                try:
                    os.remove(self.script_path)
                except Exception:
                    pass
            self.phase = "cancelled"
            if self.on_finish:
                self.on_finish(self, -999, _("تم إلغاء العملية"))

    def _handle_download_failed(self, error_str):
        self.phase = "error"
        log_debug("Download failed for %s: %s" % (self.item.key, error_str))
        try:
            with open(self.log_path, "w", encoding="utf-8") as f:
                f.write(_("خطأ أثناء تنزيل السكربت:\n%s\n") % error_str)
        except Exception:
            pass
        if self.on_finish:
            self.on_finish(self, -1, _("تعذر تنزيل السكربت"))

    def _prepare_package_wrapper(self):
        """Verify the downloaded .ipk/.deb again and write the shell wrapper that installs it."""
        pkg_file = self.script_path
        if calc_file_sha256(pkg_file) != self.downloaded_sha:
            return False
        with open(pkg_file, "rb") as f:
            magic = f.read(7)
        if magic != b"!<arch>":
            if self.pkg_type == "deb" or magic[:2] != b"\x1f\x8b":   # some ipk are tar.gz
                log_security_event("BAD_PACKAGE", "%s is not a valid %s file" % (pkg_file, self.pkg_type))
                return False
        q = quote(pkg_file)
        name = re.sub(r"[^A-Za-z0-9 ._-]", "", self.item.name or self.item.key)
        if self.pkg_type == "ipk":
            body = (
                'echo "Installing %(name)s (ipk) ..."\n'
                'opkg install --force-reinstall --force-overwrite %(q)s\n'
                'RC=$?\n'
                'if [ $RC -ne 0 ]; then\n'
                '  echo "opkg failed ($RC), retrying without dependency resolution ..."\n'
                '  opkg install --nodeps --force-reinstall --force-overwrite %(q)s\n'
                '  RC=$?\n'
                'fi\n'
            ) % {"name": name, "q": q}
        else:
            body = (
                'echo "Installing %(name)s (deb) ..."\n'
                'export DEBIAN_FRONTEND=noninteractive\n'
                'if command -v apt-get >/dev/null 2>&1; then\n'
                '  apt-get install -y --allow-downgrades --reinstall %(q)s\n'
                '  RC=$?\n'
                'else\n'
                '  RC=1\n'
                'fi\n'
                'if [ $RC -ne 0 ]; then\n'
                '  dpkg -i --force-overwrite %(q)s\n'
                '  RC=$?\n'
                '  if [ $RC -ne 0 ] && command -v apt-get >/dev/null 2>&1; then apt-get -f install -y && RC=0; fi\n'
                'fi\n'
            ) % {"name": name, "q": q}
        # Success = the package is really installed (opkg may fail on unrelated half-installed packages)
        pkg_name = getattr(self.item, "package", None)
        if pkg_name and re.match(r"^[A-Za-z0-9.+_-]+$", pkg_name):
            pq = quote(pkg_name)
            if self.pkg_type == "ipk":
                body += ('if [ $RC -ne 0 ] && opkg status %s 2>/dev/null | grep -q "^Status:.* installed"; then\n'
                         '  echo "Note: opkg reported errors about other packages; %s is installed."\n  RC=0\nfi\n') % (pq, pq)
            else:
                body += ('if [ $RC -ne 0 ] && dpkg-query -W -f=\'${Status}\' %s 2>/dev/null | grep -q "install ok installed"; then\n'
                         '  echo "Note: dpkg reported errors about other packages; %s is installed."\n  RC=0\nfi\n') % (pq, pq)
        body += 'rm -f %s\nexit $RC\n' % q
        wrapper = os.path.join(self.work_dir, "%s.sh" % self.safe_id)
        with open(wrapper, "w") as f:
            f.write("#!/bin/sh\n# generated by EnigmaPlay\n" + body)
        os.chmod(wrapper, 0o700)
        self.script_path = wrapper
        self.downloaded_sha = calc_file_sha256(wrapper)
        self.wrapper_ready = True
        return True

    def start_install(self):
        if self.pkg_type in ("ipk", "deb") and not self.wrapper_ready:
            if not self._prepare_package_wrapper():
                self.phase = "error"
                err_msg = _("فشل التحقق من ملف الحزمة. تم إلغاء التثبيت.")
                if self.on_finish:
                    self.on_finish(self, -6, err_msg)
                return
        self.phase = "install"
        log_debug("Starting install execution for %s" % self.item.key)

        # TOCTOU Check: Re-compute SHA-256 immediately before execution!
        pre_exec_sha = calc_file_sha256(self.script_path)
        if self.downloaded_sha and pre_exec_sha != self.downloaded_sha:
            self.phase = "error"
            err_msg = _("فشل أمني: تم رصد تعديل على ملف السكربت بعد تنزيله وقبل تنفيذه. تم إلغاء التثبيت فوراً.")
            log_security_event("TOCTOU_TAMPERING", "Script file %s was altered between download (%s) and execution (%s)" % (
                self.script_path, self.downloaded_sha, pre_exec_sha
            ))
            if os.path.exists(self.script_path):
                try:
                    os.remove(self.script_path)
                except Exception:
                    pass
            if self.on_finish:
                self.on_finish(self, -4, err_msg)
            return

        pid_file = os.path.join(self.work_dir, "%s.pid" % self.safe_id)
        if os.path.exists(pid_file):
            try:
                os.remove(pid_file)
            except Exception:
                pass

        # Write pending.json BEFORE running with recorded SHA-256
        pending_data = {
            "id": self.item.key,
            "name": self.item.name,
            "version": self.item.version or "",
            "url": (self.download or {}).get("url") or self.item.url,
            "sha256": self.downloaded_sha or pre_exec_sha,
            "script_path": self.script_path,
            "log_path": self.log_path,
            "rc_path": self.rc_path,
            "pid_path": pid_file,
            "phase": "install",
            "time": time.time(),
            "pid": 0
        }
        write_pending(pending_data)

        # Log start to /tmp/enigmaplay.log
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        append_to_main_log(_("\n=== [%s] بدء تثبيت: %s (v%s) ===") % (timestamp, self.item.name, self.item.version or ""))

        # Build secure quoted execution command
        pid_q = quote(pid_file)
        script_q = quote(self.script_path)
        log_q = quote(self.log_path)
        main_q = quote(MAIN_LOG_FILE)
        rc_q = quote(self.rc_path)

        inner_cmd = "echo $$ > %s; sh %s > %s 2>&1; rc=$?; cat %s >> %s; echo $rc > %s" % (
            pid_q, script_q, log_q, log_q, main_q, rc_q
        )
        cmd = "/usr/bin/setsid sh -c %s &" % quote(inner_cmd)

        if HAS_E2:
            launcher = eConsoleAppContainer()
            launcher.execute(cmd)
            self._start_polling()
        else:
            proc = subprocess.Popen(cmd, shell=True)
            self._start_polling()

    def _start_polling(self):
        if HAS_E2:
            self.e2_timer = eTimer()
            self.e2_timer.callback.append(self._poll_step)
            self.e2_timer.start(300, False)
        else:
            pass

    def _poll_step(self):
        # 1. Update log lines
        lines = self.get_last_log_lines(6)
        if self.on_log_update:
            self.on_log_update(lines)

        # 2. Check if <rc> file exists
        if os.path.exists(self.rc_path):
            try:
                with open(self.rc_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                if content:
                    rc = int(content)
                    self._on_job_completed(rc)
                    return
            except Exception as e:
                log_debug("Error reading rc file: %s" % e)

    def _on_job_completed(self, rc):
        if self.e2_timer:
            self.e2_timer.stop()
            self.e2_timer = None

        self.rc = rc
        self.phase = "finished"
        log_debug("Job finished for %s with exit code %d" % (self.item.key, rc))

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        status_str = _("نجاح") if rc == 0 else _("فشل (رمز: %d)") % rc
        append_to_main_log(_("=== [%s] انتهاء: %s - الحالة: %s ===\n") % (timestamp, self.item.name, status_str))

        add_history(self.item, self.action, rc)
        if rc == 0 and self.action == "remove":
            remove_installed_record(self.item.key)
            clear_pending()
            msg = _("تمت إزالة %s") % self.item.name
        elif rc == 0:
            save_installed_record(self.item.key, self.item.name, self.item.version, rc=0)
            clear_pending()
            msg = _("تم تثبيت %s") % self.item.name
        else:
            clear_pending()
            msg = _("فشل تثبيت %s") % self.item.name

        if self.on_finish:
            self.on_finish(self, rc, msg)
