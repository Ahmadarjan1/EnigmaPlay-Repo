# -*- coding: utf-8 -*-
"""EnigmaPlay Plugin Package

Copyright (c) 2026 Ahmad Alarjan. All rights reserved.
Proprietary software: copying, modification or redistribution without written permission
is prohibited. See LICENSE.
"""
__version__ = "1.2.27"
