# -*- coding: utf-8 -*-
"""
Backup / restore of plugin settings, saved in the user's EnigmaPlay account.

What is saved for a plugin:
  * its lines in /etc/enigma2/settings  (config.plugins.<Name>.xxx=value)
    <Name> = the plugin folder(s) found in the package file list, or the "settings.config"
    prefixes given by the developer in the store index
  * small files listed by the developer in "settings.files" (only under /etc/enigma2/)
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import base64
import glob
import hashlib
import io
import json
import os
import re

SETTINGS_FILE = "/etc/enigma2/settings"
INFO_DIRS = ("/var/lib/opkg/info", "/usr/lib/opkg/info", "/var/lib/dpkg/info")
PLUGIN_DIR_RE = re.compile(r"/usr/lib/enigma2/python/Plugins/(?:Extensions|SystemPlugins)/([^/]+)/")
FILES_ROOT = "/etc/enigma2/"
MAX_FILE = 64 * 1024
MAX_TOTAL = 200 * 1024
STATE_FILE = "/etc/enigma2/enigmaplay/backup_state.json"
NEVER = ("config.plugins.enigmaplay.",)


def _plugin_dirs(pkg):
    """Plugin folder names installed by a package (from the opkg/dpkg file list)."""
    names = set()
    if not pkg:
        return names
    for d in INFO_DIRS:
        lst = os.path.join(d, pkg + ".list")
        if not os.path.isfile(lst):
            continue
        try:
            with io.open(lst, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    m = PLUGIN_DIR_RE.search(line.strip() + "/")
                    if m:
                        names.add(m.group(1))
        except Exception:
            pass
    return names


def prefixes_for(item, pkg):
    spec = getattr(item, "settings", None) or {}
    out = set()
    for p in spec.get("config") or []:
        p = str(p).strip().lower()
        if p.startswith("config.plugins.") and len(p) > len("config.plugins.") + 1:
            out.add(p if p.endswith(".") else p + ".")
    for name in _plugin_dirs(pkg):
        out.add("config.plugins.%s." % name.lower())
    return sorted(p for p in out if not p.startswith(NEVER))


def _safe_path(p):
    p = os.path.normpath(str(p))
    return p.startswith(FILES_ROOT) and p != SETTINGS_FILE and "/enigmaplay/" not in p + "/"


def collect(item, pkg):
    """-> backup dict, or None when there is nothing to save."""
    prefixes = prefixes_for(item, pkg)
    config_lines = []
    if prefixes:
        try:
            with io.open(SETTINGS_FILE, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    line = line.rstrip("\r\n")
                    key = line.split("=", 1)[0].lower()
                    if "=" in line and any(key.startswith(p) for p in prefixes):
                        config_lines.append(line)
        except Exception:
            pass
    files = {}
    total = 0
    spec = getattr(item, "settings", None) or {}
    for pattern in spec.get("files") or []:
        for path in sorted(glob.glob(str(pattern)))[:50]:
            if not os.path.isfile(path) or not _safe_path(path):
                continue
            size = os.path.getsize(path)
            if size > MAX_FILE or total + size > MAX_TOTAL:
                continue
            with open(path, "rb") as f:
                files[path] = base64.b64encode(f.read()).decode("ascii")
            total += size
    if not config_lines and not files:
        return None
    return {"v": 1, "config": config_lines, "files": files}


def digest(data):
    return hashlib.sha256(json.dumps(data, sort_keys=True).encode("utf-8")).hexdigest()[:16]


def load_state():
    try:
        with io.open(STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(st):
    try:
        with io.open(STATE_FILE, "w", encoding="utf-8") as f:
            f.write(json.dumps(st))
    except Exception:
        pass


def apply(data):
    """Write the saved config lines and files back. Returns the number of restored entries."""
    n = 0
    lines = [l for l in (data.get("config") or []) if isinstance(l, str) and l.startswith("config.plugins.") and "=" in l
             and not l.lower().startswith(NEVER) and "\n" not in l]
    if lines:
        n += _apply_config(lines)
    for path, b64 in (data.get("files") or {}).items():
        if not _safe_path(path):
            continue
        try:
            raw = base64.b64decode(b64)
            if len(raw) > MAX_FILE:
                continue
            d = os.path.dirname(path)
            if not os.path.isdir(d):
                os.makedirs(d)
            tmp = path + ".epbak"
            with open(tmp, "wb") as f:
                f.write(raw)
            os.rename(tmp, path)
            n += 1
        except Exception:
            continue
    return n


def _apply_config(lines):
    """Merge lines into /etc/enigma2/settings and reload Enigma2's config from it."""
    try:
        from Components.config import configfile
        configfile.save()                    # flush values changed in this session first
    except Exception:
        configfile = None
    new = {}
    for l in lines:
        k, v = l.split("=", 1)
        new[k] = v
    out, seen = [], set()
    try:
        with io.open(SETTINGS_FILE, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.rstrip("\r\n")
                k = line.split("=", 1)[0]
                if k in new:
                    out.append("%s=%s" % (k, new[k]))
                    seen.add(k)
                else:
                    out.append(line)
    except Exception:
        pass
    for k, v in new.items():
        if k not in seen:
            out.append("%s=%s" % (k, v))
    tmp = SETTINGS_FILE + ".epbak"
    with io.open(tmp, "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")
    os.rename(tmp, SETTINGS_FILE)
    if configfile is not None:
        try:
            configfile.load()                # Enigma2 keeps these values and saves them on shutdown
        except Exception:
            pass
    return len(new)
