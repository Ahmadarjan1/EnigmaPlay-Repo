# -*- coding: utf-8 -*-
"""
EnigmaPlay translations.
Source strings are Arabic (the original UI). lang/<code>.json maps each Arabic string to its
translation. _() returns the translation for the active language, falling back to English,
then to the Arabic source. The language is chosen once at import (changing it restarts the GUI).
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import io
import json
import os
import re

PLUGIN_PATH = os.path.dirname(os.path.abspath(__file__))
LANG_DIR = os.path.join(PLUGIN_PATH, "lang")

# (code, native name) - shown in Settings
LANGUAGES = [
    ("auto", "Auto"),
    ("ar", "العربية"), ("en", "English"), ("tr", "Türkçe"), ("fr", "Français"),
    ("de", "Deutsch"), ("es", "Español"), ("it", "Italiano"), ("pt", "Português"),
    ("nl", "Nederlands"), ("pl", "Polski"), ("ru", "Русский"), ("uk", "Українська"),
    ("el", "Ελληνικά"), ("ro", "Română"), ("cs", "Čeština"), ("hu", "Magyar"),
    ("sv", "Svenska"), ("id", "Bahasa Indonesia"), ("fa", "فارسی"), ("ur", "اردو"),
    ("he", "עברית"),
]
RTL_LANGS = ("ar", "fa", "ur", "he")


def available():
    codes = {"ar"}
    try:
        for f in os.listdir(LANG_DIR):
            if f.endswith(".json"):
                codes.add(f[:-5])
    except Exception:
        pass
    return codes


def system_language():
    """2-letter code of the Enigma2 menu language (config.osd.language, e.g. 'de_DE')."""
    try:
        from Components.config import config
        return (config.osd.language.value or "en")[:2].lower()
    except Exception:
        return "en"


def _resolve():
    chosen = "auto"
    try:   # read the file directly (settings.py imports this module)
        with io.open("/etc/enigma2/enigmaplay/settings.json", "r", encoding="utf-8") as f:
            chosen = json.load(f).get("language", "auto") or "auto"
    except Exception:
        pass
    avail = available()
    if chosen and chosen != "auto" and chosen in avail:
        return chosen
    sys_lang = system_language()
    if sys_lang in avail:
        return sys_lang
    return "en" if "en" in avail else "ar"


def _load(code):
    if code == "ar":
        return {}
    try:
        with io.open(os.path.join(LANG_DIR, code + ".json"), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


LANG = _resolve()
IS_RTL = LANG in RTL_LANGS
_TR = _load(LANG)
_EN = _load("en") if LANG not in ("ar", "en") else {}


# Arabic diacritics (tashkeel) and tatweel: Enigma2 draws the marks as separate glyphs next to the
# letters, which breaks the words apart on screen, so they are removed from everything shown.
_TASHKEEL = re.compile("[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed\u0640]")


def plain(text):
    if not text:
        return text
    try:
        return _TASHKEEL.sub("", text)
    except Exception:
        return text


def _(text):
    if not text:
        return text
    if LANG == "ar":
        return plain(text)
    return plain(_TR.get(text) or _EN.get(text) or text)


def font_files():
    """(regular, medium, bold) TTF files suited to the active language's script."""
    fonts = os.path.join(PLUGIN_PATH, "fonts")
    if LANG == "ar":
        names = ("Tajawal-E2-Regular.ttf", "Tajawal-E2-Medium.ttf", "Tajawal-E2-Bold.ttf")
    else:
        # DejaVu Sans covers Latin-extended (tr, pl, cs, ro...), Cyrillic, Greek, Hebrew and Persian/Urdu
        names = ("DejaVuSans.ttf", "DejaVuSans.ttf", "DejaVuSans-Bold.ttf")
    out = []
    for n in names:
        p = os.path.join(fonts, n)
        if not os.path.exists(p):
            p = os.path.join(fonts, n.replace("-E2", ""))
        out.append(p)
    return tuple(out)
