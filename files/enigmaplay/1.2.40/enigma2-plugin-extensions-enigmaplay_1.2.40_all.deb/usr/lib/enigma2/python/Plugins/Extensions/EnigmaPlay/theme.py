# -*- coding: utf-8 -*-
"""
EnigmaPlay themes. The UI is designed with light colours; in dark mode every colour goes
through C() and every static image is looked up first in images/fhd_dark/.
The theme is read once at import time (changing it restarts the GUI).
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import os
import re

try:
    from . import settings as _settings
    THEME = _settings.get("theme")
except Exception:
    THEME = "dark"
DARK = (THEME == "dark")

PLUGIN_PATH = os.path.dirname(os.path.abspath(__file__))
IMAGES_DIR = os.path.join(PLUGIN_PATH, "images", "fhd")
DARK_IMAGES_DIR = os.path.join(PLUGIN_PATH, "images", "fhd_dark")
GEN_DIR = os.path.join(PLUGIN_PATH, "images", "gen_" + THEME)   # runtime-generated pixmaps
try:
    if not os.path.isdir(GEN_DIR):
        os.makedirs(GEN_DIR)
except Exception:
    GEN_DIR = "/tmp/enigmaplay_gen_" + THEME
    try:
        os.makedirs(GEN_DIR)
    except Exception:
        pass

# light design colour -> dark colour
PAGE_BG = "#111315" if DARK else "#ffffff"      # screen + top bar
SURFACE = "#1d1f23" if DARK else "#ffffff"      # cards, menus, dialogs, outlined buttons
DARK_MAP = {
    "#202124": "#e8eaed",   # primary text
    "#3c4043": "#c4c7cc",   # body text
    "#5f6368": "#9aa0a6",   # secondary text / icons
    "#dadce0": "#3a3d42",   # borders
    "#e3e3e3": "#33363b",   # dividers
    "#f1f3f4": "#26292e",   # keys bar, search pill, placeholders
    "#e6f4ea": "#183d2e",   # selected (menu focus)
    "#e6f4ee": "#183d2e",   # selected chip
}


def C(color):
    """Theme a design colour (text, border, light fills)."""
    if not DARK or not color:
        return color
    return DARK_MAP.get(color.lower(), color)


def theme_xml(xml):
    """Theme colours inside the generated skin XML."""
    if not DARK:
        return xml

    def bg(m):
        c = m.group(1).lower()
        if c == "#ffffff":
            return 'backgroundColor="%s"' % PAGE_BG
        return 'backgroundColor="%s"' % C(c)

    def fg(m):
        return 'foregroundColor="%s"' % C(m.group(1))

    xml = re.sub(r'backgroundColor="(#[0-9a-fA-F]{6})"', bg, xml)
    xml = re.sub(r'foregroundColor="(#[0-9a-fA-F]{6})"', fg, xml)
    return xml


def img_path(name):
    """Static image: dark variant first (when dark), then the normal one."""
    if DARK:
        p = os.path.join(DARK_IMAGES_DIR, name)
        if os.path.exists(p):
            return p
    return os.path.join(IMAGES_DIR, name)
