# -*- coding: utf-8 -*-
"""
EnigmaPlay themes. The UI is designed with light colours; in dark mode every colour goes
through C() and every static image is looked up first in images/fhd_dark/.
The theme is read once at import time (changing it restarts the GUI).
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import os
import re

try:
    from . import settings as _settings
    THEME = _settings.get("theme")
except Exception:
    THEME = "dark"
DARK = (THEME == "dark")

PLUGIN_PATH = os.path.dirname(os.path.abspath(__file__))
IMAGES_DIR = os.path.join(PLUGIN_PATH, "images", "fhd")
DARK_IMAGES_DIR = os.path.join(PLUGIN_PATH, "images", "fhd_dark")
GEN_DIR = os.path.join(PLUGIN_PATH, "images", "gen_" + THEME)   # runtime-generated pixmaps
TMP_GEN_DIR = "/tmp/enigmaplay_gen_" + THEME                      # RAM fallback (flash full / read-only)
GEN_MIN_FREE = 10 * 1024 * 1024


def _free_bytes(path):
    try:
        st = os.statvfs(path)
        return st.f_bavail * st.f_frsize
    except Exception:
        return 0


def _use_tmp_gen():
    global GEN_DIR
    GEN_DIR = TMP_GEN_DIR
    try:
        if not os.path.isdir(GEN_DIR):
            os.makedirs(GEN_DIR)
    except Exception:
        pass


try:
    if _free_bytes(PLUGIN_PATH) < GEN_MIN_FREE:
        raise OSError("flash almost full")
    if not os.path.isdir(GEN_DIR):
        os.makedirs(GEN_DIR)
    # drop empty/broken files left by an earlier "No space left on device"
    for _n in os.listdir(GEN_DIR):
        _f = os.path.join(GEN_DIR, _n)
        try:
            if _n.endswith(".tmp") or os.path.getsize(_f) == 0:
                os.remove(_f)
        except Exception:
            pass
except Exception:
    _use_tmp_gen()


def save_image(im, path, *args, **kwargs):
    """im.save(path) that never crashes the UI: when the flash is full (ENOSPC) or read-only,
    the partial file is removed and the image goes to RAM (/tmp) instead. Returns the real path."""
    try:
        im.save(path, *args, **kwargs)
        return path
    except (IOError, OSError):
        try:
            os.remove(path)
        except Exception:
            pass
        alt = os.path.join(TMP_GEN_DIR, os.path.basename(path))
        if alt == path:
            raise
        if not os.path.isdir(TMP_GEN_DIR):
            os.makedirs(TMP_GEN_DIR)
        if os.path.dirname(path) == GEN_DIR:
            _use_tmp_gen()          # stop writing to the full flash for the rest of the session
        im.save(alt, *args, **kwargs)
        return alt

# light design colour -> dark colour
PAGE_BG = "#111315" if DARK else "#ffffff"      # screen + top bar
SURFACE = "#1d1f23" if DARK else "#ffffff"      # cards, menus, dialogs, outlined buttons
DARK_MAP = {
    "#202124": "#e8eaed",   # primary text
    "#3c4043": "#c4c7cc",   # body text
    "#5f6368": "#9aa0a6",   # secondary text / icons
    "#dadce0": "#3a3d42",   # borders
    "#e3e3e3": "#33363b",   # dividers
    "#f1f3f4": "#26292e",   # keys bar, search pill, placeholders
    "#e6f4ea": "#183d2e",   # selected (menu focus)
    "#e6f4ee": "#183d2e",   # selected chip
}


def C(color):
    """Theme a design colour (text, border, light fills)."""
    if not DARK or not color:
        return color
    return DARK_MAP.get(color.lower(), color)


def theme_xml(xml):
    """Theme colours inside the generated skin XML."""
    if not DARK:
        return xml

    def bg(m):
        c = m.group(1).lower()
        if c == "#ffffff":
            return 'backgroundColor="%s"' % PAGE_BG
        return 'backgroundColor="%s"' % C(c)

    def fg(m):
        return 'foregroundColor="%s"' % C(m.group(1))

    xml = re.sub(r'backgroundColor="(#[0-9a-fA-F]{6})"', bg, xml)
    xml = re.sub(r'foregroundColor="(#[0-9a-fA-F]{6})"', fg, xml)
    return xml


def img_path(name):
    """Static image: dark variant first (when dark), then the normal one."""
    if DARK:
        p = os.path.join(DARK_IMAGES_DIR, name)
        if os.path.exists(p):
            return p
    return os.path.join(IMAGES_DIR, name)
