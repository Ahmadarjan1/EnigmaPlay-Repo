# -*- coding: utf-8 -*-
"""
EnigmaPlay - Enigma2 Plugin Entry Point
======================================
"""

from __future__ import print_function, unicode_literals, absolute_import, division
import os
import sys

from Plugins.Plugin import PluginDescriptor

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
# Our modules are imported relative to this package (from . import catalog ...). The plugin dir is
# NOT added to sys.path: generic names like installer/settings/catalog clash with other modules
# on some images (e.g. the "installer" package of pip on OpenATV 8).

from . import catalog
try:
    from .i18n import _
except Exception:
    _ = lambda t: t
from . import ui

GLOBAL_CATALOG = None


def get_catalog():
    global GLOBAL_CATALOG
    if GLOBAL_CATALOG is None:
        data_dir = os.path.join(PLUGIN_DIR, "data")
        try:
            # 1) Fresh cache (TTL = 1 hour)
            try:
                from . import settings as ep_settings
                ttl = int(ep_settings.get("catalog_ttl"))
            except Exception:
                ttl = 3600
            if catalog.is_cache_valid(ttl=ttl):
                GLOBAL_CATALOG = catalog.load_cached_catalog()

            # 2) Stale cache: open the store with it right away, the screen refreshes it in the background
            if GLOBAL_CATALOG is None:
                stale = catalog.load_cached_catalog()
                if stale is not None and stale.items:
                    stale.needs_refresh = True
                    GLOBAL_CATALOG = stale

            # 3) First start: download index.json from EnigmaPlay-Repo
            if GLOBAL_CATALOG is None:
                remote_cat, online, msg = catalog.fetch_remote_index()
                if remote_cat is not None:
                    GLOBAL_CATALOG = remote_cat

            # 4) Last resort: local data/ files shipped with the plugin
            if GLOBAL_CATALOG is None:
                GLOBAL_CATALOG = catalog.load(data_dir)
        except Exception as e:
            print("[EnigmaPlay] Error loading catalog: %s" % e)
            GLOBAL_CATALOG = catalog.Catalog()
    return GLOBAL_CATALOG


def main(session, start_view=None, **kwargs):
    if os.path.exists("/tmp/enigmaplay_font_test"):
        session.open(ui.FontTestScreen)
        return
    pending = _pending_version()
    if pending and pending != EP_VERSION:
        # EnigmaPlay updated itself in the background: this GUI still runs the old code
        try:
            from Screens.MessageBox import MessageBox

            def answer(yes):
                if yes:
                    _restart_gui(session, force=True)
                else:
                    session.open(ui.EnigmaPlayScreen, get_catalog(), start_view=start_view)
            session.openWithCallback(answer, MessageBox,
                                     _("تحدّث EnigmaPlay للنسخة %s. أعد تشغيل الواجهة لتفعيله. إعادة التشغيل الآن؟") % pending,
                                     MessageBox.TYPE_YESNO)
            return
        except Exception as e:
            print("[EnigmaPlay] pending restart prompt failed: %s" % e)
    cat = get_catalog()
    session.open(ui.EnigmaPlayScreen, cat, start_view=start_view)


# ---------------------------------------------------------------------------
# EnigmaPlay updates ITSELF (only itself) in the background, like a phone store app:
# a release is installed once it is a few hours old (a bad release can be pulled first), and the
# new code is loaded at the next GUI restart: right away if the box is in standby and not
# recording, else on the next standby, or when the owner opens the store (he is asked).
# ---------------------------------------------------------------------------
try:
    from . import __version__ as EP_VERSION
except Exception:
    EP_VERSION = ""
SELF_PENDING_FILE = "/etc/enigma2/enigmaplay/self_update_pending"
SELF_MIN_AGE = 6 * 3600
_self_state = {"job": None, "standby_hook": False}


def _pending_version():
    try:
        with open(SELF_PENDING_FILE) as f:
            return f.read().strip()
    except Exception:
        return ""


def _recording(session):
    try:
        return bool(session.nav.getRecordings())
    except Exception:
        return False


def _restart_gui(session, force=False):
    """Restart Enigma2 now if nobody is watching (standby) and nothing records, or when asked."""
    try:
        import Screens.Standby
        if not force and (not Screens.Standby.inStandby or _recording(session)):
            return False
        if _recording(session):
            return False
        from enigma import quitMainloop
        quitMainloop(3)
        return True
    except Exception as e:
        print("[EnigmaPlay] restart failed: %s" % e)
        return False


def _hook_standby(session):
    """Apply a pending self-update the next time the box goes to standby."""
    if _self_state["standby_hook"]:
        return
    try:
        from Components.config import config
        from enigma import eTimer
        timer = eTimer()

        def later():
            if _pending_version() and _pending_version() != EP_VERSION:
                _restart_gui(session)
        try:
            timer.callback.append(later)
        except AttributeError:
            _self_state["conn"] = timer.timeout.connect(later)
        _self_state["timer"] = timer

        def on_standby(_cfg=None):
            timer.start(20000, True)          # let Standby settle first
        config.misc.standbyCounter.addNotifier(on_standby, initial_call=False)
        _self_state["standby_hook"] = True
    except Exception as e:
        print("[EnigmaPlay] standby hook failed: %s" % e)


def self_update(session, cat, found):
    """Start the background update of EnigmaPlay itself. True when it was started."""
    from . import settings as ep_settings
    from . import installer
    import time
    if not ep_settings.get("auto_update_self") or cat is None or _self_state["job"] is not None:
        return False
    if not any(k == "enigmaplay" for k, _n, _v in found):
        return False
    item = cat.get("enigmaplay")
    if item is None or installer.select_download(item) is None:
        return False
    if getattr(item, "updated_ts", 0) and time.time() - item.updated_ts < SELF_MIN_AGE:
        return False                          # too fresh: wait until the next check
    if installer.load_pending():
        return False                          # another install is running

    def finished(job, rc, msg):
        _self_state["job"] = None
        if rc != 0:
            print("[EnigmaPlay] self update failed rc=%s %s" % (rc, msg))
            return
        try:
            with open(SELF_PENDING_FILE, "w") as f:
                f.write(item.version or "")
        except Exception:
            pass
        if not _restart_gui(session):
            _hook_standby(session)

    def unverified(job, on_confirm, on_cancel):
        on_cancel()                           # EnigmaPlay is always sha256-pinned: never run unverified
    job = installer.InstallJob(item, on_finish=finished, on_unverified=unverified, action="update")
    _self_state["job"] = job
    job.start()
    print("[EnigmaPlay] updating itself to %s" % item.version)
    return True


# ---------------------------------------------------------------------------
# Background update check: shortly after boot and then every 12 hours the
# store index is downloaded; when plugins installed on the box have a newer
# version the user gets a notification (once per set of updates).
# ---------------------------------------------------------------------------
NOTIFIED_FILE = "/etc/enigma2/enigmaplay/notified_updates.json"
FIRST_CHECK_MS = 90 * 1000
CHECK_EVERY_MS = 12 * 3600 * 1000


class UpdateNotifier(object):
    def __init__(self, session):
        import threading
        from enigma import eTimer
        self.session = session
        self.lock = threading.Lock()
        self.result = None
        self.check_timer = eTimer()
        self.check_timer.callback.append(self.start_check)
        self.poll_timer = eTimer()
        self.poll_timer.callback.append(self.poll)
        self.check_timer.start(FIRST_CHECK_MS, True)

    def start_check(self):
        import threading
        self.check_timer.start(CHECK_EVERY_MS, True)
        t = threading.Thread(target=self.worker)
        t.daemon = True
        t.start()
        self.poll_timer.start(2000, False)

    def worker(self):
        global GLOBAL_CATALOG
        found = []
        try:
            from . import account
            account.ping_daily()             # anonymous "this box is active today" for the store statistics
        except Exception as e:
            print("[EnigmaPlay] ping failed: %s" % e)
        try:
            from . import installer
            cat, online, _msg = catalog.fetch_remote_index()
            # automatic crash reports (anonymous) for plugins installed from the store
            try:
                from . import settings as ep_settings
                if cat is not None:
                    # always: a plain-language notice for the owner; the report only if allowed
                    from . import crashreport
                    crashreport.run(cat.items, send=bool(ep_settings.get("crash_reports")))
            except Exception as e:
                print("[EnigmaPlay] crash report failed: %s" % e)
            if cat is not None and online:
                GLOBAL_CATALOG = None          # next open uses the fresh index
                self.cat = cat
                for it in cat.items:
                    try:
                        if installer.get_item_state(it)[0] == "update":
                            found.append((it.key, it.name, it.version))
                    except Exception:
                        continue
        except Exception as e:
            print("[EnigmaPlay] update check failed: %s" % e)
        with self.lock:
            self.result = found

    def poll(self):
        with self.lock:
            found, self.result = self.result, None
        if found is None:
            return
        self.poll_timer.stop()
        try:
            if self_update(self.session, getattr(self, "cat", None), found):
                found = [f for f in found if f[0] != "enigmaplay"]     # updating itself, no need to ask
        except Exception as e:
            print("[EnigmaPlay] self update failed: %s" % e)
        try:
            from . import settings as ep_settings
            if not ep_settings.get("notify_updates"):
                return
        except Exception:
            pass
        if not found:
            return
        sig = sorted("%s:%s" % (k, v) for k, _n, v in found)
        try:
            import io, json
            with io.open(NOTIFIED_FILE, "r", encoding="utf-8") as f:
                if json.load(f) == sig:
                    return                      # already told the user about exactly these
        except Exception:
            pass
        try:
            import io, json
            with io.open(NOTIFIED_FILE, "w", encoding="utf-8") as f:
                f.write(json.dumps(sig))
        except Exception:
            pass
        names = ", ".join(n for _k, n, _v in found[:4]) + ("…" if len(found) > 4 else "")
        if len(found) == 1:
            head = _("يوجد تحديث لـ %s") % names
        else:
            head = _("يوجد %d تحديثات: %s") % (len(found), names)
        text = "EnigmaPlay\n\n%s\n\n%s" % (head, _("فتح قائمة التحديثات الآن؟"))
        try:
            from Tools import Notifications
            from Screens.MessageBox import MessageBox
            Notifications.AddNotificationWithCallback(self.answer, MessageBox, text, MessageBox.TYPE_YESNO, timeout=30)
        except Exception as e:
            print("[EnigmaPlay] notification failed: %s" % e)

    def answer(self, yes):
        if yes:
            try:
                main(self.session, start_view="updates")
            except Exception as e:
                print("[EnigmaPlay] open updates failed: %s" % e)


_notifier = None


def sessionstart(reason, session=None, **kwargs):
    global _notifier
    if reason == 0 and _pending_version() and _pending_version() == EP_VERSION:
        try:
            os.remove(SELF_PENDING_FILE)          # the update is active now
        except Exception:
            pass
    if reason == 0 and session is not None and _notifier is None:
        try:
            _notifier = UpdateNotifier(session)
        except Exception as e:
            print("[EnigmaPlay] notifier not started: %s" % e)
        try:
            from . import remote
            remote.start(session)
        except Exception as e:
            print("[EnigmaPlay] remote install agent not started: %s" % e)
        try:
            from . import announcements
            announcements.start(session, open_store=lambda: main(session, start_view="updates"))
        except Exception as e:
            print("[EnigmaPlay] announcements not started: %s" % e)


def menu(menuid, **kwargs):
    """Entry in the image's Main Menu."""
    if menuid == "mainmenu":
        return [("EnigmaPlay", main, "enigmaplay", 45)]
    return []


def Plugins(**kwargs):
    icon_path = os.path.join(PLUGIN_DIR, "icon.png")
    if not os.path.exists(icon_path):
        icon_path = None

    return [
        PluginDescriptor(
            name="EnigmaPlay",
            description=_("متجر ومكتبة إضافات الإنيجما الشاملة (EnigmaPlay Store)"),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon=icon_path if icon_path else "icon.png",
            fnc=main
        ),
        PluginDescriptor(
            name="EnigmaPlay",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main
        ),
        PluginDescriptor(
            name="EnigmaPlay",
            description=_("متجر ومكتبة إضافات الإنيجما الشاملة (EnigmaPlay Store)"),
            where=PluginDescriptor.WHERE_MENU,
            fnc=menu
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=sessionstart
        ),
    ]


