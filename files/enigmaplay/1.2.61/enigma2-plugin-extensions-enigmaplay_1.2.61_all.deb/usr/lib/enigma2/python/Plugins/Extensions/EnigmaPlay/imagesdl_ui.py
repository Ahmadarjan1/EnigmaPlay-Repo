# -*- coding: utf-8 -*-
"""Images download screen: one line per image this receiver can run (newest build of each),
OK / green downloads it into the folder the image's flasher reads, yellow lists other builds,
blue opens the flasher (Image Manager, Flash Manager, FlashImage) to put it into a slot."""
from __future__ import print_function, unicode_literals, absolute_import, division
import os

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import eListboxPythonMultiContent, gFont, eTimer, ePoint, eSize, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_VALIGN_CENTER

from .i18n import _, IS_RTL
from .theme import C, PAGE_BG, SURFACE, theme_xml
from . import imagesdl as dl

try:
    from enigma import getDesktop
    F = getDesktop(0).size().width() / 1920.0
except Exception:
    F = 1.0


def p(v):
    return int(round(v * F))


GREEN = "#01875f"
ROW_H = 104
W, H = 1920, 1080
LIST_X, LIST_Y, LIST_W, LIST_H = 120, 190, 1680, ROW_H * 6
HALIGN = "right" if IS_RTL else "left"
RT_H = RT_HALIGN_RIGHT if IS_RTL else RT_HALIGN_LEFT


def _hex(c):
    return int(c.lstrip("#"), 16)


def row(title, sub, badge=""):
    """Two-line row: bold name, grey detail, and a small green note on the other side."""
    bx, bw = (24, 360) if IS_RTL else (LIST_W - 384, 360)
    tx = 24
    tw = LIST_W - 48 - (380 if badge else 0)
    if IS_RTL and badge:
        tx = 24 + 380
    return [
        (title, sub, badge),
        MultiContentEntryText(pos=(p(tx), p(14)), size=(p(tw), p(42)), font=0, flags=RT_H | RT_VALIGN_CENTER,
                              text=title, color=_hex(C("#202124")), color_sel=_hex(C("#202124"))),
        MultiContentEntryText(pos=(p(tx), p(56)), size=(p(tw), p(34)), font=1, flags=RT_H | RT_VALIGN_CENTER,
                              text=sub, color=_hex(C("#5f6368")), color_sel=_hex(C("#3c4043"))),
        MultiContentEntryText(pos=(p(bx), p(14)), size=(p(bw), p(76)), font=1,
                              flags=(RT_HALIGN_LEFT if IS_RTL else RT_HALIGN_RIGHT) | RT_VALIGN_CENTER,
                              text=badge, color=_hex(GREEN), color_sel=_hex(GREEN)),
    ]


class ImageList(MenuList):
    def __init__(self):
        MenuList.__init__(self, [], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.l.setFont(0, gFont("TajawalBold", p(30)))
        self.l.setFont(1, gFont("TajawalRegular", p(24)))
        self.l.setItemHeight(p(ROW_H))


class ImagesDownloadScreen(Screen):

    def __init__(self, session, catalog_obj=None):
        key_y = H - 96
        keys = []
        kw = 380
        order = ["red", "green", "yellow", "blue"]
        if IS_RTL:
            order = list(reversed(order))
        for i, k in enumerate(order):
            x = 120 + i * (kw + 20) + (1680 - 4 * kw - 60) // 2
            col = {"red": "#d93025", "green": GREEN, "yellow": "#f9ab00", "blue": "#1a73e8"}[k]
            keys.append('<widget name="dot_%s" position="%d,%d" size="%d,%d" backgroundColor="%s" zPosition="2" />'
                        % (k, p(x + (kw - 18 if IS_RTL else 0)), p(key_y + 26), p(18), p(18), col))
            keys.append('<widget name="key_%s" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" halign="%s" valign="center" '
                        'foregroundColor="#3c4043" backgroundColor="#f1f3f4" transparent="1" zPosition="2" />'
                        % (k, p(x + (0 if IS_RTL else 30)), p(key_y + 10), p(kw - 30), p(50), p(24), HALIGN))
        self.skin = theme_xml(
            '<screen name="EnigmaPlayImages" position="0,0" size="%d,%d" flags="wfNoBorder" backgroundColor="#ffffff">'
            '<widget name="title" position="%d,%d" size="%d,%d" font="TajawalBold;%d" halign="%s" valign="center" foregroundColor="#202124" backgroundColor="#ffffff" transparent="1" />'
            '<widget name="sub" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" halign="%s" valign="center" foregroundColor="#5f6368" backgroundColor="#ffffff" transparent="1" />'
            '<eLabel position="%d,%d" size="%d,%d" backgroundColor="#e3e3e3" />'
            '<widget name="list" position="%d,%d" size="%d,%d" backgroundColor="#ffffff" backgroundColorSelected="%s" scrollbarMode="showOnDemand" transparent="0" />'
            '<widget name="status" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" halign="%s" valign="top" foregroundColor="#202124" backgroundColor="#ffffff" transparent="1" />'
            '<widget name="bar_bg" position="%d,%d" size="%d,%d" backgroundColor="#e3e3e3" />'
            '<widget name="bar" position="%d,%d" size="%d,%d" backgroundColor="%s" zPosition="1" />'
            '<eLabel position="0,%d" size="%d,%d" backgroundColor="#f1f3f4" />'
            '%s</screen>'
            % (p(W), p(H),
               p(120), p(40), p(1680), p(70), p(44), HALIGN,
               p(120), p(110), p(1680), p(44), p(26), HALIGN,
               p(120), p(170), p(1680), p(2),
               p(LIST_X), p(LIST_Y), p(LIST_W), p(LIST_H), C("#e6f4ea"),
               p(120), p(LIST_Y + LIST_H + 20), p(1680), p(110), p(27), HALIGN,
               p(120), p(LIST_Y + LIST_H + 138), p(1680), p(12),
               p(120), p(LIST_Y + LIST_H + 138), p(0) or 1, p(12), GREEN,
               p(key_y), p(W), p(96),
               "".join(keys)))
        try:
            from .announcements import _register_fonts
            _register_fonts()
        except Exception:
            pass
        Screen.__init__(self, session)
        self.catalog_obj = catalog_obj
        self["title"] = Label(_("تنزيل الصور"))
        self["sub"] = Label("")
        self["list"] = ImageList()
        self["status"] = Label(_("جارٍ البحث عن الصور المناسبة لجهازك…"))
        self["bar_bg"] = Label("")
        self["bar"] = Label("")
        for k in ("red", "green", "yellow", "blue"):
            self["key_%s" % k] = Label("")
            self["dot_%s" % k] = Label("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.key_ok,
            "green": self.key_ok,
            "cancel": self.key_back,
            "red": self.key_back,
            "yellow": self.key_versions,
            "blue": self.key_flasher,
            "up": lambda: self["list"].up(),
            "down": lambda: self["list"].down(),
            "left": lambda: self["list"].pageUp(),
            "right": lambda: self["list"].pageDown(),
        }, -1)
        self.results = None          # [{feed, model, entries, latest}]
        self.mode = "loading"        # loading, images, versions, download
        self.cur = None              # result shown in versions mode
        self.job = None
        self.saved = ""              # last finished file
        self.timer = eTimer()
        try:
            self.timer.callback.append(self._tick)
        except AttributeError:
            self._conn = self.timer.timeout.connect(self._tick)
        self.onLayoutFinish.append(self._start)
        self.onClose.append(self._closed)

    # ------------------------------------------------------------ loading
    def _start(self):
        self._bar(None)
        models = dl.model_candidates()
        self.models = models
        cur = dl.current_image()
        self["sub"].setText(_("جهازك: %s") % ((models[0].upper() if models else "?")
                                               + ("   ·   " + _("الصورة الحالية: %s") % cur.capitalize() if cur else "")))
        self._keys(red=_("رجوع"))
        import threading

        def work():
            try:
                self.results = dl.load_all(self.catalog_obj, models)
            except Exception as e:
                dl._log("load_all failed: %r" % e)
                self.results = []
        t = threading.Thread(target=work)
        t.daemon = True
        t.start()
        self.timer.start(400, False)

    def _tick(self):
        if self.mode == "loading":
            if self.results is None:
                return
            self.show_images()
            if not self.job:
                self.timer.stop()
            return
        if self.job:
            self._progress()

    def _keys(self, red="", green="", yellow="", blue=""):
        for k, v in (("red", red), ("green", green), ("yellow", yellow), ("blue", blue)):
            self["key_%s" % k].setText(v)
            if v:
                self["dot_%s" % k].show()
            else:
                self["dot_%s" % k].hide()

    def _bar(self, frac):
        if frac is None:
            self["bar_bg"].hide()
            self["bar"].hide()
            return
        self["bar_bg"].show()
        self["bar"].show()
        try:
            w = max(1, int(p(1680) * max(0.0, min(1.0, frac))))
            x = p(120) + (p(1680) - w if IS_RTL else 0)
            self["bar"].instance.move(ePoint(x, p(LIST_Y + LIST_H + 138)))
            self["bar"].instance.resize(eSize(w, p(12)))
        except Exception:
            pass

    # ------------------------------------------------------------ lists
    def show_images(self):
        self.mode = "images"
        rows = []
        cur = dl.current_image()
        for r in self.results or []:
            e = r["latest"]
            when = dl.date_of(e)
            # Latin only: mixed with Arabic, the numbers and dots get reordered on screen
            sub = "   ·   ".join(x for x in (e["category"], when, dl.human_size(e["size"]) if e.get("size") else "") if x)
            badge = ""
            if dl.already_downloaded(e):
                badge = _("جاهزة للتثبيت")
            elif r["feed"]["id"] == cur:
                badge = _("صورتك الحالية")
            rows.append(row(r["feed"]["name"], sub, badge))
        self["list"].setList(rows)
        if rows:
            self["status"].setText(_("اختر الصورة واضغط OK. سيُنزّل المتجر النسخة المناسبة لجهازك ويجهّزها للتثبيت."))
            self._keys(red=_("رجوع"), green=_("تنزيل"), yellow=_("نسخ أخرى"), blue=self._flasher_label())
        else:
            self["status"].setText(_("لم نجد صوراً لجهازك (%s) على خوادم الصور الرسمية. تأكد من الاتصال بالإنترنت وحاول لاحقاً.")
                                   % (", ".join(self.models[:2]) or "?"))
            self._keys(red=_("رجوع"))

    def key_versions(self):
        if self.mode != "images" or not self.results:
            return
        i = self["list"].getSelectedIndex()
        if i is None or i >= len(self.results):
            return
        self.cur = self.results[i]
        self.mode = "versions"
        rows = []
        for e in self.cur["entries"][:60]:
            when = dl.date_of(e)
            sub = e["file"] + (("   ·   " + dl.human_size(e["size"])) if e.get("size") else "")
            badge = _("تم تنزيلها") if dl.already_downloaded(e) else (when or "")
            rows.append(row(e["category"], sub, badge))
        self["list"].setList(rows)
        self["title"].setText(_("نسخ %s") % self.cur["feed"]["name"])
        self["status"].setText(_("كل النسخ المتوفرة لجهازك، الأحدث أولاً. اختر نسخة واضغط OK."))
        self._keys(red=_("رجوع"), green=_("تنزيل"), blue=self._flasher_label())

    # ------------------------------------------------------------ download
    def key_ok(self):
        if self.mode == "images" and self.results:
            i = self["list"].getSelectedIndex()
            if i is not None and i < len(self.results):
                self._download(self.results[i], self.results[i]["latest"])
        elif self.mode == "versions" and self.cur:
            i = self["list"].getSelectedIndex()
            if i is not None and i < len(self.cur["entries"]):
                self._download(self.cur, self.cur["entries"][i])

    def _download(self, result, entry):
        have = dl.already_downloaded(entry)
        if have:
            self.saved = have
            self["status"].setText(_("هذه النسخة منزّلة مسبقاً وجاهزة:\n%s\nاضغط الأزرق لفتح أداة التثبيت واختيارها.") % have)
            return
        need = entry.get("size") or 0
        folder, free = dl.pick_destination(need)
        if not folder and need and free:
            self["status"].setText(_("لا توجد مساحة كافية لهذه الصورة: تحتاج %s والمتوفر %s. أفرغ مساحة أو ركّب قرصاً أو فلاشة أكبر.")
                                   % (dl.human_size(need + dl.MARGIN), dl.human_size(free)))
            return
        if not folder:
            self["status"].setText(_("لا يوجد قرص أو فلاشة بمساحة كافية. ركّب قرصاً أو فلاشة (1 GB فارغ على الأقل) وحاول مجدداً."))
            return
        self.prev_mode = self.mode
        self.mode = "download"
        self.job = dl.Download(entry, folder)
        self.job_name = "%s %s" % (result["feed"]["name"], entry["category"])
        self.job.start()
        self._keys(red=_("إلغاء التنزيل"))
        self["status"].setText(_("جارٍ تنزيل %s…") % self.job_name)
        self._bar(0)
        self.timer.start(500, False)

    def _progress(self):
        j = self.job
        if j.state == "running":
            # second line without words, so it reads the same in every language
            if j.total:
                frac = float(j.done) / j.total
                txt = _("جارٍ تنزيل %s…") % self.job_name + "\n%d%%   ·   %s / %s" % (int(frac * 100), dl.human_size(j.done), dl.human_size(j.total))
            else:
                frac = 0
                txt = _("جارٍ تنزيل %s…") % self.job_name + "\n" + dl.human_size(j.done)
            sp = j.speed()
            if sp:
                txt += "   ·   %s/s" % dl.human_size(sp)
            self["status"].setText(txt)
            self._bar(frac)
            return
        self.timer.stop()
        self.job = None
        self._bar(None)
        if j.state == "ok":
            self.saved = j.target
            self["status"].setText(_("الصورة جاهزة: %s\nاضغط الأزرق لفتح %s واختيارها لتثبيتها على أي سلوت.")
                                   % (j.target, self._flasher_name() or _("أداة التثبيت")))
        elif j.state == "cancelled":
            self["status"].setText(_("تم إلغاء التنزيل."))
        else:
            msgs = {
                "no_space": _("لا توجد مساحة كافية على %s لهذه الصورة. أفرغ مساحة أو ركّب قرصاً أو فلاشة أكبر.") % os.path.dirname(j.folder),
                "incomplete": _("انقطع التنزيل قبل اكتماله. تأكد من الاتصال بالإنترنت وحاول مجدداً."),
                "bad_zip": _("الملف الذي تم تنزيله ليس صورة سليمة فتم حذفه. جرّب نسخة أخرى أو حاول لاحقاً."),
            }
            self["status"].setText(msgs.get(j.error) or _("فشل التنزيل. تأكد من الاتصال بالإنترنت وحاول مجدداً."))
        back = getattr(self, "prev_mode", "images")
        if back == "versions" and self.cur:
            self.mode = "images"
            status = self["status"].getText()
            self.key_versions_restore(status)
        else:
            status = self["status"].getText()
            self.show_images()
            self["status"].setText(status)

    def key_versions_restore(self, status):
        idx = self.results.index(self.cur) if self.cur in (self.results or []) else 0
        self["list"].moveToIndex(idx)
        self.key_versions()
        self["status"].setText(status)

    # ------------------------------------------------------------ flasher / back
    def _flasher_name(self):
        cls, _a = dl.flasher()
        if not cls:
            return ""
        name = cls.__name__
        if "ImageManager" in name:
            return "Image Manager"
        if name == "FlashManager":
            return "Flash Manager"
        return _("أداة التثبيت")

    def _flasher_label(self):
        n = self._flasher_name()
        return _("افتح %s") % n if n else ""

    def key_flasher(self):
        if self.mode == "download":
            return
        cls, args = dl.flasher()
        if not cls:
            self["status"].setText(_("لم نجد أداة التثبيت في هذه الصورة. افتح المالتي بوت من قائمة الرسيفر واختر الصورة من المجلد %s.") % dl.FOLDER)
            return
        try:
            self.session.open(cls, *args)
        except Exception as e:
            dl._log("flasher open failed: %r" % e)
            self["status"].setText(_("تعذر فتح أداة التثبيت. افتحها من قائمة الرسيفر واختر الصورة من المجلد %s.") % dl.FOLDER)

    def key_back(self):
        if self.mode == "download" and self.job:
            self.session.openWithCallback(self._confirm_cancel, MessageBox,
                                          _("التنزيل جارٍ. هل تريد إيقافه؟"), MessageBox.TYPE_YESNO, default=False)
            return
        if self.mode == "versions":
            self["title"].setText(_("تنزيل الصور"))
            idx = self.results.index(self.cur) if self.cur in (self.results or []) else 0
            self.show_images()
            self["list"].moveToIndex(idx)
            return
        self.close()

    def _confirm_cancel(self, yes):
        if yes and self.job:
            self.job.cancel()

    def _closed(self):
        try:
            self.timer.stop()
        except Exception:
            pass
        if self.job:
            self.job.cancel()
