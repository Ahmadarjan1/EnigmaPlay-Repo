# -*- coding: utf-8 -*-
"""
Images download: the store reads the receiver model, lists the images the official image servers
offer for exactly that model, downloads the one the user picks and stores it where the image's
own flasher looks for it (Image Manager on OpenViX/OpenBH, Flash Manager on OpenATV, FlashImage
on OpenPLi). Flashing itself is left to those tools.

Each official server answers https://<server>/json/<model> with
    {category: {file: {"name": ..., "link": ...}}}
and the flashers list every .zip whose name contains the model from
    <media>/imagebackups, <media>/downloaded_images, <media>/images
(Image Manager only on its backup location, so that one is preferred).
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import json
import os
import re
import threading
import time
import zipfile

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlparse
except ImportError:                       # Python 2 images
    from urllib2 import urlopen, Request
    from urlparse import urlparse

# Used when the index carries no list (older index); the signed index can add / change servers.
DEFAULT_FEEDS = [
    {"id": "openvix", "name": "OpenViX", "url": "https://www.openvix.co.uk/json/%s", "hosts": ["openvix.co.uk"]},
    {"id": "openatv", "name": "OpenATV", "url": "https://images.mynonpublic.com/openatv/json/%s", "hosts": ["mynonpublic.com"]},
    {"id": "openpli", "name": "OpenPLi", "url": "https://downloads.openpli.org/json/%s", "hosts": ["openpli.org"]},
    {"id": "openbh", "name": "OpenBH", "url": "https://images.openbh.net/json/%s", "hosts": ["openbh.net"]},
    {"id": "openhdf", "name": "OpenHDF", "url": "https://flash.hdfreaks.cc/openhdf/json/%s", "hosts": ["hdfreaks.cc"]},
    {"id": "egami", "name": "EGAMI", "url": "https://image.egami-image.com/json/%s", "hosts": ["egami-image.com"]},
    {"id": "openspa", "name": "OpenSPA", "url": "https://openspa.webhop.info/online/json.php?box=%s", "hosts": ["openspa.webhop.info"]},
    {"id": "teamblue", "name": "TeamBlue", "url": "https://images.teamblue.tech/json/%s", "hosts": ["teamblue.tech"]},
    {"id": "openvision", "name": "Open Vision", "url": "https://images.openvision.dedyn.io/json/%s", "hosts": ["images.openvision.dedyn.io"]},
]
FOLDER = "imagebackups"               # read by Image Manager, Flash Manager and FlashImage alike
MARGIN = 64 * 1024 * 1024             # free space kept besides the image
UA = {"User-Agent": "EnigmaPlay"}
IMAGE_FILES = ("uImage", "rootfs.bin", "root_cfe_auto.bin", "root_cfe_auto.jffs2", "oe_rootfs.bin",
               "e2jffs2.img", "rootfs.tar.bz2", "rootfs.ubi")


def _log(msg):
    try:
        from . import installer
        installer.log_debug("[images] " + msg)
    except Exception:
        print("[EnigmaPlay][images] " + msg)


# ---------------------------------------------------------------- receiver
def model_candidates():
    """Names the image servers may know this receiver by, most specific first."""
    out = []

    def add(v):
        v = (v or "").strip().lower()
        if v and v not in out and re.match(r"^[a-z0-9_+-]{2,40}$", v):
            out.append(v)
    try:
        from boxbranding import getMachineBuild, getBoxType
        add(getMachineBuild())
        add(getBoxType())
    except Exception:
        pass
    try:
        from Components.SystemInfo import BoxInfo        # OpenATV 7
        add(BoxInfo.getItem("BoxName"))
        add(BoxInfo.getItem("machinebuild"))
        add(BoxInfo.getItem("model"))
    except Exception:
        pass
    try:
        from Components.SystemInfo import MODEL            # OpenPLi
        add(MODEL)
    except Exception:
        pass
    try:
        from Tools.HardwareInfo import HardwareInfo
        add(HardwareInfo().get_device_name())
    except Exception:
        pass
    for path, prefix in (("/proc/stb/info/vumodel", "vu"), ("/proc/stb/info/boxtype", ""),
                         ("/proc/stb/info/model", ""), ("/etc/hostname", "")):
        try:
            with open(path) as f:
                v = f.read().strip()
            add(prefix + v if prefix and not v.lower().startswith(prefix) else v)
        except Exception:
            continue
    return out


def current_image():
    """'openvix' / 'openatv' / ... of the running image ('' when unknown)."""
    try:
        from boxbranding import getImageDistro
        return (getImageDistro() or "").lower()
    except Exception:
        pass
    try:
        from Components.SystemInfo import BoxInfo
        return (BoxInfo.getItem("distro") or "").lower()
    except Exception:
        pass
    try:
        with open("/etc/issue") as f:
            return f.read().split()[0].lower()
    except Exception:
        return ""


# ---------------------------------------------------------------- servers
def feeds(catalog_obj=None):
    lst = list(getattr(catalog_obj, "image_feeds", None) or []) or list(DEFAULT_FEEDS)
    return [f for f in lst if f.get("url") and "%s" in f["url"]]


def _get_json(url, timeout=15):
    data = urlopen(Request(url, headers=UA), timeout=timeout).read()
    return json.loads(data.decode("utf-8-sig") if isinstance(data, bytes) else data)


def _host_ok(link, feed):
    """Only the image server itself, or the hosts the signed index names for it."""
    try:
        u = urlparse(link)
    except Exception:
        return False
    if u.scheme not in ("http", "https") or not u.hostname:
        return False
    host = u.hostname.lower()
    allowed = set(h.lower() for h in (feed.get("hosts") or []))
    try:
        allowed.add(urlparse(feed["url"]).hostname.lower())
    except Exception:
        pass
    return any(host == a or host.endswith("." + a) for a in allowed)


def _usable(name):
    n = name.lower()
    return n.endswith(".zip") and "recovery" not in n


def _natural(s):
    """'6.10 Release' after '6.9 Release' (plain string order puts it first)."""
    return [(0, int(t), "") if t.isdigit() else (1, 0, t.lower()) for t in re.split(r"(\d+)", str(s))]


RELEASE_RE = re.compile(r"release|stable", re.I)
DEV_RE = re.compile(r"dev|beta|test|nightly|scarthgap|unstable|experimental|factory|recovery|backup|update", re.I)


def _rank(category, fname):
    """0 release builds, 1 plain, 2 developer / factory / backup ones: what a plain download picks
    first, and the order of the drop-down."""
    text = category + " " + fname
    if DEV_RE.search(text):
        return 2
    if RELEASE_RE.search(text):
        return 0
    return 1


def parse_feed(data, feed, model):
    """{category: {...}} -> [{category, name, link, rank}] newest first; unusable entries dropped."""
    out = []
    if not isinstance(data, dict):
        return out
    for cat in sorted(data.keys(), key=_natural, reverse=True):
        files = data.get(cat)
        if not isinstance(files, dict):
            continue

        def when(k):
            e = files.get(k) or {}
            try:
                return int(e.get("date") or 0)
            except Exception:
                return 0
        def fdate(k):
            e = files.get(k) or {}
            m = re.search(r"(?<!\d)(20\d{6})(?!\d)", str(e.get("link") or k))
            return int(m.group(1)) if m else 0
        for key in sorted(files.keys(), key=lambda k: (fdate(k), when(k), _natural(k)), reverse=True):
            e = files.get(key) or {}
            if not isinstance(e, dict):
                continue
            link = str(e.get("link") or "")
            name = str(e.get("name") or link.rsplit("/", 1)[-1])
            fname = link.rsplit("/", 1)[-1].split("?", 1)[0]
            if not _usable(fname) or not _host_ok(link, feed):
                continue
            try:
                size = int(e.get("size") or 0)
            except Exception:
                size = 0
            out.append({"category": re.sub(r"\s+", " ", str(cat)).strip(), "name": name, "link": link, "file": fname,
                        "size": size, "date": when(key), "rank": _rank(str(cat), fname),
                        "dev": _rank(str(cat), fname) == 2,
                        "usb": fname.lower().endswith("_usb.zip")})
    # release first, then newest category, then newest build (stable sort keeps the server's order)
    out.sort(key=lambda e: e["rank"])
    return out


def pick_latest(entries):
    """The image a plain 'download' gets: newest release build for flashing into a slot.
    Release categories before developer ones, *_usb.zip (USB-stick boot) only when nothing else."""
    if not entries:
        return None
    ranked = sorted(entries, key=lambda e: (e.get("rank", 1), e["usb"]))
    return ranked[0]      # stable sort: newest first within the same kind


def date_of(entry):
    """Build date: the one in the file name (the servers' own "date" can be the upload / scan day,
    the same for every build), else the server's date."""
    m = re.search(r"(?<!\d)(20\d{2})(\d{2})(\d{2})(?!\d)", entry.get("file", ""))
    if m:
        return "%s-%s-%s" % m.groups()
    if entry.get("date"):
        return time.strftime("%Y-%m-%d", time.gmtime(entry["date"]))
    m = re.search(r"(20\d{2})(\d{2})(\d{2})", entry.get("file", ""))
    return "%s-%s-%s" % m.groups() if m else ""


def load_images(feed, models=None):
    """(model, [entries]) for the first model name this server knows; (None, []) when none."""
    for m in (models or model_candidates()):
        try:
            data = _get_json(feed["url"] % m)
        except Exception as e:
            _log("%s %s: %r" % (feed.get("id"), m, e))
            continue
        entries = parse_feed(data, feed, m)
        if entries:
            return m, entries
    return None, []


def plan(catalog_obj, models):
    """[(feed, [model names to try])]: with the receiver in the index's model map, only the servers
    that build for it are asked, under the name they use; servers outside the map are always asked."""
    table = getattr(catalog_obj, "image_models", None) or {}
    spec = None
    for m in models:
        if m in table:
            spec = {}
            for part in (table[m] or "").split():
                fid, _sep, name = part.partition("=")
                spec[fid] = name or m
            break
    out = []
    for f in feeds(catalog_obj):
        if spec is not None and f.get("column"):
            if f["id"] in spec:
                out.append((f, [spec[f["id"]]] + [x for x in models if x != spec[f["id"]]][:1]))
            continue
        out.append((f, models))
    return out


def load_all(catalog_obj=None, models=None):
    """[{feed, model, entries, latest}] for every server that has images for this receiver.
    Servers are asked in parallel (a slow one does not hold the others)."""
    models = models or model_candidates()
    res = []
    lock = threading.Lock()

    def one(f, names):
        m, entries = load_images(f, names)
        if entries:
            with lock:
                res.append({"feed": f, "model": m, "entries": entries, "latest": pick_latest(entries)})
    jobs = plan(catalog_obj, models)
    threads = [threading.Thread(target=one, args=(f, names)) for f, names in jobs]
    for t in threads:
        t.daemon = True
        t.start()
    for t in threads:
        t.join(40)
    order = [f["id"] for f, _n in jobs]
    cur = current_image()
    res.sort(key=lambda r: (r["feed"]["id"] != cur, order.index(r["feed"]["id"]) if r["feed"]["id"] in order else 99))
    return res


# ---------------------------------------------------------------- where to store
def _free(path):
    try:
        st = os.statvfs(path)
        return st.f_bavail * st.f_frsize
    except Exception:
        return 0


def _is_mount(path):
    try:
        return os.path.ismount(path)
    except Exception:
        return False


def imagemanager_location():
    """Backup location chosen in Image Manager (OpenViX / OpenBH), when it is set and mounted."""
    loc = ""
    try:
        from Components.config import config
        loc = config.imagemanager.backuplocation.value
    except Exception:
        try:
            with open("/etc/enigma2/settings") as f:
                for line in f:
                    if line.startswith("config.imagemanager.backuplocation="):
                        loc = line.split("=", 1)[1].strip()
                        break
        except Exception:
            pass
    loc = (loc or "").rstrip("/")
    if loc.startswith("/media/") and os.path.isdir(loc) and "/mmc" not in loc:
        return loc
    return ""


def media_candidates():
    """Mounted storage under /media, never the receiver's internal eMMC (/media/mmc)."""
    out = []
    try:
        names = sorted(os.listdir("/media"))
    except Exception:
        names = []
    for n in names:
        p = "/media/" + n
        if n in ("mmc", "autofs", "net", "ram") or n.startswith("mmc") or not os.path.isdir(p):
            continue
        if _is_mount(p) or os.path.realpath(p) != p:
            out.append(p)
    for base in ("/media/net", "/media/autofs"):
        try:
            for n in sorted(os.listdir(base)):
                p = os.path.join(base, n)
                if _is_mount(p):
                    out.append(p)
        except Exception:
            pass
    return out


def pick_destination(need=0):
    """(folder, free_bytes) to save into, or (None, best_free) when nothing has room.
    Image Manager's own location first, then /media/hdd, then the device with the most room."""
    seen = []
    first = imagemanager_location()
    cands = ([first] if first else []) + (["/media/hdd"] if os.path.isdir("/media/hdd") else []) \
        + sorted(media_candidates(), key=_free, reverse=True)
    best = 0
    for c in cands:
        if c in seen:
            continue
        seen.append(c)
        fr = _free(c)
        best = max(best, fr)
        if fr >= need + MARGIN:
            return os.path.join(c, FOLDER), fr
    return None, best


# ---------------------------------------------------------------- download
def valid_image_zip(path):
    try:
        with zipfile.ZipFile(path) as z:
            names = [n.rsplit("/", 1)[-1] for n in z.namelist()]
    except Exception:
        return False
    hits = [n for n in names if ("kernel" in n and ".bin" in n) or n in IMAGE_FILES]
    return len(hits) >= 2


class Download(object):
    """Background download with progress; .part file renamed only when complete and checked."""

    def __init__(self, entry, folder):
        self.entry = entry
        self.folder = folder
        self.target = os.path.join(folder, entry["file"])
        self.part = self.target + ".part"
        self.total = 0
        self.done = 0
        self.state = "idle"        # idle, running, ok, error, cancelled
        self.error = ""
        self._stop = False
        self.started = 0

    def start(self):
        self.state = "running"
        self.started = time.time()
        t = threading.Thread(target=self._run)
        t.daemon = True
        t.start()

    def cancel(self):
        self._stop = True

    def speed(self):
        dt = time.time() - self.started
        return self.done / dt if dt > 1 else 0

    def _run(self):
        try:
            if not os.path.isdir(self.folder):
                os.makedirs(self.folder)
            resp = urlopen(Request(self.entry["link"], headers=UA), timeout=30)
            try:
                self.total = int(resp.headers.get("Content-Length") or 0)
            except Exception:
                self.total = 0
            if self.total and _free(self.folder) < self.total + MARGIN:
                raise IOError("no_space")
            with open(self.part, "wb") as out:
                while True:
                    if self._stop:
                        raise KeyboardInterrupt()
                    chunk = resp.read(256 * 1024)
                    if not chunk:
                        break
                    out.write(chunk)
                    self.done += len(chunk)
            if self.total and self.done < self.total:
                raise IOError("incomplete")
            if not valid_image_zip(self.part):
                raise IOError("bad_zip")
            if os.path.exists(self.target):
                os.remove(self.target)
            os.rename(self.part, self.target)
            self.state = "ok"
            _log("saved %s (%d bytes)" % (self.target, self.done))
        except KeyboardInterrupt:
            self._cleanup()
            self.state = "cancelled"
        except Exception as e:
            self._cleanup()
            msg = str(e)
            self.error = msg if msg in ("no_space", "incomplete", "bad_zip") else ("net:" + msg)
            self.state = "error"
            _log("download failed %s: %r" % (self.entry.get("link"), e))

    def _cleanup(self):
        try:
            if os.path.exists(self.part):
                os.remove(self.part)
        except Exception:
            pass


def already_downloaded(entry):
    """Path of this exact image when it is already stored on a device the flashers scan."""
    roots = ([imagemanager_location()] if imagemanager_location() else []) + media_candidates()
    for r in roots:
        for folder in (FOLDER, "downloaded_images", "images", ""):
            p = os.path.join(r, folder, entry["file"])
            if os.path.isfile(p):
                return p
    return ""


# ---------------------------------------------------------------- the image's own flasher
def flasher():
    """(screen class, args) of the tool that flashes a stored image into a slot, or (None, None)."""
    tries = (
        ("Plugins.SystemPlugins.ViX.ImageManager", "VIXImageManager"),     # OpenViX
        ("Plugins.SystemPlugins.BH.ImageManager", "BHImageManager"),       # OpenBH
        ("Screens.FlashManager", "FlashManager"),                          # OpenATV 7
        ("Screens.FlashImage", "SelectImage"),                             # OpenPLi and co.
    )
    for mod, cls in tries:
        try:
            m = __import__(mod, fromlist=[cls])
            return getattr(m, cls), ()
        except Exception:
            continue
    return None, None


BOX_PIC_URL = "https://raw.githubusercontent.com/Ahmadarjan1/EnigmaPlay-Repo/main/images/boxes/%s.png"


def box_picture(models, max_w=440, max_h=120):
    """Picture of this receiver (OpenWebif's set, kept in EnigmaPlay-Repo/images/boxes), as an RGBA
    PNG in /tmp sized for the screen; "" when there is none."""
    d = "/tmp/enigmaplay"
    for m in models or []:
        target = os.path.join(d, "box_%s_%dx%d.png" % (m, max_w, max_h))
        if os.path.isfile(target):
            return target
        try:
            data = urlopen(Request(BOX_PIC_URL % m, headers=UA), timeout=15).read()
            if not data.startswith(b"\x89PNG"):
                continue
            if not os.path.isdir(d):
                os.makedirs(d)
            from PIL import Image
            import io as _io
            im = Image.open(_io.BytesIO(data)).convert("RGBA")
            im.thumbnail((max_w, max_h), Image.LANCZOS)
            im.save(target)
            return target
        except Exception:
            continue
    return ""


def human_size(n):
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return ("%d %s" if unit in ("B", "KB") else "%.1f %s") % (n, unit)
        n /= 1024.0
