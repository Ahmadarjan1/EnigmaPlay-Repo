# -*- coding: utf-8 -*-
"""EnigmaPlay Plugin Package"""
__version__ = "1.2.7"
