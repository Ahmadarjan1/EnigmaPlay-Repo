# -*- coding: utf-8 -*-
"""System tools section: libraries and tools plugins need (Python modules, players, codecs, network
and disk tools), installed from the image's own package feed with opkg / apt.

The list comes from the store (index.json "system_tools", signed). For each tool the store knows
the package names per Python version ("3", "2") or for any image ("any"); the first name the feed
has is installed (all of them when "all" is set). Nothing is ever removed from here.
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import gzip
import io
import os
import re
import subprocess
import threading
import time

from .i18n import LANG

LOG = "/tmp/enigmaplay-systools.log"
OPKG_STATUS = ("/var/lib/opkg/status", "/usr/lib/opkg/status", "/var/opkg/status")
OPKG_LISTS = ("/var/lib/opkg/lists", "/var/opkg-lists", "/run/opkg-lists", "/var/cache/opkg")
DPKG_STATUS = "/var/lib/dpkg/status"
APT_LISTS = "/var/lib/apt/lists"
LISTS_FRESH = 6 * 3600          # package lists older than this are refreshed when the screen opens


def _log(msg):
    try:
        with io.open(LOG, "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (time.strftime("%H:%M:%S"), msg))
    except Exception:
        pass


def text(d):
    """{ar, en} -> the string for the store's language (English for every non-Arabic language)."""
    if not isinstance(d, dict):
        return "%s" % (d or "")
    return d.get(LANG) or (d.get("ar") if LANG == "ar" else d.get("en")) or d.get("en") or d.get("ar") or ""


def sysinfo():
    from . import installer
    return installer.get_system_info()


def package_manager():
    return sysinfo().get("pm")


def candidates(item):
    """Package names for this receiver, most wanted first."""
    pk = item.get("packages") or {}
    py = str(sysinfo().get("py_major") or "3")
    return list(pk.get(py) or []) + list(pk.get("any") or [])


# ------------------------------------------------------------------ what is installed / available
def _read(path):
    with open(path, "rb") as f:
        data = f.read()
    if data[:2] == b"\x1f\x8b":
        data = gzip.decompress(data) if hasattr(gzip, "decompress") else gzip.GzipFile(fileobj=io.BytesIO(data)).read()
    return data.decode("utf-8", "replace")


def installed_packages():
    """{name} of packages the image's package manager has installed."""
    out = set()
    paths = [DPKG_STATUS] if package_manager() == "dpkg" else list(OPKG_STATUS)
    for path in paths:
        if not os.path.exists(path):
            continue
        try:
            name = None
            for line in _read(path).splitlines():
                if line.startswith("Package:"):
                    name = line[8:].strip()
                elif line.startswith("Status:") and name and " installed" in line and "not-installed" not in line:
                    out.add(name)
        except Exception as e:
            _log("status %s: %r" % (path, e))
    return out


def _list_files():
    if package_manager() == "dpkg":
        if os.path.isdir(APT_LISTS):
            return [os.path.join(APT_LISTS, f) for f in os.listdir(APT_LISTS) if f.endswith("_Packages")]
        return []
    out = []
    dirs = list(OPKG_LISTS)
    try:     # the lists folder the image configured ("option lists_dir ext /var/lib/opkg/lists")
        for conf in ["/etc/opkg/opkg.conf"] + ["/etc/opkg/" + f for f in os.listdir("/etc/opkg") if f.endswith(".conf")]:
            for line in io.open(conf, encoding="utf-8", errors="replace"):
                m = re.match(r"\s*option\s+lists_dir\s+\S+\s+(\S+)", line)
                if m and m.group(1) not in dirs:
                    dirs.insert(0, m.group(1))
    except Exception:
        pass
    for d in dirs:
        if os.path.isdir(d):
            out.extend(os.path.join(d, f) for f in os.listdir(d) if not f.startswith("."))
    return [f for f in out if os.path.isfile(f)]


def lists_age():
    """Seconds since the package lists were downloaded (None: never)."""
    files = _list_files()
    if not files:
        return None
    return time.time() - max(os.path.getmtime(f) for f in files)


def available_packages():
    """{name} the image's feeds offer (from the downloaded package lists)."""
    out = set()
    for path in _list_files():
        try:
            for line in _read(path).splitlines():
                if line.startswith("Package:"):
                    out.add(line[8:].strip())
        except Exception as e:
            _log("list %s: %r" % (path, e))
    return out


def state(item, installed, available):
    """("installed" | "missing" | "unavailable", [packages to install])."""
    names = candidates(item)
    have = [n for n in names if n in installed]
    files = [f for f in item.get("files") or [] if os.path.exists(f)]
    if item.get("all"):
        todo = [n for n in names if n not in installed and n in available]
        if have and not todo:
            return "installed", []
        return ("missing", todo) if todo else (("installed", []) if have else ("unavailable", []))
    if have or files:
        return "installed", []
    for n in names:
        if n in available:
            return "missing", [n]
    return "unavailable", []


# ------------------------------------------------------------------ running opkg / apt
class Job(object):
    """Runs the package manager in a thread; the screen polls .done / .lines / .ok."""

    def __init__(self, kind, packages=None):
        self.kind = kind                    # "update" | "install"
        self.packages = list(packages or [])
        self.lines = []
        self.done = False
        self.ok = False
        self.current = ""
        t = threading.Thread(target=self._run)
        t.daemon = True
        t.start()

    def _cmd(self, args):
        _log("$ " + " ".join(args))
        try:
            env = dict(os.environ, DEBIAN_FRONTEND="noninteractive", LANG="C", LC_ALL="C")
            p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
            for raw in iter(p.stdout.readline, b""):
                line = raw.decode("utf-8", "replace").rstrip()
                if line:
                    self.lines.append(line)
                    self.lines = self.lines[-40:]
                    _log(line)
            p.wait()
            return p.returncode == 0
        except Exception as e:
            self.lines.append("%r" % e)
            _log("failed: %r" % e)
            return False

    def _run(self):
        pm = package_manager()
        try:
            if pm == "dpkg":
                if self.kind == "update":
                    self.ok = self._cmd(["apt-get", "update"])
                else:
                    self.ok = self._cmd(["apt-get", "install", "-y", "--no-remove"] + self.packages)
            elif pm == "opkg":
                if self.kind == "update":
                    self.ok = self._cmd(["opkg", "update"])
                else:
                    ok = True
                    for n in self.packages:      # one by one: a missing dependency does not stop the rest
                        self.current = n
                        ok = self._cmd(["opkg", "install", n]) and ok
                    self.ok = ok
            else:
                self.lines.append("no package manager")
        finally:
            self.done = True


def missing_after(packages):
    """Names from packages that are still not installed (to tell the user what failed)."""
    inst = installed_packages()
    return [n for n in packages if n not in inst]
