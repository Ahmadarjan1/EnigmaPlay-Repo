# -*- coding: utf-8 -*-
"""System tools screen: groups (Python libraries, players, network, disks, system) that open like a
drop-down, each tool with its state on this receiver. OK / green installs, green on a group installs
everything it is missing, yellow refreshes the image's package list, blue restarts the GUI when a
freshly installed tool needs it."""
from __future__ import print_function, unicode_literals, absolute_import, division

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from enigma import eTimer, ePoint, eSize

from .i18n import _, IS_RTL
from .theme import C, theme_xml
from . import systools as st
from .imagesdl_ui import p, row, ImageList, GREEN, W, H, LIST_X, LIST_Y, LIST_W, LIST_H, HALIGN


class SystemToolsScreen(Screen):

    def __init__(self, session, catalog_obj=None):
        key_y = H - 96
        keys = []
        kw = 380
        order = ["red", "green", "yellow", "blue"]
        if IS_RTL:
            order = list(reversed(order))
        for i, k in enumerate(order):
            x = 120 + i * (kw + 20) + (1680 - 4 * kw - 60) // 2
            col = {"red": "#d93025", "green": GREEN, "yellow": "#f9ab00", "blue": "#1a73e8"}[k]
            keys.append('<widget name="dot_%s" position="%d,%d" size="%d,%d" backgroundColor="%s" zPosition="2" />'
                        % (k, p(x + (kw - 18 if IS_RTL else 0)), p(key_y + 26), p(18), p(18), col))
            keys.append('<widget name="key_%s" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" halign="%s" valign="center" '
                        'foregroundColor="#3c4043" backgroundColor="#f1f3f4" transparent="1" zPosition="2" />'
                        % (k, p(x + (0 if IS_RTL else 30)), p(key_y + 10), p(kw - 30), p(50), p(24), HALIGN))
        self.skin = theme_xml(
            '<screen name="EnigmaPlaySystemTools" position="0,0" size="%d,%d" flags="wfNoBorder" backgroundColor="#ffffff">'
            '<widget name="title" position="%d,%d" size="%d,%d" font="TajawalBold;%d" halign="%s" valign="center" foregroundColor="#202124" backgroundColor="#ffffff" transparent="1" />'
            '<widget name="sub" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" halign="%s" valign="center" foregroundColor="#5f6368" backgroundColor="#ffffff" transparent="1" />'
            '<eLabel position="%d,%d" size="%d,%d" backgroundColor="#e3e3e3" />'
            '<widget name="list" position="%d,%d" size="%d,%d" backgroundColor="#ffffff" backgroundColorSelected="%s" scrollbarMode="showNever" transparent="0" />'
            '<widget name="status" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" halign="%s" valign="top" foregroundColor="#202124" backgroundColor="#ffffff" transparent="1" />'
            '<widget name="bar_bg" position="%d,%d" size="%d,%d" backgroundColor="#e3e3e3" />'
            '<widget name="bar" position="%d,%d" size="%d,%d" backgroundColor="%s" zPosition="1" />'
            '<eLabel position="0,%d" size="%d,%d" backgroundColor="#f1f3f4" />'
            '%s</screen>'
            % (p(W), p(H),
               p(120), p(40), p(1680), p(70), p(44), HALIGN,
               p(120), p(110), p(1680), p(44), p(26), HALIGN,
               p(120), p(170), p(1680), p(2),
               p(LIST_X), p(LIST_Y), p(LIST_W), p(LIST_H), C("#e6f4ea"),
               p(120), p(LIST_Y + LIST_H + 20), p(1680), p(110), p(27), HALIGN,
               p(120), p(LIST_Y + LIST_H + 138), p(1680), p(12),
               p(120), p(LIST_Y + LIST_H + 138), 1, p(12), GREEN,
               p(key_y), p(W), p(96),
               "".join(keys)))
        try:
            from .announcements import _register_fonts
            _register_fonts()
        except Exception:
            pass
        Screen.__init__(self, session)
        self.groups = list(getattr(catalog_obj, "system_tools", None) or [])
        self["title"] = Label(_("أدوات النظام"))
        self["sub"] = Label("")
        self["list"] = ImageList()
        self["status"] = Label("")
        self["bar_bg"] = Label("")
        self["bar"] = Label("")
        for k in ("red", "green", "yellow", "blue"):
            self["key_%s" % k] = Label("")
            self["dot_%s" % k] = Label("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.key_ok,
            "green": self.key_green,
            "yellow": self.key_yellow,
            "blue": self.key_blue,
            "cancel": self.key_back,
            "red": self.key_back,
            "up": self._up,
            "down": self._down,
            "left": lambda: self._move("pageUp"),
            "right": lambda: self._move("pageDown"),
        }, -1)
        self.expanded = None
        self.rowmap = []
        self.installed = set()
        self.available = set()
        self.job = None
        self.job_total = 0
        self.need_restart = False
        self.timer = eTimer()
        try:
            self.timer.callback.append(self._tick)
        except AttributeError:
            self._conn = self.timer.timeout.connect(self._tick)
        self.onLayoutFinish.append(self._start)
        self.onClose.append(self._closed)

    # ------------------------------------------------------------ helpers
    def _keys(self, red="", green="", yellow="", blue=""):
        for k, v in (("red", red), ("green", green), ("yellow", yellow), ("blue", blue)):
            self["key_%s" % k].setText(v)
            if v:
                self["dot_%s" % k].show()
            else:
                self["dot_%s" % k].hide()

    def _bar(self, frac):
        if frac is None:
            self["bar_bg"].hide()
            self["bar"].hide()
            return
        self["bar_bg"].show()
        self["bar"].show()
        try:
            w = max(1, int(p(1680) * max(0.0, min(1.0, frac))))
            x = p(120) + (p(1680) - w if IS_RTL else 0)
            self["bar"].instance.move(ePoint(x, p(LIST_Y + LIST_H + 138)))
            self["bar"].instance.resize(eSize(w, p(12)))
        except Exception:
            pass

    def _scan(self):
        self.installed = st.installed_packages()
        self.available = st.available_packages()

    def _states(self, group):
        return [(it, ) + st.state(it, self.installed, self.available) for it in group["items"]]

    # ------------------------------------------------------------ start
    def _start(self):
        self._bar(None)
        si = st.sysinfo()
        self["sub"].setText("Python %s   ·   %s   ·   %s" % (si.get("py") or "?", si.get("arch") or "?", si.get("pm") or "-"))
        if not self.groups:
            self._fetch_list()
            return
        if not st.package_manager():
            self["status"].setText(_("لم نجد مدير الحزم (opkg أو apt) في هذه الصورة، فلا يمكن التثبيت من هنا."))
        age = st.lists_age()
        if st.package_manager() and (age is None or age > st.LISTS_FRESH):
            self._run("update")          # lists are old: fetch the feed's package list first
            return
        self._scan()
        self.show_list()

    def _fetch_list(self):
        """The cached store list has no tools yet (written by an older version): download it again."""
        self["status"].setText(_("جارٍ تحميل قائمة الأدوات…"))
        self._keys(red=_("رجوع"))
        import threading
        self._fetched = None

        def work():
            try:
                from . import catalog as ep_catalog
                cat, _online, _msg = ep_catalog.fetch_remote_index()
                self._fetched = cat
                if cat is not None:
                    for m in list(__import__("sys").modules.values()):
                        if m is not None and hasattr(m, "GLOBAL_CATALOG") and hasattr(m, "get_catalog"):
                            m.GLOBAL_CATALOG = cat
            except Exception as e:
                st._log("fetch list: %r" % e)
            self._fetched = self._fetched or False
        t = threading.Thread(target=work)
        t.daemon = True
        t.start()
        self.fetch_timer = eTimer()
        try:
            self.fetch_timer.callback.append(self._fetch_done)
        except AttributeError:
            self._fconn = self.fetch_timer.timeout.connect(self._fetch_done)
        self.fetch_timer.start(400, False)

    def _fetch_done(self):
        if self._fetched is None:
            return
        self.fetch_timer.stop()
        self.groups = list(getattr(self._fetched, "system_tools", None) or []) if self._fetched else []
        if not self.groups:
            self["status"].setText(_("قائمة الأدوات غير متوفرة بعد. ارجع واختر «تحديث القائمة» ثم افتح هذا القسم مجدداً."))
            return
        self._start()

    # ------------------------------------------------------------ list
    def show_list(self, select=None):
        rows, self.rowmap = [], []
        for g in self.groups:
            sts = self._states(g)
            have = sum(1 for x in sts if x[1] == "installed")
            opened = self.expanded == g["id"]
            rows.append(row(st.text(g.get("name")), _("مثبتة %d من %d") % (have, len(sts)),
                            _("ناقصة %d") % sum(1 for x in sts if x[1] == "missing") if any(x[1] == "missing" for x in sts) else "",
                            arrow="open" if opened else "closed"))
            self.rowmap.append(("group", g, None))
            if opened:
                for it, s, todo in sts:
                    badge = {"installed": _("مثبتة"), "missing": _("غير مثبتة"),
                             "unavailable": _("غير متوفرة في فيد صورتك")}[s]
                    rows.append(row(it.get("name", it["id"]), st.text(it.get("desc")), badge, indent=True))
                    self.rowmap.append(("item", g, (it, s, todo)))
        self["list"].setList(rows)
        if select is not None and rows:
            self["list"].moveToIndex(max(0, min(select, len(rows) - 1)))
        self._idle_texts()

    def _sel(self):
        i = self["list"].getSelectedIndex()
        return self.rowmap[i] if 0 <= i < len(self.rowmap) else (None, None, None)

    def _idle_texts(self):
        if self.job:
            return
        kind, g, data = self._sel()
        green = ""
        if kind == "item" and data[1] == "missing":
            green = _("تثبيت")
        elif kind == "group":
            n = sum(len(x[2]) for x in self._states(g) if x[1] == "missing")
            green = _("تثبيت الناقص (%d)") % n if n else ""
        self._keys(red=_("رجوع"), green=green, yellow=_("تحديث قائمة الحزم") if st.package_manager() else "",
                   blue=_("إعادة تشغيل الواجهة") if self.need_restart else "")
        if kind == "item":
            it, s, todo = data
            if s == "missing":
                msg = _("اضغط OK أو الأخضر لتثبيت %s من فيد صورتك.") % it.get("name")
            elif s == "installed":
                msg = _("%s مثبتة على جهازك.") % it.get("name")
            else:
                msg = _("فيد صورتك لا يحتوي %s. جرّب «تحديث قائمة الحزم»، وإذا بقيت غير متوفرة فصورتك لا توفّرها.") % it.get("name")
            self["status"].setText(msg + "\n" + ", ".join(st.candidates(it)))
        else:
            self["status"].setText(_("اختر قسماً واضغط OK لعرض أدواته. الأخضر يثبّت كل ما ينقص القسم."))

    def _move(self, how):
        getattr(self["list"], how)()
        self._idle_texts()

    def _up(self):
        self._move("up")

    def _down(self):
        self._move("down")

    def _group_row(self, gid):
        for i, (k, g, _d) in enumerate(self.rowmap):
            if k == "group" and g["id"] == gid:
                return i
        return 0

    # ------------------------------------------------------------ keys
    def key_ok(self):
        if self.job:
            return
        kind, g, data = self._sel()
        if kind == "group":
            gid = g["id"]
            self.expanded = None if self.expanded == gid else gid
            self.show_list()
            self.show_list(select=self._group_row(gid))
        elif kind == "item" and data[1] == "missing":
            self._ask_install(data[2], data[0].get("name"), bool(data[0].get("restart")))

    def key_green(self):
        if self.job:
            return
        kind, g, data = self._sel()
        if kind == "item" and data[1] == "missing":
            self._ask_install(data[2], data[0].get("name"), bool(data[0].get("restart")))
        elif kind == "group":
            todo, restart = [], False
            for it, s, names in self._states(g):
                if s == "missing":
                    todo.extend(n for n in names if n not in todo)
                    restart = restart or bool(it.get("restart"))
            if todo:
                self._ask_install(todo, st.text(g.get("name")), restart)

    def _ask_install(self, packages, label, restart):
        self._pending = (packages, restart)
        self.session.openWithCallback(self._confirmed, MessageBox,
                                      _("تثبيت %s من فيد صورتك؟\n%s") % (label, " ".join(packages)),
                                      MessageBox.TYPE_YESNO, default=True)

    def _confirmed(self, yes):
        if yes and getattr(self, "_pending", None):
            packages, restart = self._pending
            self.need_restart = self.need_restart or restart
            self._run("install", packages)

    def key_yellow(self):
        if not self.job and st.package_manager():
            self._run("update")

    def key_blue(self):
        if self.need_restart and not self.job:
            from Screens.Standby import TryQuitMainloop
            self.session.open(TryQuitMainloop, 3)

    def key_back(self):
        if self.job:
            self["status"].setText(_("انتظر حتى ينتهي التثبيت…"))
            return
        if self.expanded:
            gid, self.expanded = self.expanded, None
            self.show_list()
            self.show_list(select=self._group_row(gid))
            return
        self.close()

    # ------------------------------------------------------------ jobs
    def _run(self, kind, packages=None):
        self.job = st.Job(kind, packages)
        self.job_total = len(packages or [])
        self._keys()
        self._bar(0.0 if packages else None)
        self["status"].setText(_("جارٍ تحديث قائمة الحزم من فيد صورتك…") if kind == "update" else _("جارٍ التثبيت…"))
        self.timer.start(500, False)

    def _tick(self):
        job = self.job
        if not job:
            self.timer.stop()
            return
        last = job.lines[-1][:110] if job.lines else ""
        if job.kind == "install" and job.current:
            done = job.packages.index(job.current) if job.current in job.packages else 0
            self._bar(float(done) / max(1, self.job_total))
            self["status"].setText(_("جارٍ تثبيت %s (%d من %d)…") % (job.current, done + 1, self.job_total) + "\n" + last)
        elif last:
            self["status"].setText((_("جارٍ تحديث قائمة الحزم من فيد صورتك…") if job.kind == "update" else _("جارٍ التثبيت…")) + "\n" + last)
        if not job.done:
            return
        self.timer.stop()
        self.job = None
        self._bar(None)
        sel = self["list"].getSelectedIndex()
        self._scan()
        self.show_list(select=sel)
        if job.kind == "update":
            self["status"].setText(_("تم تحديث قائمة الحزم.") if job.ok else
                                   _("تعذر تحديث قائمة الحزم. تأكد من الاتصال بالإنترنت.") + "\n" + last)
            return
        failed = st.missing_after(job.packages)
        if not failed:
            msg = _("تم التثبيت.")
            if self.need_restart:
                msg += " " + _("أعد تشغيل الواجهة (الأزرق) ليعمل ما ثبّتّه.")
            self["status"].setText(msg)
        else:
            self["status"].setText(_("لم يتم تثبيت: %s") % ", ".join(failed) + "\n" + last)

    def _closed(self):
        try:
            self.timer.stop()
        except Exception:
            pass
