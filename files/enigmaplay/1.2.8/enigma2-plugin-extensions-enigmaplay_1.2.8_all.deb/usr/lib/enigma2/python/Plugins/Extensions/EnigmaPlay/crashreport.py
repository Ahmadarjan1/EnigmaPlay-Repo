# -*- coding: utf-8 -*-
"""
Automatic crash reports for store plugins.

After a boot, new Enigma2 crash logs (enigma2_crash*.log) are scanned. When the Python traceback
points into the folder of a plugin installed from the store, a short anonymous report
(plugin id + version, image, python, arch, box model, the traceback) is sent to the API so the
plugin's developer can see it in the developer portal. Old crash logs are never sent.
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import glob
import io
import json
import os
import re
import time

CRASH_DIRS = ("/home/root/logs", "/home/root", "/media/hdd/logs", "/media/hdd", "/media/usb/logs", "/tmp")
CRASH_NAME_RE = re.compile(r"^enigma2_crash.*\.log$", re.I)      # OpenViX: Enigma2_crash_<date>.log
STATE_FILE = "/etc/enigma2/enigmaplay/crash_state.json"
PREFIX_RE = re.compile(r"^(?:<\s*[\d.]+> ?)?(?:\[?\d{2}:\d{2}:\d{2}(?:\.\d+)?\]? )?")   # "<513817.85> 15:03:22.1061 " (keeps indentation)
PLUGIN_RE = re.compile(r"/Plugins/(?:Extensions|SystemPlugins)/([^/]+)/")
MAX_PER_BOOT = 5


def _log(msg):
    try:
        with io.open("/tmp/enigmaplay_crash.log", "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (time.strftime("%H:%M:%S"), msg))
    except Exception:
        pass


def _load_state():
    try:
        with io.open(STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _save_state(st):
    try:
        with io.open(STATE_FILE, "w", encoding="utf-8") as f:
            f.write(json.dumps(st))
    except Exception:
        pass


def new_crash_files():
    files = []
    for d in CRASH_DIRS:
        try:
            names = os.listdir(d)
        except Exception:
            continue
        files.extend(os.path.join(d, n) for n in names if CRASH_NAME_RE.match(n))
    files = sorted(set(files), key=lambda p: os.path.getmtime(p))
    st = _load_state()
    if st is None:
        # first run: remember where we are, never send crashes that happened before
        _save_state({"last": max([os.path.getmtime(p) for p in files] or [time.time()])})
        return []
    last = st.get("last", 0)
    return [p for p in files if os.path.getmtime(p) > last]


def extract_trace(path):
    """Last Python traceback in a crash log (prefixes removed), or ''."""
    try:
        with open(path, "rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 400 * 1024))
            text = f.read().decode("utf-8", "replace")
    except Exception:
        return ""
    lines = [PREFIX_RE.sub("", l.rstrip("\r")) for l in text.split("\n")]
    start = None
    for i, l in enumerate(lines):
        if l.strip().startswith("Traceback (most recent call last)"):
            start = i
    if start is None:
        return ""
    out = [lines[start].strip()]
    for l in lines[start + 1:start + 120]:
        if not l.strip():
            continue
        out.append(l)
        if not l.startswith((" ", "\t")) and not l.strip().startswith(("File ", "^", "~")):
            break                                   # the "SomeError: message" line ends the block
    return "\n".join(out[:80])


def store_plugin_for(trace, installed):
    """installed: {plugin folder (lower): item}. Blame the deepest frame inside a store plugin."""
    hit = None
    for m in PLUGIN_RE.finditer(trace):
        it = installed.get(m.group(1).lower())
        if it is not None:
            hit = it
    return hit


def run(catalog_items):
    """Scan for new crash logs and report the ones caused by store plugins. Returns count sent."""
    import account
    import installer
    try:
        from backup import _plugin_dirs
    except Exception:
        return 0
    files = new_crash_files()
    if not files:
        return 0
    installed = {}
    versions = {}
    for it in catalog_items:
        try:
            st, ver = installer.get_item_state(it)
            if st == "none":
                continue
            pkg = installer.find_installed_package(it)[0]
            for d in _plugin_dirs(pkg):
                installed[d.lower()] = it
            versions[it.key] = ver or it.version
        except Exception:
            continue
    info = account.device_info()
    sent = 0
    seen = set()
    for path in files[-MAX_PER_BOOT:]:
        trace = extract_trace(path)
        it = store_plugin_for(trace, installed) if trace else None
        _log("%s -> %s" % (os.path.basename(path), it.key if it else "not a store plugin"))
        if it is None or (it.key, trace) in seen:
            continue
        seen.add((it.key, trace))
        try:
            account.request("POST", "/v1/crash", {
                "id": it.key, "version": versions.get(it.key, ""), "device": account.device_id(),
                "trace": trace, "image": info.get("image", ""), "python": info.get("python", ""),
                "arch": info.get("arch", ""), "model": info.get("model", ""),
            })
            sent += 1
        except Exception as e:
            _log("report failed: %r" % e)
    _save_state({"last": max(os.path.getmtime(p) for p in files)})
    return sent
