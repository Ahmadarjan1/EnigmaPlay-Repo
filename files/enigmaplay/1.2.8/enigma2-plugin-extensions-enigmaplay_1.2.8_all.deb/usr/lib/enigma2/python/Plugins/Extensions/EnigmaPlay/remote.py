# -*- coding: utf-8 -*-
"""
Install from the phone.

The box registers itself with the account (POST /v1/box/hello) and keeps ONE streaming
connection to ntfy.sh/<topic>. When the user taps "install" on the phone, the API sends a
wake-up ping (no data) to that topic; the box then fetches its commands from the API with its
own login token, installs, and reports the result. Nothing polls the API in a loop.
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import hashlib
import json
import subprocess
import threading
import time

import account
import catalog
import installer
try:
    from i18n import _
except Exception:
    _ = lambda t: t

NTFY = "https://ntfy.sh"
AGENT = None


def _log(msg):
    try:
        import io
        with io.open("/tmp/enigmaplay_remote.log", "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (time.strftime("%H:%M:%S"), msg))
    except Exception:
        pass


def topic():
    return "ep-" + hashlib.sha256(("ntfy:" + account.device_id()).encode("utf-8")).hexdigest()[:32]


def enabled():
    try:
        import settings
        return bool(settings.get("allow_remote"))
    except Exception:
        return True


def poke(hello=False):
    """Ask the agent to check for commands now (e.g. when the store opens or after login)."""
    if AGENT is not None:
        AGENT.request_check(hello=hello)


class RemoteAgent(object):
    def __init__(self, session):
        from enigma import eTimer
        self.session = session
        self.lock = threading.Lock()
        self.want_check = False
        self.want_hello = True
        self.busy = False
        self.results = []
        self.queue = []
        self.job = None
        self.timer = eTimer()
        self.timer.callback.append(self.tick)
        self.timer.start(2000, False)
        t = threading.Thread(target=self.listen)
        t.daemon = True
        t.start()

    # ---------------------------------------------------------------- background
    def request_check(self, hello=False):
        with self.lock:
            self.want_check = True
            if hello:
                self.want_hello = True

    def listen(self):
        """Keep a streaming connection to ntfy.sh; any message = check for commands."""
        time.sleep(20)
        while True:
            if not account.is_logged_in() or not enabled():
                time.sleep(60)
                continue
            url = "%s/%s/json" % (NTFY, topic())
            try:
                self._stream_urllib(url)
            except Exception as e:
                _log("urllib stream ended: %r" % e)
                try:
                    self._stream_curl(url)
                except Exception as e2:
                    _log("curl stream ended: %r" % e2)
            time.sleep(15)

    def _on_line(self, line):
        try:
            d = json.loads(line)
        except Exception:
            return
        if d.get("event") == "message":
            _log("wake-up received")
            self.request_check()

    def _stream_urllib(self, url):
        try:
            from urllib.request import Request, urlopen
        except ImportError:
            from urllib2 import Request, urlopen
        resp = urlopen(Request(url, headers={"User-Agent": "EnigmaPlay"}), timeout=120)
        while True:
            line = resp.readline()
            if not line:
                return
            self._on_line(line.decode("utf-8", "ignore"))

    def _stream_curl(self, url):
        p = subprocess.Popen(["curl", "-s", "-k", "-N", "--max-time", "3600", url], stdout=subprocess.PIPE)
        try:
            for line in iter(p.stdout.readline, b""):
                self._on_line(line.decode("utf-8", "ignore"))
        finally:
            try:
                p.kill()
            except Exception:
                pass

    def _fetch(self, hello):
        """(commands, catalog) - runs in a worker thread."""
        if hello:
            info = account.device_info()
            d = account._authed("POST", "/v1/box/hello", {
                "device": account.device_id(), "model": info.get("model", ""),
                "image": info.get("image", ""), "topic": topic()})
        else:
            d = account._authed("GET", "/v1/box/commands?device=" + account.device_id())
        cmds = d.get("commands", []) or []
        if hello and cmds:
            # hello returns pending ones without marking them; take them now
            d = account._authed("GET", "/v1/box/commands?device=" + account.device_id())
            cmds = d.get("commands", []) or []
        cat = None
        if cmds:
            cat, _online, _m = catalog.fetch_remote_index()
        return cmds, cat

    def _worker(self, hello):
        try:
            res = ("ok",) + self._fetch(hello)
        except Exception as e:
            res = ("err", e, None)
        with self.lock:
            self.results.append(res)

    def report(self, cmd_id, ok, message):
        def run():
            try:
                account._authed("POST", "/v1/box/commands/%s" % cmd_id, {"ok": ok, "message": message})
            except Exception as e:
                _log("report failed: %r" % e)
        t = threading.Thread(target=run)
        t.daemon = True
        t.start()

    # ---------------------------------------------------------------- UI thread
    def tick(self):
        with self.lock:
            results, self.results = self.results, []
            check = self.want_check or self.want_hello
            hello = self.want_hello
        for r in results:
            self.busy = False
            if r[0] == "ok":
                cmds, cat = r[1], r[2]
                for c in cmds:
                    self.queue.append((c, cat))
                if cmds:
                    _log("received %d command(s)" % len(cmds))
            else:
                _log("fetch failed: %r" % (r[1],))
        if check and not self.busy and account.is_logged_in() and enabled():
            with self.lock:
                self.want_check = False
                self.want_hello = False
            self.busy = True
            t = threading.Thread(target=self._worker, args=(hello,))
            t.daemon = True
            t.start()
        if self.job is None and self.queue:
            self.run_next()

    def notify(self, text, ask_restart=False):
        text = "  %s  " % text            # the image's message box clips the first RTL letter
        try:
            from Tools import Notifications
            from Screens.MessageBox import MessageBox
            if ask_restart:
                Notifications.AddNotificationWithCallback(self._restart_answer, MessageBox, text, MessageBox.TYPE_YESNO, timeout=30)
            else:
                Notifications.AddPopup(text, MessageBox.TYPE_INFO, 8, "EnigmaPlayRemote")
        except Exception as e:
            _log("notify failed: %r" % e)

    def _restart_answer(self, yes):
        if yes:
            try:
                from Screens.Standby import TryQuitMainloop
                self.session.open(TryQuitMainloop, 3)
            except Exception:
                pass

    def run_next(self):
        cmd, cat = self.queue.pop(0)
        cid, action, pid = cmd.get("id"), cmd.get("action", "install"), cmd.get("plugin_id")
        item = cat.get(pid) if cat is not None else None
        if item is None:
            self.report(cid, False, "not found in the store index")
            return
        state = installer.get_item_state(item)[0]
        if action == "install" and state == "installed":
            self.report(cid, True, _("مثبّت مسبقاً"))
            return
        if action == "install" and getattr(item, "dangerous", False):
            self.report(cid, False, _("هذا البلجن يحتاج تأكيداً على الرسيفر"))
            return
        if action == "install" and not installer.is_item_compatible(item):
            self.report(cid, False, "not compatible with this box")
            return
        job_action = "remove" if action == "remove" else ("update" if state == "update" else "install")
        self.notify(_("جاري تثبيت %s من الجوال…") % item.name)
        _log("start %s %s" % (job_action, pid))

        def finish(job, rc, msg):
            self.job = None
            ok = (rc == 0)
            ver = installer.get_item_state(item)[1] or item.version
            self.report(cid, ok, ("v%s" % ver) if ok else (msg or "rc=%s" % rc)[:200])
            if ok and action == "install":
                try:
                    account.report_install_async(item.key)
                    t = threading.Thread(target=account.push_plugins,
                                         args=([{"id": item.key, "name": item.name, "version": ver}],))
                    t.daemon = True
                    t.start()
                except Exception:
                    pass
            if action == "remove":
                text = _("تمت إزالة %s من الجوال") % item.name if ok else _("فشل تثبيت %s من الجوال") % item.name
                self.notify(text)
            elif ok and (getattr(item, "restart", False) or item.category in ("skins", "softcams")):
                self.notify(_("تم تثبيت %s من الجوال. يلزم إعادة تشغيل الواجهة لتفعيل التغييرات. إعادة التشغيل الآن؟") % item.name,
                            ask_restart=True)
            else:
                self.notify((_("تم تثبيت %s من الجوال") if ok else _("فشل تثبيت %s من الجوال")) % item.name)

        def unverified(job, on_confirm, on_cancel):
            on_cancel()   # unsigned scripts need a confirmation on the TV: never run them remotely

        self.job = installer.InstallJob(item, on_finish=finish, on_unverified=unverified, action=job_action)
        try:
            self.job.start()
        except Exception as e:
            self.job = None
            self.report(cid, False, "error: %s" % e)


def start(session):
    global AGENT
    if AGENT is None:
        AGENT = RemoteAgent(session)
    return AGENT
