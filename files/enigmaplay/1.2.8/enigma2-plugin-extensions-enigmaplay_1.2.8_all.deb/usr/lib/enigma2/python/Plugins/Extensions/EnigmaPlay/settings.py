# -*- coding: utf-8 -*-
"""EnigmaPlay user settings (/etc/enigma2/enigmaplay/settings.json)."""
from __future__ import print_function, unicode_literals, absolute_import, division
import io
import json
import os

SETTINGS_FILE = "/etc/enigma2/enigmaplay/settings.json"

# key -> (default, [(value, Arabic label), ...], Arabic title)
OPTIONS = {
    "restart_after_install": ("ask", [("ask", "اسألني"), ("auto", "تلقائياً"), ("never", "لا")],
                              "إعادة التشغيل بعد التثبيت"),
    "catalog_ttl": (3600, [(3600, "كل ساعة"), (21600, "كل 6 ساعات"), (86400, "يومياً")],
                    "تحديث قائمة البلجنات"),
    "show_incompatible": (False, [(False, "لا"), (True, "نعم")],
                          "إظهار غير المتوافق مع جهازي"),
    "auto_sync": (True, [(True, "تشغيل"), (False, "إيقاف")],
                  "المزامنة التلقائية مع حسابي"),
    "notify_updates": (True, [(True, "تشغيل"), (False, "إيقاف")],
                       "تنبيه التحديثات عند تشغيل الجهاز"),
    "crash_reports": (True, [(True, "تشغيل"), (False, "إيقاف")],
                      "إرسال تقارير الأعطال للمطوّرين"),
    "allow_remote": (True, [(True, "تشغيل"), (False, "إيقاف")],
                     "التثبيت من الجوال"),
}
ORDER = ["restart_after_install", "catalog_ttl", "show_incompatible", "auto_sync", "notify_updates", "crash_reports",
         "allow_remote"]

_cache = {}


def _load():
    if _cache:
        return _cache
    data = {}
    try:
        with io.open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        pass
    for k, (default, choices, _) in OPTIONS.items():
        v = data.get(k, default)
        if v not in [c[0] for c in choices]:
            v = default
        _cache[k] = v
    return _cache


def get(key):
    return _load().get(key, OPTIONS[key][0])


def set(key, value):
    _load()[key] = value
    try:
        d = os.path.dirname(SETTINGS_FILE)
        if not os.path.isdir(d):
            os.makedirs(d)
        with io.open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            f.write(json.dumps(_cache, ensure_ascii=False, indent=2))
    except Exception:
        pass


def cycle(key, step=1):
    """Move to the next (step=1) or previous (step=-1) choice and return it."""
    choices = [c[0] for c in OPTIONS[key][1]]
    cur = get(key)
    nxt = choices[(choices.index(cur) + step) % len(choices)] if cur in choices else choices[0]
    set(key, nxt)
    return nxt


def label(key):
    """'Title: value-label' for the settings menu."""
    default, choices, title = OPTIONS[key]
    cur = get(key)
    val = dict(choices).get(cur, str(cur))
    try:
        from i18n import _
    except Exception:
        _ = lambda t: t
    if key != "language":
        val = _(val)
    elif cur == "auto":
        val = _("تلقائي (لغة الجهاز)")
    return "%s: %s" % (_(title), val)

# appearance (needs a GUI restart to apply)
OPTIONS["theme"] = ("dark", [("dark", "داكن"), ("light", "فاتح")], "المظهر")
ORDER.insert(0, "theme")

# language (needs a GUI restart to apply); values are native names, not translated
try:
    from i18n import LANGUAGES as _LANGS
except Exception:
    _LANGS = [("auto", "Auto"), ("ar", "العربية"), ("en", "English")]
OPTIONS["language"] = ("auto", list(_LANGS), "اللغة")
ORDER.insert(0, "language")
