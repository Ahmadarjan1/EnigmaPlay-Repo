# -*- coding: utf-8 -*-
"""
Plain-language explanation of a plugin crash for the box owner.

crashreport.py saves one notice per new crash (any plugin, store or not). The next time the store
opens it shows the newest one: what happened, in Arabic, and one button that usually fixes it
(restart the GUI / reinstall). Nothing is sent anywhere from here.
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import io
import json
import os
import re
import time

NOTICE_FILE = "/etc/enigma2/enigmaplay/crash_notices.json"
MAX_AGE = 3 * 86400          # older crashes are not worth a popup any more

_RULES = (
    ("space", re.compile(r"no space left|errno 28", re.I)),
    ("restart", re.compile(r"importerror|cannot import name|modulenotfounderror|no module named|"
                           r"module '[^']+' has no attribute", re.I)),
    ("time", re.compile(r"certificate|ssl", re.I)),
    ("missing", re.compile(r"filenotfounderror|no such file or directory", re.I)),
)


def classify(error):
    for kind, rx in _RULES:
        if rx.search(error or ""):
            return kind
    return "plugin"


def _load():
    try:
        with io.open(NOTICE_FILE, "r", encoding="utf-8") as f:
            v = json.load(f)
            return v if isinstance(v, list) else []
    except Exception:
        return []


def _save(lst):
    try:
        d = os.path.dirname(NOTICE_FILE)
        if not os.path.isdir(d):
            os.makedirs(d)
        tmp = NOTICE_FILE + ".tmp"
        with io.open(tmp, "w", encoding="utf-8") as f:
            f.write(json.dumps(lst[-10:], ensure_ascii=False))
        os.rename(tmp, NOTICE_FILE)
    except Exception:
        pass


def remember(key, name, error, when=None):
    """key: store id or None (plugin not from the store); name: what the user sees."""
    lst = [n for n in _load() if not (n.get("name") == name and n.get("error") == error)]
    lst.append({"key": key, "name": name, "error": (error or "")[:300], "kind": classify(error),
                "t": int(when or time.time())})
    _save(lst)


def next_notice():
    now = time.time()
    lst = [n for n in _load() if now - n.get("t", 0) < MAX_AGE]
    return lst[-1] if lst else None


def done(notice):
    _save([n for n in _load() if n.get("t") != notice.get("t") or n.get("name") != notice.get("name")])


def explain(notice, _=lambda s: s):
    """(title, body, action) action: "restart" | "reinstall" | None"""
    name = notice.get("name") or "?"
    kind = notice.get("kind")
    title = _("بلجن %s وقف عن العمل") % name
    if kind == "space":
        return title, _("السبب: ذاكرة الجهاز ممتلئة، فما قدر البلجن يحفظ ملفاته.\nالحل: احذف بلجنات ما بتستعملها أو صور القنوات الكبيرة، وبعدين أعد تشغيل الواجهة."), None
    if kind == "restart":
        return title, _("السبب: البلجن تحدّث أو انثبت والواجهة لسا ما انعادت، فاشتغل بجزء من كوده القديم.\nالحل: أعد تشغيل الواجهة. إذا تكرر، أعد تثبيت البلجن."), "restart"
    if kind == "time":
        return title, _("السبب: البلجن ما قدر يتصل بالإنترنت بأمان، وغالباً تاريخ أو وقت الرسيفر غلط.\nالحل: صحّح التاريخ والوقت من إعدادات الرسيفر."), None
    if kind == "missing":
        return title, _("السبب: في ملف ناقص للبلجن أو ما انحفظ.\nالحل: أعد تثبيت البلجن."), ("reinstall" if notice.get("key") else None)
    return title, _("السبب: خطأ داخل البلجن نفسه، مش من المتجر. انبعت تقرير لمطوّره.\nإذا تكرر: أعد تشغيل الواجهة أو أعد تثبيت البلجن."), ("reinstall" if notice.get("key") else "restart")
