# -*- coding: utf-8 -*-
"""System tools section: libraries and tools plugins need (Python modules, players, codecs, network
and disk tools), installed from the image's own package feed with opkg / apt.

The list comes from the store (index.json "system_tools", signed). For each tool the store knows
the package names per Python version ("3", "2") or for any image ("any"); the first name the feed
has is installed (all of them when "all" is set). Nothing is ever removed from here.
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import gzip
import io
import os
import re
import subprocess
import threading
import time

from .i18n import LANG, _

LOG = "/tmp/enigmaplay-systools.log"
OPKG_STATUS = ("/var/lib/opkg/status", "/usr/lib/opkg/status", "/var/opkg/status")
OPKG_LISTS = ("/var/lib/opkg/lists", "/var/opkg-lists", "/run/opkg-lists", "/var/cache/opkg")
DPKG_STATUS = "/var/lib/dpkg/status"
APT_LISTS = "/var/lib/apt/lists"
LISTS_FRESH = 6 * 3600          # package lists older than this are refreshed when the screen opens


def _log(msg):
    try:
        with io.open(LOG, "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (time.strftime("%H:%M:%S"), msg))
    except Exception:
        pass


def text(d):
    """{ar, en} -> the string for the store's language (English for every non-Arabic language)."""
    if not isinstance(d, dict):
        return "%s" % (d or "")
    return d.get(LANG) or (d.get("ar") if LANG == "ar" else d.get("en")) or d.get("en") or d.get("ar") or ""


def sysinfo():
    from . import installer
    return installer.get_system_info()


def package_manager():
    return sysinfo().get("pm")


def candidates(item):
    """Package names for this receiver, most wanted first."""
    pk = item.get("packages") or {}
    py = str(sysinfo().get("py_major") or "3")
    return list(pk.get(py) or []) + list(pk.get("any") or [])


# ------------------------------------------------------------------ what is installed / available
def _read(path):
    with open(path, "rb") as f:
        data = f.read()
    if data[:2] == b"\x1f\x8b":
        data = gzip.decompress(data) if hasattr(gzip, "decompress") else gzip.GzipFile(fileobj=io.BytesIO(data)).read()
    return data.decode("utf-8", "replace")


def installed_packages():
    """{name} of packages the image's package manager has installed."""
    out = set()
    paths = [DPKG_STATUS] if package_manager() == "dpkg" else list(OPKG_STATUS)
    for path in paths:
        if not os.path.exists(path):
            continue
        try:
            name = None
            for line in _read(path).splitlines():
                if line.startswith("Package:"):
                    name = line[8:].strip()
                elif line.startswith("Status:") and name and " installed" in line and "not-installed" not in line:
                    out.add(name)
        except Exception as e:
            _log("status %s: %r" % (path, e))
    return out


def _list_files():
    if package_manager() == "dpkg":
        if os.path.isdir(APT_LISTS):
            return [os.path.join(APT_LISTS, f) for f in os.listdir(APT_LISTS) if f.endswith("_Packages")]
        return []
    out = []
    dirs = list(OPKG_LISTS)
    try:     # the lists folder the image configured ("option lists_dir ext /var/lib/opkg/lists")
        for conf in ["/etc/opkg/opkg.conf"] + ["/etc/opkg/" + f for f in os.listdir("/etc/opkg") if f.endswith(".conf")]:
            for line in io.open(conf, encoding="utf-8", errors="replace"):
                m = re.match(r"\s*option\s+lists_dir\s+\S+\s+(\S+)", line)
                if m and m.group(1) not in dirs:
                    dirs.insert(0, m.group(1))
    except Exception:
        pass
    for d in dirs:
        if os.path.isdir(d):
            out.extend(os.path.join(d, f) for f in os.listdir(d) if not f.startswith("."))
    return [f for f in out if os.path.isfile(f)]


def lists_age():
    """Seconds since the package lists were downloaded (None: never)."""
    files = _list_files()
    if not files:
        return None
    return time.time() - max(os.path.getmtime(f) for f in files)


def available_packages():
    """{name} the image's feeds offer (from the downloaded package lists)."""
    out = set()
    for path in _list_files():
        try:
            for line in _read(path).splitlines():
                if line.startswith("Package:"):
                    out.add(line[8:].strip())
        except Exception as e:
            _log("list %s: %r" % (path, e))
    return out


def state(item, installed, available):
    """("installed" | "missing" | "unavailable", [packages to install])."""
    names = candidates(item)
    have = [n for n in names if n in installed]
    files = [f for f in item.get("files") or [] if os.path.exists(f)]
    if item.get("all"):
        todo = [n for n in names if n not in installed and n in available]
        if have and not todo:
            return "installed", []
        return ("missing", todo) if todo else (("installed", []) if have else ("unavailable", []))
    if have or files:
        return "installed", []
    for n in names:
        if n in available:
            return "missing", [n]
    return "unavailable", []


# ------------------------------------------------------------------ running opkg / apt
class Job(object):
    """Runs the package manager in a thread; the screen polls .done / .lines / .ok."""

    def __init__(self, kind, packages=None):
        self.kind = kind                    # "update" | "install"
        self.packages = list(packages or [])
        self.lines = []
        self.done = False
        self.ok = False
        self.current = ""
        t = threading.Thread(target=self._run)
        t.daemon = True
        t.start()

    def _cmd(self, args):
        _log("$ " + " ".join(args))
        try:
            env = dict(os.environ, DEBIAN_FRONTEND="noninteractive", LANG="C", LC_ALL="C")
            p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
            for raw in iter(p.stdout.readline, b""):
                line = raw.decode("utf-8", "replace").rstrip()
                if line:
                    self.lines.append(line)
                    self.lines = self.lines[-40:]
                    _log(line)
            p.wait()
            return p.returncode == 0
        except Exception as e:
            self.lines.append("%r" % e)
            _log("failed: %r" % e)
            return False

    def _run(self):
        pm = package_manager()
        try:
            if self.kind == "remove":
                ok = True
                for n in self.packages:          # no --force: the package manager refuses what others need
                    self.current = n
                    ok = self._cmd(["apt-get", "remove", "-y", "--no-auto-remove", n] if pm == "dpkg"
                                   else ["opkg", "remove", n]) and ok
                self.ok = ok
            elif pm == "dpkg":
                if self.kind == "update":
                    self.ok = self._cmd(["apt-get", "update"])
                else:
                    self.ok = self._cmd(["apt-get", "install", "-y", "--no-remove"] + self.packages)
            elif pm == "opkg":
                if self.kind == "update":
                    self.ok = self._cmd(["opkg", "update"])
                else:
                    ok = True
                    for n in self.packages:      # one by one: a missing dependency does not stop the rest
                        self.current = n
                        ok = self._cmd(["opkg", "install", n]) and ok
                    self.ok = ok
            else:
                self.lines.append("no package manager")
        finally:
            self.done = True


def missing_after(packages):
    """Names from packages that are still not installed (to tell the user what failed)."""
    inst = installed_packages()
    return [n for n in packages if n not in inst]


def still_installed(packages):
    inst = installed_packages()
    return [n for n in packages if n in inst]


# ------------------------------------------------------------------ drivers and removable packages (built from the feed)
WIFI_KM = ("rt2800usb", "rt73usb", "rt2500usb", "rtl8187", "rtl8192cu", "rtl8xxxu", "r8188eu", "8188eu", "8192eu",
           "8812au", "88x2bu", "8821cu", "mt7601u", "mt76x0u", "mt76x2u", "mt7921u", "ath9k-htc", "carl9170", "zd1211rw",
           "rtl8192u", "r8712u")
DRIVER_RE = re.compile(r"^(enigma2-plugin-drivers-[a-z0-9.+-]+|firmware-[a-z0-9.+-]+|kernel-module-(%s|dvb-usb-[a-z0-9-]+|em28xx[a-z0-9-]*))$"
                       % "|".join(re.escape(x) for x in WIFI_KM))


def _pretty(name):
    n = re.sub(r"^(enigma2-plugin-drivers-|kernel-module-)", "", name)
    return n


def driver_groups(available, installed):
    """Wi-Fi and USB tuner drivers and firmware the image's feed offers, grouped."""
    groups = {"wifi": [], "dvb": [], "firmware": []}
    for n in sorted((available | installed)):
        if not DRIVER_RE.match(n):
            continue
        if n.startswith("firmware-"):
            g = "firmware"
        elif "dvb" in n or "em28xx" in n:
            g = "dvb"
        else:
            g = "wifi"
        groups[g].append({"id": n, "name": _pretty(n), "desc": {"ar": n, "en": n}, "packages": {"any": [n]}})
    names = {"wifi": {"ar": "تعريفات الواي فاي", "en": "Wi-Fi drivers"},
             "dvb": {"ar": "تعريفات التيونر USB", "en": "USB tuner drivers"},
             "firmware": {"ar": "ملفات Firmware", "en": "Firmware"}}
    return [{"id": k, "name": names[k], "items": groups[k]} for k in ("wifi", "dvb", "firmware") if groups[k]]


REMOVABLE = (("extensions", {"ar": "بلجنات", "en": "Plugins"}), ("softcams", {"ar": "إيميوهات", "en": "Softcams"}),
             ("skins", {"ar": "سكنات", "en": "Skins"}), ("picons", {"ar": "بيكونات", "en": "Picons"}))
PROTECTED = ("enigma2-plugin-extensions-enigmaplay",)


def removable_groups(installed):
    """Installed plugins, softcams, skins and picons (never system plugins or the store itself)."""
    out = []
    for kind, name in REMOVABLE:
        pre = "enigma2-plugin-%s-" % kind
        items = [{"id": n, "name": n[len(pre):], "desc": {"ar": n, "en": n}, "packages": {"any": [n]}}
                 for n in sorted(installed) if n.startswith(pre) and n not in PROTECTED]
        if items:
            out.append({"id": kind, "name": name, "items": items})
    return out


# ------------------------------------------------------------------ actions (DNS, fixes, disk, backup, ...)
def _sh(args, timeout=60):
    try:
        p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        out = p.communicate()[0]
        _log("$ %s -> %s" % (" ".join(args), p.returncode))
        return p.returncode == 0, out.decode("utf-8", "replace").strip()
    except Exception as e:
        _log("$ %s failed: %r" % (" ".join(args), e))
        return False, "%r" % e


def _which(name):
    for d in ("/usr/bin", "/bin", "/usr/sbin", "/sbin", "/usr/local/bin"):
        if os.path.exists(os.path.join(d, name)):
            return os.path.join(d, name)
    return None


DATA_DIR = "/etc/enigma2/enigmaplay"
DNS_BACKUP = os.path.join(DATA_DIR, "resolv.conf.orig")
DNS_SERVERS = (("google", "Google", ("8.8.8.8", "8.8.4.4")),
               ("cloudflare", "Cloudflare", ("1.1.1.1", "1.0.0.1")),
               ("quad9", "Quad9", ("9.9.9.9", "149.112.112.112")),
               ("opendns", "OpenDNS", ("208.67.222.222", "208.67.220.220")),
               ("adguard", "AdGuard", ("94.140.14.14", "94.140.15.15")))


def current_dns():
    try:
        return [l.split()[1] for l in io.open("/etc/resolv.conf", encoding="utf-8", errors="replace")
                if l.strip().startswith("nameserver") and len(l.split()) > 1]
    except Exception:
        return []


def _write_dns(servers):
    try:      # the image's own network settings, so the choice survives a restart
        from Components.Network import iNetwork
        iNetwork.clearNameservers()
        for sv in servers:
            iNetwork.addNameserver([int(x) for x in sv.split(".")])
        iNetwork.writeNameserverConfig()
    except Exception as e:
        _log("iNetwork: %r" % e)
    if current_dns()[:len(servers)] != list(servers):
        with io.open("/etc/resolv.conf", "w", encoding="utf-8") as f:
            f.write("".join("nameserver %s\n" % sv for sv in servers))


def set_dns(servers):
    if not os.path.exists(DNS_BACKUP) and os.path.exists("/etc/resolv.conf"):
        try:
            if not os.path.isdir(DATA_DIR):
                os.makedirs(DATA_DIR)
            import shutil
            shutil.copy2("/etc/resolv.conf", DNS_BACKUP)
        except Exception as e:
            _log("dns backup: %r" % e)
    _write_dns(servers)
    now = current_dns()
    return now[:len(servers)] == list(servers), _("خوادم DNS الآن: %s") % ", ".join(now)


def restore_dns():
    if not os.path.exists(DNS_BACKUP):
        return False, _("لا توجد نسخة سابقة من إعدادات DNS.")
    try:
        old = [l.split()[1] for l in io.open(DNS_BACKUP, encoding="utf-8", errors="replace")
               if l.strip().startswith("nameserver") and len(l.split()) > 1]
    except Exception:
        old = []
    if not old:
        return False, _("لا توجد نسخة سابقة من إعدادات DNS.")
    _write_dns(old)
    return True, _("خوادم DNS الآن: %s") % ", ".join(current_dns())


def test_internet():
    import socket
    lines = []
    t = time.time()
    try:
        socket.setdefaulttimeout(6)
        ip = socket.gethostbyname("github.com")
        lines.append(_("DNS يعمل: github.com = %s (%d ms)") % (ip, int((time.time() - t) * 1000)))
    except Exception:
        lines.append(_("DNS لا يعمل: تعذر معرفة عنوان github.com. جرّب تغيير DNS."))
        return False, "\n".join(lines)
    t = time.time()
    try:
        try:
            from urllib.request import urlopen
        except ImportError:
            from urllib2 import urlopen
        urlopen("https://raw.githubusercontent.com/", timeout=8).read(64)
    except Exception as e:
        if "404" not in str(e) and "400" not in str(e):
            lines.append(_("الاتصال الآمن (HTTPS) لا يعمل: %s") % str(e)[:80])
            return False, "\n".join(lines)
    lines.append(_("الاتصال الآمن (HTTPS) يعمل (%d ms)") % int((time.time() - t) * 1000))
    return True, "\n".join(lines)


def sync_time():
    for args in (["ntpdate", "-s", "-u", "pool.ntp.org"], ["ntpdate", "-u", "pool.ntp.org"], ["rdate", "-s", "time.nist.gov"],
                 ["chronyc", "makestep"]):
        if _which(args[0]) and _sh(args, 30)[0]:
            return True, _("الساعة الآن: %s") % time.strftime("%Y-%m-%d %H:%M")
    try:      # no time tool: the Date header of an HTTPS answer
        try:
            from urllib.request import urlopen
        except ImportError:
            from urllib2 import urlopen
        from email.utils import parsedate_tz, mktime_tz
        r = urlopen("https://www.google.com/generate_204", timeout=8)
        ts = mktime_tz(parsedate_tz(r.headers.get("Date")))
        ok = _sh(["date", "-s", "@%d" % ts])[0] or _sh(["date", "-u", "-s", time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(ts))])[0]
        if ok:
            _sh(["hwclock", "-w"])
            return True, _("الساعة الآن: %s") % time.strftime("%Y-%m-%d %H:%M")
    except Exception as e:
        _log("time: %r" % e)
    return False, _("تعذر ضبط الساعة. تأكد من الاتصال بالإنترنت.")


def _meminfo():
    d = {}
    try:
        for l in io.open("/proc/meminfo"):
            k, v = l.split(":", 1)
            d[k] = int(v.split()[0]) * 1024
    except Exception:
        pass
    return d.get("MemAvailable", d.get("MemFree", 0) + d.get("Cached", 0)), d.get("MemTotal", 0)


def free_ram():
    from .imagesdl import human_size
    before = _meminfo()[0]
    _sh(["sync"])
    try:
        with open("/proc/sys/vm/drop_caches", "w") as f:
            f.write("3\n")
    except Exception as e:
        _log("drop_caches: %r" % e)
    after, total = _meminfo()
    return True, _("الذاكرة المتاحة: %s من %s (كانت %s)") % (human_size(after), human_size(total), human_size(before))


def _pm_busy():
    try:
        for pid in os.listdir("/proc"):
            if pid.isdigit():
                try:
                    cmd = open("/proc/%s/cmdline" % pid, "rb").read().split(b"\0")[0]
                except Exception:
                    continue
                if os.path.basename(cmd.decode("utf-8", "replace")) in ("opkg", "apt-get", "apt", "dpkg"):
                    return True
    except Exception:
        pass
    return False


def fix_packages():
    """Clear a stale package-manager lock and finish half-done installs."""
    if _pm_busy():
        return False, _("مدير الحزم يعمل الآن. انتظر حتى ينتهي ثم حاول مجدداً.")
    pm = package_manager()
    locks = ("/var/lib/dpkg/lock", "/var/lib/dpkg/lock-frontend", "/var/cache/apt/archives/lock") if pm == "dpkg" \
        else ("/var/lock/opkg.lock", "/run/opkg.lock", "/var/run/opkg.lock", "/tmp/opkg.lock")
    for l in locks:
        if os.path.exists(l):
            try:
                os.remove(l)
                _log("removed stale lock %s" % l)
            except Exception:
                pass
    if pm == "dpkg":
        ok = _sh(["dpkg", "--configure", "-a"], 300)[0]
        ok = _sh(["apt-get", "update"], 300)[0] and ok
    else:
        _sh(["opkg", "configure"], 300)
        ok = _sh(["opkg", "update"], 300)[0]
    return ok, _("تم إصلاح مدير الحزم وتحديث قائمة الحزم.") if ok else _("تم مسح القفل، لكن تحديث قائمة الحزم فشل. تأكد من الاتصال بالإنترنت.")


def restart_network():
    for args in (["/etc/init.d/networking", "restart"], ["/etc/init.d/network", "restart"]):
        if os.path.exists(args[0]):
            ok = _sh(args, 90)[0]
            return ok, _("تمت إعادة تشغيل الشبكة.") if ok else _("تعذرت إعادة تشغيل الشبكة.")
    return False, _("تعذرت إعادة تشغيل الشبكة.")


def disks_info():
    from .imagesdl import media_candidates, human_size
    lines = []
    for m in media_candidates():
        try:
            st_ = os.statvfs(m)
            total = st_.f_blocks * st_.f_frsize
            free = st_.f_bavail * st_.f_frsize
            fs = ""
            for l in io.open("/proc/mounts"):
                parts = l.split()
                if len(parts) > 2 and parts[1] == os.path.realpath(m):
                    fs = parts[2]
            lines.append("%s   %s / %s   %s" % (m, human_size(free), human_size(total), fs))
        except Exception:
            pass
    if not lines:
        return False, _("لا يوجد قرص أو فلاشة مركّبة.")
    return True, _("المساحة الفارغة / الكلية:") + "\n" + "\n".join(lines)


def main_storage():
    from .imagesdl import media_candidates
    c = media_candidates()
    for pref in ("/media/hdd", "/media/usb"):
        if pref in c:
            return pref
    return c[0] if c else None


def make_folders():
    m = main_storage()
    if not m:
        return False, _("لا يوجد قرص أو فلاشة مركّبة.")
    made = []
    for d in ("movie", "picon", "timeshift", "backup", "imagebackups", "ImagesUpload"):
        p = os.path.join(m, d)
        if not os.path.isdir(p):
            try:
                os.makedirs(p)
                made.append(d)
            except Exception:
                pass
    return True, (_("تم إنشاء المجلدات في %s: %s") % (m, ", ".join(made))) if made else _("كل المجلدات موجودة مسبقاً في %s.") % m


def disk_standby():
    if not _which("hdparm"):
        return False, _("أداة hdparm غير مثبتة. ثبّتها من «المكتبات والأدوات».")
    done = []
    for dev in sorted(os.listdir("/dev")):
        if re.match(r"^sd[a-z]$", dev):
            if _sh(["hdparm", "-S", "120", "/dev/" + dev])[0]:
                done.append(dev)
    return bool(done), (_("القرص سيدخل السكون بعد 10 دقائق بدون استعمال: %s") % ", ".join(done)) if done else _("لا يوجد قرص صلب يدعم السكون.")


def system_info():
    from .imagesdl import current_image, model_candidates, human_size
    si = sysinfo()
    up = ""
    try:
        sec = int(float(open("/proc/uptime").read().split()[0]))
        up = "%dd %02d:%02d" % (sec // 86400, sec % 86400 // 3600, sec % 3600 // 60)
    except Exception:
        pass
    kernel = ""
    try:
        kernel = os.uname()[2]
    except Exception:
        pass
    avail, total = _meminfo()
    lines = ["%s  ·  %s" % ((model_candidates() or ["?"])[0].upper(), (current_image() or "?").capitalize()),
             "Python %s  ·  %s  ·  kernel %s" % (si.get("py"), si.get("arch"), kernel),
             "RAM %s / %s  ·  uptime %s" % (human_size(avail), human_size(total), up),
             "DNS %s" % ", ".join(current_dns())]
    return True, "\n".join(lines)


# ------------------------------------------------------------------ install from a file
PKG_EXT = (".ipk", ".deb", ".tar.gz", ".tgz")


def local_packages():
    """Package files the user copied to /tmp or the top of a USB stick / disk."""
    from .imagesdl import media_candidates
    out = []
    for d in ["/tmp"] + media_candidates():
        try:
            for f in sorted(os.listdir(d)):
                p = os.path.join(d, f)
                if f.lower().endswith(PKG_EXT) and os.path.isfile(p) and not f.startswith("enigmaplay-"):
                    out.append(p)
        except Exception:
            pass
    return out


def _tar_ok(path):
    import tarfile
    try:
        with tarfile.open(path, "r:*") as tf:
            names = tf.getnames()
    except Exception:
        return False
    for n in names:
        n2 = n.lstrip("./")
        if not n2:
            continue
        if n.startswith("/") or ".." in n2.split("/") or n2.split("/")[0] not in ("usr", "etc", "media", "var", "home", "lib"):
            return False
    return bool(names)


def install_file(path):
    low = path.lower()
    pm = package_manager()
    if low.endswith(".ipk") and pm == "opkg":
        ok, out = _sh(["opkg", "install", path], 600)
    elif low.endswith(".deb") and pm == "dpkg":
        ok, out = _sh(["apt-get", "install", "-y", path], 600)
        if not ok:
            ok, out = _sh(["dpkg", "-i", path], 600)
    elif low.endswith((".tar.gz", ".tgz")):
        if not _tar_ok(path):
            return False, _("هذا الملف لا يُفك على النظام مباشرة (يجب أن يحتوي مجلدات مثل usr أو etc).")
        ok, out = _sh(["tar", "-xzf", path, "-C", "/"], 600)
    else:
        return False, _("هذا النوع من الملفات لا يناسب صورتك.")
    last = out.splitlines()[-1] if out else ""
    return ok, (_("تم تثبيت %s.") % os.path.basename(path)) if ok else (_("فشل تثبيت %s.") % os.path.basename(path) + "\n" + last[:120])


# ------------------------------------------------------------------ backup / restore of settings
BACKUP_DIR = "enigmaplay-backup"
BACKUP_SETS = {
    "channels": ("/etc/enigma2/lamedb", "/etc/enigma2/lamedb5", "/etc/enigma2/*.tv", "/etc/enigma2/*.radio",
                 "/etc/enigma2/blacklist", "/etc/enigma2/whitelist", "/etc/tuxbox/satellites.xml"),
    "settings": ("/etc/enigma2", "/etc/tuxbox"),
    "softcam": ("/etc/tuxbox/config", "/usr/keys", "/var/keys", "/etc/CCcam.cfg", "/var/etc/CCcam.cfg", "/etc/oscam"),
}
BACKUP_SETS["full"] = BACKUP_SETS["settings"] + BACKUP_SETS["softcam"] + ("/etc/hostname", "/etc/network/interfaces",
                                                                          "/etc/wpa_supplicant.conf", "/etc/auto.network")


def _expand(paths):
    import glob
    out = []
    for p in paths:
        for q in (sorted(glob.glob(p)) if "*" in p else [p]):
            if os.path.exists(q) and q not in out:
                out.append(q)
    return out


def backup(kind):
    import tarfile
    from .imagesdl import model_candidates
    m = main_storage()
    if not m:
        return False, _("لا يوجد قرص أو فلاشة مركّبة.")
    files = _expand(BACKUP_SETS[kind])
    if not files:
        return False, _("لا توجد ملفات لحفظها.")
    folder = os.path.join(m, BACKUP_DIR)
    try:
        if not os.path.isdir(folder):
            os.makedirs(folder)
        name = "%s-%s-%s.tar.gz" % (kind, (model_candidates() or ["box"])[0], time.strftime("%Y%m%d-%H%M"))
        path = os.path.join(folder, name)
        with tarfile.open(path + ".part", "w:gz") as tf:
            for f in files:
                tf.add(f, arcname=f.lstrip("/"))
        os.rename(path + ".part", path)
    except Exception as e:
        _log("backup: %r" % e)
        return False, _("فشل حفظ النسخة الاحتياطية: %s") % str(e)[:100]
    return True, _("تم حفظ النسخة الاحتياطية:\n%s") % path


def backups():
    """Backups made here, newest first: [(path, kind)]."""
    from .imagesdl import media_candidates
    out = []
    for m in media_candidates():
        d = os.path.join(m, BACKUP_DIR)
        try:
            for f in os.listdir(d):
                if f.endswith(".tar.gz"):
                    out.append(os.path.join(d, f))
        except Exception:
            pass
    out.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    return out


def restore(path):
    """Unpack a backup with Enigma2 stopped (so it does not write its old settings back), then start it."""
    import tarfile
    try:
        with tarfile.open(path, "r:gz") as tf:
            names = tf.getnames()
    except Exception:
        return False, _("ملف النسخة الاحتياطية تالف.")
    for n in names:
        if n.startswith("/") or ".." in n.split("/") or n.split("/")[0] not in ("etc", "usr", "var"):
            return False, _("ملف النسخة الاحتياطية تالف.")
    script = "/tmp/enigmaplay-restore.sh"
    with io.open(script, "w", encoding="utf-8") as f:
        f.write("#!/bin/sh\ninit 4\nsleep 4\ntar -xzf '%s' -C /\nsync\ninit 3\n" % path.replace("'", ""))
    os.chmod(script, 0o755)
    subprocess.Popen(["nohup", "/bin/sh", script], stdout=open("/dev/null", "w"), stderr=subprocess.STDOUT,
                     preexec_fn=getattr(os, "setsid", None))
    return True, _("جارٍ الاستعادة. ستتوقف الواجهة وتعود خلال ثوانٍ.")
