# -*- coding: utf-8 -*-
"""System tools screen: groups (Python libraries, players, network, disks, system) that open like a
drop-down, each tool with its state on this receiver. OK / green installs, green on a group installs
everything it is missing, yellow refreshes the image's package list, blue restarts the GUI when a
freshly installed tool needs it."""
from __future__ import print_function, unicode_literals, absolute_import, division

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from enigma import eTimer, ePoint, eSize
import os
import sys

from .i18n import _, IS_RTL
from .theme import C, theme_xml
from . import systools as st
from .imagesdl_ui import p, row, ImageList, GREEN, W, H, LIST_X, LIST_Y, LIST_W, LIST_H, HALIGN


class SystemToolsScreen(Screen):

    def __init__(self, session, catalog_obj=None, kind="deps", title=None):
        key_y = H - 96
        keys = []
        kw = 380
        order = ["red", "green", "yellow", "blue"]
        if IS_RTL:
            order = list(reversed(order))
        for i, k in enumerate(order):
            x = 120 + i * (kw + 20) + (1680 - 4 * kw - 60) // 2
            col = {"red": "#d93025", "green": GREEN, "yellow": "#f9ab00", "blue": "#1a73e8"}[k]
            keys.append('<widget name="dot_%s" position="%d,%d" size="%d,%d" backgroundColor="%s" zPosition="2" />'
                        % (k, p(x + (kw - 18 if IS_RTL else 0)), p(key_y + 26), p(18), p(18), col))
            keys.append('<widget name="key_%s" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" halign="%s" valign="center" '
                        'foregroundColor="#3c4043" backgroundColor="#f1f3f4" transparent="1" zPosition="2" />'
                        % (k, p(x + (0 if IS_RTL else 30)), p(key_y + 10), p(kw - 30), p(50), p(24), HALIGN))
        self.skin = theme_xml(
            '<screen name="EnigmaPlaySystemTools" position="0,0" size="%d,%d" flags="wfNoBorder" backgroundColor="#ffffff">'
            '<widget name="title" position="%d,%d" size="%d,%d" font="TajawalBold;%d" halign="%s" valign="center" foregroundColor="#202124" backgroundColor="#ffffff" transparent="1" />'
            '<widget name="sub" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" halign="%s" valign="center" foregroundColor="#5f6368" backgroundColor="#ffffff" transparent="1" />'
            '<eLabel position="%d,%d" size="%d,%d" backgroundColor="#e3e3e3" />'
            '<widget name="list" position="%d,%d" size="%d,%d" backgroundColor="#ffffff" backgroundColorSelected="%s" scrollbarMode="showNever" transparent="0" />'
            '<widget name="status" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" halign="%s" valign="top" foregroundColor="#202124" backgroundColor="#ffffff" transparent="1" />'
            '<widget name="bar_bg" position="%d,%d" size="%d,%d" backgroundColor="#e3e3e3" />'
            '<widget name="bar" position="%d,%d" size="%d,%d" backgroundColor="%s" zPosition="1" />'
            '<eLabel position="0,%d" size="%d,%d" backgroundColor="#f1f3f4" />'
            '%s</screen>'
            % (p(W), p(H),
               p(120), p(40), p(1680), p(70), p(44), HALIGN,
               p(120), p(110), p(1680), p(44), p(26), HALIGN,
               p(120), p(170), p(1680), p(2),
               p(LIST_X), p(LIST_Y), p(LIST_W), p(LIST_H), C("#e6f4ea"),
               p(120), p(LIST_Y + LIST_H + 20), p(1680), p(110), p(27), HALIGN,
               p(120), p(LIST_Y + LIST_H + 138), p(1680), p(12),
               p(120), p(LIST_Y + LIST_H + 138), 1, p(12), GREEN,
               p(key_y), p(W), p(96),
               "".join(keys)))
        try:
            from .announcements import _register_fonts
            _register_fonts()
        except Exception:
            pass
        Screen.__init__(self, session)
        self.kind = kind             # "deps" (store list), "drivers" (from the feed), "remove" (installed plugins)
        self.groups = list(getattr(catalog_obj, "system_tools", None) or []) if kind == "deps" else []
        self["title"] = Label(title or _("المكتبات والأدوات"))
        self["sub"] = Label("")
        self["list"] = ImageList()
        self["status"] = Label("")
        self["bar_bg"] = Label("")
        self["bar"] = Label("")
        for k in ("red", "green", "yellow", "blue"):
            self["key_%s" % k] = Label("")
            self["dot_%s" % k] = Label("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.key_ok,
            "green": self.key_green,
            "yellow": self.key_yellow,
            "blue": self.key_blue,
            "cancel": self.key_back,
            "red": self.key_back,
            "up": self._up,
            "down": self._down,
            "left": lambda: self._move("pageUp"),
            "right": lambda: self._move("pageDown"),
        }, -1)
        self.expanded = None
        self.rowmap = []
        self.installed = set()
        self.available = set()
        self.job = None
        self.job_total = 0
        self.need_restart = False
        self.timer = eTimer()
        try:
            self.timer.callback.append(self._tick)
        except AttributeError:
            self._conn = self.timer.timeout.connect(self._tick)
        self.onLayoutFinish.append(self._start)
        self.onClose.append(self._closed)

    # ------------------------------------------------------------ helpers
    def _keys(self, red="", green="", yellow="", blue=""):
        for k, v in (("red", red), ("green", green), ("yellow", yellow), ("blue", blue)):
            self["key_%s" % k].setText(v)
            if v:
                self["dot_%s" % k].show()
            else:
                self["dot_%s" % k].hide()

    def _bar(self, frac):
        if frac is None:
            self["bar_bg"].hide()
            self["bar"].hide()
            return
        self["bar_bg"].show()
        self["bar"].show()
        try:
            w = max(1, int(p(1680) * max(0.0, min(1.0, frac))))
            x = p(120) + (p(1680) - w if IS_RTL else 0)
            self["bar"].instance.move(ePoint(x, p(LIST_Y + LIST_H + 138)))
            self["bar"].instance.resize(eSize(w, p(12)))
        except Exception:
            pass

    def _scan(self):
        self.installed = st.installed_packages()
        self.available = st.available_packages()
        if self.kind == "drivers":
            self.groups = st.driver_groups(self.available, self.installed)
        elif self.kind == "remove":
            self.groups = st.removable_groups(self.installed)

    def _states(self, group):
        return [(it, ) + st.state(it, self.installed, self.available) for it in group["items"]]

    # ------------------------------------------------------------ start
    def _start(self):
        self._bar(None)
        si = st.sysinfo()
        self["sub"].setText("Python %s   ·   %s   ·   %s" % (si.get("py") or "?", si.get("arch") or "?", si.get("pm") or "-"))
        if self.kind == "deps" and not self.groups:
            self._fetch_list()
            return
        if not st.package_manager():
            self["status"].setText(_("لم نجد مدير الحزم (opkg أو apt) في هذه الصورة، فلا يمكن التثبيت من هنا."))
        age = st.lists_age()
        if self.kind != "remove" and st.package_manager() and (age is None or age > st.LISTS_FRESH):
            self._run("update")          # lists are old: fetch the feed's package list first
            return
        self._scan()
        self.show_list()

    def _fetch_list(self):
        """The cached store list has no tools yet (written by an older version): download it again."""
        self["status"].setText(_("جارٍ تحميل قائمة الأدوات…"))
        self._keys(red=_("رجوع"))
        import threading
        self._fetched = None

        def work():
            try:
                from . import catalog as ep_catalog
                cat, _online, _msg = ep_catalog.fetch_remote_index()
                self._fetched = cat
                if cat is not None:
                    for m in list(sys.modules.values()):
                        if m is not None and hasattr(m, "GLOBAL_CATALOG") and hasattr(m, "get_catalog"):
                            m.GLOBAL_CATALOG = cat
            except Exception as e:
                st._log("fetch list: %r" % e)
            self._fetched = self._fetched or False
        t = threading.Thread(target=work)
        t.daemon = True
        t.start()
        self.fetch_timer = eTimer()
        try:
            self.fetch_timer.callback.append(self._fetch_done)
        except AttributeError:
            self._fconn = self.fetch_timer.timeout.connect(self._fetch_done)
        self.fetch_timer.start(400, False)

    def _fetch_done(self):
        if self._fetched is None:
            return
        self.fetch_timer.stop()
        self.groups = list(getattr(self._fetched, "system_tools", None) or []) if self._fetched else []
        if not self.groups:
            self["status"].setText(_("قائمة الأدوات غير متوفرة بعد. ارجع واختر «تحديث القائمة» ثم افتح هذا القسم مجدداً."))
            return
        self._start()

    # ------------------------------------------------------------ list
    def show_list(self, select=None):
        rows, self.rowmap = [], []
        if self.kind == "remove":
            return self._show_remove(select)
        if not self.groups and self.kind == "drivers":
            self["list"].setList([])
            self._keys(red=_("رجوع"), yellow=_("تحديث قائمة الحزم") if st.package_manager() else "")
            self["status"].setText(_("لم نجد تعريفات في فيد صورتك. جرّب «تحديث قائمة الحزم»."))
            return
        for g in self.groups:
            sts = self._states(g)
            have = sum(1 for x in sts if x[1] == "installed")
            opened = self.expanded == g["id"]
            rows.append(row(st.text(g.get("name")), _("مثبتة %d من %d") % (have, len(sts)),
                            _("ناقصة %d") % sum(1 for x in sts if x[1] == "missing") if any(x[1] == "missing" for x in sts) else "",
                            arrow="open" if opened else "closed"))
            self.rowmap.append(("group", g, None))
            if opened:
                for it, s, todo in sts:
                    badge = {"installed": _("مثبتة"), "missing": _("غير مثبتة"),
                             "unavailable": _("غير متوفرة في فيد صورتك")}[s]
                    rows.append(row(it.get("name", it["id"]), st.text(it.get("desc")), badge, indent=True))
                    self.rowmap.append(("item", g, (it, s, todo)))
        self["list"].setList(rows)
        if select is not None and rows:
            self["list"].moveToIndex(max(0, min(select, len(rows) - 1)))
        self._idle_texts()

    def _show_remove(self, select=None):
        rows, self.rowmap = [], []
        for g in self.groups:
            opened = self.expanded == g["id"]
            rows.append(row(st.text(g.get("name")), _("مثبتة %d") % len(g["items"]), "",
                            arrow="open" if opened else "closed"))
            self.rowmap.append(("group", g, None))
            if opened:
                for it in g["items"]:
                    rows.append(row(it["name"], it["id"], _("مثبتة"), indent=True))
                    self.rowmap.append(("item", g, (it, "installed", it["packages"]["any"])))
        self["list"].setList(rows)
        if select is not None and rows:
            self["list"].moveToIndex(max(0, min(select, len(rows) - 1)))
        if not rows:
            self._keys(red=_("رجوع"))
            self["status"].setText(_("لا توجد بلجنات مثبتة يمكن إزالتها من هنا."))
            return
        self._idle_texts()

    def _sel(self):
        i = self["list"].getSelectedIndex()
        return self.rowmap[i] if 0 <= i < len(self.rowmap) else (None, None, None)

    def _idle_texts(self):
        if self.job:
            return
        kind, g, data = self._sel()
        if self.kind == "remove":
            self._keys(red=_("رجوع"), green=_("إزالة") if kind == "item" else "",
                       blue=_("إعادة تشغيل الواجهة") if self.need_restart else "")
            self["status"].setText(_("اضغط OK أو الأخضر لإزالة %s من جهازك.") % data[0]["name"] if kind == "item"
                                   else _("اختر قسماً واضغط OK لعرض ما هو مثبت فيه."))
            return
        green = ""
        if kind == "item" and data[1] == "missing":
            green = _("تثبيت")
        elif kind == "group":
            n = sum(len(x[2]) for x in self._states(g) if x[1] == "missing")
            green = _("تثبيت الناقص (%d)") % n if n else ""
        self._keys(red=_("رجوع"), green=green, yellow=_("تحديث قائمة الحزم") if st.package_manager() else "",
                   blue=_("إعادة تشغيل الواجهة") if self.need_restart else "")
        if kind == "item":
            it, s, todo = data
            if s == "missing":
                msg = _("اضغط OK أو الأخضر لتثبيت %s من فيد صورتك.") % it.get("name")
            elif s == "installed":
                msg = _("%s مثبتة على جهازك.") % it.get("name")
            else:
                msg = _("فيد صورتك لا يحتوي %s. جرّب «تحديث قائمة الحزم»، وإذا بقيت غير متوفرة فصورتك لا توفّرها.") % it.get("name")
            self["status"].setText(msg + "\n" + ", ".join(st.candidates(it)))
        else:
            self["status"].setText(_("اختر قسماً واضغط OK لعرض أدواته. الأخضر يثبّت كل ما ينقص القسم."))

    def _move(self, how):
        getattr(self["list"], how)()
        self._idle_texts()

    def _up(self):
        self._move("up")

    def _down(self):
        self._move("down")

    def _group_row(self, gid):
        for i, (k, g, _d) in enumerate(self.rowmap):
            if k == "group" and g["id"] == gid:
                return i
        return 0

    # ------------------------------------------------------------ keys
    def key_ok(self):
        if self.job:
            return
        kind, g, data = self._sel()
        if kind == "group":
            gid = g["id"]
            self.expanded = None if self.expanded == gid else gid
            self.show_list()
            self.show_list(select=self._group_row(gid))
        elif kind == "item" and self.kind == "remove":
            self._ask_remove(data[2], data[0]["name"])
        elif kind == "item" and data[1] == "missing":
            self._ask_install(data[2], data[0].get("name"), bool(data[0].get("restart")))

    def _ask_remove(self, packages, label):
        self._pending_rm = packages
        self.session.openWithCallback(self._confirmed_rm, MessageBox,
                                      _("إزالة %s من جهازك؟\n%s") % (label, " ".join(packages)),
                                      MessageBox.TYPE_YESNO, default=False)

    def _confirmed_rm(self, yes):
        if yes and getattr(self, "_pending_rm", None):
            self.need_restart = True
            self._run("remove", self._pending_rm)

    def key_green(self):
        if self.job:
            return
        kind, g, data = self._sel()
        if self.kind == "remove":
            if kind == "item":
                self._ask_remove(data[2], data[0]["name"])
            return
        if kind == "item" and data[1] == "missing":
            self._ask_install(data[2], data[0].get("name"), bool(data[0].get("restart")))
        elif kind == "group":
            todo, restart = [], False
            for it, s, names in self._states(g):
                if s == "missing":
                    todo.extend(n for n in names if n not in todo)
                    restart = restart or bool(it.get("restart"))
            if todo:
                self._ask_install(todo, st.text(g.get("name")), restart)

    def _ask_install(self, packages, label, restart):
        self._pending = (packages, restart)
        self.session.openWithCallback(self._confirmed, MessageBox,
                                      _("تثبيت %s من فيد صورتك؟\n%s") % (label, " ".join(packages)),
                                      MessageBox.TYPE_YESNO, default=True)

    def _confirmed(self, yes):
        if yes and getattr(self, "_pending", None):
            packages, restart = self._pending
            self.need_restart = self.need_restart or restart
            self._run("install", packages)

    def key_yellow(self):
        if not self.job and st.package_manager() and self.kind != "remove":
            self._run("update")

    def key_blue(self):
        if self.need_restart and not self.job:
            from Screens.Standby import TryQuitMainloop
            self.session.open(TryQuitMainloop, 3)

    def key_back(self):
        if self.job:
            self["status"].setText(_("انتظر حتى ينتهي التثبيت…"))
            return
        if self.expanded:
            gid, self.expanded = self.expanded, None
            self.show_list()
            self.show_list(select=self._group_row(gid))
            return
        self.close()

    # ------------------------------------------------------------ jobs
    def _run(self, kind, packages=None):
        self.job = st.Job(kind, packages)
        self.job_total = len(packages or [])
        self._keys()
        self._bar(0.0 if packages else None)
        self["status"].setText(_("جارٍ تحديث قائمة الحزم من فيد صورتك…") if kind == "update" else _("جارٍ التثبيت…"))
        self.timer.start(500, False)

    def _tick(self):
        job = self.job
        if not job:
            self.timer.stop()
            return
        last = job.lines[-1][:110] if job.lines else ""
        if job.kind == "install" and job.current:
            done = job.packages.index(job.current) if job.current in job.packages else 0
            self._bar(float(done) / max(1, self.job_total))
            self["status"].setText(_("جارٍ تثبيت %s (%d من %d)…") % (job.current, done + 1, self.job_total) + "\n" + last)
        elif job.kind == "remove" and job.current:
            self["status"].setText(_("جارٍ إزالة %s…") % job.current + "\n" + last)
        elif last:
            self["status"].setText((_("جارٍ تحديث قائمة الحزم من فيد صورتك…") if job.kind == "update" else _("جارٍ التثبيت…")) + "\n" + last)
        if not job.done:
            return
        self.timer.stop()
        self.job = None
        self._bar(None)
        sel = self["list"].getSelectedIndex()
        self._scan()
        self.show_list(select=sel)
        if job.kind == "update":
            self["status"].setText(_("تم تحديث قائمة الحزم.") if job.ok else
                                   _("تعذر تحديث قائمة الحزم. تأكد من الاتصال بالإنترنت.") + "\n" + last)
            return
        if job.kind == "remove":
            left = st.still_installed(job.packages)
            self["status"].setText(_("لم تتم الإزالة: %s") % ", ".join(left) + "\n" + last if left else
                                   _("تمت الإزالة. أعد تشغيل الواجهة (الأزرق) لتكتمل."))
            return
        failed = st.missing_after(job.packages)
        if not failed:
            msg = _("تم التثبيت.")
            if self.need_restart:
                msg += " " + _("أعد تشغيل الواجهة (الأزرق) ليعمل ما ثبّتّه.")
            self["status"].setText(msg)
        else:
            self["status"].setText(_("لم يتم تثبيت: %s") % ", ".join(failed) + "\n" + last)

    def _closed(self):
        try:
            self.timer.stop()
        except Exception:
            pass


# ====================================================================== sections
SECTIONS = ("dns", "deps", "fix", "drivers", "hdd", "install", "remove", "other", "backup", "restore")


def section_texts():
    return {
        "dns": (_("DNS"), _("اختر خوادم DNS أسرع أو أكثر أماناً، واختبر الاتصال")),
        "deps": (_("المكتبات والأدوات"), _("مكتبات بايثون والمشغلات والترميزات وأدوات الشبكة والأقراص")),
        "fix": (_("إصلاحات"), _("ضبط الساعة، تحرير الذاكرة، إصلاح مدير الحزم، إعادة تشغيل الشبكة")),
        "drivers": (_("التعريفات"), _("تعريفات الواي فاي والتيونر USB من فيد صورتك")),
        "hdd": (_("القرص والفلاشة"), _("المساحة، إنشاء المجلدات المعتادة، سكون القرص")),
        "install": (_("تثبيت من ملف"), _("ثبّت ملف ipk أو deb أو tar.gz نسخته على الفلاشة أو /tmp")),
        "remove": (_("إزالة بلجنات"), _("أزل بلجنات وإيميوهات وسكنات مثبتة")),
        "other": (_("أخرى"), _("معلومات الجهاز، إعادة تشغيل الواجهة أو الجهاز")),
        "backup": (_("نسخ احتياطي"), _("احفظ القنوات والإعدادات وملفات الإيميو على القرص أو الفلاشة")),
        "restore": (_("استعادة"), _("أرجع نسخة احتياطية حفظتها من هنا")),
    }


class ToolsHomeScreen(SystemToolsScreen):
    """System tools: one row per section, OK opens it."""

    def __init__(self, session, catalog_obj=None):
        SystemToolsScreen.__init__(self, session, catalog_obj, kind="home", title=_("أدوات النظام"))
        self.catalog_obj = catalog_obj

    def _start(self):
        self._bar(None)
        si = st.sysinfo()
        self["sub"].setText("Python %s   ·   %s   ·   %s" % (si.get("py") or "?", si.get("arch") or "?", si.get("pm") or "-"))
        self.show_list()

    def show_list(self, select=None):
        tx = section_texts()
        self.rowmap = [("section", sid, None) for sid in SECTIONS]
        self["list"].setList([row(tx[sid][0], tx[sid][1], "", arrow="closed") for sid in SECTIONS])
        if select is not None:
            self["list"].moveToIndex(select)
        self._idle_texts()

    def _idle_texts(self):
        self._keys(red=_("رجوع"), green=_("فتح"))
        self["status"].setText(_("اختر قسماً واضغط OK."))

    def key_ok(self):
        kind, sid, _d = self._sel()
        if kind != "section":
            return
        title = section_texts()[sid][0]
        if sid in ("deps", "drivers", "remove"):
            self.session.open(SystemToolsScreen, self.catalog_obj, sid, title)
        else:
            self.session.open(ActionsScreen, sid, title)

    key_green = key_ok

    def key_yellow(self):
        pass

    def key_blue(self):
        pass

    def key_back(self):
        self.close()


class _Task(object):
    def __init__(self, fn):
        self.done, self.ok, self.msg = False, False, ""
        import threading

        def work():
            try:
                self.ok, self.msg = fn()
            except Exception as e:
                st._log("action failed: %r" % e)
                self.ok, self.msg = False, "%r" % e
            self.done = True
        t = threading.Thread(target=work)
        t.daemon = True
        t.start()


class ActionsScreen(SystemToolsScreen):
    """A section of one-press actions (DNS, fixes, disk, other, backup, restore, install from a file)."""

    def __init__(self, session, section, title):
        SystemToolsScreen.__init__(self, session, None, kind="actions", title=title)
        self.section = section
        self.actions = []
        self.result = ""

    # ---------------------------------------------------------- the actions of each section
    def _build(self):
        a = []

        def add(aid, title, desc, fn, confirm=None, restart=False, badge="", gui=None):
            a.append({"id": aid, "title": title, "desc": desc, "fn": fn, "confirm": confirm, "restart": restart,
                      "badge": badge, "gui": gui})
        s = self.section
        if s == "dns":
            cur = st.current_dns()
            for did, name, servers in st.DNS_SERVERS:
                add(did, name, "  ·  ".join(servers), (lambda sv=servers: st.set_dns(sv)),
                    confirm=_("استعمال خوادم %s؟") % name, badge=_("الحالي") if cur[:2] == list(servers) else "")
            add("restore_dns", _("إرجاع DNS السابق"), _("الخوادم التي كانت قبل أول تغيير من هنا"), st.restore_dns,
                confirm=_("إرجاع خوادم DNS السابقة؟"))
            add("test", _("اختبار الاتصال"), _("يفحص DNS والاتصال الآمن بالإنترنت"), st.test_internet)
        elif s == "fix":
            add("time", _("ضبط الساعة"), _("من خوادم الوقت على الإنترنت"), st.sync_time)
            add("ram", _("تحرير الذاكرة"), _("يفرغ ذاكرة الكاش المؤقتة"), st.free_ram)
            add("pkg", _("إصلاح مدير الحزم"), _("يمسح القفل العالق ويكمل التثبيتات الناقصة ثم يحدّث القائمة"), st.fix_packages,
                confirm=_("إصلاح مدير الحزم؟ لا تستعمله أثناء تثبيت أي شيء."))
            add("net", _("إعادة تشغيل الشبكة"), _("قد ينقطع الاتصال لثوانٍ"), st.restart_network,
                confirm=_("إعادة تشغيل الشبكة الآن؟"))
            add("test", _("اختبار الاتصال"), _("يفحص DNS والاتصال الآمن بالإنترنت"), st.test_internet)
        elif s == "hdd":
            add("info", _("المساحة"), _("الأقراص والفلاشات المركّبة ومساحتها"), st.disks_info)
            add("folders", _("إنشاء المجلدات المعتادة"), "movie · picon · timeshift · backup · imagebackups", st.make_folders)
            add("standby", _("سكون القرص بعد 10 دقائق"), _("يوقف دوران القرص عندما لا يُستعمل"), st.disk_standby)
        elif s == "other":
            add("info", _("معلومات الجهاز"), _("الموديل والصورة وبايثون والذاكرة"), st.system_info)
            add("gui", _("إعادة تشغيل الواجهة"), "Enigma2", None, confirm=_("إعادة تشغيل الواجهة الآن؟"), gui=3)
            add("reboot", _("إعادة تشغيل الجهاز"), "Reboot", None, confirm=_("إعادة تشغيل الجهاز الآن؟"), gui=2)
        elif s == "backup":
            for kind, title, desc in (("channels", _("القنوات"), _("قائمة القنوات والمفضلة وملف الأقمار")),
                                      ("settings", _("القنوات وكل الإعدادات"), "/etc/enigma2  ·  /etc/tuxbox"),
                                      ("softcam", _("ملفات الإيميو"), "/etc/tuxbox/config  ·  /usr/keys"),
                                      ("full", _("الكل"), _("القنوات والإعدادات والإيميو والشبكة"))):
                add(kind, title, desc, (lambda k=kind: st.backup(k)))
        elif s == "restore":
            for path in st.backups():
                name = os.path.basename(path)
                add(path, name[:-7], os.path.dirname(path), (lambda pth=path: st.restore(pth)),
                    confirm=_("استعادة %s؟ ستتوقف الواجهة وتعود خلال ثوانٍ، وستُستبدل الملفات الحالية بالنسخة المحفوظة.") % name)
        elif s == "install":
            for path in st.local_packages():
                add(path, os.path.basename(path), os.path.dirname(path), (lambda pth=path: st.install_file(pth)),
                    confirm=_("تثبيت %s؟ ثبّت فقط ملفات تثق بمصدرها.") % os.path.basename(path), restart=True)
        return a

    # ---------------------------------------------------------- list
    def _start(self):
        self._bar(None)
        self["sub"].setText(section_texts().get(self.section, ("", ""))[1])
        self.show_list()

    def show_list(self, select=None):
        self.actions = self._build()
        self.rowmap = [("action", a, None) for a in self.actions]
        self["list"].setList([row(a["title"], a["desc"], a["badge"]) for a in self.actions])
        if select is not None and self.actions:
            self["list"].moveToIndex(max(0, min(select, len(self.actions) - 1)))
        self._idle_texts()

    def _idle_texts(self):
        if self.job:
            return
        self._keys(red=_("رجوع"), green=_("تنفيذ") if self.actions else "",
                   blue=_("إعادة تشغيل الواجهة") if self.need_restart else "")
        if self.result:
            self["status"].setText(self.result)
        elif not self.actions:
            self["status"].setText({
                "install": _("لم نجد ملفات. انسخ ملف ipk أو deb أو tar.gz إلى /tmp أو إلى أول الفلاشة ثم افتح القسم مجدداً."),
                "restore": _("لا توجد نسخ احتياطية بعد. احفظ نسخة من قسم «نسخ احتياطي»."),
            }.get(self.section, ""))
        else:
            self["status"].setText(_("اختر واضغط OK."))

    def _move(self, how):
        getattr(self["list"], how)()
        self.result = ""
        self._idle_texts()

    # ---------------------------------------------------------- keys
    def key_ok(self):
        if self.job:
            return
        kind, a, _d = self._sel()
        if kind != "action":
            return
        self._pending_a = a
        if a["confirm"]:
            self.session.openWithCallback(self._go, MessageBox, a["confirm"], MessageBox.TYPE_YESNO,
                                          default=a["id"] not in ("reboot",))
        else:
            self._go(True)

    key_green = key_ok

    def _go(self, yes):
        a = getattr(self, "_pending_a", None)
        if not yes or not a:
            return
        if a["gui"]:
            from Screens.Standby import TryQuitMainloop
            self.session.open(TryQuitMainloop, a["gui"])
            return
        if self.section == "backup" and a["id"] in ("settings", "full"):
            try:      # write the settings Enigma2 holds in memory before copying them
                from Components.config import configfile
                configfile.save()
            except Exception:
                pass
        self.job = _Task(a["fn"])
        self.job_action = a
        self._keys()
        self["status"].setText(_("جارٍ التنفيذ…"))
        self.timer.start(400, False)

    def _tick(self):
        job = self.job
        if not job or not job.done:
            return
        self.timer.stop()
        self.job = None
        if job.ok and self.job_action.get("restart"):
            self.need_restart = True
        self.result = job.msg or (_("تم.") if job.ok else _("فشل."))
        if job.ok and self.need_restart and self.section == "install":
            self.result += "\n" + _("أعد تشغيل الواجهة (الأزرق) ليعمل ما ثبّتّه.")
        self.show_list(select=self["list"].getSelectedIndex())

    def key_yellow(self):
        pass

    def key_back(self):
        if self.job:
            self["status"].setText(_("انتظر حتى ينتهي…"))
            return
        self.close()
