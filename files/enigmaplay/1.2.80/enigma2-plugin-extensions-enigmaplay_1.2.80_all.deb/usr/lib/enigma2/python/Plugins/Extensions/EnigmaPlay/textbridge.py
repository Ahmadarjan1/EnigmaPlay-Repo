# -*- coding: utf-8 -*-
"""Typing from the phone, on every image.

The EnigmaPlay app sends text typed on the phone to http://<receiver>:8781/ep/text?t=... and it is
typed into whatever is open on the TV (virtual keyboard, search, a text setting). OpenWebif has the
same feature only in recent versions, so the store does it itself:
  1. ascii key events (setPrevAsciiCode + KEY_ASCII), like a USB keyboard: works in every input
  2. images without setPrevAsciiCode: the open screen's Input / text setting gets the text directly
Only answers devices on the home network. Built on twisted core only (always in Enigma2).
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import json
import re

PORT = 8781
MAX_TEXT = 500
_SESSION = None
_LISTENING = None
REMOTE_TYPE = "dreambox remote control (native)"
KEY_ASCII = 510

try:
    from urllib.parse import unquote_plus
except ImportError:          # Python 2
    from urllib import unquote_plus


def _log(msg):
    try:
        import io
        import time
        with io.open("/tmp/enigmaplay_remote.log", "a", encoding="utf-8") as f:
            f.write("%s text: %s\n" % (time.strftime("%H:%M:%S"), msg))
    except Exception:
        pass


def _private(ip):
    ip = (ip or "").replace("::ffff:", "")
    if ip in ("127.0.0.1", "::1"):
        return True
    m = re.match(r"^(\d+)\.(\d+)\.\d+\.\d+$", ip)
    if not m:
        return ip.startswith("fe80:") or ip.startswith("fd") or ip.startswith("fc")
    a, b = int(m.group(1)), int(m.group(2))
    return a == 10 or (a == 192 and b == 168) or (a == 172 and 16 <= b <= 31) or (a == 169 and b == 254)


def _text(t):
    if not isinstance(t, type(u"")):
        t = t.decode("utf-8", "replace")
    return t


def type_text(text):
    """Type text into what is open on the TV. Returns how ("ascii", "input", "config") or "none"."""
    text = _text(text)[:MAX_TEXT]
    if not text:
        return "none"
    try:
        from enigma import eActionMap, setPrevAsciiCode
    except ImportError:
        setPrevAsciiCode = None
    if setPrevAsciiCode is not None:
        amap = eActionMap.getInstance()
        for ch in text:
            setPrevAsciiCode(ord(ch))
            amap.keyPressed(REMOTE_TYPE, KEY_ASCII, 0)
            amap.keyPressed(REMOTE_TYPE, KEY_ASCII, 1)
        return "ascii"
    return _type_direct(text)


def _type_direct(text):
    dlg = getattr(_SESSION, "current_dialog", None) if _SESSION else None
    if dlg is None:
        return "none"
    try:
        from Components.Input import Input
    except Exception:
        Input = None
    if Input is not None:
        for name in ("text", "input", "Input", "search", "searchText"):
            try:
                w = dlg[name]
            except Exception:
                continue
            if isinstance(w, Input):
                w.setText(w.getText() + text)
                try:
                    w.end()
                except Exception:
                    pass
                return "input"
    try:                                  # a text setting selected in a settings list
        from Components.config import ConfigText
        cur = dlg["config"].getCurrent()
        cfg = cur and cur[1]
        if isinstance(cfg, ConfigText):
            cfg.value = (cfg.value or "") + text
            dlg["config"].invalidateCurrent()
            return "config"
    except Exception:
        pass
    return "none"


def _answer(path):
    """-> (status, dict)"""
    from . import __version__
    route, _, query = path.partition("?")
    args = {}
    for part in query.split("&"):
        k, _, v = part.partition("=")
        if k:
            args[k] = unquote_plus(v)
    if route == "/ep/ping":
        return 200, {"ok": True, "version": __version__, "text": True}
    if route == "/ep/text":
        how = type_text(args.get("t", ""))
        _log("%d chars -> %s" % (len(args.get("t", "")), how))
        return 200, {"ok": how != "none", "how": how}
    return 404, {"ok": False}


def start(session):
    """Listen on PORT (once per Enigma2 start)."""
    global _SESSION, _LISTENING
    _SESSION = session
    if _LISTENING is not None:
        return
    from twisted.internet import reactor, protocol

    class Http(protocol.Protocol):
        def connectionMade(self):
            self.buf = b""

        def dataReceived(self, data):
            self.buf += data
            if len(self.buf) > 8192:
                self.transport.loseConnection()
                return
            if b"\r\n" not in self.buf:
                return
            line = self.buf.split(b"\r\n", 1)[0].decode("latin-1", "replace")
            parts = line.split(" ")
            status, body = 400, {"ok": False}
            try:
                if not _private(self.transport.getPeer().host):
                    status, body = 403, {"ok": False}
                elif len(parts) >= 2 and parts[0] == "GET":
                    status, body = _answer(parts[1])
            except Exception as e:
                _log("error %r" % e)
                status, body = 500, {"ok": False}
            raw = json.dumps(body).encode("utf-8")
            head = ("HTTP/1.0 %d OK\r\nContent-Type: application/json\r\nContent-Length: %d\r\n"
                    "Connection: close\r\n\r\n" % (status, len(raw))).encode("latin-1")
            self.transport.write(head + raw)
            self.transport.loseConnection()

    f = protocol.ServerFactory()
    f.protocol = Http
    try:
        _LISTENING = reactor.listenTCP(PORT, f)
        _log("listening on %d" % PORT)
    except Exception as e:
        _LISTENING = False
        _log("cannot listen on %d: %r" % (PORT, e))
