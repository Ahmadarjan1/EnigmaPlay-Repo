# -*- coding: utf-8 -*-
"""
Rollback: go back to the version of a plugin that was installed before an update.

Before every update the store saves the plugin as it is (in the same background job, before the new
version is installed):
  * a package (opkg / dpkg): every file of its file list, its files in the package database
    (control, list, scripts) and its entry in the database's status file
  * a plugin installed by a script (no package): its plugin folder
  * its lines in /etc/enigma2/settings (backup.collect)
Copies go to the hard disk / USB stick when there is one, otherwise to the flash if there is room.
Two copies are kept per plugin.

Going back (a background job too): files the new version added are removed, the saved files are put
back, then the package database entry and the settings are restored. The store then holds that update
back: "update all" and the update notices skip it until the user updates by hand.
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import io
import json
import os
import re
import time

try:
    from shlex import quote
except ImportError:                       # Python 2
    from pipes import quote

FS_ROOT = "/"                             # tests point this at a fake receiver
INFO_DIRS = ("var/lib/opkg/info", "usr/lib/opkg/info", "var/lib/dpkg/info")
STATUS_FILES = ("var/lib/opkg/status", "usr/lib/opkg/status", "var/lib/dpkg/status")
INFO_KINDS = ("list", "control", "postinst", "preinst", "prerm", "postrm", "md5sums", "conffiles", "shlibs",
              "triggers", "templates", "config")
MEDIA = ("media/hdd", "media/usb", "media/usb2", "media/mmc", "media/sdcard")
DIR_NAME = "enigmaplay-rollback"
FLASH_DIR = "home/root/.enigmaplay-rollback"
KEEP_PER_PLUGIN = 2
MB = 1024 * 1024
CAP_MEDIA = 400 * MB                      # all copies together
CAP_FLASH = 60 * MB
MAX_FLASH_COPY = 25 * MB                  # a bigger plugin is only saved on a disk / stick
NEVER_REMOVE = ("etc/",)                  # files of the new version kept on rollback (user configuration)
PLUGIN_DIR_RE = re.compile(r"^usr/lib/enigma2/python/Plugins/(Extensions|SystemPlugins)/[^/]+$")


def _abs(rel):
    return os.path.join(FS_ROOT, rel.lstrip("/"))


def _safe(s):
    return re.sub(r"[^A-Za-z0-9._-]", "_", str(s or ""))[:60] or "x"


def _log(msg):
    try:
        from .installer import log_debug
        log_debug("[rollback] " + msg)
    except Exception:
        pass


# ------------------------------------------------------------------ what belongs to a plugin
def _pkg_list(pkg):
    """Files (relative paths) installed by a package, from its file list; directories left out."""
    out = []
    for d in INFO_DIRS:
        lst = _abs(os.path.join(d, pkg + ".list"))
        if not os.path.isfile(lst):
            continue
        try:
            with io.open(lst, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    p = line.strip().split("\t")[0].lstrip("/")
                    if not p or ".." in p.split("/"):
                        continue
                    a = _abs(p)
                    if os.path.islink(a) or os.path.isfile(a):
                        out.append(p)
        except Exception:
            pass
        break
    return out


def _pkg_info(pkg):
    out = []
    for d in INFO_DIRS:
        full = _abs(d)
        if not os.path.isdir(full):
            continue
        for kind in INFO_KINDS:
            p = os.path.join(d, pkg + "." + kind)
            if os.path.isfile(_abs(p)):
                out.append(p)
    return out


def _blocks(text):
    return [b for b in re.split(r"\n\s*\n", text) if b.strip()]


def _status_block(pkg):
    """(status file, the package's entry) from the package database."""
    for rel in STATUS_FILES:
        path = _abs(rel)
        if not os.path.isfile(path):
            continue
        try:
            with io.open(path, "r", encoding="utf-8", errors="replace") as f:
                text = f.read()
        except Exception:
            continue
        for b in _blocks(text):
            if re.search(r"^Package:\s*%s\s*$" % re.escape(pkg), b, re.M):
                return rel, b.strip("\n")
    return None, None


def _walk(rel_dir):
    out = []
    base = _abs(rel_dir)
    for top, dirs, files in os.walk(base):
        for n in files:
            a = os.path.join(top, n)
            if os.path.isfile(a) or os.path.islink(a):
                out.append(os.path.relpath(a, FS_ROOT))
    return out


def plugin_dir_of(plugin_path):
    """'/usr/lib/enigma2/python/Plugins/Extensions/X/plugin.py' (or the folder) -> its relative folder."""
    p = (plugin_path or "").rstrip("/")
    if p.endswith(".py") or p.endswith(".pyc"):
        p = os.path.dirname(p)
    rel = os.path.relpath(p, FS_ROOT) if p.startswith(FS_ROOT) else p.lstrip("/")
    return rel if PLUGIN_DIR_RE.match(rel) else None


def plan(pkg, plugin_path=None):
    """{kind, files, size, status_file, status_block, dirs} or None when nothing can be saved."""
    files, status_file, block, dirs = [], None, None, []
    if pkg and re.match(r"^[A-Za-z0-9.+_-]+$", pkg):
        files = _pkg_list(pkg)
        if files:
            files += _pkg_info(pkg)
            status_file, block = _status_block(pkg)
    if not files:
        d = plugin_dir_of(plugin_path)
        if d:
            files, dirs = _walk(d), [d]
    if not files:
        return None
    size = 0
    for p in files:
        try:
            size += os.lstat(_abs(p)).st_size
        except Exception:
            pass
    return {"kind": "pkg" if status_file or (pkg and not dirs) else "dir", "files": sorted(set(files)), "size": size,
            "status_file": status_file, "status_block": block, "dirs": dirs}


# ------------------------------------------------------------------ where copies live
def _free(path):
    try:
        st = os.statvfs(path)
        return st.f_bavail * st.f_frsize
    except Exception:
        return 0


def _writable(d):
    try:
        if not os.path.isdir(d):
            os.makedirs(d)
        t = os.path.join(d, ".w")
        with open(t, "w") as f:
            f.write("1")
        os.remove(t)
        return True
    except Exception:
        return False


def _media_dirs():
    out = []
    for m in MEDIA:
        a = _abs(m)
        if os.path.ismount(a) or (FS_ROOT != "/" and os.path.isdir(a)):
            out.append(os.path.join(a, DIR_NAME))
    return out


def store_dirs():
    """Every place copies may be (for listing)."""
    return _media_dirs() + [_abs(FLASH_DIR)]


def pick_store(size):
    for d in _media_dirs():
        if _free(os.path.dirname(d)) > size * 2 + 50 * MB and _writable(d):
            return d, CAP_MEDIA
    fd = _abs(FLASH_DIR)
    if size <= MAX_FLASH_COPY and _free(os.path.dirname(fd) if not os.path.isdir(fd) else fd) > size * 3 + 30 * MB and _writable(fd):
        return fd, CAP_FLASH
    return None, 0


# ------------------------------------------------------------------ copies
def list_copies(key=None):
    """Saved copies, newest first: [{id, name, version, time, size, tar, meta_path, ...}]"""
    out = []
    for base in store_dirs():
        if not os.path.isdir(base):
            continue
        for sub in os.listdir(base):
            d = os.path.join(base, sub)
            if not os.path.isdir(d):
                continue
            for n in os.listdir(d):
                if not n.endswith(".json"):
                    continue
                mp = os.path.join(d, n)
                try:
                    with io.open(mp, "r", encoding="utf-8") as f:
                        m = json.load(f)
                except Exception:
                    continue
                if key and m.get("id") != key:
                    continue
                tar = m.get("tar") or ""
                if not os.path.isfile(tar) or os.path.getsize(tar) < 20:
                    continue
                m["meta_path"] = mp
                m["disk"] = os.path.getsize(tar)
                out.append(m)
    out.sort(key=lambda m: m.get("time", 0), reverse=True)
    return out


def delete_copy(m):
    for p in (m.get("tar"), m.get("meta_path")):
        try:
            if p and os.path.exists(p):
                os.remove(p)
        except Exception:
            pass


def _prune(base, key, cap, keep):
    """Keep the newest `keep` copies of this plugin, and stay under `cap` bytes in this place."""
    mine = [m for m in list_copies(key) if m.get("meta_path", "").startswith(base)]
    for m in mine[keep:]:
        delete_copy(m)
    allc = [m for m in list_copies() if m.get("meta_path", "").startswith(base)]
    total = sum(m.get("disk", 0) for m in allc)
    for m in reversed(allc):
        if total <= cap:
            break
        total -= m.get("disk", 0)
        delete_copy(m)


def prepare_copy(item, pkg, version, plugin_path, work_dir, settings=None):
    """Shell script that saves the plugin before its update, or None (nothing to save / no room)."""
    try:
        p = plan(pkg, plugin_path)
        if not p:
            _log("%s: nothing to save" % getattr(item, "key", "?"))
            return None
        base, cap = pick_store(p["size"])
        if not base:
            _log("%s: no room for a copy (%d KB)" % (getattr(item, "key", "?"), p["size"] // 1024))
            return None
        key = getattr(item, "key", "") or "x"
        _prune(base, key, cap, KEEP_PER_PLUGIN - 1)
        d = os.path.join(base, _safe(key))
        if not os.path.isdir(d):
            os.makedirs(d)
        stamp = int(time.time())
        name = "%s_%d" % (_safe(version or "0"), stamp)
        tar = os.path.join(d, name + ".tar.gz")
        meta_path = os.path.join(d, name + ".json")
        meta = {"v": 1, "id": key, "name": getattr(item, "name", "") or key, "version": version or "", "pkg": pkg or "",
                "time": stamp, "size": p["size"], "kind": p["kind"], "files": p["files"], "dirs": p["dirs"],
                "status_file": p["status_file"], "status_block": p["status_block"], "settings": settings, "tar": tar}
        with io.open(meta_path, "w", encoding="utf-8") as f:
            f.write(json.dumps(meta, ensure_ascii=False))
        lst = os.path.join(work_dir, "%s.copylist" % _safe(key))
        with io.open(lst, "w", encoding="utf-8") as f:
            f.write("\n".join(p["files"]) + "\n")
        part = tar + ".part"
        script = os.path.join(work_dir, "%s_copy.sh" % _safe(key))
        with io.open(script, "w", encoding="utf-8") as f:
            f.write(
                "#!/bin/sh\n# generated by EnigmaPlay: save the installed version before the update\n"
                "echo \"Saving %(nm)s %(ver)s so it can be rolled back ...\"\n"
                "cd %(root)s || exit 0\n"
                "tar -czf %(part)s -T %(lst)s 2>/dev/null\n"
                "[ -s %(part)s ] || tar -czf %(part)s $(cat %(lst)s) 2>/dev/null\n"
                "if [ -s %(part)s ]; then mv -f %(part)s %(tar)s; echo \"Saved ($(du -k %(tar)s | cut -f1) KB)\";\n"
                "else rm -f %(part)s %(meta)s; echo \"Could not save a rollback copy, the update continues\"; fi\n"
                "rm -f %(lst)s\nexit 0\n" % {
                    "nm": re.sub(r"[^A-Za-z0-9 ._-]", "", meta["name"])[:40], "ver": re.sub(r"[^A-Za-z0-9._-]", "", version or "")[:30],
                    "root": quote(FS_ROOT), "part": quote(part), "lst": quote(lst), "tar": quote(tar), "meta": quote(meta_path)})
        os.chmod(script, 0o700)
        _log("%s %s: copy of %d files (%d KB) -> %s" % (key, version, len(p["files"]), p["size"] // 1024, tar))
        return script
    except Exception as e:
        _log("copy not prepared: %r" % e)
        return None


# ------------------------------------------------------------------ going back
def prepare_rollback(m, work_dir):
    """Shell script that puts the saved copy back (files only; finish() fixes the database)."""
    keep = set(m.get("files") or [])
    if m.get("kind") == "pkg" and m.get("pkg"):
        now = _pkg_list(m["pkg"])
    else:
        now = []
        for d in m.get("dirs") or []:
            now += _walk(d)
    remove = [p for p in now if p not in keep and not p.startswith(NEVER_REMOVE)]
    key = _safe(m.get("id"))
    rml = os.path.join(work_dir, "%s.rmlist" % key)
    with io.open(rml, "w", encoding="utf-8") as f:
        f.write("\n".join(remove) + ("\n" if remove else ""))
    script = os.path.join(work_dir, "%s_rollback.sh" % key)
    with io.open(script, "w", encoding="utf-8") as f:
        f.write(
            "#!/bin/sh\n# generated by EnigmaPlay: go back to the saved version\n"
            "echo \"Restoring %(nm)s %(ver)s ...\"\n"
            "cd %(root)s || exit 1\n"
            "[ -s %(tar)s ] || { echo \"The saved copy is missing\"; exit 2; }\n"
            "n=0\nwhile IFS= read -r f; do [ -n \"$f\" ] && rm -f \"./$f\" && n=$((n+1)); done < %(rml)s\n"
            "echo \"Removed $n files of the newer version\"\n"
            "tar -xzf %(tar)s || { echo \"Could not unpack the saved copy\"; exit 3; }\n"
            "rm -f %(rml)s\necho \"Files restored\"\nexit 0\n" % {
                "nm": re.sub(r"[^A-Za-z0-9 ._-]", "", m.get("name") or "")[:40], "ver": re.sub(r"[^A-Za-z0-9._-]", "", m.get("version") or "")[:30],
                "root": quote(FS_ROOT), "tar": quote(m.get("tar") or ""), "rml": quote(rml)})
    os.chmod(script, 0o700)
    _log("%s: rollback to %s removes %d new files" % (m.get("id"), m.get("version"), len(remove)))
    return script


def _put_status_block(rel, pkg, block):
    path = _abs(rel)
    try:
        with io.open(path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except Exception:
        text = ""
    out, done = [], False
    for b in _blocks(text):
        if re.search(r"^Package:\s*%s\s*$" % re.escape(pkg), b, re.M):
            if not done:
                out.append(block)
                done = True
            continue
        out.append(b.strip("\n"))
    if not done:
        out.append(block)
    tmp = path + ".epbak"
    with io.open(tmp, "w", encoding="utf-8") as f:
        f.write("\n\n".join(out) + "\n\n")
    os.rename(tmp, path)


def finish(m):
    """After the files are back: the package database entry and the settings. Returns True when done."""
    ok = True
    if m.get("kind") == "pkg" and m.get("pkg") and m.get("status_file") and m.get("status_block"):
        try:
            _put_status_block(m["status_file"], m["pkg"], m["status_block"])
        except Exception as e:
            ok = False
            _log("status entry not restored: %r" % e)
    if m.get("settings"):
        try:
            from .backup import apply
            apply(m["settings"])
        except Exception as e:
            _log("settings not restored: %r" % e)
    return ok
