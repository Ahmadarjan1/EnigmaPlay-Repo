# -*- coding: utf-8 -*-
"""Typing from the phone, on every image.

The EnigmaPlay app sends text typed on the phone to http://<receiver>:8781/ep/text?t=... and it is
typed into whatever is open on the TV (virtual keyboard, search, a text setting). OpenWebif has the
same feature only in recent versions, so the store does it itself:
  1. ascii key events (setPrevAsciiCode + KEY_ASCII), like a USB keyboard: works in every input
  2. images without setPrevAsciiCode: the open screen's Input / text setting gets the text directly
Only answers devices on the home network. Built on twisted core only (always in Enigma2).

Terminal (app 2.2.2+): the phone pastes an install command (wget ... | sh) or a plugin link and it runs
here. A phone must be allowed once ON THE TV (/ep/pair shows a yes/no box); it then gets a key that
only its sha256 is kept of (/etc/enigma2/enigmaplay/phones.json). /ep/run starts the command,
/ep/out reads its output, /ep/kill stops it. One command at a time.
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import json
import re

PORT = 8781
MAX_TEXT = 500
_SESSION = None
_LISTENING = None
REMOTE_TYPE = "dreambox remote control (native)"
KEY_ASCII = 510

PHONES = "/etc/enigma2/enigmaplay/phones.json"
MAX_CMD = 4000
MAX_OUT = 300000
_JOB = {"id": 0, "proc": None, "out": u"", "base": 0, "done": True, "code": None, "lock": None}
_PAIRING = [False]

try:
    from urllib.parse import unquote_plus
except ImportError:          # Python 2
    from urllib import unquote_plus


def _log(msg):
    try:
        import io
        import time
        with io.open("/tmp/enigmaplay_remote.log", "a", encoding="utf-8") as f:
            f.write("%s text: %s\n" % (time.strftime("%H:%M:%S"), msg))
    except Exception:
        pass


def _private(ip):
    ip = (ip or "").replace("::ffff:", "")
    if ip in ("127.0.0.1", "::1"):
        return True
    m = re.match(r"^(\d+)\.(\d+)\.\d+\.\d+$", ip)
    if not m:
        return ip.startswith("fe80:") or ip.startswith("fd") or ip.startswith("fc")
    a, b = int(m.group(1)), int(m.group(2))
    return a == 10 or (a == 192 and b == 168) or (a == 172 and 16 <= b <= 31) or (a == 169 and b == 254)


def _text(t):
    if not isinstance(t, type(u"")):
        t = t.decode("utf-8", "replace")
    return t


def type_text(text):
    """Type text into what is open on the TV. Returns how ("ascii", "input", "config") or "none"."""
    text = _text(text)[:MAX_TEXT]
    if not text:
        return "none"
    try:
        from enigma import eActionMap, setPrevAsciiCode
    except ImportError:
        setPrevAsciiCode = None
    if setPrevAsciiCode is not None:
        amap = eActionMap.getInstance()
        for ch in text:
            setPrevAsciiCode(ord(ch))
            amap.keyPressed(REMOTE_TYPE, KEY_ASCII, 0)
            amap.keyPressed(REMOTE_TYPE, KEY_ASCII, 1)
        return "ascii"
    return _type_direct(text)


def _type_direct(text):
    dlg = getattr(_SESSION, "current_dialog", None) if _SESSION else None
    if dlg is None:
        return "none"
    try:
        from Components.Input import Input
    except Exception:
        Input = None
    if Input is not None:
        for name in ("text", "input", "Input", "search", "searchText"):
            try:
                w = dlg[name]
            except Exception:
                continue
            if isinstance(w, Input):
                w.setText(w.getText() + text)
                try:
                    w.end()
                except Exception:
                    pass
                return "input"
    try:                                  # a text setting selected in a settings list
        from Components.config import ConfigText
        cur = dlg["config"].getCurrent()
        cfg = cur and cur[1]
        if isinstance(cfg, ConfigText):
            cfg.value = (cfg.value or "") + text
            dlg["config"].invalidateCurrent()
            return "config"
    except Exception:
        pass
    return "none"


# ------------------------------------------------------------------ terminal
def _sha(t):
    import hashlib
    return hashlib.sha256(_text(t).encode("utf-8")).hexdigest()


def _phones():
    try:
        import io
        with io.open(PHONES, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, list) else []
    except Exception:
        return []


def _save_phones(lst):
    import io
    import os
    try:
        os.makedirs(os.path.dirname(PHONES))
    except Exception:
        pass
    tmp = PHONES + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        f.write(_text(json.dumps(lst[-20:], ensure_ascii=False)))
    os.chmod(tmp, 0o600)
    os.rename(tmp, PHONES)


def allowed(key):
    if not key or len(key) < 32:
        return False
    h = _sha(key)
    return any(p.get("key") == h for p in _phones())


def pair(name, reply):
    """Ask on the TV whether this phone may run commands. reply(status, dict) is called with the answer."""
    import os
    import binascii
    import time
    name = (_text(name) or u"phone")[:40]
    if _PAIRING[0]:
        return reply(409, {"ok": False, "why": "busy"})
    if _SESSION is None:
        return reply(503, {"ok": False, "why": "no_session"})
    from Screens.MessageBox import MessageBox
    from .i18n import _

    def answered(yes):
        _PAIRING[0] = False
        if not yes:
            _log("pair refused: %s" % name)
            return reply(200, {"ok": False, "why": "refused"})
        key = binascii.hexlify(os.urandom(24)).decode("ascii")
        lst = [p for p in _phones() if p.get("name") != name]
        lst.append({"name": name, "key": _sha(key), "at": int(time.time())})
        try:
            _save_phones(lst)
        except Exception as e:
            _log("cannot save phones: %r" % e)
            return reply(500, {"ok": False, "why": "save"})
        _log("pair allowed: %s" % name)
        reply(200, {"ok": True, "key": key})

    _PAIRING[0] = True
    try:
        _SESSION.openWithCallback(answered, MessageBox,
            _("جهاز «%s» يطلب تشغيل أوامر على هذا الرسيفر من تطبيق EnigmaPlay. هل تسمح له؟ وافق فقط إذا كنت أنت من طلب ذلك.") % name,
            MessageBox.TYPE_YESNO, timeout=60, default=False)
    except Exception as e:
        _PAIRING[0] = False
        _log("pair box failed: %r" % e)
        reply(500, {"ok": False, "why": "box"})


def _reader(proc, jid):
    while True:
        try:
            chunk = proc.stdout.read1(4096) if hasattr(proc.stdout, "read1") else proc.stdout.readline()
        except Exception:
            chunk = b""
        if not chunk:
            break
        t = chunk.decode("utf-8", "replace") if isinstance(chunk, bytes) else _text(chunk)
        with _JOB["lock"]:
            if _JOB["id"] != jid:
                return
            _JOB["out"] += t
            if len(_JOB["out"]) > MAX_OUT:              # keep the tail; offsets stay absolute
                cut = len(_JOB["out"]) - MAX_OUT
                _JOB["out"] = _JOB["out"][cut:]
                _JOB["base"] += cut
    code = proc.wait()
    with _JOB["lock"]:
        if _JOB["id"] == jid:
            _JOB["done"] = True
            _JOB["code"] = code
    _log("job %d ended: %s" % (jid, code))


def run(cmd):
    import os
    import subprocess
    import threading
    cmd = _text(cmd).strip()[:MAX_CMD]
    if not cmd:
        return 400, {"ok": False, "why": "empty"}
    if _JOB["lock"] is None:
        _JOB["lock"] = threading.Lock()
    if not _JOB["done"]:
        return 409, {"ok": False, "why": "busy", "id": _JOB["id"]}
    env = dict(os.environ)
    env["PATH"] = "/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin:" + env.get("PATH", "")
    env["HOME"] = "/root"
    env.setdefault("TERM", "dumb")
    try:
        proc = subprocess.Popen(["/bin/sh", "-c", cmd], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                stdin=open(os.devnull), cwd="/tmp", env=env, close_fds=True,
                                preexec_fn=os.setsid)        # own process group: "stop" ends its children too
    except Exception as e:
        return 500, {"ok": False, "why": "start", "error": str(e)}
    with _JOB["lock"]:
        _JOB.update({"id": _JOB["id"] + 1, "proc": proc, "out": u"", "base": 0, "done": False, "code": None, "killed": False})
        jid = _JOB["id"]
    t = threading.Thread(target=_reader, args=(proc, jid))
    t.daemon = True
    t.start()
    _log("job %d: %s" % (jid, cmd[:300].replace("\n", " ")))
    return 200, {"ok": True, "id": jid}


def output(jid, start):
    if _JOB["lock"] is None or jid != _JOB["id"]:
        return 404, {"ok": False, "why": "no_job"}
    p = _JOB.get("proc")
    if _JOB.get("killed") and not _JOB["done"] and p is not None and p.poll() is not None:
        _JOB["done"], _JOB["code"] = True, p.returncode     # stopped, even if a child still holds the pipe
    with _JOB["lock"]:
        i = max(0, start - _JOB["base"])
        text = _JOB["out"][i:i + 60000]
        nxt = _JOB["base"] + i + len(text)
        done = _JOB["done"] and nxt >= _JOB["base"] + len(_JOB["out"])
        return 200, {"ok": True, "out": text, "next": nxt, "done": done, "code": _JOB["code"] if done else None}


def kill(jid):
    p = _JOB.get("proc")
    if jid != _JOB["id"] or p is None or _JOB["done"]:
        return 200, {"ok": True}
    import os
    import signal
    _JOB["killed"] = True
    for sig in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.killpg(p.pid, sig)
        except Exception:
            try:
                p.send_signal(sig)
            except Exception:
                pass
        for _i in range(10):
            if p.poll() is not None:
                break
            import time
            time.sleep(0.1)
        if p.poll() is not None:
            break
    return 200, {"ok": True}


def _int(v, d=0):
    try:
        return int(v)
    except Exception:
        return d


def _answer(path, reply=None):
    """-> (status, dict), or None when reply(status, dict) will be called later"""
    from . import __version__
    route, _, query = path.partition("?")
    args = {}
    for part in query.split("&"):
        k, _, v = part.partition("=")
        if k:
            args[k] = unquote_plus(v)
    if route == "/ep/ping":
        return 200, {"ok": True, "version": __version__, "text": True, "term": True,
                     "paired": allowed(args.get("k", ""))}
    if route == "/ep/text":
        how = type_text(args.get("t", ""))
        _log("%d chars -> %s" % (len(args.get("t", "")), how))
        return 200, {"ok": how != "none", "how": how}
    if route == "/ep/pair" and reply is not None:
        pair(args.get("name", ""), reply)
        return None
    if route in ("/ep/run", "/ep/out", "/ep/kill"):
        if not allowed(args.get("k", "")):
            return 403, {"ok": False, "why": "not_paired"}
        if route == "/ep/run":
            return run(args.get("c", ""))
        if route == "/ep/out":
            return output(_int(args.get("id")), _int(args.get("from")))
        return kill(_int(args.get("id")))
    return 404, {"ok": False}


def start(session):
    """Listen on PORT (once per Enigma2 start)."""
    global _SESSION, _LISTENING
    _SESSION = session
    if _LISTENING is not None:
        return
    from twisted.internet import reactor, protocol

    class Http(protocol.Protocol):
        def connectionMade(self):
            self.buf = b""

        def dataReceived(self, data):
            self.buf += data
            if len(self.buf) > 32768:
                self.transport.loseConnection()
                return
            if b"\r\n" not in self.buf:
                return
            if getattr(self, "started", False):
                return
            self.started = True
            line = self.buf.split(b"\r\n", 1)[0].decode("latin-1", "replace")
            parts = line.split(" ")
            res = (400, {"ok": False})
            try:
                if not _private(self.transport.getPeer().host):
                    res = (403, {"ok": False})
                elif len(parts) >= 2 and parts[0] == "GET":
                    res = _answer(parts[1], self.reply)
            except Exception as e:
                _log("error %r" % e)
                res = (500, {"ok": False})
            if res is not None:
                self.reply(*res)

        def reply(self, status, body):
            if getattr(self, "replied", False):
                return
            self.replied = True
            raw = json.dumps(body).encode("utf-8")
            head = ("HTTP/1.0 %d OK\r\nContent-Type: application/json\r\nContent-Length: %d\r\n"
                    "Connection: close\r\n\r\n" % (status, len(raw))).encode("latin-1")
            try:
                self.transport.write(head + raw)
                self.transport.loseConnection()
            except Exception:
                pass

    f = protocol.ServerFactory()
    f.protocol = Http
    try:
        _LISTENING = reactor.listenTCP(PORT, f)
        _log("listening on %d" % PORT)
    except Exception as e:
        _LISTENING = False
        _log("cannot listen on %d: %r" % (PORT, e))
