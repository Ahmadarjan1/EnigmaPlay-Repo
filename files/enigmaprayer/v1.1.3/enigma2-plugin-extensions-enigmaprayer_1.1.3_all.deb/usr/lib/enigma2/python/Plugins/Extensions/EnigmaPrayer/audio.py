# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""Adhan playback through ALSA while the channel keeps running (same method as IPAudio).

During the adhan the DVB audio decoder is stopped (AUDIO_STOP ioctl on the decoder that
Enigma2 already holds open), so the picture continues and only the channel sound is
replaced. The adhan file is played by gst-launch-1.0 / gst-play-1.0 / ffmpeg to the ALSA
card. When it ends the decoder is restarted (AUDIO_PLAY + AV sync) and the normal
channel sound returns.
"""
from __future__ import absolute_import, division, print_function
import os
import signal
import struct
import subprocess
import time

try:
	import fcntl
except ImportError:  # not on a receiver
	fcntl = None

try:
	from urllib import pathname2url  # py2
except ImportError:
	from urllib.request import pathname2url  # py3

AUDIO_STOP = 0x6f01
AUDIO_PLAY = 0x6f02
AUDIO_SET_AV_SYNC = 0x6f07

BIN_DIRS = ("/usr/bin", "/bin", "/usr/local/bin", "/usr/sbin")


def _which(name):
	for d in BIN_DIRS:
		p = os.path.join(d, name)
		if os.path.isfile(p) and os.access(p, os.X_OK):
			return p
	return None


def available():
	return any(_which(b) for b in ("gst-launch-1.0", "gst-play-1.0", "ffmpeg"))


# ---------------------------------------------------------------- DVB decoder audio
def _enigma_audio_fds():
	"""file descriptors of /dev/dvb/adapterX/audioY that this (enigma2) process holds"""
	fds = []
	try:
		for fd in os.listdir("/proc/self/fd"):
			try:
				target = os.readlink("/proc/self/fd/" + fd)
			except OSError:
				continue
			if "/dev/dvb/adapter" in target and "/audio" in target:
				fds.append(int(fd))
	except OSError:
		pass
	return fds


def _ioctl(fd, req, arg):
	try:
		fcntl.ioctl(fd, req, arg)
		return True
	except Exception:
		return False


def mute_dvb(enable=True):
	"""Stop / restart the channel's hardware audio without touching the video."""
	if fcntl is None:
		return
	if enable:
		for adapter in range(4):
			for dev in range(4):
				path = "/dev/dvb/adapter%d/audio%d" % (adapter, dev)
				if os.path.exists(path):
					try:
						fd = os.open(path, os.O_RDWR | os.O_NONBLOCK)
					except OSError:
						continue
					_ioctl(fd, AUDIO_SET_AV_SYNC, 0)
					_ioctl(fd, AUDIO_STOP, 0)
					os.close(fd)
	for fd in _enigma_audio_fds():
		if enable:
			_ioctl(fd, AUDIO_SET_AV_SYNC, 0)
			_ioctl(fd, AUDIO_STOP, 0)
		else:
			_ioctl(fd, AUDIO_PLAY, 0)
			_ioctl(fd, AUDIO_SET_AV_SYNC, 1)
	ensure_alsa_unmuted()


def ensure_alsa_unmuted():
	"""ALSA master / HDMI / DAC switches on (some boxes keep the PCM path muted)."""
	if _which("amixer"):
		for args in ("ALL on", "Master 95%", "Hdmi 95%", "Adac 95%", "Spdif 95%"):
			os.system("amixer set %s >/dev/null 2>&1" % args)
	try:
		if os.path.exists("/proc/stb/audio/j1_mute"):
			with open("/proc/stb/audio/j1_mute", "w") as f:
				f.write("0")
	except Exception:
		pass


# ---------------------------------------------------------------- mp3 duration
_BITRATES = {  # (version, layer) -> kbps table
	(1, 3): [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320],
	(2, 3): [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160],
}
_RATES = {1: [44100, 48000, 32000], 2: [22050, 24000, 16000], 25: [11025, 12000, 8000]}


def duration(path):
	"""seconds (best effort, mp3 CBR/VBR-Xing/VBRI); 0 when unknown"""
	try:
		size = os.path.getsize(path)
		with open(path, "rb") as f:
			data = f.read(200000)
		pos = 0
		if data[:3] == b"ID3" and len(data) > 10:
			b = bytearray(data[6:10])
			pos = 10 + ((b[0] << 21) | (b[1] << 14) | (b[2] << 7) | b[3])
		data_b = bytearray(data)
		while pos + 4 < len(data_b):
			if data_b[pos] == 0xFF and (data_b[pos + 1] & 0xE0) == 0xE0:
				h = struct.unpack(">I", bytes(data_b[pos:pos + 4]))[0]
				ver_bits = (h >> 19) & 3
				layer_bits = (h >> 17) & 3
				br_i = (h >> 12) & 15
				sr_i = (h >> 10) & 3
				mode = (h >> 6) & 3
				if ver_bits == 1 or layer_bits != 1 or br_i in (0, 15) or sr_i == 3:
					pos += 1
					continue
				ver = {3: 1, 2: 2, 0: 25}[ver_bits]
				kbps = _BITRATES[(1 if ver == 1 else 2, 3)][br_i]
				rate = _RATES[ver][sr_i]
				spf = 1152 if ver == 1 else 576
				# Xing / Info header
				side = (32 if mode != 3 else 17) if ver == 1 else (17 if mode != 3 else 9)
				x = pos + 4 + side
				tag = bytes(data_b[x:x + 4])
				if tag in (b"Xing", b"Info"):
					flags = struct.unpack(">I", bytes(data_b[x + 4:x + 8]))[0]
					if flags & 1:
						frames = struct.unpack(">I", bytes(data_b[x + 8:x + 12]))[0]
						return frames * spf / float(rate)
				v = pos + 4 + 32
				if bytes(data_b[v:v + 4]) == b"VBRI":
					frames = struct.unpack(">I", bytes(data_b[v + 14:v + 18]))[0]
					return frames * spf / float(rate)
				return (size - pos) * 8.0 / (kbps * 1000.0)
			pos += 1
	except Exception as e:
		print("[EnigmaPrayer] duration", e)
	return 0.0


# ---------------------------------------------------------------- player
class AlsaPlayer(object):
	def __init__(self):
		self.proc = None
		self.started = 0.0
		self.length = 0.0
		self.muted_dvb = False

	def command(self, path, volume):
		vol = max(0.0, min(1.0, volume / 100.0))
		qpath = path.replace('"', '\\"')
		gst = _which("gst-launch-1.0")
		if gst:
			uri = "file://" + pathname2url(path)
			return ('%s playbin uri="%s" flags=0x02 volume=%.2f '
			        'audio-sink="alsasink buffer-time=200000 latency-time=20000" video-sink="fakesink"') % (gst, uri, vol)
		play = _which("gst-play-1.0")
		if play:
			return ('%s "%s" --flags=0x02 --no-interactive --audiosink="alsasink buffer-time=200000 latency-time=20000" '
			        '--volume=%.2f') % (play, qpath, vol)
		ff = _which("ffmpeg")
		if ff:
			return ('%s -nostats -loglevel error -i "%s" -af "volume=%.2f" -vn -acodec pcm_s16le -ar 48000 -ac 2 '
			        '-f alsa default') % (ff, qpath, vol)
		return None

	def start(self, path, volume, mute_channel=True):
		self.stop(restore=False)
		cmd = self.command(path, volume)
		if not cmd:
			return False
		if mute_channel:
			mute_dvb(True)
			self.muted_dvb = True
		else:
			ensure_alsa_unmuted()
		devnull = open(os.devnull, "wb")
		try:
			self.proc = subprocess.Popen(cmd, shell=True, stdout=devnull, stderr=devnull, preexec_fn=os.setsid)
		except Exception as e:
			print("[EnigmaPrayer] player start failed", e)
			self.proc = None
			if self.muted_dvb:
				mute_dvb(False)
				self.muted_dvb = False
			return False
		finally:
			devnull.close()
		self.started = time.time()
		self.length = duration(path)
		print("[EnigmaPrayer] adhan:", cmd)
		return True

	def remute(self):
		"""after a zap the new decoder starts with sound: stop it again"""
		if self.muted_dvb and self.running():
			mute_dvb(True)

	def running(self):
		return self.proc is not None and self.proc.poll() is None

	def position(self):
		if not self.proc:
			return 0.0
		pos = time.time() - self.started
		if self.length > 0:
			pos = min(pos, self.length)
		return pos

	def stop(self, restore=True):
		p = self.proc
		self.proc = None
		if p is not None and p.poll() is None:
			try:
				os.killpg(os.getpgid(p.pid), signal.SIGKILL)
			except Exception:
				try:
					p.kill()
				except Exception:
					pass
		if p is not None:
			try:
				p.wait()
			except Exception:
				pass
		if self.muted_dvb and restore:
			mute_dvb(False)
			self.muted_dvb = False
