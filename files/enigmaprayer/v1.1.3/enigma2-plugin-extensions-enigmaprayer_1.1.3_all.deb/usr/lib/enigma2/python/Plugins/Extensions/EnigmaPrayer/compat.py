# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""Python 2 / Python 3 helpers and Arabic text cleanup for Enigma2's text renderer."""
from __future__ import absolute_import, division, print_function
import re
import sys

PY2 = sys.version_info[0] == 2

if PY2:
	text_type = unicode  # noqa: F821
	binary_type = str
else:
	text_type = str
	binary_type = bytes

# Enigma2 shapes Arabic through presentation forms without OpenType mark positioning,
# so tashkeel (shadda, fatha, ...) breaks the joining of letters ("عمّان" -> "عـّمان").
_MARKS = re.compile(u"[ؐ-ًؚ-ٰٟۖ-ۜ۟-۪ۨ-ۭـ]")


def u(s):
	"""-> unicode text"""
	if s is None:
		return u""
	if isinstance(s, binary_type):
		return s.decode("utf-8", "replace")
	if not isinstance(s, text_type):
		return text_type(s)
	return s


def n(s):
	"""-> native str for Enigma2 (utf-8 bytes on Python 2)"""
	s = u(s)
	if PY2:
		return s.encode("utf-8")
	return s


def clean(s):
	return _MARKS.sub(u"", u(s))


def display(s):
	"""text ready for an eLabel"""
	return n(clean(s))
