# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""Enigma Prayer core: configuration, schedule, reminders, tasbih state, sounds."""
from __future__ import absolute_import, division, print_function
import os
import json
import time
import datetime

import io

from Components.config import config, ConfigSubsection, ConfigText, ConfigInteger, ConfigYesNo, ConfigSelection, configfile
try:
	from Components.config import ConfigSelectionNumber
except ImportError:  # very old images
	class ConfigSelectionNumber(ConfigSelection):
		def __init__(self, min, max, stepwidth, default=None, wraparound=False):
			ConfigSelection.__init__(self, choices=[str(i) for i in range(min, max + 1, stepwidth)], default=str(default))

		def getValue(self):
			return int(ConfigSelection.getValue(self))

		def setValue(self, val):
			ConfigSelection.setValue(self, str(val))

		value = property(getValue, setValue)

from .compat import u, n

from . import prayertimes as PT
from . import hijri as HJ
from . import cities as CT

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = "/etc/enigma2/EnigmaPrayer"
VERSION = "1.1.3"
AUTHOR = u"أحمد القيسي"
AUTHOR_EN = "Ahmad Al-Qaisi"
COPYRIGHT = u"Enigma Prayer v%s · © 2026 %s" % (VERSION, AUTHOR)

PRAYERS = PT.PRAYERS                      # fajr sunrise dhuhr asr maghrib isha
ADHAN_PRAYERS = ("fajr", "dhuhr", "asr", "maghrib", "isha")

# ------------------------------------------------------------------ config
cfg = config.plugins.EnigmaPrayer = ConfigSubsection()
cfg.country = ConfigText(default="jo")
cfg.city = ConfigInteger(default=0, limits=(0, 999))
cfg.custom_lat = ConfigText(default="")
cfg.custom_lon = ConfigText(default="")
cfg.method = ConfigSelection(default="jordan", choices=[(m[0], m[0]) for m in PT.METHODS])
cfg.asr = ConfigSelection(default="1", choices=[("1", "1"), ("2", "2")])
cfg.high_lat = ConfigSelection(default="angle", choices=[("angle", "angle"), ("midnight", "midnight"),
                                                         ("seventh", "seventh"), ("none", "none")])
cfg.offset_all = ConfigSelectionNumber(-60, 60, 1, default=0)
cfg.dst = ConfigSelection(default="auto", choices=[("auto", "auto"), ("winter", "winter"), ("summer", "summer")])
cfg.sound = ConfigText(default="auto")
cfg.sound_fajr = ConfigText(default="same")
cfg.volume = ConfigInteger(default=70, limits=(0, 100))
cfg.iqama = ConfigInteger(default=10, limits=(0, 60))
cfg.mute_channel = ConfigYesNo(default=True)
cfg.adhan_screen = ConfigSelection(default="full", choices=[("full", "full"), ("toast", "toast"), ("off", "off")])
cfg.iqama_screen = ConfigSelection(default="full", choices=[("full", "full"), ("toast", "toast"), ("off", "off")])
cfg.pre_alert = ConfigInteger(default=10, limits=(0, 60))
cfg.toast_secs = ConfigInteger(default=15, limits=(5, 120))
cfg.post_mute = ConfigInteger(default=10, limits=(0, 60))
cfg.hijri_adj = ConfigSelectionNumber(-3, 3, 1, default=-1)
cfg.main_view = ConfigSelection(default="table", choices=[("table", "table"), ("scene", "scene")])
cfg.months = ConfigSelection(default="greg", choices=[("greg", "greg"), ("levant", "levant")])
cfg.show_mainmenu = ConfigYesNo(default=False)
cfg.tasbih_auto = ConfigYesNo(default=True)
for _p in PRAYERS:
	setattr(cfg, "off_" + _p, ConfigSelectionNumber(-30, 30, 1, default=0))
	setattr(cfg, "alert_" + _p, ConfigYesNo(default=(_p != "sunrise")))
	setattr(cfg, "iqama_" + _p, ConfigSelectionNumber(-1, 60, 1, default=-1))


def save_config():
	cfg.save()
	configfile.save()
	bump()


# settings version: screens/service recompute when it changes
_version = [0]


def bump():
	_version[0] += 1


def version():
	return _version[0]


# ------------------------------------------------------------------ helpers
def minutes_ar(n, zero=u"بدون"):
	n = int(n)
	if n == 0:
		return zero
	a = abs(n)
	if a == 1:
		w = u"دقيقة"
	elif a == 2:
		w = u"دقيقتان"
	elif 3 <= a <= 10:
		w = u"دقائق"
	else:
		w = u"دقيقة"
	return (u"%d %s" % (a, w)) if a != 2 else u"دقيقتان"


def prayer_name(key, date=None):
	if key == "dhuhr" and date is not None and date.weekday() == 4:
		return PT.JUMUAH
	return PT.PRAYER_NAMES[key]


def hm(dt):
	return u"%02d:%02d" % (dt.hour, dt.minute)


def hms(seconds):
	seconds = max(0, int(seconds))
	return u"%02d:%02d:%02d" % (seconds // 3600, (seconds // 60) % 60, seconds % 60)


def ms(seconds):
	seconds = max(0, int(seconds))
	return u"%02d:%02d" % (seconds // 60, seconds % 60)


# ------------------------------------------------------------------ location / time
def location():
	"""(label, lat, lon, std_tz)"""
	if cfg.country.value == CT.CUSTOM_KEY:
		try:
			lat = float(cfg.custom_lat.value)
			lon = float(cfg.custom_lon.value)
		except ValueError:
			lat, lon = 31.9539, 35.9106
		return (u"موقع مخصص", lat, lon, round(lon / 15.0))
	c = CT.city(cfg.country.value, cfg.city.value)
	return (CT.label(cfg.country.value, cfg.city.value), c[1], c[2], CT.city_tz(cfg.country.value, c[0]))


def city_short():
	if cfg.country.value == CT.CUSTOM_KEY:
		return u"موقع مخصص"
	return CT.city(cfg.country.value, cfg.city.value)[0]


def now():
	if cfg.dst.value == "auto":
		return datetime.datetime.now()
	tz = location()[3] + (1 if cfg.dst.value == "summer" else 0)
	return datetime.datetime.utcnow() + datetime.timedelta(hours=tz)


def clock_valid():
	return time.time() > 1600000000  # box clock synced (after 2020)


def tz_for(date):
	if cfg.dst.value != "auto":
		return location()[3] + (1 if cfg.dst.value == "summer" else 0)
	ts = time.mktime((date.year, date.month, date.day, 12, 0, 0, 0, 0, -1))
	lt = time.localtime(ts)
	off = getattr(lt, "tm_gmtoff", None)
	if off is None:
		off = -(time.altzone if lt.tm_isdst > 0 else time.timezone)
	return off / 3600.0


_cache = {}


def day_times(date):
	"""dict prayer -> datetime for a date (cached per settings version)."""
	key = (date, version())
	r = _cache.get(key)
	if r is None:
		if len(_cache) > 16:
			_cache.clear()
		_, lat, lon, _tz = location()
		offsets = dict((p, getattr(cfg, "off_" + p).value) for p in PRAYERS)
		r = PT.calc_day(date, lat, lon, tz_for(date), cfg.method.value, int(cfg.asr.value), cfg.high_lat.value,
		                offsets, cfg.offset_all.value)
		_cache[key] = r
	return r


def iqama_minutes(p):
	if p == "sunrise":
		return 0
	v = getattr(cfg, "iqama_" + p).value
	return cfg.iqama.value if v < 0 else v


def alert_on(p):
	return getattr(cfg, "alert_" + p).value


def timeline(n=None):
	"""sorted list of (datetime, prayer) from yesterday to tomorrow"""
	n = n or now()
	d = n.date()
	out = []
	for dd in (d - datetime.timedelta(days=1), d, d + datetime.timedelta(days=1)):
		t = day_times(dd)
		for p in PRAYERS:
			out.append((t[p], p))
	out.sort(key=lambda x: x[0])
	return out


def state(n=None):
	"""Current situation used by every screen.

	returns dict: prev (dt,p), next (dt,p), iqama (None or (adhan_dt, iqama_dt, p))
	"""
	n = n or now()
	tl = timeline(n)
	prev = nxt = None
	for i, (t, p) in enumerate(tl):
		if t > n:
			nxt = (t, p)
			prev = tl[i - 1] if i > 0 else tl[0]
			break
	iq = None
	if prev and prev[1] != "sunrise":
		m = iqama_minutes(prev[1])
		if m > 0 and n < prev[0] + datetime.timedelta(minutes=m):
			iq = (prev[0], prev[0] + datetime.timedelta(minutes=m), prev[1])
	return {"now": n, "prev": prev, "next": nxt, "iqama": iq}


def date_lines(n=None):
	n = n or now()
	d = n.date()
	return greg_line(d), hijri_line(d)


def hijri_line(d):
	return HJ.hijri_str(d, cfg.hijri_adj.value)


def greg_line(d, weekday=True):
	return HJ.greg_str(d, weekday, cfg.months.value == "levant")


def period(n=None):
	"""background scene key for the time of day"""
	n = n or now()
	t = day_times(n.date())
	if n < t["fajr"]:
		return "isha"
	if n < t["sunrise"]:
		return "fajr"
	if n < t["dhuhr"] - datetime.timedelta(minutes=60):
		return "duha"
	if n < t["asr"]:
		return "dhuhr"
	if n < t["maghrib"] - datetime.timedelta(minutes=20):
		return "asr"
	if n < t["isha"]:
		return "maghrib"
	return "isha"


def method_short():
	m = cfg.method.value
	short = {"jordan": u"وزارة الأوقاف", "makkah": u"أم القرى", "egypt": u"الهيئة المصرية", "mwl": u"رابطة العالم الإسلامي",
	         "karachi": u"كراتشي", "isna": u"ISNA", "gulf": u"الخليج", "kuwait": u"الكويت", "qatar": u"قطر", "dubai": u"دبي",
	         "turkey": u"ديانت تركيا", "tunisia": u"تونس", "algeria": u"الجزائر", "morocco": u"المغرب", "france": u"فرنسا",
	         "russia": u"روسيا", "singapore": u"سنغافورة", "tehran": u"طهران"}
	return short.get(m, m)


# ------------------------------------------------------------------ sounds
SOUND_DIRS = [os.path.join(PLUGIN_DIR, "sounds"), os.path.join(DATA_DIR, "sounds"),
              "/media/hdd/adhan", "/media/usb/adhan", "/media/mmc/adhan", "/media/hdd/EnigmaPrayer",
              "/media/usb/EnigmaPrayer", "/usr/share/enigma2/EnigmaPrayer/sounds"]
SOUND_EXT = (".mp3", ".wav", ".ogg", ".m4a", ".aac", ".flac")
SOUND_NAMES = {"makkah": u"مكة المكرمة", "mecca": u"مكة المكرمة", "madinah": u"المدينة المنورة", "madina": u"المدينة المنورة",
               "aqsa": u"المسجد الأقصى", "alaqsa": u"المسجد الأقصى", "egypt": u"مصر", "fajr": u"أذان الفجر",
               "mishary": u"مشاري العفاسي", "afasy": u"مشاري العفاسي", "abdulbasit": u"عبد الباسط"}


def sound_name(path):
	base = u(os.path.splitext(os.path.basename(path))[0])
	key = base.lower().replace("_", "").replace("-", "").replace(" ", "")
	for k, v in SOUND_NAMES.items():
		if key == k:
			return v
	return base.replace("_", " ").replace("-", " ")


def sounds():
	seen = set()
	res = []
	for d in SOUND_DIRS:
		try:
			names = sorted(os.listdir(d))
		except OSError:
			continue
		for f in names:
			if f.lower().endswith(SOUND_EXT) and f not in seen:
				seen.add(f)
				res.append(os.path.join(d, f))
	return res


def sound_for(p):
	files = sounds()
	if p == "fajr" and cfg.sound_fajr.value not in ("same", "") and os.path.exists(cfg.sound_fajr.value):
		return cfg.sound_fajr.value
	v = cfg.sound.value
	if v == "none":
		return None
	if v and v != "auto" and os.path.exists(v):
		return v
	if v == "auto" or (v and not os.path.exists(v)):
		# first non-fajr file
		for f in files:
			if "fajr" not in os.path.basename(f).lower():
				return f
		return files[0] if files else None
	return None


# ------------------------------------------------------------------ json storage
def _path(name):
	return os.path.join(DATA_DIR, name)


def load_json(name, default):
	try:
		with io.open(_path(name), "r", encoding="utf-8") as f:
			return json.loads(f.read())
	except Exception:
		return default


def save_json(name, data):
	try:
		if not os.path.isdir(DATA_DIR):
			os.makedirs(DATA_DIR)
		tmp = _path(name) + ".tmp"
		txt = json.dumps(data, ensure_ascii=False, indent=1)
		with io.open(tmp, "w", encoding="utf-8") as f:
			f.write(u(txt))
		os.rename(tmp, _path(name))
	except Exception as e:
		print("[EnigmaPrayer] save error", e)


# ------------------------------------------------------------------ reminders
ANCHORS = ["fixed"] + list(PRAYERS)
WEEKDAY_NAMES = [u"الاثنين", u"الثلاثاء", u"الأربعاء", u"الخميس", u"الجمعة", u"السبت", u"الأحد"]
WEEKDAY_SINGLE = [u"اثنين", u"ثلاثاء", u"أربعاء", u"خميس", u"جمعة", u"سبت", u"أحد"]
DAY_PRESETS = [[], [4], [3], [0, 3], [6, 2], [0], [1], [2], [5], [6], [0, 1, 2, 3, 6], [4, 5]]

DEFAULT_REMINDERS = [
	{"title": u"أذكار الصباح", "enabled": True, "anchor": "fajr", "offset": 30, "time": "05:30", "days": [], "action": "tasbih"},
	{"title": u"صلاة الضحى", "enabled": True, "anchor": "sunrise", "offset": 20, "time": "07:00", "days": [], "action": "none"},
	{"title": u"أذكار المساء", "enabled": True, "anchor": "asr", "offset": 25, "time": "16:00", "days": [], "action": "tasbih"},
	{"title": u"ورد القرآن", "enabled": True, "anchor": "isha", "offset": 45, "time": "20:00", "days": [], "action": "none"},
	{"title": u"سورة الكهف", "enabled": True, "anchor": "fixed", "offset": 0, "time": "18:00", "days": [3], "action": "none"},
	{"title": u"صيام الاثنين والخميس", "enabled": False, "anchor": "fixed", "offset": 0, "time": "21:00", "days": [6, 2], "action": "none"},
]
TITLE_PRESETS = [u"أذكار الصباح", u"أذكار المساء", u"صلاة الضحى", u"ورد القرآن", u"سورة الكهف", u"قيام الليل",
                 u"صيام الاثنين والخميس", u"الصلاة على النبي", u"الاستغفار", u"أذكار النوم"]


def days_text(days):
	days = sorted(set(days or []))
	if not days or len(days) == 7:
		return u"يومياً"
	if len(days) == 1:
		return u"كل " + WEEKDAY_SINGLE[days[0]]
	if days == [0, 1, 2, 3, 6]:
		return u"أيام العمل"
	# order starting from Sunday for readability
	order = sorted(days, key=lambda d: (d + 1) % 7)
	names = [WEEKDAY_NAMES[d] for d in order]
	return u" و".join([u"، ".join(names[:-1]), names[-1]]) if len(names) > 1 else names[0]


def anchor_text(r):
	a = r.get("anchor", "fixed")
	if a == "fixed":
		return u"الساعة " + r.get("time", "00:00")
	off = int(r.get("offset", 0))
	name = PT.PRAYER_NAMES[a]
	what = name if a == "sunrise" else u"صلاة " + name
	if off == 0:
		return u"عند " + what
	if off > 0:
		return u"بعد %s بـ %s" % (what, minutes_ar(off))
	return u"قبل %s بـ %s" % (what, minutes_ar(-off))


def reminder_subtitle(r):
	return days_text(r.get("days")) + u" · " + anchor_text(r)


def reminder_time(r, date):
	a = r.get("anchor", "fixed")
	if a == "fixed":
		try:
			h, m = [int(x) for x in r.get("time", "00:00").split(":")]
		except ValueError:
			h, m = 0, 0
		return datetime.datetime(date.year, date.month, date.day, h, m)
	return day_times(date)[a] + datetime.timedelta(minutes=int(r.get("offset", 0)))


def reminder_active_on(r, date):
	days = r.get("days") or []
	return not days or date.weekday() in days


class Reminders(object):
	def __init__(self):
		self.items = load_json("reminders.json", None)
		if self.items is None:
			self.items = [dict(x) for x in DEFAULT_REMINDERS]

	def save(self):
		save_json("reminders.json", self.items)
		bump()


_reminders = [None]


def reminders():
	if _reminders[0] is None:
		_reminders[0] = Reminders()
	return _reminders[0]


# ------------------------------------------------------------------ tasbih
ADHKAR = [(u"سبحان الله", 33), (u"الحمد لله", 33), (u"الله أكبر", 34), (u"لا إله إلا الله", 100),
          (u"أستغفر الله", 100), (u"سبحان الله وبحمده", 100), (u"لا حول ولا قوة إلا بالله", 100),
          (u"اللهم صلّ على محمد", 100)]
TARGETS = [33, 34, 99, 100, 7, 10, 1000]


class Tasbih(object):
	def __init__(self):
		d = load_json("tasbih.json", {})
		self.index = d.get("index", 0)
		self.counts = d.get("counts", [0] * len(ADHKAR))
		self.targets = d.get("targets", [t for _, t in ADHKAR])
		self.today = d.get("today", 0)
		self.rounds = d.get("rounds", 0)
		self.day = d.get("day", "")
		self.total = d.get("total", 0)
		while len(self.counts) < len(ADHKAR):
			self.counts.append(0)
		while len(self.targets) < len(ADHKAR):
			self.targets.append(ADHKAR[len(self.targets)][1])
		self._check_day()
		self.dirty = False

	def _check_day(self):
		d = datetime.date.today().isoformat()
		if d != self.day:
			self.day = d
			self.today = 0
			self.rounds = 0
			self.counts = [0] * len(ADHKAR)
			self.dirty = True

	def name(self, i=None):
		return ADHKAR[self.index if i is None else i][0]

	def count(self, i=None):
		return self.counts[self.index if i is None else i]

	def target(self, i=None):
		return self.targets[self.index if i is None else i]

	def tick(self):
		"""returns True when a round has just been completed"""
		self._check_day()
		i = self.index
		self.counts[i] += 1
		self.today += 1
		self.total += 1
		self.dirty = True
		if self.counts[i] >= self.targets[i]:
			self.rounds += 1
			if cfg.tasbih_auto.value:
				self.counts[i] = 0
				self.index = (i + 1) % len(ADHKAR)
			else:
				self.counts[i] = 0
			return True
		return False

	def reset(self):
		self.counts[self.index] = 0
		self.dirty = True

	def next(self, step=1):
		self.index = (self.index + step) % len(ADHKAR)
		self.dirty = True

	def cycle_target(self):
		t = self.targets[self.index]
		i = TARGETS.index(t) if t in TARGETS else -1
		self.targets[self.index] = TARGETS[(i + 1) % len(TARGETS)]
		self.dirty = True

	def save(self, force=False):
		if self.dirty or force:
			save_json("tasbih.json", {"index": self.index, "counts": self.counts, "targets": self.targets,
			                          "today": self.today, "rounds": self.rounds, "day": self.day, "total": self.total})
			self.dirty = False


_tasbih = [None]


def tasbih():
	if _tasbih[0] is None:
		_tasbih[0] = Tasbih()
	return _tasbih[0]
