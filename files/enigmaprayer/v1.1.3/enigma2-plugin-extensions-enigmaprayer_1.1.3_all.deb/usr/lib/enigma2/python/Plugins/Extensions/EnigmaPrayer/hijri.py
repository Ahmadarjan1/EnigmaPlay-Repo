# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""Arabic Gregorian / Hijri (tabular, adjustable) date strings."""
from __future__ import absolute_import, division, print_function
import math

HIJRI_MONTHS = [u"محرم", u"صفر", u"ربيع الأول", u"ربيع الآخر", u"جمادى الأولى", u"جمادى الآخرة",
                u"رجب", u"شعبان", u"رمضان", u"شوال", u"ذو القعدة", u"ذو الحجة"]
GREG_MONTHS = [u"يناير", u"فبراير", u"مارس", u"أبريل", u"مايو", u"يونيو", u"يوليو",
               u"أغسطس", u"سبتمبر", u"أكتوبر", u"نوفمبر", u"ديسمبر"]
GREG_MONTHS_LEVANT = [u"كانون الثاني", u"شباط", u"آذار", u"نيسان", u"أيار", u"حزيران", u"تموز",
                      u"آب", u"أيلول", u"تشرين الأول", u"تشرين الثاني", u"كانون الأول"]
# Python weekday(): Monday = 0
WEEKDAYS = [u"الاثنين", u"الثلاثاء", u"الأربعاء", u"الخميس", u"الجمعة", u"السبت", u"الأحد"]


def gregorian_to_jd(y, m, d):
	return (1461 * (y + 4800 + (m - 14) // 12)) // 4 + (367 * (m - 2 - 12 * ((m - 14) // 12))) // 12 \
		- (3 * ((y + 4900 + (m - 14) // 12) // 100)) // 4 + d - 32075


def jd_to_hijri(jd):
	# civil tabular calendar (Kuwaiti algorithm variant)
	l = jd - 1948440 + 10632
	n = (l - 1) // 10631
	l = l - 10631 * n + 354
	j = ((10985 - l) // 5316) * ((50 * l) // 17719) + (l // 5670) * ((43 * l) // 15238)
	l = l - ((30 - j) // 15) * ((17719 * j) // 50) - (j // 16) * ((15238 * j) // 43) + 29
	m = (24 * l) // 709
	d = l - (709 * m) // 24
	y = 30 * n + j - 30
	return y, m, d


def hijri(date, adjust=0):
	jd = gregorian_to_jd(date.year, date.month, date.day) + int(adjust)
	return jd_to_hijri(jd)


def hijri_str(date, adjust=0):
	y, m, d = hijri(date, adjust)
	return u"%d %s %d" % (d, HIJRI_MONTHS[m - 1], y)


def greg_str(date, with_weekday=True, levant=False):
	months = GREG_MONTHS_LEVANT if levant else GREG_MONTHS
	s = u"%d %s %d" % (date.day, months[date.month - 1], date.year)
	if with_weekday:
		s = WEEKDAYS[date.weekday()] + u" " + s
	return s


def is_ramadan(date, adjust=0):
	return hijri(date, adjust)[1] == 9
