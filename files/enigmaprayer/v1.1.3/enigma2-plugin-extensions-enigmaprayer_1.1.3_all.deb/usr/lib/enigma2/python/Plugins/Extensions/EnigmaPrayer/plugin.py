# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""Enigma Prayer - prayer times, adhan, iqama, reminders and tasbih for Enigma2.

Author: Ahmad Al-Qaisi (أحمد القيسي)
"""
from __future__ import absolute_import, division, print_function
from Plugins.Plugin import PluginDescriptor

from . import core
from . import ui
from .compat import n

NAME = "Enigma Prayer"
DESC = u"مواقيت الصلاة والأذان والتسبيح"


def _prepare():
	ui.register_fonts()
	ui.load_keymap()


def main(session, **kwargs):
	_prepare()
	from .s_main import open_main
	open_main(session)


def tasbih_overlay(session, **kwargs):
	_prepare()
	from .service import PrayerService
	if PrayerService.instance is None:
		PrayerService(session)
	PrayerService.instance.open_tasbih_overlay()


def sessionstart(reason, session=None, **kwargs):
	if reason == 0 and session is not None:
		_prepare()
		from .service import PrayerService
		if PrayerService.instance is None:
			PrayerService(session)


def menu(menuid, **kwargs):
	if menuid == "mainmenu" and core.cfg.show_mainmenu.value:
		return [(n(NAME), main, "enigma_prayer", 45)]
	return []


def Plugins(**kwargs):
	return [
		PluginDescriptor(name=n(NAME), description=n(DESC), where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU],
		                 icon="plugin.png", fnc=main),
		PluginDescriptor(name=n(u"المسبحة فوق القناة"), description=n(DESC), where=PluginDescriptor.WHERE_EXTENSIONSMENU,
		                 fnc=tasbih_overlay),
		PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart),
		PluginDescriptor(name=n(NAME), description=n(DESC), where=PluginDescriptor.WHERE_MENU, fnc=menu),
	]
