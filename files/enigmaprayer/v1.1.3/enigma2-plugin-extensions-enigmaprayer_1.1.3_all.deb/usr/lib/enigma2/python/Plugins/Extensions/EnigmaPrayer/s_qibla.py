# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""Qibla direction (blue button on the main screen)."""
from __future__ import absolute_import, division, print_function
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap

from . import core
from . import prayertimes as PT
from . import ui
from .ui import label, pix, epix, screen, set_text, set_pix, GOLD, TEXT, SUB

DIRS = [u"الشمال", u"الشمال الشرقي", u"الشرق", u"الجنوب الشرقي", u"الجنوب", u"الجنوب الغربي", u"الغرب", u"الشمال الغربي"]


class QiblaScreen(Screen):
	def __init__(self, session):
		W = [epix("bg_qibla", 0, 0, 1280, 720, 0, "off"),
		     epix("compass", 150, 168, 320, 320, 1),
		     pix("needle", 150, 168, 320, 320, None, 2),
		     label("city", 560, 130, 680, 56, "EPXBold", 30, TEXT, "right"),
		     label("cap", 560, 200, 680, 40, "EPReg", 22, SUB, "right"),
		     label("deg", 560, 236, 680, 120, "EPXBold", 84, GOLD, "right"),
		     label("dir", 560, 360, 680, 44, "EPReg", 24, TEXT, "right"),
		     label("dist", 560, 412, 680, 44, "EPReg", 22, SUB, "right"),
		     label("tip", 560, 480, 680, 120, "EPReg", 18, SUB, "right", wrap=True)]
		self.skin = screen("EnigmaPrayerQibla", 0, 0, 1280, 720, W)
		Screen.__init__(self, session)
		self.setTitle(ui.n(u"اتجاه القبلة"))
		for n in ("city", "cap", "deg", "dir", "dist", "tip"):
			self[n] = Label("")
		self["needle"] = Pixmap()
		self["actions"] = ActionMap(ui.ACTION_CONTEXTS, {"cancel": self.close, "ok": self.close}, -1)
		self.onLayoutFinish.append(self.refresh)

	def refresh(self):
		name, lat, lon, _ = core.location()
		b, dist = PT.qibla(lat, lon)
		set_text(self["city"], name)
		set_text(self["cap"], u"اتجاه القبلة من الشمال الحقيقي")
		set_text(self["deg"], u"%d°" % round(b))
		set_text(self["dir"], u"باتجاه عقارب الساعة · نحو " + DIRS[int((b + 22.5) // 45) % 8])
		set_text(self["dist"], u"المسافة إلى الكعبة المشرفة: %s كم" % format(int(round(dist)), ","))
		set_text(self["tip"], u"قف متجهاً إلى الشمال (استعن ببوصلة الهاتف)، ثم استدر مع عقارب الساعة بمقدار الزاوية الظاهرة.")
		set_pix(self["needle"], "needle_%03d" % (int(round(b / 5.0)) * 5 % 360))
