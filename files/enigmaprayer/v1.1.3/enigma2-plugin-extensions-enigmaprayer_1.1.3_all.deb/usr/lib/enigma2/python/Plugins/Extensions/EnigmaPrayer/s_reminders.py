# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""Reminders list (design screen 5) and reminder editor."""
from __future__ import absolute_import, division, print_function
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap

from . import core
from . import prayertimes as PT
from . import ui
from .ui import label, pix, epix, screen, set_text, set_fg, set_font, set_pix, GOLD, DARK, TEXT, SUB, MUTED
from .s_settings import TwoColumnScreen, Opt

ROW_Y = [112 + 78 * i for i in range(6)]


class RemindersScreen(Screen):
	def __init__(self, session):
		W = [epix("bg_reminders", 0, 0, 1280, 720, 0, "off"),
		     label("subtitle", 40, 21, 400, 42, "EPReg", 22, SUB, "left"),
		     label("empty", 532, 112, 708, 200, "EPBold", 24, SUB, "center", wrap=True),
		     label("pv_title", 150, 450, 254, 45, "EPXBold", 24, TEXT, "right"),
		     label("pv_time", 74, 467, 70, 42, "EPReg", 22, GOLD, "left"),
		     label("help", 40, 572, 460, 66, "EPReg", 16, SUB, "right", wrap=True)]
		for i, y in enumerate(ROW_Y):
			W.append(pix("row%d" % i, 532, y, 708, 68, "row_rem_normal", 1))
			W.append(label("title%d" % i, 711, y + 1, 507, 38, "EPBold", 26, TEXT, "right"))
			W.append(label("sub%d" % i, 711, y + 40, 507, 26, "EPReg", 17, SUB, "right"))
			W.append(label("time%d" % i, 600, y, 95, 68, "EPReg", 28, TEXT, "right"))
			W.append(pix("tog%d" % i, 554, y + 19, 56, 30, "toggle_on", 2))
		self.skin = screen("EnigmaPrayerReminders", 0, 0, 1280, 720, W)
		Screen.__init__(self, session)
		self.setTitle(ui.n(u"التذكيرات"))
		self.rem = core.reminders()
		self.cursor = 0
		for n in ("subtitle", "empty", "pv_title", "pv_time", "help"):
			self[n] = Label("")
		for i in range(6):
			self["row%d" % i] = Pixmap()
			self["tog%d" % i] = Pixmap()
			for n in ("title", "sub", "time"):
				self["%s%d" % (n, i)] = Label("")
		self["actions"] = ActionMap(ui.ACTION_CONTEXTS, {
			"ok": self.toggle, "cancel": self.close, "red": self.delete, "green": self.new, "yellow": self.edit,
			"up": self.up, "down": self.down, "pageUp": self.page_up, "pageDown": self.page_down,
		}, -1)
		self.onLayoutFinish.append(self.refresh)

	def up(self):
		if self.rem.items:
			self.cursor = (self.cursor - 1) % len(self.rem.items)
			self.refresh()

	def down(self):
		if self.rem.items:
			self.cursor = (self.cursor + 1) % len(self.rem.items)
			self.refresh()

	def page_up(self):
		self.cursor = max(0, self.cursor - 6)
		self.refresh()

	def page_down(self):
		self.cursor = min(max(0, len(self.rem.items) - 1), self.cursor + 6)
		self.refresh()

	def toggle(self):
		if self.rem.items:
			r = self.rem.items[self.cursor]
			r["enabled"] = not r.get("enabled", True)
			self.rem.save()
			self.refresh()

	def delete(self):
		if self.rem.items:
			r = self.rem.items[self.cursor]
			self.session.openWithCallback(self._delete_ok, MessageBox, ui.n(u"حذف التذكير «%s»؟" % r.get("title")), MessageBox.TYPE_YESNO)

	def _delete_ok(self, yes):
		if yes and self.rem.items:
			del self.rem.items[self.cursor]
			self.cursor = max(0, min(self.cursor, len(self.rem.items) - 1))
			self.rem.save()
			self.refresh()

	def new(self):
		r = {"title": u"أذكار الصباح", "enabled": True, "anchor": "fajr", "offset": 30, "time": "06:00", "days": [], "action": "tasbih"}
		self.session.openWithCallback(self._edited, ReminderEditor, r, None)

	def edit(self):
		if self.rem.items:
			self.session.openWithCallback(self._edited, ReminderEditor, dict(self.rem.items[self.cursor]), self.cursor)

	def _edited(self, result=None):
		if result:
			r, idx = result
			if idx is None:
				self.rem.items.append(r)
				self.cursor = len(self.rem.items) - 1
			else:
				self.rem.items[idx] = r
			self.rem.save()
		self.refresh()

	def refresh(self):
		items = self.rem.items
		n = core.now()
		on = sum(1 for r in items if r.get("enabled"))
		set_text(self["subtitle"], u"%d تذكيرات · %d مفعّلة" % (len(items), on) if items else u"لا توجد تذكيرات")
		set_text(self["empty"], u"" if items else u"لا توجد تذكيرات بعد\nاضغط الزر الأخضر لإضافة تذكير جديد")
		set_text(self["help"], u"يظهر التذكير لمدة %d ثانية في أسفل الشاشة دون إيقاف القناة، ويختفي تلقائياً." % core.cfg.toast_secs.value)
		first = max(0, min(self.cursor - 2, len(items) - 6))
		for i in range(6):
			k = first + i
			row, tog = self["row%d" % i], self["tog%d" % i]
			tl, sl, tm = self["title%d" % i], self["sub%d" % i], self["time%d" % i]
			if k >= len(items):
				for w in (row, tog, tl, sl, tm):
					w.hide()
				continue
			for w in (row, tog, tl, sl, tm):
				w.show()
			r = items[k]
			active = k == self.cursor
			enabled = r.get("enabled", True)
			kind = "active" if active else ("normal" if enabled else "off")
			set_pix(row, "row_rem_" + kind)
			set_text(tl, r.get("title", u""))
			set_text(sl, core.reminder_subtitle(r))
			set_text(tm, core.hm(core.reminder_time(r, n.date())))
			fg = DARK if active else (TEXT if enabled else MUTED)
			set_fg(tl, fg)
			set_fg(tm, fg)
			set_fg(sl, DARK if active else (SUB if enabled else MUTED))
			set_font(tl, "EPXBold" if active else "EPBold", 26)
			set_font(tm, "EPBold" if active else "EPReg", 28)
			set_pix(tog, "toggle_%s%s" % ("on" if enabled else "off", "_inv" if active else ""))
		if items:
			r = items[self.cursor]
			set_text(self["pv_title"], u"تذكير: " + r.get("title", u""))
			set_text(self["pv_time"], core.hm(core.reminder_time(r, n.date())))
		else:
			set_text(self["pv_title"], u"")
			set_text(self["pv_time"], u"")


class ReminderEditor(TwoColumnScreen):
	BG = "bg_editor"
	SKIN_NAME = "EnigmaPrayerReminderEditor"

	def __init__(self, session, r, idx):
		self.r = r
		self.idx = idx
		r.setdefault("days", [])
		r.setdefault("offset", 0)
		r.setdefault("time", "20:00")
		TwoColumnScreen.__init__(self, session)
		self.setTitle(ui.n(u"تعديل التذكير"))

	def build_pages(self):
		r = self.r

		def g(k):
			return lambda: r.get(k)

		def s(k):
			def setter(v):
				r[k] = v
			return setter

		titles = list(core.TITLE_PRESETS)
		if r.get("title") not in titles:
			titles.insert(0, r.get("title"))
		anchors = [("fixed", u"وقت محدد")] + [(p, PT.PRAYER_NAMES[p]) for p in core.PRAYERS]

		def off_text(v):
			if v == 0:
				return u"عند الوقت"
			return (u"بعد " if v > 0 else u"قبل ") + core.minutes_ar(abs(v))
		offsets = [(v, off_text(v)) for v in range(-120, 125, 5)]

		def hour_get():
			return int(r.get("time", "20:00").split(":")[0])

		def hour_set(v):
			r["time"] = u"%02d:%02d" % (v, minute_get())

		def minute_get():
			return int(r.get("time", "20:00").split(":")[1])

		def minute_set(v):
			r["time"] = u"%02d:%02d" % (hour_get(), v)

		fixed = lambda: r.get("anchor") == "fixed"
		relative = lambda: r.get("anchor") != "fixed"
		presets = [list(p) for p in core.DAY_PRESETS]
		if sorted(r.get("days") or []) not in [sorted(p) for p in presets]:
			presets.insert(0, sorted(r.get("days") or []))
		day_vals = [(tuple(sorted(p)), core.days_text(p)) for p in presets]

		def days_get():
			return tuple(sorted(r.get("days") or []))

		def days_set(v):
			r["days"] = list(v)

		right = (u"التذكير", [
			Opt(u"العنوان", "select", g("title"), s("title"), [(t, t) for t in titles]),
			Opt(u"التوقيت", "select", g("anchor"), s("anchor"), anchors),
			Opt(u"الفارق", "select", g("offset"), s("offset"), offsets, wrap=False, enabled=relative),
			Opt(u"الساعة", "select", hour_get, hour_set, [(h, u"%02d" % h) for h in range(24)], enabled=fixed),
			Opt(u"الدقيقة", "select", minute_get, minute_set, [(m, u"%02d" % m) for m in range(0, 60, 5)], enabled=fixed),
		])
		left = (u"التكرار والإجراء", [
			Opt(u"الأيام", "select", days_get, days_set, day_vals),
			Opt(u"فتح المسبحة", "toggle", lambda: r.get("action") == "tasbih",
			    lambda v: r.__setitem__("action", "tasbih" if v else "none")),
			Opt(u"مفعّل", "toggle", lambda: r.get("enabled", True), s("enabled")),
		])
		return [(right, left)]

	def key_yellow(self):
		try:
			from Screens.VirtualKeyBoard import VirtualKeyBoard
		except ImportError:
			return
		self.session.openWithCallback(self._renamed, VirtualKeyBoard, title=ui.n(u"اسم التذكير"), text=ui.n(self.r.get("title", u"")))

	def _renamed(self, text=None):
		if text:
			self.r["title"] = ui.u(text).strip()
			p, c = self.page, self.cursor
			self.pages = self.build_pages()
			self.page, self.cursor = p, c
			self.refresh()

	def key_save(self):
		self.close((self.r, self.idx))

	def key_cancel(self):
		self.close(None)

	def key_exit(self):
		self.close(None)

