# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""Settings (design screen 6), generic two-column option pages, city picker."""
from __future__ import absolute_import, division, print_function
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap

from . import core
from . import cities as CT
from . import prayertimes as PT
from . import ui
from .ui import (label, box, pix, epix, screen, set_text, set_fg, set_font, set_pix, fill_rtl,
                 GOLD, DARK, TEXT, SUB, MUTED)

COL_X = [656, 40]            # right column first (RTL)
ROW_Y = [152 + 88 * i for i in range(5)]


class Opt(object):
	"""one settings row.
	kind: select | toggle | slider | action
	values: list of (value, text) for select
	"""

	def __init__(self, title, kind, get, set=None, values=None, ok=None, text=None, wrap=True, enabled=None):
		self.title = title
		self.kind = kind
		self.get = get
		self.set = set
		self.values = values or []
		self.ok = ok
		self.text_fn = text
		self.wrap = wrap
		self.enabled = enabled

	def is_enabled(self):
		return self.enabled is None or self.enabled()

	def text(self):
		if not self.is_enabled():
			return u"—"
		if self.text_fn:
			return self.text_fn()
		v = self.get()
		for val, t in self.values:
			if val == v:
				return t
		return ui.u(v)

	def step(self, d):
		if not self.is_enabled():
			return
		if self.kind == "toggle":
			self.set(not self.get())
			return
		if self.kind == "slider":
			self.set(max(0, min(100, self.get() + 5 * d)))
			return
		if not self.values:
			if self.ok and self.kind == "action" and self.set:
				self.set(d)
			return
		vals = [v for v, _ in self.values]
		v = self.get()
		i = vals.index(v) if v in vals else -1
		i += d
		if self.wrap:
			i %= len(vals)
		else:
			i = max(0, min(len(vals) - 1, i))
		self.set(vals[i])


def cfg_opt(title, el, values, kind="select", wrap=True, enabled=None):
	def setter(v):
		el.value = v
	return Opt(title, kind, lambda: el.value, setter, values, wrap=wrap, enabled=enabled)


def minutes_values(lst, zero=u"بدون"):
	return [(v, core.minutes_ar(v, zero)) for v in lst]


class TwoColumnScreen(Screen):
	BG = "bg_settings"
	SKIN_NAME = "EnigmaPrayerSettings"

	def __init__(self, session):
		W = [epix(self.BG, 0, 0, 1280, 720, 0, "off"),
		     label("page", 440, 21, 400, 42, "EPReg", 18, SUB, "center"),
		     label("credit", 40, 602, 1200, 40, "EPReg", 17, MUTED, "center")]
		for c, x in enumerate(COL_X):
			W.append(label("sect%d" % c, x, 108, 584, 36, "EPReg", 20, SUB, "right"))
			for r, y in enumerate(ROW_Y):
				k = "%d_%d" % (c, r)
				W.append(pix("row" + k, x, y, 584, 76, "row_set_normal", 1))
				W.append(label("name" + k, x + 282, y, 280, 76, "EPBold", 24, TEXT, "right"))
				W.append(label("val" + k, x + 48, y, 198, 76, "EPReg", 22, TEXT, "center"))
				W.append(pix("chl" + k, x + 22, y + 27, 22, 22, "chev_l", 2))
				W.append(pix("chr" + k, x + 250, y + 27, 22, 22, "chev_r", 2))
				W.append(pix("tog" + k, x + 22, y + 23, 56, 30, "toggle_on", 2))
				W.append(label("pct" + k, x + 22, y, 56, 76, "EPReg", 22, TEXT, "left"))
				W.append(pix("trk" + k, x + 80, y + 33, 140, 10, "track_140", 2))
				W.append(box("fil" + k, x + 80, y + 33, 140, 10, GOLD, 3))
		self.skin = screen(self.SKIN_NAME, 0, 0, 1280, 720, W)
		Screen.__init__(self, session)
		self["page"] = Label("")
		self["credit"] = Label("")
		for c in range(2):
			self["sect%d" % c] = Label("")
			for r in range(5):
				k = "%d_%d" % (c, r)
				for n in ("name", "val", "pct", "fil"):
					self[n + k] = Label("")
				for n in ("row", "chl", "chr", "tog", "trk"):
					self[n + k] = Pixmap()
		self.page = 0
		self.cursor = 0
		self.pages = self.build_pages()
		self["actions"] = ActionMap(ui.ACTION_CONTEXTS, {
			"ok": self.key_ok, "cancel": self.key_exit, "red": self.key_cancel, "green": self.key_save,
			"yellow": self.key_yellow, "up": self.up, "down": self.down, "left": self.left, "right": self.right,
			"pageUp": self.page_prev, "pageDown": self.page_next,
		}, -1)
		self.onLayoutFinish.append(self.refresh)

	# subclasses -------------------------------------------------
	def build_pages(self):
		return []

	def key_save(self):
		self.close(True)

	def key_cancel(self):
		self.close(False)

	def key_exit(self):
		self.key_cancel()

	def key_yellow(self):
		pass

	def changed(self):
		return False

	# navigation -------------------------------------------------
	def opts(self):
		p = self.pages[self.page]
		return p[0][1] + p[1][1]

	def current(self):
		o = self.opts()
		return o[self.cursor] if self.cursor < len(o) else None

	def up(self):
		if self.cursor > 0:
			self.cursor -= 1
		elif self.page > 0:
			self.page -= 1
			self.cursor = len(self.opts()) - 1
		else:
			self.page = len(self.pages) - 1
			self.cursor = len(self.opts()) - 1
		self.refresh()

	def down(self):
		if self.cursor < len(self.opts()) - 1:
			self.cursor += 1
		elif self.page < len(self.pages) - 1:
			self.page += 1
			self.cursor = 0
		else:
			self.page = 0
			self.cursor = 0
		self.refresh()

	def page_next(self):
		self.page = (self.page + 1) % len(self.pages)
		self.cursor = 0
		self.refresh()

	def page_prev(self):
		self.page = (self.page - 1) % len(self.pages)
		self.cursor = 0
		self.refresh()

	# RTL: the left arrow moves "forward"
	def left(self):
		o = self.current()
		if o:
			o.step(1)
			self.after_change(o)
			self.refresh()

	def right(self):
		o = self.current()
		if o:
			o.step(-1)
			self.after_change(o)
			self.refresh()

	def after_change(self, o):
		pass

	def key_ok(self):
		o = self.current()
		if o and o.kind == "action" and o.ok:
			o.ok()
		elif o and o.kind == "toggle":
			o.step(1)
			self.refresh()
		else:
			self.key_save()

	# drawing ----------------------------------------------------
	def refresh(self):
		set_text(self["credit"], core.COPYRIGHT)
		pg = self.pages[self.page]
		if len(self.pages) > 1:
			set_text(self["page"], u"صفحة %d من %d · CH± للتنقل" % (self.page + 1, len(self.pages)))
		else:
			set_text(self["page"], u"")
		idx = 0
		for c in range(2):
			title, opts = pg[c]
			set_text(self["sect%d" % c], title)
			for r in range(5):
				k = "%d_%d" % (c, r)
				o = opts[r] if r < len(opts) else None
				active = o is not None and idx == self.cursor
				self.draw_row(k, o, active, c, r)
				if o is not None:
					idx += 1

	def draw_row(self, k, o, active, c, r):
		row, name, val = self["row" + k], self["name" + k], self["val" + k]
		chl, chr_, tog, pct, trk, fil = (self["chl" + k], self["chr" + k], self["tog" + k],
		                                 self["pct" + k], self["trk" + k], self["fil" + k])
		if o is None:
			for w in (row, name, val, chl, chr_, tog, pct, trk, fil):
				w.hide()
			return
		row.show()
		name.show()
		set_pix(row, "row_set_active" if active else "row_set_normal")
		set_text(name, o.title)
		fg = DARK if active else TEXT
		set_fg(name, fg)
		set_font(name, "EPXBold" if active else "EPBold", 24)
		kind = o.kind
		is_sel = kind in ("select", "action")
		for w in (val, chl, chr_):
			ui.set_visible(w, is_sel)
		ui.set_visible(tog, kind == "toggle")
		for w in (pct, trk):
			ui.set_visible(w, kind == "slider")
		if kind != "slider":
			fil.hide()
		if is_sel:
			t = o.text()
			set_text(val, t)
			set_fg(val, fg)
			size = 22 if len(t) <= 16 else (19 if len(t) <= 21 else 17)
			set_font(val, "EPBold" if active else "EPReg", size)
			set_pix(chl, "chev_l_dark" if active else "chev_l")
			set_pix(chr_, "chev_r_dark" if active else "chev_r")
			if not o.is_enabled():
				chl.hide()
				chr_.hide()
		elif kind == "toggle":
			on = bool(o.get())
			set_pix(tog, "toggle_%s%s" % ("on" if on else "off", "_inv" if active else ""))
		elif kind == "slider":
			v = o.get()
			set_text(pct, u"%d%%" % v)
			set_fg(pct, fg)
			set_pix(trk, "track_140_inv" if active else "track_140")
			x = COL_X[c] + 80
			y = ROW_Y[r] + 33
			fill_rtl(fil, x, y, 140, 10, v / 100.0)
			set_fg(fil, fg)
			if fil.instance:
				fil.instance.setBackgroundColor(ui.parseColor(DARK if active else GOLD))


# ====================================================================== settings
class SettingsScreen(TwoColumnScreen):
	BG = "bg_settings"
	SKIN_NAME = "EnigmaPrayerSettings"

	def __init__(self, session):
		self.cfg = core.cfg
		self.snapshot = dict((k, getattr(core.cfg, k).value) for k in core.cfg.dict().keys())
		TwoColumnScreen.__init__(self, session)
		self.setTitle(ui.n(u"الإعدادات"))

	def build_pages(self):
		c = core.cfg
		files = core.sounds()
		sound_vals = [("auto", u"تلقائي")] + [(f, core.sound_name(f)) for f in files] + [("none", u"بدون صوت")]
		if not files:
			sound_vals = [("auto", u"لا توجد ملفات صوت"), ("none", u"بدون صوت")]
		fajr_vals = [("same", u"نفس صوت الأذان")] + [(f, core.sound_name(f)) for f in files]

		def city_text():
			return core.location()[0]

		def city_step(d):
			if c.country.value == CT.CUSTOM_KEY:
				return
			n = len(CT.CITIES.get(c.country.value, []))
			c.city.value = (c.city.value + d) % max(1, n)

		city = Opt(u"المدينة", "action", lambda: None, city_step, ok=self.pick_city, text=city_text)
		methods = [(m[0], m[1]) for m in PT.METHODS]
		iq_vals = minutes_values(range(0, 61))
		per_iq = [(-1, u"حسب العام (%s)" % core.minutes_ar(c.iqama.value))] + minutes_values(range(0, 61))
		offs = [(v, (u"%+d دقيقة" % v) if v else u"بدون") for v in range(-30, 31)]
		offs_all = [(v, (u"%+d دقيقة" % v) if v else u"0 دقيقة") for v in range(-60, 61)]
		hij = [(v, (u"%+d يوم" % v) if v else u"بدون") for v in range(-3, 4)]

		page1 = ((u"الموقع والحساب", [
			city,
			cfg_opt(u"طريقة الحساب", c.method, methods),
			cfg_opt(u"وقت العصر", c.asr, [("1", u"الجمهور"), ("2", u"الحنفي")]),
			cfg_opt(u"تعديل كل الصلوات", c.offset_all, offs_all, wrap=False),
			cfg_opt(u"التوقيت الصيفي", c.dst, [("auto", u"تلقائي"), ("winter", u"شتوي"), ("summer", u"صيفي (+1)")]),
		]), (u"الأذان والإقامة", [
			cfg_opt(u"صوت الأذان", c.sound, sound_vals),
			cfg_opt(u"مستوى صوت الأذان", c.volume, [], kind="slider"),
			cfg_opt(u"الإقامة بعد الأذان", c.iqama, iq_vals, wrap=False),
			cfg_opt(u"كتم القناة أثناء الأذان", c.mute_channel, [], kind="toggle"),
			cfg_opt(u"شكل شاشة الأذان", c.adhan_screen, [("full", u"ملء الشاشة"), ("toast", u"إشعار"), ("off", u"بدون")]),
		]))
		page2 = ((u"التنبيهات", [
			cfg_opt(u"تنبيه قبل الأذان", c.pre_alert, minutes_values([0, 5, 10, 15, 20, 30])),
			cfg_opt(u"مدة ظهور الإشعار", c.toast_secs, [(v, u"%d ثانية" % v) for v in (10, 15, 20, 30, 60)]),
			cfg_opt(u"كتم الصوت بعد الإقامة", c.post_mute, minutes_values([0, 5, 10, 15, 20, 30])),
			cfg_opt(u"شاشة العد للإقامة", c.iqama_screen, [("full", u"ملء الشاشة"), ("toast", u"إشعار"), ("off", u"بدون")]),
			cfg_opt(u"صوت أذان الفجر", c.sound_fajr, fajr_vals),
		]), (u"الإقامة لكل صلاة", [
			cfg_opt(u"الفجر", c.iqama_fajr, per_iq, wrap=False),
			cfg_opt(u"الظهر", c.iqama_dhuhr, per_iq, wrap=False),
			cfg_opt(u"العصر", c.iqama_asr, per_iq, wrap=False),
			cfg_opt(u"المغرب", c.iqama_maghrib, per_iq, wrap=False),
			cfg_opt(u"العشاء", c.iqama_isha, per_iq, wrap=False),
		]))
		page3 = ((u"العرض والتاريخ", [
			cfg_opt(u"الشاشة الرئيسية", c.main_view, [("table", u"جدول المواقيت"), ("scene", u"مشهد السماء")]),
			cfg_opt(u"تعديل التاريخ الهجري", c.hijri_adj, hij, wrap=False),
			cfg_opt(u"أسماء الأشهر", c.months, [("greg", u"يناير، فبراير…"), ("levant", u"كانون، شباط…")]),
			cfg_opt(u"خطوط العرض العليا", c.high_lat, [("angle", u"نسبة الزاوية"), ("midnight", u"منتصف الليل"),
			                                            ("seventh", u"سُبع الليل"), ("none", u"بدون")]),
			cfg_opt(u"في القائمة الرئيسية", c.show_mainmenu, [], kind="toggle"),
		]), (u"تعديل دقائق كل صلاة", [
			cfg_opt(u"الفجر", c.off_fajr, offs, wrap=False),
			cfg_opt(u"الظهر", c.off_dhuhr, offs, wrap=False),
			cfg_opt(u"العصر", c.off_asr, offs, wrap=False),
			cfg_opt(u"المغرب", c.off_maghrib, offs, wrap=False),
			cfg_opt(u"العشاء", c.off_isha, offs, wrap=False),
		]))
		return [page1, page2, page3]

	def after_change(self, o):
		if o.title == u"الإقامة بعد الأذان":
			# refresh the "general" label of the per-prayer values
			p, c = self.page, self.cursor
			self.pages = self.build_pages()
			self.page, self.cursor = p, c
		core.bump()   # preview immediately (times, labels)

	def changed(self):
		return any(getattr(core.cfg, k).value != v for k, v in self.snapshot.items())

	def pick_city(self):
		self.session.openWithCallback(self._city_done, CityPicker)

	def _city_done(self, result=None):
		if result:
			country, idx = result
			core.cfg.country.value = country
			core.cfg.city.value = idx
			if country != CT.CUSTOM_KEY:
				core.cfg.method.value = CT.country(country)[3]
			core.bump()
		self.refresh()

	def key_save(self):
		core.save_config()
		self.close(True)

	def key_cancel(self):
		for k, v in self.snapshot.items():
			getattr(core.cfg, k).value = v
		core.bump()
		self.close(False)

	def key_exit(self):
		if self.changed():
			self.session.openWithCallback(self._ask_done, MessageBox, ui.n(u"حفظ التغييرات؟"), MessageBox.TYPE_YESNO)
		else:
			self.close(False)

	def _ask_done(self, yes):
		if yes:
			self.key_save()
		else:
			self.key_cancel()

	def key_yellow(self):
		from .service import PrayerService
		if PrayerService.instance:
			core.save_config()
			self.snapshot = dict((k, getattr(core.cfg, k).value) for k in core.cfg.dict().keys())
			PrayerService.instance.test_adhan()


# ====================================================================== city picker
class CityPicker(Screen):
	ROWS = 8

	def __init__(self, session):
		W = [epix("bg_city", 0, 0, 1280, 720, 0, "off")]
		for c, x in enumerate(COL_X):
			W.append(label("sect%d" % c, x, 108, 584, 36, "EPReg", 20, SUB, "right"))
			for r in range(self.ROWS):
				y = 152 + 60 * r
				W.append(pix("row%d_%d" % (c, r), x, y, 584, 52, "row_city_normal", 1))
				W.append(label("txt%d_%d" % (c, r), x + 22, y, 540, 52, "EPBold", 22, TEXT, "right"))
		self.skin = screen("EnigmaPrayerCity", 0, 0, 1280, 720, W)
		Screen.__init__(self, session)
		self.setTitle(ui.n(u"اختيار المدينة"))
		for c in range(2):
			self["sect%d" % c] = Label("")
			for r in range(self.ROWS):
				self["row%d_%d" % (c, r)] = Pixmap()
				self["txt%d_%d" % (c, r)] = Label("")
		self.countries = [(k, n) for k, n, _, _ in CT.COUNTRIES] + [(CT.CUSTOM_KEY, u"إحداثيات مخصصة…")]
		keys = [k for k, _ in self.countries]
		cur = core.cfg.country.value
		self.ci = keys.index(cur) if cur in keys else 0
		self.ti = core.cfg.city.value if cur != CT.CUSTOM_KEY else 0
		self.col = 1 if cur != CT.CUSTOM_KEY else 0   # start in the cities column
		self["actions"] = ActionMap(ui.ACTION_CONTEXTS, {
			"ok": self.ok, "green": self.ok, "cancel": self.cancel, "red": self.cancel,
			"up": self.up, "down": self.down, "left": self.to_cities, "right": self.to_countries,
			"pageUp": self.page_up, "pageDown": self.page_down,
		}, -1)
		self.onLayoutFinish.append(self.refresh)

	def cities(self):
		k = self.countries[self.ci][0]
		return [c[0] for c in CT.CITIES.get(k, [])]

	def up(self):
		self._move(-1)

	def down(self):
		self._move(1)

	def page_up(self):
		self._move(-self.ROWS)

	def page_down(self):
		self._move(self.ROWS)

	def _move(self, d):
		if self.col == 0:
			self.ci = max(0, min(len(self.countries) - 1, self.ci + d))
			self.ti = 0
		else:
			n = len(self.cities())
			if n:
				self.ti = max(0, min(n - 1, self.ti + d))
		self.refresh()

	def to_cities(self):
		if self.cities():
			self.col = 1
			self.refresh()

	def to_countries(self):
		self.col = 0
		self.refresh()

	def ok(self):
		key = self.countries[self.ci][0]
		if key == CT.CUSTOM_KEY:
			self.ask_custom()
			return
		if self.col == 0:
			self.to_cities()
			return
		self.close((key, self.ti))

	def ask_custom(self):
		try:
			from Screens.VirtualKeyBoard import VirtualKeyBoard
		except ImportError:
			return
		cur = u"%s,%s" % (ui.u(core.cfg.custom_lat.value) or u"31.95", ui.u(core.cfg.custom_lon.value) or u"35.91")
		self.session.openWithCallback(self._custom_done, VirtualKeyBoard,
		                              title=ui.n(u"خط العرض,خط الطول (مثال 31.95,35.91)"), text=ui.n(cur))

	def _custom_done(self, text=None):
		if not text:
			return
		text = ui.u(text)
		try:
			lat, lon = [float(x.strip()) for x in text.replace(u"،", u",").split(u",")[:2]]
		except ValueError:
			self.session.open(MessageBox, ui.n(u"صيغة غير صحيحة"), MessageBox.TYPE_ERROR, timeout=5)
			return
		core.cfg.custom_lat.value = "%.4f" % lat
		core.cfg.custom_lon.value = "%.4f" % lon
		self.close((CT.CUSTOM_KEY, 0))

	def cancel(self):
		self.close(None)

	def refresh(self):
		set_text(self["sect0"], u"الدولة")
		set_text(self["sect1"], u"المدينة")
		lists = [[n for _, n in self.countries], self.cities()]
		sel = [self.ci, self.ti]
		for c in range(2):
			items = lists[c]
			first = max(0, min(sel[c] - self.ROWS // 2, len(items) - self.ROWS))
			for r in range(self.ROWS):
				i = first + r
				row, txt = self["row%d_%d" % (c, r)], self["txt%d_%d" % (c, r)]
				if i >= len(items):
					row.hide()
					txt.hide()
					continue
				row.show()
				txt.show()
				is_sel = i == sel[c]
				focused = is_sel and self.col == c
				set_pix(row, "row_city_active" if focused else ("row_city_sel" if is_sel else "row_city_normal"))
				set_text(txt, items[i])
				set_fg(txt, DARK if focused else TEXT)
				set_font(txt, "EPXBold" if focused else "EPBold", 22)
