# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""Tasbih counter (design screen 4)."""
from __future__ import absolute_import, division, print_function
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap

from . import core
from . import ui
from .ui import label, pix, epix, screen, set_text, set_fg, set_font, set_pix, GOLD, DARK, TEXT, WHITE, SUB

ROW_Y = [154, 224, 294, 365, 435]


class TasbihScreen(Screen):
	def __init__(self, session, context=None):
		W = [epix("bg_tasbih", 0, 0, 1280, 720, 0, "off"),
		     label("subtitle", 40, 21, 560, 42, "EPReg", 22, SUB, "left"),
		     label("dhikr", 520, 106, 720, 146, "EPAmiri", 96, WHITE, "center"),
		     pix("ring", 730, 257, 300, 300, None, 1),
		     label("count", 750, 322, 260, 120, "EPXBold", 110, TEXT, "center"),
		     label("target", 760, 437, 240, 49, "EPReg", 26, SUB, "center"),
		     label("today", 285, 550, 176, 63, "EPBold", 34, TEXT, "right"),
		     label("rounds", 59, 550, 176, 63, "EPBold", 34, TEXT, "right")]
		for i, y in enumerate(ROW_Y):
			W.append(pix("row%d" % i, 40, y, 440, 58, "row_tas_normal", 1))
			W.append(label("rname%d" % i, 200, y, 258, 58, "EPBold", 24, TEXT, "right"))
			W.append(label("rcount%d" % i, 62, y, 140, 58, "EPBold", 24, SUB, "left"))
		self.skin = screen("EnigmaPrayerTasbih", 0, 0, 1280, 720, W)
		Screen.__init__(self, session)
		self.setTitle(ui.n(u"المسبحة"))
		self.st = core.tasbih()
		self.context = context
		for n in ("subtitle", "dhikr", "count", "target", "today", "rounds"):
			self[n] = Label("")
		self["ring"] = Pixmap()
		for i in range(5):
			self["row%d" % i] = Pixmap()
			self["rname%d" % i] = Label("")
			self["rcount%d" % i] = Label("")
		self._rows = [None] * 5
		self._ring = None
		self._dhikr = None
		self["actions"] = ActionMap(ui.ACTION_CONTEXTS, {
			"ok": self.count, "cancel": self.exit, "red": self.reset, "green": self.next,
			"yellow": self.target, "blue": self.toggle_auto, "up": self.prev, "down": self.next,
		}, -1)
		self.onLayoutFinish.append(self.refresh)
		self.onClose.append(lambda: self.st.save(True))

	def _subtitle(self):
		if self.context:
			return self.context
		st = core.state()
		prev = st["prev"]
		n = st["now"]
		if prev and prev[1] != "sunrise" and (n - prev[0]).total_seconds() < 3600:
			return u"تسبيح ما بعد الصلاة · " + core.prayer_name(prev[1], prev[0].date())
		auto = u" · انتقال تلقائي" if core.cfg.tasbih_auto.value else u""
		return u"تسبيح حر" + auto

	def refresh(self):
		st = self.st
		set_text(self["subtitle"], self._subtitle())
		name = st.name()
		if name != self._dhikr:
			self._dhikr = name
			# long adhkar get a smaller font so they stay on one line
			L = len(name)
			size = 96 if L <= 11 else (76 if L <= 16 else 60)
			set_font(self["dhikr"], "EPAmiri", size)
			set_text(self["dhikr"], name)
		c, t = st.count(), st.target()
		set_text(self["count"], u"%d" % c)
		set_text(self["target"], u"من %d" % t)
		set_font(self["count"], "EPXBold", 110 if c < 100 else (84 if c < 1000 else 64))
		r = ui.ring_name("ring300", c / float(max(1, t)))
		if r != self._ring:
			self._ring = r
			set_pix(self["ring"], r)
		set_text(self["today"], u"%d" % st.today)
		set_text(self["rounds"], u"%d" % st.rounds)
		# list window keeps the selected dhikr visible
		n = len(core.ADHKAR)
		first = max(0, min(st.index - 2, n - 5))
		for i in range(5):
			k = first + i
			active = k == st.index
			key = (k, active, st.count(k), st.target(k))
			if self._rows[i] == key:
				continue
			self._rows[i] = key
			set_pix(self["row%d" % i], "row_tas_active" if active else "row_tas_normal")
			set_text(self["rname%d" % i], st.name(k))
			set_text(self["rcount%d" % i], u"%d / %d" % (st.count(k), st.target(k)))
			set_fg(self["rname%d" % i], DARK if active else TEXT)
			set_fg(self["rcount%d" % i], DARK if active else SUB)
			set_font(self["rname%d" % i], "EPXBold" if active else "EPBold", 24)
			set_font(self["rcount%d" % i], "EPXBold" if active else "EPBold", 24)

	def count(self):
		self.st.tick()
		self.refresh()

	def reset(self):
		self.st.reset()
		self.refresh()

	def next(self):
		self.st.next(1)
		self.refresh()

	def prev(self):
		self.st.next(-1)
		self.refresh()

	def target(self):
		self.st.cycle_target()
		self.refresh()

	def toggle_auto(self):
		core.cfg.tasbih_auto.value = not core.cfg.tasbih_auto.value
		core.cfg.tasbih_auto.save()
		self.refresh()

	def exit(self):
		self.st.save(True)
		self.close()
