# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""Skin building (designed at 1280x720, scaled to the desktop) and widget helpers."""
from __future__ import absolute_import, division, print_function
import os

from enigma import getDesktop, addFont, gFont, eSize, ePoint, eTimer

try:
	from skin import parseColor
except ImportError:  # very old images
	from enigma import gRGB

	def parseColor(s):
		return gRGB(int(s[1:], 16))

from Tools.LoadPixmap import LoadPixmap

from .compat import u, n, clean, display, PY2  # noqa: F401

try:  # older images / DreamOS have no eLabel.setNoWrap -> no "noWrap" skin attribute
	from enigma import eLabel
	HAS_NOWRAP = hasattr(eLabel, "setNoWrap")
except ImportError:
	HAS_NOWRAP = False

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))

# ------------------------------------------------------------------ palette
GOLD = "#D9B25F"
DARK = "#0A1C26"
TEXT = "#EAF2F0"
WHITE = "#FFFFFF"
SUB = "#9DB6BB"
MUTED = "#6F8A91"
FOOT = "#C5D6D8"
CARD = "#10303D"
PAST = "#0F2733"
TRACK = "#1B3B49"
FILL_DIM = "#3F6A7A"

# font weights in the design -> registered font names
FONTS = {
	"EPReg": "EPCairo-Regular.ttf",
	"EPBold": "EPCairo-Bold.ttf",
	"EPXBold": "EPCairo-ExtraBold.ttf",
	"EPAmiri": "EPAmiri-Bold.ttf",
}
_fonts_done = [False]


def register_fonts():
	if _fonts_done[0]:
		return
	for name, f in FONTS.items():
		path = os.path.join(PLUGIN_DIR, "fonts", f)
		try:
			addFont(path, name, 100, False)
		except Exception as e:
			print("[EnigmaPrayer] addFont failed", path, e)
	_fonts_done[0] = True


# ------------------------------------------------------------------ scaling
def _desktop_width():
	try:
		return getDesktop(0).size().width()
	except Exception:
		return 1280


def scale():
	return 1.5 if _desktop_width() >= 1920 else 1.0


def res_dir():
	return "fhd" if scale() > 1 else "hd"


def S(v):
	return int(round(v * scale()))


def img(name):
	return os.path.join(PLUGIN_DIR, "images", res_dir(), name + ".png")


_pix_cache = {}


def pixmap(name):
	p = _pix_cache.get(name)
	if p is None:
		p = LoadPixmap(img(name))
		_pix_cache[name] = p
	return p


# ------------------------------------------------------------------ skin xml
def _esc(t):
	return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def _geo(x, y, w, h):
	return 'position="%d,%d" size="%d,%d"' % (S(x), S(y), S(w), S(h))


# line height (ascender + descender) of each font, in em. Enigma2 only centres text vertically
# when this line box fits inside the widget; otherwise it draws from the top and the glyphs
# get clipped at the bottom (e.g. the big tasbih counter).
LINE_EM = {"EPReg": 1.874, "EPBold": 1.874, "EPXBold": 1.874, "EPAmiri": 1.758}


def label(name, x, y, w, h, font="EPReg", size=22, color=TEXT, halign="right", valign="center", bg=None, z=3,
          wrap=False, text=None):
	"""dynamic label widget (Components.Label)"""
	if not wrap and valign == "center" and not bg:
		need = LINE_EM.get(font, 1.9) * size * 1.08 + 2
		if h < need:   # grow around the same centre so the text stays where the design puts it
			y -= (need - h) / 2.0
			h = need
	attrs = [_geo(x, y, w, h), 'font="%s;%d"' % (font, S(size)), 'foregroundColor="%s"' % color,
	         'halign="%s"' % halign, 'valign="%s"' % valign, 'zPosition="%d"' % z]
	if bg:
		attrs.append('backgroundColor="%s"' % bg)
	else:
		attrs.append('backgroundColor="#ff000000" transparent="1"')
	if not wrap and HAS_NOWRAP:
		attrs.append('noWrap="1"')
	if text is not None:
		return '<eLabel text="%s" %s />' % (_esc(text), " ".join(attrs))
	return '<widget name="%s" %s />' % (name, " ".join(attrs))


def box(name, x, y, w, h, color, z=2):
	"""coloured rectangle (Label without text) used for progress fills"""
	return '<widget name="%s" %s backgroundColor="%s" zPosition="%d" />' % (name, _geo(x, y, w, h), color, z)


def rect(x, y, w, h, color, z=1):
	return '<eLabel %s backgroundColor="%s" zPosition="%d" />' % (_geo(x, y, w, h), color, z)


def pix(name, x, y, w, h, image=None, z=1):
	"""dynamic pixmap widget (Components.Pixmap)"""
	p = (' pixmap="%s"' % img(image)) if image else ""
	return '<widget name="%s" %s%s alphatest="blend" zPosition="%d" />' % (name, _geo(x, y, w, h), p, z)


def epix(image, x, y, w, h, z=0, alpha="blend"):
	return '<ePixmap pixmap="%s" %s alphatest="%s" zPosition="%d" />' % (img(image), _geo(x, y, w, h), alpha, z)


def screen(name, x, y, w, h, children, bg=DARK, title="Enigma Prayer"):
	return n(u'<screen name="%s" %s flags="wfNoBorder" backgroundColor="%s" title="%s">%s</screen>' % (
		name, _geo(x, y, w, h), bg, _esc(u(title)), u"".join(u(c) for c in children)))


# ------------------------------------------------------------------ runtime widget helpers
def set_text(w, text):
	t = display(text)
	if w.getText() != t:
		w.setText(t)


def set_fg(w, color):
	if w.instance:
		w.instance.setForegroundColor(parseColor(color))
		try:
			w.instance.invalidate()
		except Exception:
			pass


def set_font(w, font, size):
	if w.instance:
		w.instance.setFont(gFont(font, S(size)))


def set_pix(w, name):
	if w.instance:
		p = pixmap(name)
		if p is not None:
			w.instance.setPixmap(p)


def move(w, x, y):
	if w.instance:
		w.instance.move(ePoint(S(x), S(y)))


def resize(w, width, height):
	if w.instance:
		w.instance.resize(eSize(max(0, S(width)), S(height)))


def set_visible(w, on):
	if on:
		w.show()
	else:
		w.hide()


def fill_rtl(w, x, y, width, height, frac):
	"""progress fill growing from the right edge (RTL)"""
	frac = max(0.0, min(1.0, frac))
	fw = width * frac
	if fw < 1:
		w.hide()
		return
	w.show()
	resize(w, fw, height)
	move(w, x + width - fw, y)


def ring_name(prefix, frac, steps=50):
	i = int(round(max(0.0, min(1.0, frac)) * steps))
	return "%s_%02d" % (prefix, i)


class Timer(object):
	"""eTimer wrapper (native eTimer objects do not accept extra attributes)"""

	def __init__(self, fn):
		self.t = eTimer()
		self.conn = None
		try:
			self.t.callback.append(fn)
		except AttributeError:
			self.conn = self.t.timeout.connect(fn)   # DreamOS style

	def start(self, ms, single=False):
		self.t.start(ms, single)

	def stop(self):
		self.t.stop()

	def isActive(self):
		return self.t.isActive()


def make_timer(fn):
	return Timer(fn)


_deferred = []


def defer(fn, ms=200):
	"""run fn later (after the current screen transition has completed)"""
	holder = []

	def run():
		t = holder[0]
		if t in _deferred:
			_deferred.remove(t)
		try:
			fn()
		except Exception:
			import traceback
			traceback.print_exc()
	t = make_timer(run)
	holder.append(t)
	_deferred.append(t)
	t.start(ms, True)


def open_safe(session, cls, *args, **kw):
	"""session.open that retries while another screen is still closing"""
	on_open = kw.pop("on_open", None)
	tries = kw.pop("_tries", 0)
	try:
		dlg = session.open(cls, *args)
	except RuntimeError as e:
		if tries < 10:
			defer(lambda: open_safe(session, cls, *args, on_open=on_open, _tries=tries + 1), 300)
		else:
			print("[EnigmaPrayer] open failed", e)
		return None
	if on_open:
		on_open(dlg)
	return dlg


# ------------------------------------------------------------------ keymap
_keymap_done = [False]
ACTION_CONTEXTS = ["OkCancelActions", "ColorActions", "DirectionActions", "MenuActions", "EnigmaPrayerActions"]


def load_keymap():
	if _keymap_done[0]:
		return
	_keymap_done[0] = True
	try:
		from keymapparser import readKeymap
		readKeymap(os.path.join(PLUGIN_DIR, "keymap.xml"))
	except Exception as e:
		print("[EnigmaPrayer] keymap", e)
