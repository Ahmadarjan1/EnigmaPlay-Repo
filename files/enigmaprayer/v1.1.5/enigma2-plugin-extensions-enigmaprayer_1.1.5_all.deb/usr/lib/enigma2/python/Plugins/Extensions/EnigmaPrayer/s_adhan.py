# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""Adhan (design screen 2) and Iqama countdown (design screen 3)."""
from __future__ import absolute_import, division, print_function
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap

from . import core
from . import ui
from .ui import label, pix, epix, screen, set_text, set_pix, GOLD, TEXT, WHITE, SUB


class AdhanScreen(Screen):
	def __init__(self, session, service):
		W = [epix("bg_adhan", 0, 0, 1280, 720, 0, "off"),
		     label("date", 340, 36, 600, 49, "EPReg", 26, SUB, "center"),
		     label("head", 390, 109, 500, 56, "EPBold", 30, GOLD, "center"),
		     ui.word("name", 190, 150, 900, 240),
		     label("time", 440, 384, 400, 110, "EPBold", 72, GOLD, "center"),
		     label("sound", 560, 563, 300, 42, "EPReg", 22, TEXT, "center"),
		     label("pos", 360, 563, 160, 42, "EPReg", 22, SUB, "center"),
		     label("sub", 190, 620, 900, 34, "EPReg", 22, SUB, "center")]
		self.skin = screen("EnigmaPrayerAdhan", 0, 0, 1280, 720, W, bg="#07151D")
		Screen.__init__(self, session)
		self.setTitle(ui.n(u"الأذان"))
		self.service = service
		self.a = service.adhan
		for n in ("date", "head", "time", "sound", "pos", "sub"):
			self[n] = Label("")
		self["name"] = Pixmap()
		self["actions"] = ActionMap(ui.ACTION_CONTEXTS, {
			"red": self.stop, "green": self.back_to_tv, "cancel": self.hide_screen, "ok": self.hide_screen,
		}, -1)
		self.timer = ui.make_timer(self.refresh)
		self.onLayoutFinish.append(self._start)
		self.onClose.append(self._closed)

	def _start(self):
		a = self.a
		if not a:
			return
		d = a["time"].date()
		set_text(self["date"], u"%s · %s" % (core.greg_line(d), core.city_short()))
		set_text(self["head"], u"تجربة صوت الأذان" if a["test"] else u"حان الآن موعد أذان")
		ui.set_word(self["name"], "adhan", core.prayer_key(a["prayer"], d))
		set_text(self["time"], core.hm(a["time"]))
		if a["playing"]:
			set_text(self["sound"], u"صوت الأذان: " + core.sound_name(a["file"]))
		elif a["file"] is None:
			set_text(self["sound"], u"لا يوجد ملف صوت للأذان")
		else:
			set_text(self["sound"], u"بدون صوت")
		self.refresh()
		self.timer.start(500, False)

	def refresh(self):
		if self.service.adhan is not self.a:
			return
		pos, length, frac = self.service.adhan_progress()
		set_text(self["pos"], u"%s / %s" % (core.ms(pos), core.ms(length)) if length > 0 else u"")
		set_text(self["sub"], self.service.adhan_subtitle(False))

	def _closed(self):
		self.timer.stop()
		if self.a is not None and self.a.get("screen") is self:
			self.a["screen"] = None

	def stop(self):
		# stop the sound, return to the channel, continue with the iqama countdown
		self.service.stop_adhan(restore=True)
		self._close_me()

	def back_to_tv(self):
		# stop and return to the channel without the iqama screen
		self.service.stop_adhan(restore=True, go_iqama=False)
		self._close_me()

	def hide_screen(self):
		# keep the adhan playing; show the small notification instead
		self._close_me()
		if self.service.adhan is self.a and self.a is not None:
			self.service.later(self.service._adhan_toast)

	def _close_me(self):
		if not getattr(self, "_ep_closing", False):
			self._ep_closing = True
			self.close()


class IqamaScreen(Screen):
	def __init__(self, session, service):
		W = [epix("bg_iqama", 0, 0, 1280, 720, 0, "off"),
		     label("title", 600, 14, 640, 56, "EPXBold", 30, GOLD, "right"),
		     label("clock", 40, 0, 130, 84, "EPBold", 46, TEXT, "left"),
		     pix("ring", 718, 180, 380, 380, None, 1),
		     label("count", 728, 317, 360, 106, "EPXBold", 96, TEXT, "center"),
		     label("unit", 789, 423, 238, 42, "EPReg", 22, SUB, "center"),
		     ui.word("name", 182, 150, 455, 150),
		     label("v_adhan", 207, 458, 200, 42, "EPReg", 22, TEXT, "left"),
		     label("v_iqama", 207, 512, 200, 42, "EPBold", 22, GOLD, "left"),
		     label("v_after", 207, 566, 290, 42, "EPReg", 22, TEXT, "left")]
		self.skin = screen("EnigmaPrayerIqama", 0, 0, 1280, 720, W)
		Screen.__init__(self, session)
		self.setTitle(ui.n(u"الإقامة"))
		self.service = service
		self.q = service.iqama
		for n in ("title", "clock", "count", "unit", "v_adhan", "v_iqama", "v_after"):
			self[n] = Label("")
		self["name"] = Pixmap()
		self["ring"] = Pixmap()
		self._ring = None
		self["actions"] = ActionMap(ui.ACTION_CONTEXTS, {
			"red": self.skip, "green": self.postpone, "yellow": self.tasbih, "cancel": self.hide_screen,
		}, -1)
		self.timer = ui.make_timer(self.refresh)
		self.onLayoutFinish.append(self._start)
		self.onClose.append(self._closed)

	def _start(self):
		q = self.q
		if not q:
			return
		name = core.prayer_name(q["prayer"], q["adhan"].date())
		set_text(self["title"], u"الإقامة بعد أذان " + name)
		ui.set_word(self["name"], "iqama", core.prayer_key(q["prayer"], q["adhan"].date()))
		set_text(self["v_adhan"], core.hm(q["adhan"]))
		m = core.cfg.post_mute.value
		set_text(self["v_after"], (u"كتم الصوت لمدة " + core.minutes_ar(m)) if m > 0 else u"بدون كتم للصوت")
		self.refresh()
		self.timer.start(500, False)

	def refresh(self):
		q = self.q
		if not q:
			return
		n = core.now()
		set_text(self["clock"], u"%02d:%02d" % (n.hour, n.minute))
		set_text(self["v_iqama"], core.hm(q["target"]))
		left = (q["target"] - n).total_seconds()
		set_text(self["count"], core.ms(left))
		set_text(self["unit"], u"دقيقة" if left >= 60 else u"ثانية")
		name = ui.ring_name("ring380", left / q["total"])
		if name != self._ring:
			self._ring = name
			set_pix(self["ring"], name)

	def _closed(self):
		self.timer.stop()
		if self.q is not None and self.q.get("screen") is self:
			self.q["screen"] = None

	def skip(self):
		self.service.skip_iqama()
		self._close_me()

	def postpone(self):
		self.service.postpone_iqama(2)
		set_text(self["v_iqama"], core.hm(self.q["target"]))
		self.refresh()

	def tasbih(self):
		from .s_tasbih import TasbihScreen
		self.session.open(TasbihScreen)

	def hide_screen(self):
		self._close_me()
		if self.service.iqama is self.q and self.q is not None:
			self.service.later(self.service.iqama_toast)

	def _close_me(self):
		if not getattr(self, "_ep_closing", False):
			self._ep_closing = True
			self.close()
