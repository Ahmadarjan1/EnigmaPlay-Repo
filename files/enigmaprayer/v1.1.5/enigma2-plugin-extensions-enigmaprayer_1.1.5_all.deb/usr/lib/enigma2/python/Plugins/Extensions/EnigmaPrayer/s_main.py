# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""Main screen: prayer table (design screen 1) and sky scene (design screens 7-12)."""
from __future__ import absolute_import, division, print_function
import datetime

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap

from . import core
from . import ui
from .ui import (label, box, pix, epix, screen, set_text, set_fg, set_font, set_pix, move, fill_rtl,
                 GOLD, DARK, TEXT, WHITE, SUB, MUTED, FOOT)

ROW_Y = [156 + 74 * i for i in range(6)]
CHIP_X = [1040, 842, 643, 444, 246, 47]


def panel_info(st):
	"""texts for the 'next prayer' panel"""
	n = st["now"]
	if st["iqama"]:
		adhan, iq, p = st["iqama"]
		return {"title": u"الصلاة الحالية", "key": p, "name": core.prayer_name(p, adhan.date()), "wkey": core.prayer_key(p, adhan.date()), "time": core.hm(adhan),
		        "sub": u"الإقامة بعد", "count": core.ms((iq - n).total_seconds()), "iqama": True}
	t, p = st["next"]
	return {"title": u"الصلاة القادمة", "key": p, "name": core.prayer_name(p, t.date()), "wkey": core.prayer_key(p, t.date()), "time": core.hm(t),
	        "sub": u"المتبقي على الشروق" if p == "sunrise" else u"المتبقي على الأذان",
	        "count": core.hms((t - n).total_seconds()), "iqama": False}


class _Base(Screen):
	def common_actions(self, extra):
		acts = {
			"cancel": self.close,
			"red": self.open_settings,
			"menu": self.open_settings,
			"green": self.open_tasbih,
			"yellow": self.open_reminders,
			"blue": self.open_qibla,
			"info": self.toggle_view,
		}
		acts.update(extra)
		self["actions"] = ActionMap(ui.ACTION_CONTEXTS, acts, -1)
		self.timer = ui.make_timer(self.refresh)
		self.onLayoutFinish.append(self._start)
		self.onClose.append(self.timer.stop)

	def _start(self):
		self.refresh()
		self.timer.start(1000, False)

	def _after(self, *args):
		self._ver = None
		self.refresh()

	def open_settings(self):
		from .s_settings import SettingsScreen
		self.session.openWithCallback(self._after, SettingsScreen)

	def open_tasbih(self):
		from .s_tasbih import TasbihScreen
		self.session.openWithCallback(self._after, TasbihScreen)

	def open_reminders(self):
		from .s_reminders import RemindersScreen
		self.session.openWithCallback(self._after, RemindersScreen)

	def open_qibla(self):
		from .s_qibla import QiblaScreen
		self.session.open(QiblaScreen)


class MainScreen(_Base):
	def __init__(self, session):
		W = []
		W.append(epix("bg_main", 0, 0, 1280, 720, 0, "off"))
		W.append(label("city", 380, 21, 520, 42, "EPReg", 22, SUB, "center"))
		W.append(label("date1", 178, 15, 330, 27, "EPReg", 18, SUB, "left"))
		W.append(label("date2", 178, 42, 330, 27, "EPReg", 18, SUB, "left"))
		W.append(label("clock", 40, 0, 130, 84, "EPBold", 46, TEXT, "left"))
		# next prayer panel
		W.append(label("p_title", 853, 145, 354, 42, "EPReg", 22, SUB))
		W.append(ui.word("p_name", 853, 178, 354, 136))
		W.append(label("p_time", 853, 306, 354, 98, "EPBold", 52, TEXT))
		W.append(label("p_sub", 853, 404, 354, 37, "EPReg", 20, SUB))
		W.append(label("p_count", 853, 441, 354, 120, "EPXBold", 64, WHITE))
		W.append(box("p_fill", 853, 575, 354, 10, GOLD, 2))
		W.append(label("p_prev", 1007, 595, 200, 30, "EPReg", 16, SUB, "right"))
		W.append(label("p_next", 853, 595, 200, 30, "EPReg", 16, SUB, "left"))
		for i, y in enumerate(ROW_Y):
			W.append(pix("row%d" % i, 40, y, 752, 64, "row_main_future", 1))
			W.append(pix("focus%d" % i, 40, y, 752, 64, "row_main_focus", 2))
			W.append(label("name%d" % i, 504, y, 264, 64, "EPBold", 26, TEXT, "right"))
			W.append(label("adhan%d" % i, 316, y, 188, 64, "EPReg", 28, TEXT, "center"))
			W.append(label("iqama%d" % i, 128, y, 188, 64, "EPReg", 28, TEXT, "center"))
			W.append(pix("icon%d" % i, 82, y + 18, 28, 28, None, 3))
		self.skin = screen("EnigmaPrayerMain", 0, 0, 1280, 720, W)
		Screen.__init__(self, session)
		self.setTitle(ui.n(u"مواقيت الصلاة"))
		for n in ("city", "date1", "date2", "clock", "p_title", "p_time", "p_sub", "p_count", "p_prev", "p_next"):
			self[n] = Label("")
		self["p_name"] = Pixmap()
		self["p_fill"] = Label("")
		for i in range(6):
			self["row%d" % i] = Pixmap()
			self["focus%d" % i] = Pixmap()
			self["icon%d" % i] = Pixmap()
			for n in ("name", "adhan", "iqama"):
				self["%s%d" % (n, i)] = Label("")
		self.cursor = -1      # -1: no focus outline until the user presses up/down
		self.row_state = [None] * 6
		self._ver = None
		self.common_actions({"ok": self.toggle_alert, "up": self.up, "down": self.down})
		if core.cfg.main_view.value == "scene":
			self._scene_timer = ui.make_timer(self._open_scene)
			self._scene_timer.start(10, True)

	def _open_scene(self):
		self.session.openWithCallback(self._scene_closed, SceneScreen)

	# -------------------------------------------------- keys
	def up(self):
		self.cursor = 5 if self.cursor <= 0 else self.cursor - 1
		self.refresh()

	def down(self):
		self.cursor = 0 if self.cursor < 0 or self.cursor >= 5 else self.cursor + 1
		self.refresh()

	def toggle_alert(self):
		if self.cursor < 0:
			# first OK: focus the next prayer row
			st = core.state()
			self.cursor = core.PRAYERS.index(st["next"][1]) if st["next"][0].date() == st["now"].date() else 0
			self.refresh()
			return
		p = core.PRAYERS[self.cursor]
		c = getattr(core.cfg, "alert_" + p)
		c.value = not c.value
		core.save_config()
		self.row_state[self.cursor] = None
		self.refresh()

	def toggle_view(self):
		core.cfg.main_view.value = "scene"
		core.save_config()
		self.session.openWithCallback(self._scene_closed, SceneScreen)

	def _scene_closed(self, *args):
		if core.cfg.main_view.value == "scene":   # EXIT from the scene leaves the plugin
			self.close()
		else:
			self._after()

	# -------------------------------------------------- refresh
	def refresh(self):
		st = core.state()
		n = st["now"]
		set_text(self["clock"], u"%02d:%02d" % (n.hour, n.minute))
		if self._ver != core.version() or n.second == 0:
			self._ver = core.version()
			set_text(self["city"], u"%s · %s" % (core.location()[0], core.method_short()))
			set_text(self["date1"], core.greg_line(n.date()))
			set_text(self["date2"], core.hijri_line(n.date()))
			self.row_state = [None] * 6
		info = panel_info(st)
		set_text(self["p_title"], info["title"])
		ui.set_word(self["p_name"], "panel", info["wkey"])
		set_text(self["p_time"], info["time"])
		set_text(self["p_sub"], info["sub"])
		set_text(self["p_count"], info["count"])
		# progress between the previous and the next prayer
		pt, pp = st["prev"]
		nt, np_ = st["next"]
		total = max(1.0, (nt - pt).total_seconds())
		fill_rtl(self["p_fill"], 853, 575, 354, 10, (n - pt).total_seconds() / total)
		set_text(self["p_prev"], u"%s %s" % (core.prayer_name(pp, pt.date()), core.hm(pt)))
		set_text(self["p_next"], u"%s %s" % (core.prayer_name(np_, nt.date()), core.hm(nt)))
		# table
		today = core.day_times(n.date())
		active = info["key"]
		active_today = (st["iqama"] and st["iqama"][0].date() == n.date()) or (not st["iqama"] and nt.date() == n.date())
		for i, p in enumerate(core.PRAYERS):
			t = today[p]
			if active_today and p == active:
				kind = "active"
			elif t <= n:
				kind = "past"
			else:
				kind = "future"
			alert = core.alert_on(p)
			iq = core.iqama_minutes(p)
			iq_txt = core.hm(t + datetime.timedelta(minutes=iq)) if p != "sunrise" and iq > 0 else u"—"
			key = (kind, alert, core.hm(t), iq_txt, self.cursor == i, core.prayer_name(p, n.date()))
			if self.row_state[i] == key:
				continue
			self.row_state[i] = key
			set_pix(self["row%d" % i], "row_main_" + kind)
			name_l, ad_l, iq_l = self["name%d" % i], self["adhan%d" % i], self["iqama%d" % i]
			set_text(name_l, key[5])
			set_text(ad_l, key[2])
			set_text(iq_l, iq_txt)
			color = {"past": MUTED, "active": DARK, "future": TEXT}[kind]
			for w in (name_l, ad_l, iq_l):
				set_fg(w, color)
			if kind == "active":
				set_font(name_l, "EPXBold", 28)
				set_font(ad_l, "EPBold", 30)
				set_font(iq_l, "EPBold", 30)
			else:
				set_font(name_l, "EPBold", 26)
				set_font(ad_l, "EPReg", 28)
				set_font(iq_l, "EPReg", 28)
			if kind == "past":
				icon = "ic_check"
			elif kind == "active":
				icon = "ic_bell_dark" if alert else "ic_belloff_dark"
			else:
				icon = "ic_bell_gold" if alert else "ic_belloff_gray"
			set_pix(self["icon%d" % i], icon)
			f = self["focus%d" % i]
			if self.cursor == i:
				set_pix(f, "row_main_focus_dark" if kind == "active" else "row_main_focus")
				f.show()
			else:
				f.hide()


class SceneScreen(_Base):
	def __init__(self, session):
		W = []
		W.append(pix("sky", 0, 0, 1280, 720, "sky_" + core.period(), 0))
		W.append(label("date1", 1030, 35, 185, 25, "EPReg", 18, SUB, "right"))
		W.append(label("date2", 1030, 60, 185, 25, "EPReg", 18, SUB, "right"))
		W.append(label("clock", 935, 28, 110, 64, "EPBold", 38, TEXT, "left"))
		W.append(label("p_title", 867, 135, 346, 37, "EPReg", 20, SUB))
		W.append(ui.word("p_name", 867, 166, 346, 118))
		W.append(label("p_time", 867, 278, 346, 82, "EPBold", 44, TEXT))
		W.append(label("p_sub", 867, 374, 346, 33, "EPReg", 18, SUB))
		W.append(label("p_count", 867, 407, 346, 98, "EPXBold", 52, TEXT))
		W.append(pix("chip", CHIP_X[0], 631, 193, 62, "chip_active", 1))
		for i, x in enumerate(CHIP_X):
			W.append(label("cname%d" % i, x, 633, 193, 28, "EPBold", 19, FOOT, "center"))
			W.append(label("ctime%d" % i, x, 659, 193, 30, "EPReg", 22, FOOT, "center"))
		self.skin = screen("EnigmaPrayerScene", 0, 0, 1280, 720, W, bg="#070F24")
		Screen.__init__(self, session)
		self.setTitle(ui.n(u"مواقيت الصلاة"))
		self["sky"] = Pixmap()
		self["chip"] = Pixmap()
		for n in ("date1", "date2", "clock", "p_title", "p_time", "p_sub", "p_count"):
			self[n] = Label("")
		self["p_name"] = Pixmap()
		for i in range(6):
			self["cname%d" % i] = Label("")
			self["ctime%d" % i] = Label("")
		self._ver = None
		self._sky = None
		self._active = None
		self.common_actions({"ok": self.toggle_view})

	def toggle_view(self):
		core.cfg.main_view.value = "table"
		core.save_config()
		self.close()

	def refresh(self):
		st = core.state()
		n = st["now"]
		set_text(self["clock"], u"%02d:%02d" % (n.hour, n.minute))
		sky = "sky_" + core.period(n)
		if sky != self._sky:
			self._sky = sky
			set_pix(self["sky"], sky)
		today = core.day_times(n.date())
		if self._ver != core.version() or n.second == 0:
			self._ver = core.version()
			set_text(self["date1"], core.greg_line(n.date()))
			set_text(self["date2"], core.hijri_line(n.date()))
			for i, p in enumerate(core.PRAYERS):
				set_text(self["cname%d" % i], core.prayer_name(p, n.date()))
				set_text(self["ctime%d" % i], core.hm(today[p]))
			self._active = None
		info = panel_info(st)
		set_text(self["p_title"], info["title"])
		ui.set_word(self["p_name"], "scene", info["wkey"])
		set_text(self["p_time"], info["time"])
		set_text(self["p_sub"], info["sub"])
		set_text(self["p_count"], info["count"])
		# chip: the current period's prayer (last passed), like the design
		cur = st["prev"][1] if st["prev"][0].date() == n.date() else "isha"
		if info["iqama"]:
			cur = info["key"]
		if cur != self._active:
			self._active = cur
			idx = core.PRAYERS.index(cur)
			move(self["chip"], CHIP_X[idx], 631)
			for i in range(6):
				on = i == idx
				set_fg(self["cname%d" % i], DARK if on else FOOT)
				set_fg(self["ctime%d" % i], DARK if on else FOOT)
				set_font(self["cname%d" % i], "EPXBold" if on else "EPBold", 19)
				set_font(self["ctime%d" % i], "EPBold" if on else "EPReg", 22)


def open_main(session):
	session.open(MainScreen)
