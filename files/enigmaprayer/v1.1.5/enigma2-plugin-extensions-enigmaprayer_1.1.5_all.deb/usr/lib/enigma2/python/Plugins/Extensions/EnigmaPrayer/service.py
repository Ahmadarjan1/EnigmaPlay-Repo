# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""Background service: fires pre-alerts, adhan, iqama, post-iqama mute and reminders."""
from __future__ import absolute_import, division, print_function
import os
import time
import datetime

from enigma import eServiceReference, iPlayableService, eDVBVolumecontrol

from . import core
from . import ui
from . import audio
from .toasts import ToastManager, safe_close

FIRE_WINDOW = 90  # seconds: events older than this (e.g. after boot) are skipped


def in_standby():
	try:
		from Screens import Standby
		return Standby.inStandby is not None
	except Exception:
		return False


class PrayerService(object):
	instance = None

	def __init__(self, session):
		PrayerService.instance = self
		self.session = session
		self.toasts = ToastManager(session)
		self.fired = set()
		self.events = []
		self._ev_key = None
		self.adhan = None
		self.iqama = None
		self.unmute_at = None
		self.we_muted = False
		self._nav_hooked = False
		self.timer = ui.make_timer(self.tick)
		self.timer.start(1000, False)
		self._finish_timer = ui.make_timer(self._finish_from_event)
		self.player = audio.AlsaPlayer()

	# ------------------------------------------------------------------ scheduling
	def build_events(self, n):
		d = n.date()
		ev = []
		t = core.day_times(d)
		pre = core.cfg.pre_alert.value
		for p in core.PRAYERS:
			if not core.alert_on(p):
				continue
			if pre > 0:
				ev.append(("%s-pre-%s" % (d, p), t[p] - datetime.timedelta(minutes=pre), self._mk(self.pre_alert, p, t[p])))
			ev.append(("%s-adhan-%s" % (d, p), t[p], self._mk(self.start_adhan, p, t[p])))
		for i, r in enumerate(core.reminders().items):
			if not r.get("enabled") or not core.reminder_active_on(r, d):
				continue
			rt = core.reminder_time(r, d)
			ev.append(("%s-rem-%d-%s-%s" % (d, i, r.get("title"), core.hm(rt)), rt, self._mk(self.show_reminder, r, rt)))
		ev.sort(key=lambda e: e[1])
		return ev

	@staticmethod
	def _mk(fn, *args):
		return lambda: fn(*args)

	def tick(self):
		try:
			self._tick()
		except Exception as e:
			import traceback
			traceback.print_exc()
			print("[EnigmaPrayer] tick error", e)

	def _tick(self):
		if not core.clock_valid():
			return
		n = core.now()
		key = (n.date(), core.version())
		if key != self._ev_key:
			self._ev_key = key
			self.events = self.build_events(n)
			if len(self.fired) > 300:
				self.fired = set(k for k in self.fired if k.startswith(str(n.date())))
		for k, when, fn in self.events:
			if k in self.fired:
				continue
			if when <= n < when + datetime.timedelta(seconds=FIRE_WINDOW):
				self.fired.add(k)
				fn()
		if self.adhan:
			self._watch_adhan()
		if self.iqama and not self.iqama.get("done") and n >= self.iqama["target"]:
			self.on_iqama()
		if self.unmute_at and n >= self.unmute_at:
			self.unmute_at = None
			self.set_mute(False)

	# ------------------------------------------------------------------ pre alert / reminders
	def pre_alert(self, p, t):
		if in_standby():
			return
		lead = max(1, core.cfg.pre_alert.value) * 60.0
		name = core.prayer_name(p, t.date())

		def provider():
			left = (t - core.now()).total_seconds()
			if left <= 0:
				return None
			mins = int((left + 59) // 60)
			title = (u"بعد %s: %s" % (core.minutes_ar(mins), name)) if p == "sunrise" else (u"بعد %s: أذان %s" % (core.minutes_ar(mins), name))
			return {"title": title, "sub": u"تنبيه قبل الشروق" if p == "sunrise" else u"تنبيه قبل الأذان",
			        "time": core.hm(t), "frac": 1.0 - left / lead}
		self.toasts.show("pre", provider, duration=core.cfg.toast_secs.value)

	def show_reminder(self, r, rt):
		if in_standby():
			return
		dur = core.cfg.toast_secs.value
		start = time.time()
		tasbih = r.get("action") == "tasbih"
		title = u"تذكير: " + r.get("title", u"")

		def provider():
			return {"title": title, "sub": u"OK فتح المسبحة · EXIT إغلاق" if tasbih else u"EXIT إغلاق",
			        "time": core.hm(rt), "frac": 1.0 - (time.time() - start) / float(dur)}
		self.toasts.show("reminder", provider, duration=dur, interactive=True,
		                 on_ok=self.open_tasbih_overlay if tasbih else None)

	def info(self, title, sub, t=None, duration=None):
		dur = duration or core.cfg.toast_secs.value
		start = time.time()

		def provider():
			return {"title": title, "sub": sub, "time": core.hm(t or core.now()), "frac": 1.0 - (time.time() - start) / float(dur)}
		self.toasts.show("info", provider, duration=dur)

	def open_tasbih_overlay(self):
		st = core.tasbih()

		def provider():
			return {"word": st.index, "sub": u"%d من %d · OK تسبيحة" % (st.count(), st.target()),
			        "time": u"%d" % st.today, "ringtxt": u"%d" % st.count(),
			        "ring": st.count() / float(max(1, st.target()))}

		def on_ok():
			st.tick()

		def on_cancel():
			st.save()
		self.toasts.show("tasbih", provider, interactive=True, force_modal=True, on_ok=on_ok, keep_on_ok=True,
		                 on_cancel=on_cancel)

	# ------------------------------------------------------------------ adhan
	def start_adhan(self, p, t, test=False):
		if p == "sunrise":
			if not in_standby():
				self.info(u"حان الآن وقت الشروق", u"انتهى وقت صلاة الفجر · " + core.city_short(), t)
			return
		if in_standby() and not test:
			return
		if self.adhan:
			self.stop_adhan(restore=True, go_iqama=False)
		self.toasts.hide_kind("pre")
		f = core.sound_for(p)
		a = {"prayer": p, "time": t, "test": test, "file": f, "playing": False, "started": time.time(),
		     "screen": None, "ref": None, "saved": None, "volume": None, "was_muted": False,
		     "how": None, "muted_channel": False, "service_key": self._ref_key()}
		self.adhan = a
		if f and not self._media_playing():
			if audio.available():
				# IPAudio method: the channel keeps running, only its sound is replaced
				mute = bool(core.cfg.mute_channel.value)
				if self.player.start(f, core.cfg.volume.value, mute_channel=mute):
					a["playing"] = True
					a["how"] = "alsa"
					a["muted_channel"] = mute
			if not a["playing"] and core.cfg.mute_channel.value:
				self._play_service(a)   # fallback for boxes without gstreamer/ffmpeg
		mode = "full" if test else core.cfg.adhan_screen.value
		if mode == "full":
			from .s_adhan import AdhanScreen
			ui.open_safe(self.session, AdhanScreen, self, on_open=lambda d: self._set_screen(a, d))
		elif mode == "toast":
			self._adhan_toast()
		if not a["playing"]:
			# no sound: keep the notification for one minute
			a["visual_until"] = time.time() + (60 if mode != "off" else 0)

	def _adhan_toast(self):
		a = self.adhan
		if not a:
			return

		def provider():
			if self.adhan is not a:
				return None
			return {"title": u"حان الآن موعد أذان " + core.prayer_name(a["prayer"], a["time"].date()),
			        "sub": self.adhan_subtitle(True), "time": core.hm(a["time"]), "frac": self.adhan_progress()[2]}
		self.toasts.show("adhan", provider, interactive=True, on_ok=self.open_adhan_screen,
		                 on_cancel=lambda: self.stop_adhan(restore=True))

	def open_adhan_screen(self):
		a = self.adhan
		if a and not a.get("screen"):
			from .s_adhan import AdhanScreen
			ui.open_safe(self.session, AdhanScreen, self, on_open=lambda d: self._set_screen(a, d))

	def _set_screen(self, holder, dlg):
		if holder is self.adhan or holder is self.iqama:
			holder["screen"] = dlg
		else:  # finished meanwhile
			safe_close(self.session, dlg)

	def adhan_subtitle(self, with_city=False):
		a = self.adhan
		if not a:
			return u""
		parts = []
		m = core.iqama_minutes(a["prayer"])
		if m > 0 and not a["test"]:
			parts.append(u"الإقامة بعد " + core.minutes_ar(m))
		if with_city:
			parts.append(core.city_short())
		if a["playing"] and (a["how"] == "service" or a["muted_channel"]):
			parts.append(u"تم كتم القناة تلقائياً" if with_city else u"تم كتم صوت القناة")
		return u" · ".join(parts)

	def adhan_progress(self):
		"""(pos_seconds, length_seconds, fraction)"""
		a = self.adhan
		if not a or not a["playing"]:
			return 0, 0, 1.0
		pos = length = 0
		if a["how"] == "alsa":
			pos, length = self.player.position(), self.player.length
		else:
			try:
				s = self.session.nav.getCurrentService()
				seek = s and s.seek()
				if seek:
					r = seek.getLength()
					if r and r[0] == 0:
						length = r[1] / 90000.0
					r = seek.getPlayPosition()
					if r and r[0] == 0:
						pos = r[1] / 90000.0
			except Exception:
				pass
		frac = pos / length if length > 0 else 0.0
		return pos, length, frac

	def _media_playing(self):
		try:
			ref = self.session.nav.getCurrentlyPlayingServiceReference()
			# a local media file is playing (movie player); IPTV streams are channels
			return ref is not None and ref.valid() and ref.getPath().startswith("/")
		except Exception:
			return False

	def _current_ref(self):
		nav = self.session.nav
		try:
			return nav.getCurrentlyPlayingServiceOrGroup()
		except AttributeError:
			return nav.getCurrentlyPlayingServiceReference()

	def _ref_key(self):
		r = self._current_ref()
		try:
			return r.toString() if r is not None else ""
		except Exception:
			return ""

	def _play_service(self, a):
		"""fallback: stop the channel and play the file as a service"""
		nav = self.session.nav
		a["saved"] = self._current_ref()
		ref = eServiceReference(4097, 0, a["file"])
		try:
			ref.setName(ui.n(core.sound_name(a["file"])))
		except Exception:
			pass
		nav.stopService()
		nav.playService(ref)
		a["ref"] = ref
		a["playing"] = True
		a["how"] = "service"
		if not self._nav_hooked:
			nav.event.append(self._nav_event)
			self._nav_hooked = True

	def _nav_event(self, ev):
		if self.adhan and self.adhan["how"] == "service" and ev == iPlayableService.evEOF:
			self._finish_timer.start(10, True)

	def _finish_from_event(self):
		if self.adhan:
			self.stop_adhan(restore=True)

	def _watch_adhan(self):
		a = self.adhan
		if a["playing"] and a["how"] == "alsa":
			if not self.player.running():
				self.stop_adhan(restore=True)
				return
			key = self._ref_key()
			if key != a["service_key"]:
				# the user zapped: the new channel starts with sound, silence it again
				a["service_key"] = key
				self.player.remute()
				ui.defer(self.player.remute, 800)
			if time.time() - a["started"] > 900:
				self.stop_adhan(restore=True)
		elif a["playing"]:
			cur = self._current_ref()
			path = ""
			try:
				path = cur.getPath() if cur is not None else ""
			except Exception:
				pass
			if cur is None or not path or os.path.basename(path) != os.path.basename(a["file"]):
				# the user zapped away: nothing to restore
				if time.time() - a["started"] > 3:
					a["saved"] = None
					self.stop_adhan(restore=False)
				return
			pos, length, frac = self.adhan_progress()
			if (length > 0 and pos >= length - 0.3) or time.time() - a["started"] > 900:
				self.stop_adhan(restore=True)
		elif time.time() >= a.get("visual_until", 0):
			self.stop_adhan(restore=False)

	def stop_adhan(self, restore=True, go_iqama=True):
		a = self.adhan
		if not a:
			return
		self.adhan = None
		if a["how"] == "alsa":
			self.player.stop(restore=True)   # always give the channel its sound back
		elif a["how"] == "service":
			nav = self.session.nav
			if self._nav_hooked:
				try:
					nav.event.remove(self._nav_event)
				except ValueError:
					pass
				self._nav_hooked = False
			cur = self._current_ref()
			try:
				ours = cur is not None and os.path.basename(cur.getPath()) == os.path.basename(a["file"])
			except Exception:
				ours = False
			if ours:
				nav.stopService()
			if restore and a["saved"] is not None:
				nav.playService(a["saved"])
		if a.get("screen"):
			safe_close(self.session, a["screen"])
		self.toasts.hide_kind("adhan")
		if go_iqama and not a["test"]:
			self.start_iqama(a["prayer"], a["time"])

	# ------------------------------------------------------------------ iqama
	def start_iqama(self, p, adhan_t):
		m = core.iqama_minutes(p)
		if m <= 0:
			return
		target = adhan_t + datetime.timedelta(minutes=m)
		if core.now() >= target:
			return
		self.iqama = {"prayer": p, "adhan": adhan_t, "target": target, "total": m * 60.0, "screen": None, "done": False}
		mode = core.cfg.iqama_screen.value
		if in_standby():
			return
		if mode == "full":
			self.open_iqama_screen()
		elif mode == "toast":
			self.iqama_toast()

	def open_iqama_screen(self):
		if self.iqama and not self.iqama.get("screen"):
			self.toasts.hide_kind("iqama")
			from .s_adhan import IqamaScreen
			q = self.iqama
			ui.open_safe(self.session, IqamaScreen, self, on_open=lambda d: self._set_screen(q, d))

	def iqama_toast(self):
		q = self.iqama
		if not q:
			return
		name = core.prayer_name(q["prayer"], q["adhan"].date())

		def provider():
			if self.iqama is not q or q["done"]:
				return None
			left = (q["target"] - core.now()).total_seconds()
			return {"title": u"الإقامة بعد %s دقيقة" % core.ms(left), "sub": u"استعدّوا لصلاة %s وسوّوا الصفوف" % name,
			        "time": core.hm(q["target"]), "ringtxt": core.ms(left), "ring": left / q["total"]}
		self.toasts.show("iqama", provider)

	def postpone_iqama(self, minutes=2):
		if self.iqama:
			self.iqama["target"] += datetime.timedelta(minutes=minutes)
			self.iqama["total"] += minutes * 60.0

	def skip_iqama(self):
		q = self.iqama
		self.iqama = None
		if q and q.get("screen"):
			safe_close(self.session, q["screen"])
		self.toasts.hide_kind("iqama")

	def on_iqama(self):
		q = self.iqama
		q["done"] = True
		self.iqama = None
		if q.get("screen"):
			safe_close(self.session, q["screen"])
		self.toasts.hide_kind("iqama")
		if in_standby():
			return
		name = core.prayer_name(q["prayer"], q["adhan"].date())
		mute = core.cfg.post_mute.value
		if mute > 0:
			self.set_mute(True)
			self.unmute_at = core.now() + datetime.timedelta(minutes=mute)
			sub = u"تم كتم الصوت لمدة " + core.minutes_ar(mute)
		else:
			sub = core.city_short()
		self.info(u"حان الآن موعد إقامة صلاة " + name, sub, q["target"], duration=max(15, core.cfg.toast_secs.value))

	# ------------------------------------------------------------------ volume mute
	def set_mute(self, on, force=False):
		try:
			vc = eDVBVolumecontrol.getInstance()
			if bool(vc.isMuted()) == bool(on):
				return
			if not force and not on and not self.we_muted:
				return  # the user changed it meanwhile
			try:
				from Components.VolumeControl import VolumeControl
				inst = VolumeControl.instance
			except Exception:
				inst = None
			if inst is not None:
				inst.volMute()
			elif on:
				vc.volumeMute()
			else:
				vc.volumeUnMute()
			if not force:
				self.we_muted = on
		except Exception as e:
			print("[EnigmaPrayer] mute", e)

	def later(self, fn, ms=300):
		ui.defer(fn, ms)

	# ------------------------------------------------------------------ test
	def test_adhan(self):
		st = core.state()
		p = st["next"][1]
		if p == "sunrise":
			p = "dhuhr"
		self.start_adhan(p, core.now().replace(second=0, microsecond=0), test=True)
