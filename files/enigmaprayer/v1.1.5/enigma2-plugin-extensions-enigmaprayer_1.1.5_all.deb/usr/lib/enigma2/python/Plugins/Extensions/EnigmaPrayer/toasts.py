# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""On-screen notifications shown above the running channel (design screens 13-18)."""
from __future__ import absolute_import, division, print_function
import time

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap

from . import ui
from .ui import label, box, pix, epix, screen, set_text, set_pix, fill_rtl, GOLD, TEXT, SUB, FILL_DIM

TRANSPARENT = "#ff000000"

# kind: (x, y, w, h, background, widgets...)
LAYOUTS = {
	"adhan": (40, 28, 1200, 134, "toast_adhan", [
		("title", 129, 19, 978, 56, "EPXBold", 30, TEXT, "right"),
		("sub", 129, 75, 978, 36, "EPReg", 19, SUB, "right"),
		("time", 25, 34, 120, 63, "EPBold", 34, GOLD, "left"),
	], ("fill", 25, 120, 1150, 4, GOLD)),
	"pre": (40, 28, 560, 115, "toast_pre", [
		("title", 96, 17, 387, 45, "EPXBold", 24, TEXT, "right"),
		("sub", 96, 62, 387, 32, "EPReg", 17, SUB, "right"),
		("time", 21, 33, 75, 45, "EPBold", 24, GOLD, "left"),
	], ("fill", 21, 102, 518, 4, GOLD)),
	"info": (40, 28, 560, 115, "toast_info", [
		("title", 96, 17, 387, 45, "EPXBold", 24, TEXT, "right"),
		("sub", 96, 62, 387, 32, "EPReg", 17, SUB, "right"),
		("time", 21, 33, 75, 45, "EPBold", 24, GOLD, "left"),
	], ("fill", 21, 102, 518, 4, GOLD)),
	"iqama": (40, 28, 560, 107, "toast_iqama", [
		("title", 96, 15, 355, 45, "EPXBold", 24, TEXT, "right"),
		("sub", 96, 60, 355, 32, "EPReg", 17, SUB, "right"),
		("time", 21, 31, 75, 45, "EPBold", 24, GOLD, "left"),
		("ringtxt", 467, 18, 72, 72, "EPXBold", 17, TEXT, "center"),
	], None),
	"reminder": (40, 478, 560, 115, "toast_reminder", [
		("title", 96, 17, 387, 45, "EPXBold", 24, TEXT, "right"),
		("sub", 96, 62, 387, 32, "EPReg", 17, SUB, "right"),
		("time", 21, 33, 75, 45, "EPBold", 24, GOLD, "left"),
	], ("fill", 21, 102, 518, 4, FILL_DIM)),
	"tasbih": (780, 484, 460, 104, "toast_tasbih", [
		("sub", 77, 56, 286, 32, "EPReg", 17, SUB, "right"),
		("time", 21, 44, 70, 45, "EPBold", 24, GOLD, "left"),
		("ringtxt", 379, 22, 60, 60, "EPXBold", 22, TEXT, "center"),
	], None),
}
RINGS = {"iqama": ("ring72", 467, 18, 72), "tasbih": ("ring60", 379, 22, 60)}
SLOTS = {"adhan": "top", "pre": "top", "info": "top", "iqama": "top", "reminder": "bottom", "tasbih": "br"}


class Toast(Screen):
	"""data: dict(kind, provider -> dict(title, sub, time, frac, ring, ringtxt), expires, on_ok, on_cancel)"""

	def __init__(self, session, data, modal=False):
		kind = data["kind"]
		x, y, w, h, bg, labels, fill = LAYOUTS[kind]
		W = [epix(bg, 0, 0, w, h, 0)]
		for name, lx, ly, lw, lh, font, size, color, align in labels:
			W.append(label(name, lx, ly, lw, lh, font, size, color, align, z=3))
		if fill:
			W.append(box("fill", fill[1], fill[2], fill[3], fill[4], fill[5], 2))
		if kind in RINGS:
			r = RINGS[kind]
			W.append(pix("ring", r[1], r[2], r[3], r[3], None, 1))
		if kind == "tasbih":
			W.append(ui.word("wtitle", 77, 10, 286, 50))
		self.skin = screen("EnigmaPrayerToast_" + kind, x, y, w, h, W, bg=TRANSPARENT, title="")
		Screen.__init__(self, session)
		self.data = data
		self.kind = kind
		self.modal = modal
		self.fill_geo = fill
		for l in labels:
			self[l[0]] = Label("")
		if fill:
			self["fill"] = Label("")
		if kind in RINGS:
			self["ring"] = Pixmap()
		if kind == "tasbih":
			self["wtitle"] = Pixmap()
		self._ring = None
		if modal:
			self["actions"] = ActionMap(ui.ACTION_CONTEXTS, {
				"ok": self.key_ok, "cancel": self.key_cancel,
				"up": self.zap_up, "down": self.zap_down, "pageUp": self.zap_up, "pageDown": self.zap_down,
			}, -1)
		self.timer = ui.make_timer(self.update)
		self.onLayoutFinish.append(self._start)
		self.onClose.append(self.timer.stop)
		self.closed = False

	def _start(self):
		self.update()
		self.timer.start(500, False)

	def update(self):
		d = self.data
		if d.get("expires") and time.time() >= d["expires"]:
			self.dismiss()
			return
		try:
			v = d["provider"]()
		except Exception as e:
			print("[EnigmaPrayer] toast provider", e)
			v = None
		if v is None:
			self.dismiss()
			return
		for k in ("title", "sub", "time", "ringtxt"):
			if k in self:
				set_text(self[k], v.get(k, u""))
		if "wtitle" in self and "word" in v:
			ui.set_word(self["wtitle"], "tbtoast", v["word"])
		if self.fill_geo is not None:
			f = self.fill_geo
			fill_rtl(self["fill"], f[1], f[2], f[3], f[4], v.get("frac", 0))
		if "ring" in self:
			r = RINGS[self.kind]
			name = ui.ring_name(r[0], v.get("ring", 0))
			if name != self._ring:
				self._ring = name
				set_pix(self["ring"], name)

	# -------------------------------------------------- keys (modal only)
	def key_ok(self):
		cb = self.data.get("on_ok")
		if self.data.get("keep_on_ok"):
			if cb:
				cb()
			self.update()
			return
		self.dismiss()
		if cb:
			ui.defer(cb, 250)

	def key_cancel(self):
		cb = self.data.get("on_cancel")
		self.dismiss()
		if cb:
			ui.defer(cb, 250)

	def zap_up(self):
		self._zap("zapUp")

	def zap_down(self):
		self._zap("zapDown")

	def _zap(self, what):
		try:
			from Screens.InfoBar import InfoBar
			if InfoBar.instance:
				getattr(InfoBar.instance, what)()
		except Exception as e:
			print("[EnigmaPrayer] zap", e)

	def dismiss(self):
		if self.closed:
			return
		self.closed = True
		self.timer.stop()
		# read everything we need first: on some images (e.g. DM8000 / py3.9) deleteDialog,
		# called from removed(), wipes the screen's attributes
		modal = self.modal
		mgr = self.data.get("manager")
		if mgr:
			mgr.removed(self)
		if modal:
			self.close()


class ToastManager(object):
	def __init__(self, session):
		self.session = session
		self.slots = {}

	def can_modal(self):
		try:
			from Screens.InfoBar import InfoBar
			cur = self.session.current_dialog
			return InfoBar.instance is not None and cur is InfoBar.instance
		except Exception:
			return False

	def show(self, kind, provider, duration=None, interactive=False, force_modal=False, **kw):
		slot = SLOTS[kind]
		self.hide_slot(slot)
		data = dict(kind=kind, provider=provider, manager=self,
		            expires=(time.time() + duration) if duration else None)
		data.update(kw)
		modal = (interactive and self.can_modal()) or force_modal
		dlg = None
		if modal:
			try:
				dlg = self.session.open(Toast, data, True)
			except RuntimeError:
				dlg = None
		if dlg is None:
			data["modal_failed"] = modal
			dlg = self.session.instantiateDialog(Toast, data, False)
			dlg.show()
		self.slots[slot] = dlg
		return dlg

	def hide_slot(self, slot):
		dlg = self.slots.pop(slot, None)
		if dlg is not None:
			self._remove(dlg)

	def hide_kind(self, kind):
		slot = SLOTS[kind]
		dlg = self.slots.get(slot)
		if dlg is not None and dlg.kind == kind:
			self.hide_slot(slot)

	def removed(self, dlg):
		"""called by a toast that dismissed itself"""
		for k, v in list(self.slots.items()):
			if v is dlg:
				del self.slots[k]
		if not dlg.modal:
			self._delete(dlg)

	def _remove(self, dlg):
		if dlg.closed:
			return
		dlg.closed = True
		dlg.timer.stop()
		if dlg.modal:
			safe_close(self.session, dlg)
		else:
			self._delete(dlg)

	def _delete(self, dlg):
		try:
			dlg.hide()
			self.session.deleteDialog(dlg)
		except Exception as e:
			print("[EnigmaPrayer] deleteDialog", e)


def safe_close(session, scr, *ret):
	"""close a screen now if it is on top, otherwise as soon as it becomes the top screen"""
	if getattr(scr, "_ep_closing", False):
		return
	if session.current_dialog is scr:
		scr._ep_closing = True
		scr.close(*ret)
	else:
		def do_close():
			if not getattr(scr, "_ep_closing", False) and session.current_dialog is scr:
				scr._ep_closing = True
				scr.close(*ret)

		def later():
			ui.defer(do_close, 50)
		scr.onExecBegin.append(later)
