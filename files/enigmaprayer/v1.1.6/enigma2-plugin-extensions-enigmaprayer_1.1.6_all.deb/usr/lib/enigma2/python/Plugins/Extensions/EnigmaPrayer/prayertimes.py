# -*- coding: utf-8 -*-
# Enigma Prayer - Copyright (c) 2026 Ahmad Al-Qaisi (أحمد القيسي). All rights reserved.
# جميع الحقوق محفوظة لـ أحمد القيسي. يُمنع النسخ أو التعديل أو إعادة النشر دون إذن خطي من المؤلف.
"""
Enigma Prayer - offline prayer time calculation.

Standard astronomical method (sun declination / equation of time) as used by
most calculators (PrayTimes, Aladhan). No network needed.
"""
from __future__ import absolute_import, division, print_function
import math
import datetime

# ---------------------------------------------------------------- methods
# key: (arabic name, fajr angle, isha angle or "Nmin", maghrib angle/"Nmin" or None,
#       {extra minute offsets})
METHODS = [
	("jordan",  u"وزارة الأوقاف الأردنية", 18.0, 18.0, "5min", {}),
	("makkah",  u"أم القرى - مكة المكرمة", 18.5, "90min", None, {}),
	("egypt",   u"الهيئة المصرية العامة للمساحة", 19.5, 17.5, None, {}),
	("mwl",     u"رابطة العالم الإسلامي", 18.0, 17.0, None, {}),
	("karachi", u"جامعة العلوم الإسلامية - كراتشي", 18.0, 18.0, None, {}),
	("isna",    u"أمريكا الشمالية (ISNA)", 15.0, 15.0, None, {}),
	("gulf",    u"منطقة الخليج", 19.5, "90min", None, {}),
	("kuwait",  u"الكويت", 18.0, 17.5, None, {}),
	("qatar",   u"قطر", 18.0, "90min", None, {}),
	("dubai",   u"دبي - الإمارات", 18.2, 18.2, None, {"sunrise": 3, "dhuhr": 3, "asr": 3, "maghrib": 3}),
	("turkey",  u"رئاسة الشؤون الدينية - تركيا", 18.0, 17.0, None, {}),
	("tunisia", u"تونس", 18.0, 18.0, None, {}),
	("algeria", u"الجزائر", 18.0, 17.0, None, {}),
	("morocco", u"المغرب", 19.0, 17.0, None, {}),
	("france",  u"اتحاد المنظمات الإسلامية - فرنسا", 12.0, 12.0, None, {}),
	("russia",  u"الإدارة الدينية لمسلمي روسيا", 16.0, 15.0, None, {}),
	("singapore", u"سنغافورة / ماليزيا / إندونيسيا", 20.0, 18.0, None, {}),
	("tehran",  u"جامعة طهران", 17.7, 14.0, 4.5, {}),
]
METHOD_KEYS = [m[0] for m in METHODS]
METHOD_NAMES = dict((m[0], m[1]) for m in METHODS)

PRAYERS = ("fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha")
PRAYER_NAMES = {
	"fajr": u"الفجر", "sunrise": u"الشروق", "dhuhr": u"الظهر",
	"asr": u"العصر", "maghrib": u"المغرب", "isha": u"العشاء",
}
# Friday dhuhr
JUMUAH = u"الجمعة"


def _method(key):
	for m in METHODS:
		if m[0] == key:
			return m
	return METHODS[0]


# ---------------------------------------------------------------- math helpers
def dsin(d): return math.sin(math.radians(d))
def dcos(d): return math.cos(math.radians(d))
def dtan(d): return math.tan(math.radians(d))
def darcsin(x): return math.degrees(math.asin(max(-1.0, min(1.0, x))))
def darccos(x): return math.degrees(math.acos(max(-1.0, min(1.0, x))))
def darctan2(y, x): return math.degrees(math.atan2(y, x))
def darccot(x): return math.degrees(math.atan(1.0 / x))
def fix(a, b):
	a = a - b * math.floor(a / b)
	return a + b if a < 0 else a
def fixangle(a): return fix(a, 360.0)
def fixhour(a): return fix(a, 24.0)


def julian(year, month, day):
	if month <= 2:
		year -= 1
		month += 12
	a = math.floor(year / 100.0)
	b = 2 - a + math.floor(a / 4.0)
	return math.floor(365.25 * (year + 4716)) + math.floor(30.6001 * (month + 1)) + day + b - 1524.5


def sun_position(jd):
	d = jd - 2451545.0
	g = fixangle(357.529 + 0.98560028 * d)
	q = fixangle(280.459 + 0.98564736 * d)
	L = fixangle(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g))
	e = 23.439 - 0.00000036 * d
	RA = darctan2(dcos(e) * dsin(L), dcos(L)) / 15.0
	eqt = q / 15.0 - fixhour(RA)
	decl = darcsin(dsin(e) * dsin(L))
	return decl, eqt


class PrayerCalculator(object):
	"""calc(date, lat, lon, tz_hours) -> dict prayer -> minutes from local midnight (float)"""

	def __init__(self, method="jordan", asr_factor=1, high_lat="angle", elevation=0):
		self.method = _method(method)
		self.asr_factor = asr_factor  # 1 = standard (shafi), 2 = hanafi
		self.high_lat = high_lat      # none | angle | midnight | seventh
		self.elevation = elevation

	def _mid_day(self, t):
		eqt = sun_position(self.jdate + t)[1]
		return fixhour(12 - eqt)

	def _sun_angle_time(self, angle, t, ccw=False):
		decl = sun_position(self.jdate + t)[0]
		noon = self._mid_day(t)
		v = (-dsin(angle) - dsin(decl) * dsin(self.lat)) / (dcos(decl) * dcos(self.lat))
		if v > 1 or v < -1:
			return float("nan")
		tt = darccos(v) / 15.0
		return noon + (-tt if ccw else tt)

	def _asr_time(self, factor, t):
		decl = sun_position(self.jdate + t)[0]
		angle = -darccot(factor + dtan(abs(self.lat - decl)))
		return self._sun_angle_time(angle, t)

	def _rise_set_angle(self):
		return 0.833 + 0.0347 * math.sqrt(max(0, self.elevation))

	def calc(self, date, lat, lon, tz):
		self.lat, self.lon = lat, lon
		self.jdate = julian(date.year, date.month, date.day) - lon / (15.0 * 24.0)
		m = self.method
		fajr_a, isha_p, magh_p = m[2], m[3], m[4]

		times = {"fajr": 5, "sunrise": 6, "dhuhr": 12, "asr": 13, "sunset": 18, "maghrib": 18, "isha": 18}
		for _ in range(2):
			defaults = {"fajr": 5, "sunrise": 6, "dhuhr": 12, "asr": 13, "sunset": 18, "maghrib": 18, "isha": 18}
			p = dict((k, (v if v == v else defaults[k]) / 24.0) for k, v in times.items())
			rs = self._rise_set_angle()
			times = {
				"fajr": self._sun_angle_time(fajr_a, p["fajr"], True),
				"sunrise": self._sun_angle_time(rs, p["sunrise"], True),
				"dhuhr": self._mid_day(p["dhuhr"]),
				"asr": self._asr_time(self.asr_factor, p["asr"]),
				"sunset": self._sun_angle_time(rs, p["sunset"]),
				"maghrib": self._sun_angle_time(magh_p if isinstance(magh_p, float) else rs, p["maghrib"]),
				"isha": self._sun_angle_time(isha_p if isinstance(isha_p, float) else 18.0, p["isha"]),
			}

		# timezone
		for k in times:
			times[k] += tz - lon / 15.0

		# high latitude adjustment
		if self.high_lat != "none":
			night = fixhour(times["sunrise"] - times["sunset"])
			def portion(angle):
				if self.high_lat == "midnight":
					return 0.5 * night
				if self.high_lat == "seventh":
					return night / 7.0
				return angle / 60.0 * night
			def adjust(t, base, angle, direction_ccw):
				port = portion(angle)
				if t != t:
					return base - port if direction_ccw else base + port
				diff = fixhour(base - t) if direction_ccw else fixhour(t - base)
				if diff > port:
					return base - port if direction_ccw else base + port
				return t
			times["fajr"] = adjust(times["fajr"], times["sunrise"], fajr_a, True)
			if isinstance(isha_p, float):
				times["isha"] = adjust(times["isha"], times["sunset"], isha_p, False)
			if isinstance(magh_p, float):
				times["maghrib"] = adjust(times["maghrib"], times["sunset"], magh_p, False)

		if isinstance(magh_p, str):
			times["maghrib"] = times["sunset"] + int(magh_p[:-3]) / 60.0
		if isinstance(isha_p, str):
			times["isha"] = times["maghrib"] + int(isha_p[:-3]) / 60.0

		out = {}
		extra = m[5]
		for k in PRAYERS:
			mins = times[k] * 60.0 + extra.get(k, 0)
			out[k] = mins
		return out


def calc_day(date, lat, lon, tz, method="jordan", asr_factor=1, high_lat="angle",
             offsets=None, global_offset=0):
	"""Returns dict prayer -> datetime.datetime (local, naive), rounded to minute."""
	pc = PrayerCalculator(method, asr_factor, high_lat)
	raw = pc.calc(date, lat, lon, tz)
	base = datetime.datetime(date.year, date.month, date.day)
	res = {}
	for k in PRAYERS:
		mins = raw[k]
		if mins != mins:  # NaN (polar)
			mins = {"fajr": 300, "sunrise": 360, "dhuhr": 720, "asr": 900, "maghrib": 1080, "isha": 1170}[k]
		off = int(global_offset or 0) + int((offsets or {}).get(k, 0) or 0)
		mins = int(math.floor(mins + 0.5)) + off
		res[k] = base + datetime.timedelta(minutes=mins)
	return res


def qibla(lat, lon):
	"""bearing in degrees from true north (clockwise) and distance km to the Kaaba."""
	klat, klon = 21.4224779, 39.8251832
	dl = math.radians(klon - lon)
	p1, p2 = math.radians(lat), math.radians(klat)
	y = math.sin(dl)
	x = math.cos(p1) * math.tan(p2) - math.sin(p1) * math.cos(dl)
	bearing = fixangle(math.degrees(math.atan2(y, x)))
	a = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
	dist = 6371.0 * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
	return bearing, dist
