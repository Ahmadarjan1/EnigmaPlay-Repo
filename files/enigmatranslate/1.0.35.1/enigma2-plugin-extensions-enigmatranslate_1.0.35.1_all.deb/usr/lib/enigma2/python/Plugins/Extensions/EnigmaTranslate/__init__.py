# -*- coding: utf-8 -*-
# Author: Ahmad Al-Qaisi
"""Enigma Translate - Live translation of foreign TV channels (subtitles and audio)."""

VERSION = "1.0.35.1"
__version__ = VERSION



__author__ = "Ahmad Al-Qaisi"

