# -*- coding: utf-8 -*-
# Author: Ahmad Al-Qaisi
"""Enigma Translate configuration and settings management."""


import json
import os
import stat

DATA_DIR = "/etc/enigma2/enigmatranslate"
KEYS_FILE = os.path.join(DATA_DIR, "keys.json")
if not os.path.exists(KEYS_FILE):
    _local_k = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "keys.json")
    if os.path.isfile(_local_k):
        KEYS_FILE = _local_k
MODELS_FILE = os.path.join(DATA_DIR, "ai_models.json")
CACHE_FILE = os.path.join(DATA_DIR, "cache.json")
PROFILES_FILE = os.path.join(DATA_DIR, "profiles.json")
GLOSSARY_FILE = os.path.join(DATA_DIR, "glossary.json")
AI_USAGE_FILE = os.path.join(DATA_DIR, "ai_usage.json")
CHANNEL_BRIDGES_FILE = os.path.join(DATA_DIR, "channel_bridges.json")
GROQ_DROPIN_KEY_FILE = os.path.join(DATA_DIR, "groq_key.txt")
ASSEMBLYAI_DROPIN_KEY_FILE = os.path.join(DATA_DIR, "assemblyai_key.txt")
IPTV_POLICY_FILE = os.path.join(DATA_DIR, "iptv_policy.json")

# Internal display defaults (not user cards)
DEFAULT_MAX_LINES = 2
DEFAULT_MAX_CHARS = 38
DEFAULT_CPS = 17.0

# Fallback models dictionary if ai_models.json does not exist
DEFAULT_AI_MODELS = {
    "gemini": {
        "fast": "gemini-2.0-flash",
        "balanced": "gemini-1.5-flash",
        "best": "gemini-1.5-pro",
        "audio": "gemini-2.0-flash",
        "audio_fallback": "gemini-1.5-flash"
    },
    "cloudflare": {
        "model": "@cf/openai/whisper-large-v3-turbo",
        "whisper": "@cf/openai/whisper-large-v3-turbo",
        "universal": "assemblyai/universal-3.5-pro",
        "fallback": "@cf/openai/whisper-large-v3-turbo"
    },
    "deepgram": {
        "model": "nova-3",
        "fallback": "nova-2"
    },
    "speechmatics": {
        "model": "default"
    },
    "openai": {
        "fast": "gpt-4o-mini",
        "balanced": "gpt-4o-mini",
        "best": "gpt-4o"
    },
    "claude": {
        "fast": "claude-3-haiku-20240307",
        "balanced": "claude-3-5-haiku-20241022",
        "best": "claude-3-5-sonnet-20241022"
    },
    "groq": {
        "fast": "allam-2-7b",
        "balanced": "allam-2-7b",
        "best": "qwen/qwen3.8-27b",
        "identify": "qwen/qwen3.8-27b",
        "whisper": "whisper-large-v3-turbo"
    },
    "assemblyai": {
        "speech_models": ["universal-3-5-pro", "universal-2"]
    },
    "deepl": {
        "fast": "default",
        "balanced": "default",
        "best": "default"
    }
}

try:
    from Components.config import (
        config,
        ConfigSubsection,
        ConfigYesNo,
        ConfigSelection,
        ConfigInteger,
        ConfigFloat,
        ConfigText
    )
    HAS_ENIGMA = True
except ImportError:
    HAS_ENIGMA = False
    # Fallback mocks for unit testing without Enigma2
    class _MockConfigElement:
        def __init__(self, default, choices=None):
            self.value = default
            self.default = default
            self.saved_value = None
            self.choices = choices or []
            self.notifiers = []
        def save(self):
            pass
        def load(self):
            if self.saved_value is not None:
                self.value = self.saved_value
        def addNotifier(self, notifier, immediate_feedback=False):
            self.notifiers.append(notifier)
        def getText(self):
            for c in self.choices:
                if c[0] == self.value:
                    return c[1]
            return str(self.value)

    class _MockConfigSubsection:
        def __init__(self):
            pass

    class _MockConfig:
        def __init__(self):
            self.plugins = type("Plugins", (), {})()

    config = _MockConfig()
    ConfigSubsection = _MockConfigSubsection
    ConfigYesNo = lambda default=False: _MockConfigElement(default)
    ConfigSelection = lambda choices=[], default="": _MockConfigElement(default, choices=choices)
    ConfigInteger = lambda default=0, limits=(0, 100): _MockConfigElement(default)
    ConfigFloat = lambda default=[0.0, 1], limits=[(0.0, 10.0)]: _MockConfigElement(default[0] if isinstance(default, list) else default)
    ConfigText = lambda default="", fixed_size=False: _MockConfigElement(default)


DELAY_CHOICES = [
    (f"{x/10.0:.1f}", f"{x/10.0:+.1f} s" if x != 0 else "0.0 s")
    for x in range(-50, 105, 5)
]

SUB_DURATION_CHOICES = [
    ("auto", "تلقائي"),
    ("1", "1 ثانية"),
    ("2", "2 ثوانٍ"),
    ("3", "3 ثوانٍ"),
    ("4", "4 ثوانٍ"),
    ("5", "5 ثوانٍ"),
    ("6", "6 ثوانٍ"),
    ("8", "8 ثوانٍ"),
    ("until_next", "حتى السطر التالي"),
]


def parse_delay_to_seconds(raw_val):
    """Safely parse delay from legacy ConfigFloat list [m, e], str, int or float into float seconds."""
    if raw_val is None:
        return 0.0
    if isinstance(raw_val, (list, tuple)):
        if len(raw_val) >= 2:
            try:
                return float(raw_val[0]) / (10.0 ** float(raw_val[1]))
            except Exception:
                try:
                    return float(raw_val[0])
                except Exception:
                    return 0.0
        elif len(raw_val) == 1:
            try:
                return float(raw_val[0])
            except Exception:
                return 0.0
        return 0.0
    if isinstance(raw_val, str):
        s = raw_val.strip()
        if s.startswith("[") and s.endswith("]"):
            try:
                parts = [p.strip() for p in s[1:-1].split(",") if p.strip()]
                if len(parts) >= 2:
                    return float(parts[0]) / (10.0 ** float(parts[1]))
                elif len(parts) == 1:
                    return float(parts[0])
            except Exception:
                pass
        try:
            return float(s)
        except Exception:
            return 0.0
    try:
        return float(raw_val)
    except Exception:
        return 0.0


def delay_to_choice(sec):
    """Convert seconds to closest valid choice string (-5.0 to 10.0 in 0.5 steps)."""
    val = round(float(sec) * 2.0) / 2.0
    val = max(-5.0, min(10.0, val))
    return f"{val:.1f}"


def migrate_delay_setting(elem):
    """Migrate legacy ConfigFloat or raw setting on delay ConfigElement to valid ConfigSelection value."""
    if elem is None:
        return
    try:
        cur_val = getattr(elem, "value", None)
        valid_keys = [c[0] for c in getattr(elem, "choices", [])]
        if cur_val not in valid_keys:
            sec = parse_delay_to_seconds(cur_val)
            migrated = delay_to_choice(sec)
            elem.value = migrated
            try:
                elem.save()
            except Exception:
                pass
    except Exception:
        pass


def migrate_delay_config(cfg):
    """Ensure delay on given config subsection is migrated and saved."""
    if cfg is None:
        return
    try:
        elem = getattr(cfg, "delay", None)
        if elem is not None:
            migrate_delay_setting(elem)
        if getattr(cfg, "bridge_auto", None) is None:
            cfg.bridge_auto = ConfigYesNo(default=True)
    except Exception:
        pass


def get_config_items(cfg):
    """Retrieve dict of (name, ConfigElement) from subsection."""
    if cfg is None:
        return {}
    if hasattr(cfg, "dict") and callable(cfg.dict):
        try:
            return cfg.dict()
        except Exception:
            pass
    if hasattr(cfg, "content") and hasattr(cfg.content, "items"):
        return cfg.content.items
    items = {}
    for name in dir(cfg):
        if not name.startswith("_"):
            try:
                items[name] = getattr(cfg, name)
            except Exception:
                pass
    return items


def _make_config_logger(key):
    def _logger(elem):
        val = getattr(elem, "value", None)
        print(f"[EnigmaTranslate] [CONFIG WRITE] config.plugins.enigmatranslate.{key} = {val!r}")
    return _logger


def save_config_file():
    """Flush all config.plugins.enigmatranslate items and write /etc/enigma2/settings immediately."""
    cfg = getattr(getattr(config, "plugins", None), "enigmatranslate", None)
    if cfg is not None:
        items = get_config_items(cfg)
        for name, elem in items.items():
            try:
                if elem is not None and callable(getattr(elem, "save", None)):
                    elem.save()
            except Exception:
                pass

    try:
        from Components.config import configfile
        if configfile is not None and hasattr(configfile, "save"):
            configfile.save()
            print("[EnigmaTranslate] [CONFIG] Saved /etc/enigma2/settings successfully.")
            return True
    except Exception as e:
        print(f"[EnigmaTranslate] [CONFIG] configfile.save() error: {e}")
    return False


def init_config():
    """Initialize config.plugins.enigmatranslate subsystem."""
    # Always (re)define every element. A subsection left over from an older
    # version loaded in the same GUI session may lack newer elements
    # (crash: AttributeError ai_provider on OpenBH after install without restart).
    if True:
        try:
            cfg = config.plugins.enigmatranslate
        except (AttributeError, KeyError):
            cfg = None
        if cfg is None:
            cfg = ConfigSubsection()
            # Attach subsection to config.plugins immediately so Enigma2 resolves stored values from /etc/enigma2/settings
            config.plugins.enigmatranslate = cfg
        
        # General & Capture
        cfg.enabled = ConfigYesNo(default=False)
        cfg.channel_autostart = ConfigYesNo(default=False)
        cfg.ui_lang = ConfigSelection(choices=[("ar", "العربية"), ("en", "English")], default="ar")
        cfg.source = ConfigSelection(
            choices=[
                ("auto", "تلقائي"),
                ("teletext", "تليتكست (Teletext)"),
                ("sub", "ترجمة نصية DVB"),
                ("audio", "صوت")
            ],
            default="auto"
        )
        cfg.teletext_page = ConfigText(default="auto", fixed_size=False)
        cfg.src_lang = ConfigSelection(
            choices=[
                ("auto", "كشف تلقائي"),
                ("nl", "Nederlands"),
                ("he", "עברית"),
                ("en", "English"),
                ("fr", "Français"),
                ("tr", "Türkçe"),
                ("de", "Deutsch"),
                ("es", "Español"),
                ("it", "Italiano"),
                ("ru", "Русский"),
                ("fa", "فارسی"),
                ("ur", "اردو")
            ],
            default="auto"
        )
        cfg.dst_lang = ConfigSelection(
            choices=[
                ("ar", "العربية"),
                ("en", "English"),
                ("tr", "Türkçe"),
                ("fr", "Français"),
                ("fa", "فارسی"),
                ("ur", "اردو"),
                ("de", "Deutsch"),
                ("es", "Español")
            ],
            default="ar"
        )
        cfg.dual = ConfigYesNo(default=True)
        cfg.ignore_native_subs = ConfigYesNo(default=False)
        cfg.content_type = ConfigSelection(
            choices=[
                ("auto", "تلقائي"),
                ("movie", "فيلم"),
                ("series", "مسلسل"),
                ("news", "أخبار"),
                ("sport", "رياضة"),
                ("documentary", "وثائقي"),
                ("history", "تاريخي"),
                ("nature", "طبيعة وحيوانات"),
                ("science", "علوم وتقنية"),
                ("kids", "أطفال وكرتون"),
                ("talk", "حواري"),
                ("music", "موسيقى"),
                ("cooking", "طبخ وسفر"),
                ("religious", "ديني"),
                ("general", "عام")
            ],
            default="auto"
        )
        cfg.sub_index = ConfigInteger(default=0, limits=(0, 16))
        cfg.stt_engine = ConfigSelection(
            choices=[
                ("auto", "تلقائي"),
                ("groq", "Groq"),
                ("cloudflare", "Cloudflare"),
                ("gemini", "Gemini"),
                ("speechmatics", "Speechmatics"),
                ("deepgram", "Deepgram"),
                ("assemblyai", "AssemblyAI"),
                ("vosk", "Vosk (محلي)"),
                ("off", "معطل")
            ],
            default="auto"
        )
        cfg.stt_chunk_sec = ConfigInteger(default=10, limits=(10, 15))
        cfg.whisper_prompt = ConfigText(default="", fixed_size=False)
        cfg.vosk_dir = ConfigText(default="/etc/enigma2/enigmatranslate/vosk", fixed_size=False)
        cfg.ffmpeg = ConfigText(default="ffmpeg", fixed_size=False)
        cfg.stream_port = ConfigInteger(default=8001, limits=(1, 65535))
        cfg.iptv_relay = ConfigSelection(
            choices=[
                ("on", "مفعل (تجريبي)"),
                ("off", "معطل")
            ],
            default="on"
        )
        cfg.iptv_bridge = ConfigYesNo(default=True)
        cfg.identify_movie_audio = ConfigYesNo(default=True)
        cfg.hud = ConfigYesNo(default=True)
        
        # Engines & Fallback chain
        cfg.eng1 = ConfigSelection(
            choices=[
                ("google", "Google"),
                ("mymemory", "MyMemory"),
                ("libre", "Libre"),
                ("lingva", "Lingva"),
                ("ai", "AI"),
                ("argos", "Argos"),
                ("none", "—")
            ],
            default="google"
        )
        cfg.eng2 = ConfigSelection(
            choices=[
                ("google", "Google"),
                ("mymemory", "MyMemory"),
                ("libre", "Libre"),
                ("lingva", "Lingva"),
                ("ai", "AI"),
                ("argos", "Argos"),
                ("none", "—")
            ],
            default="mymemory"
        )
        cfg.eng3 = ConfigSelection(
            choices=[
                ("google", "Google"),
                ("mymemory", "MyMemory"),
                ("libre", "Libre"),
                ("lingva", "Lingva"),
                ("ai", "AI"),
                ("argos", "Argos"),
                ("none", "—")
            ],
            default="lingva"
        )
        cfg.timeout = ConfigFloat(default=[3.0, 1], limits=[(1.0, 10.0)])
        cfg.cache = ConfigYesNo(default=True)
        cfg.cache_size = ConfigInteger(default=2000, limits=(100, 20000))
        cfg.libre_url = ConfigText(default="https://libretranslate.com", fixed_size=False)
        cfg.glossary_on = ConfigYesNo(default=True)
        cfg.quick_button = ConfigSelection(
            choices=[
                ("subtitle", "SUBTITLE"),
                ("text", "TEXT"),
                ("help", "HELP"),
                ("none", "none")
            ],
            default="subtitle"
        )
        
        # Look & OSD
        cfg.font_size = ConfigInteger(default=36, limits=(20, 64))
        cfg.font_color = ConfigSelection(
            choices=[
                ("#ffffff", "أبيض"),
                ("#ffe34d", "أصفر"),
                ("#6df0ff", "سماوي"),
                ("#8dff9a", "أخضر")
            ],
            default="#ffffff"
        )
        cfg.sub_duration = ConfigSelection(choices=SUB_DURATION_CHOICES, default="auto")
        cfg.bg_alpha = ConfigInteger(default=55, limits=(0, 100))
        cfg.pos_y = ConfigInteger(default=7, limits=(0, 40))
        cfg.dock_pos = ConfigSelection(choices=[("top", "أعلى"), ("bottom", "أسفل")], default="top")
        cfg.status_pill = ConfigSelection(
            choices=[
                ("auto", "تلقائي"),
                ("always", "دائماً"),
                ("hidden", "مخفي")
            ],
            default="auto"
        )
        
        # Sync & Safe Mode
        cfg.delay = ConfigSelection(choices=DELAY_CHOICES, default="0.0")
        cfg.sync_keys = ConfigSelection(
            choices=[
                ("<>", "< > (السابق / التالي)"),
                ("rew_ff", "<< >> (تقديم / إرجاع)"),
                ("both", "كلاهما (< > و << >>)"),
                ("off", "معطل")
            ],
            default="<>"
        )
        cfg.bridge_auto = ConfigYesNo(default=True)
        cfg.bridge = ConfigYesNo(default=False)
        cfg.bridge_sec = ConfigInteger(default=14, limits=(8, 16))
        cfg.safe_mode = ConfigYesNo(default=True)
        cfg.cpu_limit = ConfigInteger(default=80, limits=(50, 95))
        
        # AI Engine Settings
        cfg.ai_provider = ConfigSelection(
            choices=[
                ("gemini", "Gemini"),
                ("openai", "OpenAI"),
                ("claude", "Claude"),
                ("groq", "Groq"),
                ("deepl", "DeepL")
            ],
            default="gemini"
        )
        cfg.ai_model_tier = ConfigSelection(
            choices=[
                ("fast", "سريع (Fast)"),
                ("balanced", "متوازن (Balanced)"),
                ("best", "الأفضل (Best)")
            ],
            default="balanced"
        )
        cfg.ai_when = ConfigSelection(
            choices=[
                ("hard", "للجمل الصعبة"),
                ("fallback", "عند الفشل"),
                ("always", "دائمًا")
            ],
            default="hard"
        )
        cfg.ai_cap = ConfigInteger(default=1000, limits=(100, 5000))
        cfg.ai_context = ConfigInteger(default=2, limits=(0, 5))
        cfg.ai_style = ConfigSelection(
            choices=[
                ("natural", "طبيعي"),
                ("literal", "حرفي"),
                ("simple", "مبسط")
            ],
            default="natural"
        )
        cfg.ai_detect_content = ConfigYesNo(default=True)
        cfg.ai_learn_terms = ConfigYesNo(default=False)
        
        migrate_delay_config(cfg)

        # Force-load saved values into elements if available
        items = get_config_items(cfg)
        for name, elem in items.items():
            try:
                if elem is not None and hasattr(elem, "saved_value") and elem.saved_value is not None:
                    if callable(getattr(elem, "load", None)):
                        elem.load()
            except Exception:
                pass

        # Boot log: Log every config write / setting at boot
        print("[EnigmaTranslate] [CONFIG BOOT] Initializing config.plugins.enigmatranslate:")
        for name in sorted(items.keys()):
            elem = items[name]
            try:
                if elem is not None and hasattr(elem, "value"):
                    val = getattr(elem, "value", None)
                    print(f"[EnigmaTranslate] [CONFIG BOOT] config.plugins.enigmatranslate.{name} = {val!r}")
                    if hasattr(elem, "addNotifier"):
                        elem.addNotifier(_make_config_logger(name), immediate_feedback=False)
            except Exception:
                pass

init_config()


def _ensure_dir(path):
    """Ensure directory exists with safe permissions."""
    try:
        if not os.path.isdir(path):
            os.makedirs(path, mode=0o755, exist_ok=True)
    except Exception:
        pass


def check_and_import_dropin_keys():
    """If groq_key.txt or assemblyai_key.txt exists: read key once, move into keys.json (mode 0600), delete file."""
    for prov, fpath in [("groq", GROQ_DROPIN_KEY_FILE), ("assemblyai", ASSEMBLYAI_DROPIN_KEY_FILE)]:
        if os.path.isfile(fpath):
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    key = f.read().strip()
                if key:
                    set_api_key(prov, key)
                try:
                    os.remove(fpath)
                except Exception:
                    pass
            except Exception:
                pass


def get_api_key(provider):
    """Securely retrieve API key for a provider from keys.json."""
    check_and_import_dropin_keys()
    try:
        if os.path.isfile(KEYS_FILE):
            with open(KEYS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                val = data.get(provider, "")
                if not val and provider == "cloudflare":
                    val = data.get("cloudflare_token", "") or data.get("cloudflare_api_key", "")
                return str(val or "").strip()
    except Exception:
        pass
    return ""


def set_api_key(provider, key):
    """Securely store API key for a provider in keys.json (mode 0600)."""
    _ensure_dir(DATA_DIR)
    data = {}
    try:
        if os.path.isfile(KEYS_FILE):
            with open(KEYS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
    except Exception:
        data = {}
    
    if key:
        data[provider] = key.strip()
    else:
        data.pop(provider, None)
        
    try:
        # Write to temporary file first then rename
        tmp_file = KEYS_FILE + ".tmp"
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        try:
            os.chmod(tmp_file, stat.S_IRUSR | stat.S_IWUSR)
        except Exception:
            pass
        os.replace(tmp_file, KEYS_FILE)
        return True
    except Exception:
        return False


def mask_key(key):
    """Return masked representation of an API key."""
    if not key:
        return "اضغط للإدخال"
    k = key.strip()
    if len(k) <= 4:
        return "••••"
    return "••••" + k[-4:]


def get_ai_models():
    """Load AI models configuration or return defaults."""
    if os.path.isfile(MODELS_FILE):
        try:
            with open(MODELS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                groq_cfg = data.get("groq", {})
                updated = False
                if "llama" in str(groq_cfg.get("best", "")).lower() or not groq_cfg.get("best"):
                    groq_cfg["best"] = "qwen/qwen3.8-27b"
                    updated = True
                if not groq_cfg.get("identify") or "llama" in str(groq_cfg.get("identify", "")).lower():
                    groq_cfg["identify"] = "qwen/qwen3.8-27b"
                    updated = True
                if "llama" in str(groq_cfg.get("balanced", "")).lower() or not groq_cfg.get("balanced"):
                    groq_cfg["balanced"] = "allam-2-7b"
                    updated = True
                if "llama" in str(groq_cfg.get("fast", "")).lower() or not groq_cfg.get("fast"):
                    groq_cfg["fast"] = "allam-2-7b"
                    updated = True
                if updated:
                    data["groq"] = groq_cfg
                    try:
                        with open(MODELS_FILE, "w", encoding="utf-8") as wf:
                            json.dump(data, wf, indent=2)
                    except Exception:
                        pass
                return data
        except Exception:
            pass
    # Create default file if missing
    try:
        _ensure_dir(DATA_DIR)
        with open(MODELS_FILE, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_AI_MODELS, f, indent=2)
    except Exception:
        pass
    return DEFAULT_AI_MODELS


def _T(ar, en):
    """Return Arabic or English string depending on configured UI language."""
    try:
        if config.plugins.enigmatranslate.ui_lang.value == "en":
            return en
    except Exception:
        pass
    return ar


def get_iptv_policy(provider_key):
    """Return True (allow), False (deny), or None (unasked) for IPTV provider second connection."""
    try:
        if os.path.isfile(IPTV_POLICY_FILE):
            with open(IPTV_POLICY_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict) and str(provider_key) in data:
                    return bool(data[str(provider_key)])
    except Exception:
        pass
    return None


def set_iptv_policy(provider_key, allow):
    """Save user second-connection policy for IPTV provider."""
    try:
        data = {}
        if os.path.isfile(IPTV_POLICY_FILE):
            try:
                with open(IPTV_POLICY_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if not isinstance(data, dict):
                        data = {}
            except Exception:
                data = {}
        data[str(provider_key)] = bool(allow)
        os.makedirs(os.path.dirname(IPTV_POLICY_FILE), exist_ok=True)
        with open(IPTV_POLICY_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        print(f"[EnigmaTranslate] set_iptv_policy error: {e}")

