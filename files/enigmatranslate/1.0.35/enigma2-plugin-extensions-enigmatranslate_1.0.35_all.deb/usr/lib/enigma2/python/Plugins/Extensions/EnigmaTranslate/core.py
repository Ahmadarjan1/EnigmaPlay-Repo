# -*- coding: utf-8 -*-
# Author: Ahmad Al-Qaisi
"""Enigma Translate Controller singleton and lifecycle coordinator."""

import collections
import ctypes
import glob
import json
import math
import os
import queue
import re
import subprocess
import threading
import time
import urllib.parse
from datetime import datetime

from . import settings, VERSION
from .engines import EngineChain, TranslationCache, Glossary, AIEngine, TranslationContext
from .taps import TapManager, serviceref_to_stream_url, is_iptv_service, get_iptv_provider_key

# Default internal text display metrics
DEFAULT_CPS = 17.0
MIN_DURATION = 1.8
MAX_DURATION = 7.0
MAX_LINE_CHARS = 38
MAX_LINES = 2

_CONTROLLER_INSTANCE = None

_LAMEDB_CRYPTED_CACHE = None
_LAMEDB_MTIME = 0


def get_lamedb_crypted_services():
    """Load and cache the set of crypted service keys from /etc/enigma2/lamedb."""
    global _LAMEDB_CRYPTED_CACHE, _LAMEDB_MTIME
    lamedb_path = "/etc/enigma2/lamedb"
    if not os.path.isfile(lamedb_path):
        return set()
    try:
        mtime = os.path.getmtime(lamedb_path)
        if _LAMEDB_CRYPTED_CACHE is not None and mtime == _LAMEDB_MTIME:
            return _LAMEDB_CRYPTED_CACHE
        crypted = set()
        with open(lamedb_path, "r", encoding="latin-1") as f:
            lines = f.readlines()
        for i, line in enumerate(lines):
            line = line.strip()
            if line.startswith("p:") and ("C:" in line or "c:05" in line):
                if i >= 2:
                    k = lines[i - 2].strip().lower()
                    parts = k.split(":")
                    if len(parts) >= 4:
                        skey = f"{parts[0]}:{parts[1]}:{parts[2]}:{parts[3]}"
                        crypted.add(skey)
        _LAMEDB_CRYPTED_CACHE = crypted
        _LAMEDB_MTIME = mtime
        return crypted
    except Exception as e:
        print(f"[EnigmaTranslate] get_lamedb_crypted_services error: {e}")
        return _LAMEDB_CRYPTED_CACHE or set()


def is_service_encrypted(service=None, service_ref=None):
    """Detect whether a service is encrypted (lamedb, CAIDs in PMT, service info, or /tmp/ecm.info)."""
    ref_str = str(service_ref or "").strip()
    # 1. Skip IPTV streams (not DVB encrypted)
    parts = ref_str.split(":")
    if len(parts) >= 11:
        stype = parts[0]
        if stype in ("4097", "5001", "5002", "5003"):
            return False
        field10 = parts[10]
        if field10.startswith("http") or "%3a" in field10.lower():
            return False

    # 2. Check lamedb static database (instant, reliable even before tuner lock)
    if len(parts) >= 7:
        try:
            sid = f"{int(parts[3], 16):04x}"
            tsid = f"{int(parts[4], 16):04x}"
            onid = f"{int(parts[5], 16):04x}"
            ns = f"{int(parts[6], 16):08x}"
            target_key = f"{sid}:{ns}:{tsid}:{onid}"
            crypted_set = get_lamedb_crypted_services()
            if target_key in crypted_set:
                return True
        except Exception:
            pass

    # 3. Check live service object if provided
    if service:
        try:
            info = service.info() if hasattr(service, "info") else None
            if info:
                s_caids = 21
                s_crypted = 8
                try:
                    from enigma import iServiceInformation
                    s_caids = getattr(iServiceInformation, "sCAIDs", 21)
                    s_crypted = getattr(iServiceInformation, "sIsCrypted", 8)
                except ImportError:
                    pass
                caids = info.getInfoObject(s_caids) if hasattr(info, "getInfoObject") else None
                if caids and len(caids) > 0:
                    return True
                if hasattr(info, "getInfo") and info.getInfo(s_crypted) == 1:
                    return True
        except Exception:
            pass

    # 4. Check eServiceCenter for ref
    if ref_str:
        try:
            from enigma import eServiceCenter, eServiceReference, iServiceInformation
            ref_obj = eServiceReference(ref_str)
            info = eServiceCenter.getInstance().info(ref_obj)
            if info:
                s_crypted = getattr(iServiceInformation, "sIsCrypted", 8)
                if info.getInfo(ref_obj, s_crypted) == 1:
                    return True
        except Exception:
            pass

    # 5. Check ecm.info files in /tmp
    for ecm_file in ("/tmp/ecm.info", "/tmp/ecm0.info", "/tmp/ecm1.info"):
        if os.path.isfile(ecm_file) and os.path.getsize(ecm_file) > 0:
            try:
                with open(ecm_file, "r") as f:
                    cnt = f.read().lower()
                    if "caid:" in cnt or "reader:" in cnt:
                        return True
            except Exception:
                pass

    return False


def find_active_timeshift_file():
    """Locate the current active timeshift TS file on disk."""
    dirs = []
    try:
        from Components.config import config
        ts_dir = getattr(getattr(config, "usage", None), "timeshift_path", None)
        if ts_dir and ts_dir.value and os.path.isdir(ts_dir.value):
            dirs.append(ts_dir.value)
    except Exception:
        pass
    for d in ["/media/hdd/enigmatranslate/tmp", "/media/hdd/timeshift", "/media/hdd", "/media/usb/timeshift", "/media/usb", "/tmp/enigmatranslate/tmp", "/tmp"]:
        if d not in dirs and os.path.isdir(d):
            dirs.append(d)

    candidates = []
    now = time.time()
    for d in dirs:
        try:
            for fname in os.listdir(d):
                if fname.endswith(".meta") or fname.endswith(".ap") or fname.endswith(".sc") or fname.endswith(".cuts") or fname.endswith(".del") or fname.endswith(".py") or fname.endswith(".eit") or fname.endswith(".json") or fname.endswith(".txt"):
                    continue
                if fname.startswith("timeshift.") or fname.startswith("pts_livebuffer") or fname.startswith("bg_record_") or (fname.endswith(".ts") and "timeshift" in fname.lower()) or (fname.endswith(".ts") and "pts" in fname.lower()) or (fname.endswith(".ts") and "bg_record" in fname.lower()):
                    fpath = os.path.join(d, fname)
                    st = os.stat(fpath)
                    if abs(now - st.st_mtime) < 300 and st.st_size > 0:
                        candidates.append((st.st_mtime, st.st_size, fpath))
        except Exception:
            pass

    if candidates:
        candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)
        return candidates[0][2]
    return None


FALLOC_FL_KEEP_SIZE = 0x01
FALLOC_FL_PUNCH_HOLE = 0x02


def punch_hole_in_file(filepath, keep_tail_bytes):
    """Keep only keep_tail_bytes at the end of filepath, punching holes in the front.
    Releases disk blocks to ext4 while the write and read heads remain open and valid.
    """
    if not filepath or not os.path.isfile(filepath):
        return 0
    try:
        size = os.path.getsize(filepath)
    except Exception:
        return 0
    if size <= keep_tail_bytes:
        return 0

    punch_len = size - keep_tail_bytes
    # Round down to 4096-byte page boundary
    punch_len = (punch_len // 4096) * 4096
    if punch_len <= 0:
        return 0

    try:
        libc = ctypes.CDLL(None)
        with open(filepath, "r+b") as f:
            fd = f.fileno()
            if hasattr(libc, "fallocate64"):
                libc.fallocate64.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int64, ctypes.c_int64]
                res = libc.fallocate64(fd, FALLOC_FL_PUNCH_HOLE | FALLOC_FL_KEEP_SIZE, 0, punch_len)
            else:
                libc.fallocate.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int64, ctypes.c_int64]
                res = libc.fallocate(fd, FALLOC_FL_PUNCH_HOLE | FALLOC_FL_KEEP_SIZE, 0, punch_len)
            if res == 0:
                return punch_len
    except Exception:
        pass
    return 0


def restore_leftover_timeshift_bypass():
    """Restore check_timeshift and favoriteSaveAction if a leftover bypass flag exists from a crash or abrupt restart."""
    flag_files = [
        os.path.join(getattr(settings, "DATA_DIR", "/etc/enigma2/enigmatranslate"), "ts_bypass.json"),
        "/tmp/enigmatranslate_ts_bypass.json"
    ]
    for flag_file in flag_files:
        if os.path.isfile(flag_file):
            try:
                with open(flag_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                saved_check_ts = data.get("saved_check_ts")
                saved_fav = data.get("saved_fav_action")
                from Components.config import config
                if saved_check_ts is not None:
                    try:
                        config.usage.check_timeshift.value = bool(saved_check_ts)
                    except (AttributeError, KeyError):
                        pass
                if saved_fav is not None:
                    try:
                        config.timeshift.favoriteSaveAction.value = str(saved_fav)
                    except (AttributeError, KeyError):
                        pass
                print(f"[EnigmaTranslate] [TIMESHIFT] check_timeshift restored ({saved_check_ts}) from flag '{flag_file}'")
            except Exception as e:
                print(f"[EnigmaTranslate] [TIMESHIFT] Error restoring leftover bypass flag from '{flag_file}': {e}")
            finally:
                try:
                    os.remove(flag_file)
                except Exception:
                    pass


def clean_temp_disk_files():
    """Delete all background recording and temporary timeshift files created by EnigmaTranslate."""
    dirs = ["/media/hdd/enigmatranslate/tmp", "/tmp/enigmatranslate/tmp"]
    patterns = ["bg_record_*", "pts_livebuffer_*", "timeshift.*", "*.ts", "*.ts.cuts", "*.ts.meta", "*.ts.ap", "*.ts.sc"]
    for d in dirs:
        if os.path.exists(d):
            for pat in patterns:
                for f in glob.glob(os.path.join(d, pat)):
                    try:
                        os.remove(f)
                    except Exception:
                        pass


class FragmentMerger:
    """Holds unfinished sentence tails (without terminal punctuation . ? !) across chunks."""
    TERMINAL_PUNCT_RE = re.compile(r"[.?!…؟।]+['\"»”]?\s*$")
    SPLIT_PUNCT_RE = re.compile(r"([.?!…؟।]+['\"»”]?\s+)")

    def __init__(self, max_hold_sec=14.0, max_words=30):
        self.pending_tail = ""
        self.pending_time = 0.0
        self.max_hold_sec = max_hold_sec
        self.max_words = max_words

    def feed(self, text, now=None):
        now = now or time.time()
        text = text.strip()
        if not text:
            return "", self.pending_tail

        combined = (self.pending_tail + " " + text).strip() if self.pending_tail else text

        if self.pending_tail and (now - self.pending_time > self.max_hold_sec or len(combined.split()) > self.max_words):
            self.pending_tail = ""
            self.pending_time = 0.0
            return combined, ""

        if self.TERMINAL_PUNCT_RE.search(combined):
            self.pending_tail = ""
            self.pending_time = 0.0
            return combined, ""

        parts = self.SPLIT_PUNCT_RE.split(combined)
        if len(parts) > 1:
            head = "".join(parts[:-1]).strip()
            tail = parts[-1].strip()
            self.pending_tail = tail
            self.pending_time = now
            return head, tail
        else:
            self.pending_tail = combined
            self.pending_time = self.pending_time or now
            return "", self.pending_tail

    def flush(self, now=None):
        """Emit pending tail if held longer than max_hold_sec."""
        now = now or time.time()
        if self.pending_tail and (now - self.pending_time >= 5.0):
            tail = self.pending_tail
            self.pending_tail = ""
            self.pending_time = 0.0
            return tail
        return ""


def wrap_text(text, max_chars=MAX_LINE_CHARS, max_lines=MAX_LINES):
    """Wrap text to max_chars per line with max_lines and ellipsis if truncated."""
    if not text:
        return ""
    words = text.split()
    lines = []
    curr = ""
    for w in words:
        cand = (curr + " " + w).strip() if curr else w
        if len(cand) > max_chars and curr:
            lines.append(curr)
            curr = w
        else:
            curr = cand
    if curr:
        lines.append(curr)

    if len(lines) > max_lines:
        lines = lines[:max_lines]
        lines[-1] = lines[-1].rstrip(". ") + "…"
    return "\n".join(lines)


_LAST_CPU_STAT = None


def get_system_load():
    """Read true CPU load percentage from /proc/stat delta, and memory info."""
    global _LAST_CPU_STAT
    cpu_percent = 15
    try:
        if os.path.isfile("/proc/stat"):
            with open("/proc/stat", "r") as f:
                line = f.readline()
            if line.startswith("cpu "):
                parts = [float(x) for x in line.split()[1:]]
                idle = parts[3] + (parts[4] if len(parts) > 4 else 0)
                total = sum(parts)
                now_t = time.time()
                if _LAST_CPU_STAT is not None:
                    last_idle, last_total, last_t = _LAST_CPU_STAT
                    d_idle = idle - last_idle
                    d_total = total - last_total
                    if d_total > 0:
                        cpu_percent = int(round((1.0 - (d_idle / d_total)) * 100))
                        cpu_percent = max(0, min(100, cpu_percent))
                _LAST_CPU_STAT = (idle, total, now_t)
        elif hasattr(os, "getloadavg"):
            avg = os.getloadavg()[0]
            cpus = os.cpu_count() or 1
            cpu_percent = int(min(100, max(0, (avg / cpus) * 100)))
    except Exception:
        cpu_percent = 15

    mem_percent = 0
    try:
        if os.path.isfile("/proc/meminfo"):
            mem_total = 0
            mem_avail = 0
            with open("/proc/meminfo", "r") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        mem_total = int(line.split()[1])
                    elif line.startswith("MemAvailable:"):
                        mem_avail = int(line.split()[1])
            if mem_total > 0:
                mem_percent = int(((mem_total - mem_avail) / mem_total) * 100)
    except Exception:
        mem_percent = 40

    return cpu_percent, mem_percent


class Controller:
    """Core controller singleton coordinating taps, translator threads, and OSD display."""

    def __init__(self, session=None):
        self.session = session
        print(f"[EnigmaTranslate] version {VERSION} loaded")
        self.running = False
        self.current_service_ref = ""
        self.current_service_name = ""
        self.channel_profiles = {}
        self.runtime_no_ts_playback_channels = set()
        self.plugin_started_timeshift = False
        restore_leftover_timeshift_bypass()
        clean_temp_disk_files()
        self.load_profiles()

        # Engine chain, cache, glossary
        self.cache = TranslationCache(
            maxsize=getattr(settings.config.plugins.enigmatranslate.cache_size, "value", 2000),
            filepath=settings.CACHE_FILE
        )
        self.glossary = Glossary(filepath=settings.GLOSSARY_FILE)
        self.ai_engine = AIEngine(
            provider=getattr(settings.config.plugins.enigmatranslate.ai_provider, "value", "gemini"),
            tier=getattr(settings.config.plugins.enigmatranslate.ai_model_tier, "value", "balanced"),
            models_dict=settings.get_ai_models(),
            cap=getattr(settings.config.plugins.enigmatranslate.ai_cap, "value", 1000),
            context_len=getattr(settings.config.plugins.enigmatranslate.ai_context, "value", 2),
            style=getattr(settings.config.plugins.enigmatranslate.ai_style, "value", "natural"),
            usage_file=settings.AI_USAGE_FILE
        )
        self.chain = EngineChain(cache=self.cache, glossary=self.glossary, ai_engine=self.ai_engine)

        # Worker threads & queues
        self.raw_q = queue.Queue(maxsize=100)
        self.gui_q = queue.Queue(maxsize=100)
        self.pending_subs = []
        self.tap_manager = None
        self.translator_thread = None
        self.translator_stop_event = threading.Event()
        self.is_channel_paused = False
        self.last_measured_real_delay = None

        # Context lines for AI
        self.context_lines = []
        self.fragment_merger = FragmentMerger()
        self.channel_delays = {}

        # Stats
        self.total_translated = 0
        self.latency_history = []
        self.last_stt_latency_ms = 0
        self.last_status_message = ""
        self.detected_lang = ""
        self.srt_bg_translator = None

        try:
            today = datetime.now().strftime("%Y-%m-%d")
            usage_f = getattr(settings, "AI_USAGE_FILE", "/etc/enigma2/enigmatranslate/ai_usage.json")
            if os.path.isfile(usage_f):
                with open(usage_f, "r", encoding="utf-8") as f:
                    ud = json.load(f)
                    if ud.get("date") == today:
                        self.total_translated = int(ud.get("count", 0))
                    last_lat = int(ud.get("last_stt_latency_ms", 0) or ud.get("last_latency_ms", 0))
                    if last_lat > 0:
                        self.last_stt_latency_ms = last_lat
                        self.latency_history = [last_lat]
        except Exception:
            pass

        # Safe mode
        self.safe_mode_active = False
        self.native_sub_active = False
        self.plugin_enabled_track = None
        self.waiting_for_tune = False
        self.channel_has_text_subs = False

        # GUI timer
        self.gui_timer = None
        self.osd = None
        self.toast = None

        # Settle timer for channel zap
        self.settle_timer = None
        self.descramble_timer = None
        self.descramble_poll_count = 0
        self.is_encrypted = False
        self.bridge_timer = None
        self.bridge_adj_timer = None

        # Time-Bridge latency measurement & dynamic adjustments
        self.recent_latencies = collections.deque(maxlen=20)
        self.current_bridge_sec = 14.0
        self.target_bridge_sec = 14.0
        self.last_bridge_recompute = time.time()
        self.bg_record_entry = None
        self.bg_record_service = None
        self.bg_record_file = None
        self.dock_open = False
        self.stats_dropped_segments = 0
        self.stats_displayed_segments = 0
        self.stats_sync_errors = []
        self.ch_sel_was_open = False
        self.last_audio_segment_time = time.time()
        self.session_disabled = False

        # Rolling buffer & disk safety monitor timer
        self.disk_monitor_timer = None
        try:
            from enigma import eTimer
            self.disk_monitor_timer = eTimer()
            self.disk_monitor_timer.callback.append(self._on_disk_monitor_tick)
            self.disk_monitor_timer.start(10000, False)
        except Exception:
            pass
        self.channel_bridges_file = settings.CHANNEL_BRIDGES_FILE
        self.channel_bridges = self._load_channel_bridges()

        self._setup_gui_timer()
        self._hook_service_events()
        self._install_info_key_hook()
        self._install_quick_button_hook()

        # Content type
        self.current_content_type = "general"
        self.active_whisper_prompt = ""
        self.audio_fallback_reason = ""

        # Start local Web Setup server daemon
        try:
            from .web import start_web_server
            self.web_server = start_web_server(self)
        except Exception as e:
            print(f"[EnigmaTranslate] Web setup server start error: {e}")

        # SubRip (.srt) subtitle synchronization
        self.srt_synchronizer = None
        self.srt_active_movie = None
        self.srt_searching = False
        self.srt_candidates = []
        self._last_srt_text = None
        self._last_srt_toast_time = 0.0
        self._srt_mode_announced = False
        self.srt_last_query = ""
        self.srt_last_result = "لا يوجد بحث بعد"
        self.srt_movie_info = None

        # IPTV Relay internal switch tracking and retry limits
        self.ignore_nav_events_until = 0.0
        self.failed_relay_channels = set()
        self.relay_attempted_channels = set()


    @classmethod
    def instance(cls, session=None):
        global _CONTROLLER_INSTANCE
        if _CONTROLLER_INSTANCE is None:
            _CONTROLLER_INSTANCE = cls(session)
        elif session and _CONTROLLER_INSTANCE.session is None:
            _CONTROLLER_INSTANCE.session = session
            _CONTROLLER_INSTANCE._setup_gui_timer()
            _CONTROLLER_INSTANCE._hook_service_events()
            _CONTROLLER_INSTANCE._install_info_key_hook()
        return _CONTROLLER_INSTANCE

    @classmethod
    def get_instance(cls):
        global _CONTROLLER_INSTANCE
        return _CONTROLLER_INSTANCE

    def _setup_gui_timer(self):
        try:
            from enigma import eTimer
            self.gui_timer = eTimer()
            self.gui_timer.callback.append(self._on_gui_tick)
            self.gui_timer.start(100, False)
        except Exception:
            pass

    def _hook_service_events(self):
        if not self.session:
            return
        try:
            from enigma import iPlayableService
            self.session.nav.event.append(self._on_nav_event)
        except Exception:
            pass

    def _is_frontend_locked(self):
        try:
            if is_iptv_service(self.current_service_ref):
                return True
            if not self.session or not self.session.nav:
                return True
            service = self.session.nav.getCurrentService()
            if not service:
                return False
            fe = service.frontendInfo() if hasattr(service, "frontendInfo") else None
            if fe and hasattr(fe, "getFrontendStatus"):
                st = fe.getFrontendStatus()
                if st is not None:
                    return bool(st & 0x10) # 0x10 is FE_HAS_LOCK
        except Exception:
            pass
        return True

    def _on_nav_event(self, event):
        try:
            now = time.time()
            if now < getattr(self, "ignore_nav_events_until", 0.0):
                print(f"[EnigmaTranslate] [NAV] Internal switch active ({getattr(self, 'ignore_nav_events_until', 0.0) - now:.1f}s remaining) -> ignoring event {event}")
                return
            from enigma import iPlayableService
            if event == iPlayableService.evStart:
                self._on_service_started()
            elif event == iPlayableService.evEnd:
                self._on_service_stopped()
            elif hasattr(iPlayableService, "evTunedIn") and event == iPlayableService.evTunedIn:
                self._on_tuned_in()
            elif hasattr(iPlayableService, "evTuneFailed") and event == iPlayableService.evTuneFailed:
                self._on_tune_failed()
            elif hasattr(iPlayableService, "evUpdatedInfo") and event == iPlayableService.evUpdatedInfo:
                self._on_updated_info()
        except Exception as e:
            self._handle_callback_error(e, "_on_nav_event")

    def _is_channel_auto_start(self, sref=None):
        """Check if translation should auto-start on zap for this channel.
        Rules:
        - Default: False (nothing starts on zap, only SUBTITLE starts it).
        - The IPTV relay must NEVER start by itself.
        - Per-channel auto-start only if explicitly enabled in channel profile.
        """
        ref_str = sref or self.current_service_ref or ""
        if not ref_str:
            return False
        if is_iptv_service(ref_str):
            # The IPTV relay must NEVER start by itself.
            return False
        self.load_profiles()
        prof = self.channel_profiles.get(ref_str, {})
        return bool(prof.get("auto_start", False))

    def _on_updated_info(self):
        if not getattr(self, "is_encrypted", False):
            service = self.session.nav.getCurrentService() if self.session and self.session.nav else None
            if is_service_encrypted(service=service, service_ref=self.current_service_ref):
                print(f"[EnigmaTranslate] [PMT] Channel '{self.current_service_name}' identified as ENCRYPTED via PMT!")
                self.is_encrypted = True
                if hasattr(self, "settle_timer") and self.settle_timer:
                    try:
                        self.settle_timer.stop()
                    except Exception:
                        pass
                if self._is_channel_auto_start(self.current_service_ref):
                    self.descramble_poll_count = 0
                    self._poll_descrambled()

    def _on_tuned_in(self):
        print(f"[EnigmaTranslate] [TUNE] evTunedIn received for '{self.current_service_name}'")
        service = self.session.nav.getCurrentService() if self.session and self.session.nav else None
        if not getattr(self, "is_encrypted", False):
            self.is_encrypted = is_service_encrypted(service=service, service_ref=self.current_service_ref)
        if not self._is_channel_auto_start(self.current_service_ref):
            return
        if getattr(self, "waiting_for_tune", False):
            self.waiting_for_tune = False
            if not self.is_encrypted:
                self._start_settle_timer(delay_ms=3000)
            else:
                self.descramble_poll_count = 0
                self._poll_descrambled()
        elif self.is_encrypted and not getattr(self, "running", False):
            if hasattr(self, "settle_timer") and self.settle_timer:
                try:
                    self.settle_timer.stop()
                except Exception:
                    pass
            self.descramble_poll_count = 0
            self._poll_descrambled()

    def _on_tune_failed(self):
        print(f"[EnigmaTranslate] [TUNE] evTuneFailed for '{self.current_service_name}'")
        self.waiting_for_tune = True
        self.show_status("بانتظار الإشارة", duration=3.0)

    def _is_descrambled(self):
        """Check if softcam has descrambled the current channel (valid CW / ecm time)."""
        if not getattr(self, "is_encrypted", False):
            return True
        for ecm_file in ("/tmp/ecm.info", "/tmp/ecm0.info"):
            if os.path.isfile(ecm_file) and os.path.getsize(ecm_file) > 0:
                try:
                    with open(ecm_file, "r") as f:
                        cnt = f.read().lower()
                        if ("cw0:" in cnt or "cw:" in cnt or "ecm time:" in cnt) and "timeout" not in cnt:
                            return True
                except Exception:
                    pass
        return False

    def _poll_descrambled(self):
        """Wait until picture is playing (descrambled), then start 3s settle timer."""
        if not self._is_channel_auto_start(self.current_service_ref) and not getattr(self, "running", False):
            return
        try:
            from enigma import eTimer
            if self._is_descrambled():
                print(f"[EnigmaTranslate] [ZAP] Channel '{self.current_service_name}' is descrambled! Starting 3s settle timer.")
                self._start_settle_timer(delay_ms=3000)
                return

            self.descramble_poll_count = getattr(self, "descramble_poll_count", 0) + 1
            if self.descramble_poll_count >= 20: # 10s timeout
                print(f"[EnigmaTranslate] [ZAP] Channel '{self.current_service_name}' not descrambled within 10s.")
                self.show_status("قناة مشفرة: بانتظار فك التشفير", duration=4.0)
                return

            if not hasattr(self, "descramble_timer") or not self.descramble_timer:
                self.descramble_timer = eTimer()
                self.descramble_timer.callback.append(self._poll_descrambled)
            self.descramble_timer.start(500, True)
        except Exception as e:
            print(f"[EnigmaTranslate] [ZAP] _poll_descrambled error: {e}")
            if self._is_channel_auto_start(self.current_service_ref):
                self._start_settle_timer(delay_ms=3000)

    def _start_settle_timer(self, delay_ms=3000):
        try:
            from enigma import eTimer
            if not self.settle_timer:
                self.settle_timer = eTimer()
                self.settle_timer.callback.append(self._delayed_start)
            print(f"[EnigmaTranslate] [ZAP] Settle timer {delay_ms/1000.0:.1f}s started")
            self.settle_timer.start(delay_ms, True)
        except Exception:
            self._delayed_start()

    def _on_service_started(self):
        now = time.time()
        if now < getattr(self, "ignore_nav_events_until", 0.0):
            print(f"[EnigmaTranslate] [RELAY] Internal switch active -> ignoring service start")
            return

        service = self.session.nav.getCurrentService() if self.session else None
        ref = self.session.nav.getCurrentlyPlayingServiceReference() if self.session else None
        ref_str = ref.toString() if ref else ""
        if "127.0.0.1" in ref_str:
            print(f"[EnigmaTranslate] [RELAY] Player started local relay: {ref_str}")
            return

        name = ""
        try:
            if service:
                info = service.info()
                name = info.getName() if info else ""
        except Exception:
            pass

        self.current_service_ref = ref_str
        self.current_service_name = name
        self.service_start_time = time.time()
        self._srt_mode_announced = False
        self.ignored_epg_event = None
        self.recent_english_dialogue = []
        print(f"[EnigmaTranslate] [ZAP] Service started: '{name}' ({ref_str})")

        # Stop previous controller & release tuner stream immediately
        self.stop()
        self._kill_leftover_ffmpeg()
        clean_temp_disk_files()
        if hasattr(self, "descramble_timer") and self.descramble_timer:
            try:
                self.descramble_timer.stop()
            except Exception:
                pass
        if hasattr(self, "settle_timer") and self.settle_timer:
            try:
                self.settle_timer.stop()
            except Exception:
                pass

        # If frontend is not locked (rotor moving / "try it again when we are tuned in"), wait for evTunedIn
        if not self._is_frontend_locked():
            print(f"[EnigmaTranslate] [ZAP] Frontend not locked (rotor moving / tuning) -> Waiting for evTunedIn")
            self.waiting_for_tune = True
            self.show_status("بانتظار الإشارة", duration=5.0)
            return

        self.waiting_for_tune = False
        self.is_encrypted = is_service_encrypted(service=service, service_ref=ref_str)
        print(f"[EnigmaTranslate] [ZAP] Channel '{name}' is_encrypted={self.is_encrypted}")

        # Exception kept: native DVB subtitles in target language may auto-enable (channel's own subtitles, no relay, no STT)
        is_iptv = is_iptv_service(ref_str)
        if not is_iptv and not self.get_effective_setting("ignore_native_subs"):
            if self.check_native_subtitles():
                print(f"[EnigmaTranslate] [ZAP] Native DVB subtitle auto-enabled for '{name}'. Plugin stays idle.")
                return

        # Per-channel auto-start check (Default: OFF. IPTV relay: NEVER starts by itself)
        if self._is_channel_auto_start(ref_str):
            print(f"[EnigmaTranslate] [ZAP] Auto-start is explicitly ON for '{name}'. Starting translation...")
            if not self.is_encrypted:
                # FTA channel: start capture 3s after picture is playing
                self._start_settle_timer(delay_ms=3000)
            else:
                # Encrypted channel: start capture only once descrambled + 3s
                self.descramble_poll_count = 0
                self._poll_descrambled()
        else:
            print(f"[EnigmaTranslate] [ZAP] Channel '{name}' auto-start is OFF (default). Waiting for SUBTITLE.")

    def _on_service_stopped(self):
        now = time.time()
        if now < getattr(self, "ignore_nav_events_until", 0.0) or getattr(self, "switching_to_relay", False):
            print("[EnigmaTranslate] [RELAY] Internal switch active -> ignoring stop event.")
            return
        ref = self.session.nav.getCurrentlyPlayingServiceReference() if self.session else None
        ref_str = ref.toString() if ref else ""
        if "127.0.0.1" in ref_str and getattr(self, "original_iptv_service_ref", None):
            return
        print(f"[EnigmaTranslate] [ZAP] Service stopped: '{self.current_service_name}'")
        if getattr(self, "plugin_started_timeshift", False):
            self._stop_plugin_timeshift_no_dialog()
        self.stop()
        self._kill_leftover_ffmpeg()
        if hasattr(self, "descramble_timer") and self.descramble_timer:
            try:
                self.descramble_timer.stop()
            except Exception:
                pass

    def _start_relay_failsafe_watchdog(self, relay_mgr, orig_ref):
        """Monitors relay startup: aborts if no upstream data in 6s or no video in 8s."""
        self._relay_failsafe_start = time.time()
        self._relay_orig_ref = orig_ref
        self._last_play_pos = -1

        try:
            from enigma import eTimer
            if not hasattr(self, "_relay_failsafe_timer") or not self._relay_failsafe_timer:
                self._relay_failsafe_timer = eTimer()
                self._relay_failsafe_timer.callback.append(self._check_relay_failsafe)
            self._relay_failsafe_timer.start(1000, False)
        except Exception as e:
            print(f"[EnigmaTranslate] [RELAY] Watchdog timer start error: {e}")

    def _check_relay_failsafe(self):
        try:
            if not getattr(self, "relay_active", False) and not self.running:
                if hasattr(self, "_relay_failsafe_timer") and self._relay_failsafe_timer:
                    self._relay_failsafe_timer.stop()
                return

            if getattr(self, "iptv_buffer_sref", None) is not None:
                # Still counting down in Time-Bridge buffering; watchdog does not count
                return

            from .iptv_relay import IPTVRelayManager
            relay_mgr = IPTVRelayManager.get_instance()
            elapsed = time.time() - getattr(self, "_relay_failsafe_start", time.time())

            # Check 1: No upstream data within 6 seconds
            if elapsed >= 6.0:
                if relay_mgr.bytes_received == 0 or relay_mgr.last_error:
                    print(f"[EnigmaTranslate] [RELAY FAILSAFE] No upstream data after {elapsed:.1f}s -> aborting")
                    self.stop_iptv_relay(restore_playback=True, reason="no upstream data within 6s")
                    self.show_status("وسيط IPTV: تعذر جلب البث، تم استرجاع القناة", duration=4.0, force=True)
                    return

            # Check 2: Check video playback after playService on relay URL
            video_ok = self._is_video_playing()
            if video_ok:
                print(f"[EnigmaTranslate] [RELAY FAILSAFE] Video playback confirmed after {elapsed:.1f}s. Disarming watchdog.")
                if hasattr(self, "_relay_failsafe_timer") and self._relay_failsafe_timer:
                    self._relay_failsafe_timer.stop()
                self._start_playback_watchdog()
                return

            if elapsed >= 8.0:
                print(f"[EnigmaTranslate] [RELAY FAILSAFE] No video playing after {elapsed:.1f}s -> aborting")
                self.stop_iptv_relay(restore_playback=True, reason="no video decoded within 8s")
                self.show_status("وسيط IPTV: تعذر تشغيل الفيديو، تم استرجاع القناة", duration=4.0, force=True)
                return
        except Exception as e:
            print(f"[EnigmaTranslate] [RELAY FAILSAFE] Watchdog check error: {e}")

    def _is_video_playing(self):
        """Checks if video is active via video size (width/height) or play-position advance."""
        if not self.session or not hasattr(self.session, "nav"):
            return False
        service = self.session.nav.getCurrentService()
        if not service:
            return False

        # 1. Video dimensions check (GStreamer eServiceMP3 caps)
        try:
            from enigma import iServiceInformation
            info = service.info() if hasattr(service, "info") else None
            if info:
                s_width = getattr(iServiceInformation, "sVideoWidth", 16)
                s_height = getattr(iServiceInformation, "sVideoHeight", 15)
                w = info.getInfo(s_width)
                h = info.getInfo(s_height)
                if w > 0 and h > 0:
                    print(f"[EnigmaTranslate] [VIDEO CHECK] Video dimensions active: {w}x{h}")
                    return True
        except Exception:
            pass

        # 2. Play position advance check (eServiceMP3 seek position)
        try:
            seek = service.seek() if hasattr(service, "seek") else None
            if seek and hasattr(seek, "getPlayPosition"):
                res, pos = seek.getPlayPosition()
                if res == 0 and pos > 0:
                    last_pos = getattr(self, "_last_play_pos", -1)
                    self._last_play_pos = pos
                    if last_pos >= 0 and pos > last_pos:
                        print(f"[EnigmaTranslate] [VIDEO CHECK] Play position advanced: {last_pos} -> {pos}")
                        return True
                    elif pos > 0:
                        print(f"[EnigmaTranslate] [VIDEO CHECK] Play position active: {pos}")
                        return True
        except Exception:
            pass

        # 3. Relay buffer client streaming check
        try:
            from .iptv_relay import IPTVRelayManager
            relay_mgr = IPTVRelayManager.get_instance()
            if relay_mgr.is_running and relay_mgr.bytes_sent_to_player > 524288 and len(relay_mgr.subscribers) > 0:
                print(f"[EnigmaTranslate] [VIDEO CHECK] Relay streaming confirmed ({relay_mgr.bytes_sent_to_player} bytes sent to player)")
                return True
        except Exception:
            pass

        return False


    def _start_iptv_restore_verification(self, orig_ref):
        """Verify video playback within 5 seconds after restoring original IPTV URL, else re-zap."""
        try:
            if hasattr(self, "_iptv_restore_timer") and self._iptv_restore_timer:
                try:
                    self._iptv_restore_timer.stop()
                except Exception:
                    pass
            self._iptv_restore_ref = orig_ref
            self._iptv_restore_start = time.time()

            try:
                from enigma import eTimer
                self._iptv_restore_timer = eTimer()
                self._iptv_restore_timer_conn = self._iptv_restore_timer.timeout.connect(self._check_iptv_restore_verification)
                self._iptv_restore_timer.start(1000, False)
            except Exception:
                pass
        except Exception as e:
            print(f"[EnigmaTranslate] [IPTV] Error starting restore verification: {e}")

    def _check_iptv_restore_verification(self):
        try:
            elapsed = time.time() - getattr(self, "_iptv_restore_start", time.time())
            orig_ref = getattr(self, "_iptv_restore_ref", None)
            if not orig_ref:
                if hasattr(self, "_iptv_restore_timer") and self._iptv_restore_timer:
                    self._iptv_restore_timer.stop()
                return

            if self._is_video_playing():
                print(f"[EnigmaTranslate] [IPTV VERIFY] Video playback confirmed after {elapsed:.1f}s.")
                if hasattr(self, "_iptv_restore_timer") and self._iptv_restore_timer:
                    self._iptv_restore_timer.stop()
                self._iptv_restore_ref = None
                return

            if elapsed >= 5.0:
                print(f"[EnigmaTranslate] [IPTV VERIFY] No video decoded after {elapsed:.1f}s -> re-zapping original service: {orig_ref}")
                if hasattr(self, "_iptv_restore_timer") and self._iptv_restore_timer:
                    self._iptv_restore_timer.stop()
                self._iptv_restore_ref = None
                if self.session and hasattr(self.session, "nav"):
                    try:
                        from enigma import eServiceReference
                        sref_obj = eServiceReference(orig_ref)
                    except Exception:
                        sref_obj = orig_ref
                    try:
                        self.ignore_nav_events_until = time.time() + 5.0
                        self.session.nav.playService(sref_obj)
                    except Exception as e_rezap:
                        print(f"[EnigmaTranslate] [IPTV VERIFY] Re-zap error: {e_rezap}")
        except Exception as e:
            print(f"[EnigmaTranslate] [IPTV VERIFY] Check error: {e}")

    def get_current_player_audio_track(self):
        """Get the audio track currently playing in the player, falling back to 0."""
        # Method 1: Enigma2 C++ audioTracks()
        if self.session and hasattr(self.session, "nav"):
            try:
                service = self.session.nav.getCurrentService()
                audio = service and service.audioTracks()
                if audio:
                    cur = audio.getCurrentTrack()
                    if cur is not None and cur >= 0:
                        return cur
            except Exception:
                pass

        # Method 2: Web API /web/getaudiotracks
        try:
            import urllib.request
            import xml.etree.ElementTree as ET
            req = urllib.request.Request("http://127.0.0.1/web/getaudiotracks", headers={"User-Agent": "EnigmaTranslate/1.0"})
            with urllib.request.urlopen(req, timeout=1.0) as resp:
                root = ET.fromstring(resp.read())
                for tr in root.findall(".//e2audiotrack"):
                    act = (tr.findtext("e2audiotrackactive") or "").lower() == "true"
                    if act:
                        tid = tr.findtext("e2audiotrackid")
                        if tid is not None and tid.isdigit():
                            return int(tid)
        except Exception:
            pass

        return 0

    def toggle_iptv_relay(self):
        """Toggle IPTV relay mode (Phase 2: relay + translation)."""
        if getattr(self, "relay_active", False):
            print("[EnigmaTranslate] [RELAY] SUBTITLE pressed while relay active -> stopping relay and replaying original channel.")
            self.stop_iptv_relay(restore_playback=True, reason="subtitle_toggle")
            self.show_status("وسيط IPTV: متوقف", duration=3.0, force=True)
            return False
        else:
            print("[EnigmaTranslate] [RELAY] SUBTITLE pressed on IPTV channel -> starting single-connection relay with audio translation (Phase 2).")
            self.start_iptv_relay()
            return True

    def start_iptv_relay(self):
        """Phase 2: Start local IPTV single-connection relay and feed audio to translation pipeline."""
        if getattr(self, "relay_active", False):
            print("[EnigmaTranslate] [RELAY] Relay already active on current channel.")
            return

        ref_str = str(self.current_service_ref or "")
        if not ref_str:
            ref = self.session.nav.getCurrentlyPlayingServiceReference() if self.session else None
            ref_str = ref.toString() if ref else ""
            self.current_service_ref = ref_str

        if "127.0.0.1" in ref_str:
            print("[EnigmaTranslate] [RELAY] Current service is already pointing to 127.0.0.1 relay.")
            return

        parts = ref_str.split(":")
        if len(parts) < 11:
            print(f"[EnigmaTranslate] [RELAY] Invalid IPTV service ref: {ref_str}")
            return

        try:
            from .iptv_relay import IPTVRelayManager, wait_for_socket_close, parse_enigma2_stream_url

            raw_field10 = parts[10]
            clean_upstream, headers = parse_enigma2_stream_url(raw_field10)
            parsed_u = urllib.parse.urlparse(clean_upstream)
            provider_host = parsed_u.hostname or ""
            provider_port = parsed_u.port or (443 if parsed_u.scheme == "https" else 80)

            # Check IPTV Time-Bridge setting (Requirement 5, default ON)
            self.load_profiles()
            iptv_bridge_on = bool(self.get_effective_setting("iptv_bridge"))

            if iptv_bridge_on:
                saved_bridge = self.channel_bridges.get(self.current_service_ref) if hasattr(self, "channel_bridges") else None
                if saved_bridge is not None and saved_bridge is not False:
                    bridge_sec = max(8.0, min(16.0, float(saved_bridge)))
                    print(f"[EnigmaTranslate] [RELAY BRIDGE] Using saved channel bridge {bridge_sec:.1f}s for '{self.current_service_name}'")
                elif hasattr(self, "recent_latencies") and len(self.recent_latencies) >= 3:
                    p90 = self._calc_percentile_90(self.recent_latencies)
                    bridge_sec = max(8.0, min(16.0, round(p90 + 0.5, 1)))
                    print(f"[EnigmaTranslate] [RELAY BRIDGE] Using p90 latency bridge {bridge_sec:.1f}s for '{self.current_service_name}'")
                else:
                    cfg_sec = self.get_effective_setting("bridge_sec")
                    bridge_sec = max(8.0, min(16.0, float(cfg_sec or 14.0)))
                    print(f"[EnigmaTranslate] [RELAY BRIDGE] Using default bridge {bridge_sec:.1f}s for '{self.current_service_name}'")

                if self.current_service_ref and hasattr(self, "channel_bridges"):
                    self.channel_bridges[self.current_service_ref] = bridge_sec
                    self._save_channel_bridges()
                target_delay = bridge_sec
            else:
                target_delay = 0.0

            print(f"[EnigmaTranslate] [RELAY] Starting Phase 3 relay for '{self.current_service_name}' ({parts[0]}), target_delay={target_delay:.1f}s")
            print(f"[EnigmaTranslate] [RELAY] Clean upstream URL: {clean_upstream}")
            print(f"[EnigmaTranslate] [RELAY] Headers: {headers}")

            # 1. Stop current service FIRST so provider connection is released
            self.switching_to_relay = True
            self.original_iptv_service_ref = ref_str
            self.ignore_nav_events_until = time.time() + 6.0

            self.show_status("وسيط IPTV: جاري التحويل…", duration=3.0, force=True)

            if self.session and hasattr(self.session, "nav"):
                try:
                    print(f"[EnigmaTranslate] [RELAY] Stopping original playback for '{self.current_service_name}' to release provider connection")
                    self.session.nav.stopService()
                except Exception as e_stop:
                    print(f"[EnigmaTranslate] [RELAY] stopService warning: {e_stop}")

            # 2. Wait for socket to provider to close
            if provider_host:
                wait_for_socket_close(provider_host, port=provider_port, timeout=1.5)

            # 3. Open ONE upstream connection via IPTVRelayManager with delay buffer
            relay_mgr = IPTVRelayManager.get_instance()
            relay_mgr.set_drop_callback(self._on_relay_upstream_dropped)

            relay_url = relay_mgr.start_relay(raw_field10, delay_sec=target_delay)

            # 4. Prepare relay service reference
            relay_ref_parts = list(parts)
            relay_ref_parts[10] = relay_url.replace(":", "%3a")
            relay_sref_str = ":".join(relay_ref_parts)

            from enigma import eServiceReference, eTimer
            relay_sref = eServiceReference(relay_sref_str)
            if self.current_service_name:
                relay_sref.setName(self.current_service_name)

            self.relay_active = True
            self.current_relay_ref = relay_sref_str
            self.running = True
            settings.config.plugins.enigmatranslate.enabled.value = True
            self.current_bridge_sec = target_delay
            self.target_bridge_sec = target_delay

            # 5. Requirement 1: Relay feeds FFmpeg/STT immediately
            relay_stream_q = relay_mgr.subscribe_ffmpeg(maxsize_mb=4)
            self.relay_ffmpeg_q = relay_stream_q

            audio_idx = self.get_current_player_audio_track()
            print(f"[EnigmaTranslate] [RELAY PHASE 3] Subscribed FFmpeg immediately (4 MB bounded queue), active audio track {audio_idx}")

            # 6. Requirement 2: Player feed timing
            if target_delay <= 0.0:
                # Phase 2 behavior: play immediately after 64 KB initial data arrives
                data_ok = relay_mgr.wait_for_initial_data(min_bytes=65536, timeout=5.0)
                if not data_ok and (relay_mgr.last_error or relay_mgr.bytes_received == 0):
                    raise RuntimeError(f"Relay upstream connection failed: {relay_mgr.last_error or 'no initial data'}")
                if self.session and hasattr(self.session, "nav"):
                    print(f"[EnigmaTranslate] [RELAY] Playing relay ref of type {parts[0]}: {relay_url}")
                    self.session.nav.playService(relay_sref)
                self._start_relay_failsafe_watchdog(relay_mgr, self.original_iptv_service_ref)
            else:
                # Phase 3 behavior: do NOT hold an open player connection silent.
                # Start playService on relay URL only after N seconds are buffered.
                # Show existing countdown toast meanwhile.
                self.iptv_buffer_target = target_delay
                self.iptv_buffer_sref = relay_sref
                self.iptv_buffer_start = time.time()
                rem_init = int(round(target_delay))
                self.show_status(f"جاري تجهيز الترجمة… {rem_init}", duration=1.5, force=True)

                if hasattr(self, "iptv_bridge_timer") and self.iptv_bridge_timer:
                    try:
                        self.iptv_bridge_timer.stop()
                    except Exception:
                        pass
                self.iptv_bridge_timer = eTimer()
                self.iptv_bridge_timer.callback.append(self._on_iptv_bridge_timer_tick)
                self.iptv_bridge_timer.start(500, False)

            # Clear queues
            while not self.raw_q.empty():
                try:
                    self.raw_q.get_nowait()
                except Exception:
                    break
            while not self.gui_q.empty():
                try:
                    self.gui_q.get_nowait()
                except Exception:
                    break

            self.context_lines.clear()
            self.update_content_type_and_context()

            src_lang = self.get_effective_setting("src_lang") or "auto"
            stt_engine = self.get_effective_setting("stt_engine") or "vosk"
            stt_chunk_sec = self.get_effective_setting("stt_chunk_sec") or getattr(
                settings.config.plugins.enigmatranslate.stt_chunk_sec, "value", 10
            )
            whisper_prompt = self.get_effective_setting("whisper_prompt") or getattr(self, "active_whisper_prompt", None)
            vosk_dir = getattr(settings.config.plugins.enigmatranslate.vosk_dir, "value", "/etc/enigma2/enigmatranslate/vosk")
            ffmpeg_bin = getattr(settings.config.plugins.enigmatranslate.ffmpeg, "value", "ffmpeg")

            self.tap_manager = TapManager(
                stream_url="",
                mode="audio",
                src_lang=src_lang,
                audio_track_idx=audio_idx,
                vosk_dir=vosk_dir,
                ffmpeg_bin=ffmpeg_bin,
                status_cb=self._on_tap_status,
                safe_mode_getter=lambda: self.safe_mode_active,
                stt_engine=stt_engine,
                chunk_sec=stt_chunk_sec,
                prompt=whisper_prompt,
                relay_stream_q=relay_stream_q
            )
            self.tap_manager.raw_q = self.raw_q
            self.tap_manager.start()

            self.translator_stop_event.clear()
            self.translator_thread = threading.Thread(target=self._translator_worker, daemon=True, name="ET_Translator")
            self.translator_thread.start()

            self._ensure_osd()
            self.show_status("وسيط IPTV + ترجمة: تشغيل", duration=3.0, force=True)
            if target_delay <= 0.0:
                self._start_playback_watchdog()

        except Exception as e:
            print(f"[EnigmaTranslate] [RELAY CRASH SHIELD] Error starting relay: {e}")
            self.stop_iptv_relay(restore_playback=True, reason=f"crash shield: {e}")
            self.show_status("وسيط IPTV: تعذر الاتصال، تم استرجاع البث", duration=4.0, force=True)
        finally:
            self.switching_to_relay = False

    def _on_iptv_bridge_timer_tick(self):
        """Countdown timer for IPTV Time-Bridge buffering (Requirement 2)."""
        if not getattr(self, "relay_active", False) or not self.running:
            if hasattr(self, "iptv_bridge_timer") and self.iptv_bridge_timer:
                try:
                    self.iptv_bridge_timer.stop()
                except Exception:
                    pass
                self.iptv_bridge_timer = None
            return

        from .iptv_relay import IPTVRelayManager
        relay_mgr = IPTVRelayManager.get_instance()
        if not relay_mgr.is_upstream_alive():
            print(f"[EnigmaTranslate] [RELAY BRIDGE] Upstream disconnected while buffering: {relay_mgr.last_error}")
            if hasattr(self, "iptv_bridge_timer") and self.iptv_bridge_timer:
                try:
                    self.iptv_bridge_timer.stop()
                except Exception:
                    pass
                self.iptv_bridge_timer = None
            self.show_status("تعذّر الاتصال بمزود IPTV", duration=3.0, force=True)
            return

        buffered = relay_mgr.get_buffered_duration()
        target = getattr(self, "iptv_buffer_target", 14.0)
        rem = max(0, int(round(target - buffered)))

        elapsed_since_start = time.time() - getattr(self, "iptv_buffer_start", time.time())
        # Buffer reached target, or failsafe timeout (target + 3.0s)
        if rem <= 0 or buffered >= target or elapsed_since_start >= (target + 3.0):
            print(f"[EnigmaTranslate] [RELAY BRIDGE] Buffered {buffered:.1f}s / {target:.1f}s in {elapsed_since_start:.1f}s -> Starting player on relay!")
            if hasattr(self, "iptv_bridge_timer") and self.iptv_bridge_timer:
                try:
                    self.iptv_bridge_timer.stop()
                except Exception:
                    pass
                self.iptv_bridge_timer = None

            sref = getattr(self, "iptv_buffer_sref", None)
            self.iptv_buffer_sref = None
            if self.session and hasattr(self.session, "nav") and sref:
                self.session.nav.playService(sref)
            self._start_relay_failsafe_watchdog(relay_mgr, self.original_iptv_service_ref)

        else:
            self.show_status(f"جاري تجهيز الترجمة… {rem}", duration=1.5, force=True)

    def stop_iptv_relay(self, restore_playback=True, reason="user"):
        """Stop local IPTV relay and restore original playback via fast complete stop."""
        print(f"[EnigmaTranslate] [RELAY] stop_iptv_relay called (restore={restore_playback}, reason={reason})")
        self.stop(is_shutdown=(not restore_playback))

    def _on_relay_upstream_dropped(self, reason):
        """Called from relay background thread when all 3 retries fail."""
        print(f"[EnigmaTranslate] [RELAY] Upstream dropped permanently: {reason}")
        if hasattr(self, "gui_q"):
            self.gui_q.put(("relay_dropped", str(reason)))

    def _abort_relay_and_restore(self, reason="fail-safe"):
        print(f"[EnigmaTranslate] [RELAY] Aborting relay and restoring original stream. Reason: {reason}")
        orig_ref = getattr(self, "original_iptv_service_ref", None) or getattr(self, "_relay_orig_ref", None)
        if orig_ref:
            self.failed_relay_channels.add(orig_ref)
        self.stop_iptv_relay(restore_playback=True, reason=reason)
        self.show_status("وسيط IPTV: تعذر تشغيل البث، تم استرجاع القناة", duration=4.0, force=True)

    def _delayed_start(self):
        try:
            if getattr(self, "session_disabled", False):
                return
            if not self._is_frontend_locked():
                print(f"[EnigmaTranslate] [ZAP] Frontend still not locked -> Waiting for lock")
                self.waiting_for_tune = True
                self.show_status("بانتظار الإشارة", duration=3.0)
                return

            if self._is_channel_auto_start(self.current_service_ref):
                print(f"[EnigmaTranslate] [ZAP] Settle timer expired -> auto-starting Controller for '{self.current_service_name}'")
                self.start()
            else:
                print(f"[EnigmaTranslate] [ZAP] Settle timer expired but auto-start is OFF -> remaining idle.")
        except Exception as e:
            self._handle_callback_error(e, "_delayed_start")

    def load_profiles(self):
        if os.path.isfile(settings.PROFILES_FILE):
            try:
                with open(settings.PROFILES_FILE, "r", encoding="utf-8") as f:
                    self.channel_profiles = json.load(f)
            except Exception:
                if not hasattr(self, "channel_profiles") or self.channel_profiles is None:
                    self.channel_profiles = {}


    def save_profiles(self):
        """Write self.channel_profiles to profiles.json."""
        try:
            os.makedirs(settings.DATA_DIR, exist_ok=True)
            with open(settings.PROFILES_FILE, "w", encoding="utf-8") as f:
                json.dump(self.channel_profiles, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"[EnigmaTranslate] save_profiles error: {e}")
            return False

    def save_channel_profile_keys(self, keys):
        """Save only explicitly specified keys for current channel profile.
        Never stores auto-written keys like bridge or no_timeshift_playback.
        """
        if not self.current_service_ref:
            return False
        sref = self.current_service_ref
        prof = self.channel_profiles.setdefault(sref, {})
        prof["name"] = self.current_service_name or prof.get("name", "")
        cfg = getattr(settings.config.plugins, "enigmatranslate", None)
        if cfg:
            for k in keys:
                elem = getattr(cfg, k, None)
                if elem is not None:
                    prof[k] = getattr(elem, "value", elem)
        return self.save_profiles()

    def save_current_as_profile(self):
        """Save explicitly customized profile keys for current channel."""
        if not self.current_service_ref:
            return False
        return self.save_profiles()

    def _load_channel_bridges(self):
        if getattr(self, "channel_bridges_file", None) and os.path.isfile(self.channel_bridges_file):
            try:
                with open(self.channel_bridges_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _save_channel_bridges(self):
        try:
            if not getattr(self, "channel_bridges_file", None):
                return False
            os.makedirs(settings.DATA_DIR, exist_ok=True)
            with open(self.channel_bridges_file, "w", encoding="utf-8") as f:
                json.dump(self.channel_bridges, f, ensure_ascii=False, indent=2)
            return True
        except Exception:
            return False

    def _is_israeli_channel(self):
        cname = (self.current_service_name or "").lower()
        if not cname and self.session and hasattr(self.session, "nav"):
            try:
                srv = self.session.nav.getCurrentService()
                info = srv and srv.info()
                cname = (info.getName() or "").lower() if info else ""
            except Exception:
                pass
        # Check Hebrew characters in channel name
        if any('\u0590' <= ch <= '\u05ff' for ch in cname):
            return True
        # Check channel keywords
        if any(k in cname for k in ['5sport', 'sport 5', '5plus', '5live', '5gold', '5stars', 'one sport israel', 'israel', 'ch-5', 'ch5']):
            return True
        # Check src_lang profile
        prof = self.channel_profiles.get(self.current_service_ref, {})
        if prof.get("src_lang") in ("he", "heb"):
            return True
        return False

    def detect_content_type(self):
        """Auto-detect content type from manual setting, EPG DVB content nibble/sub-nibble, keywords in title/desc & channel name."""
        cfg_val = self.get_effective_setting("content_type") or "auto"
        if cfg_val and cfg_val != "auto":
            return cfg_val

        ch_name = (self.current_service_name or "").lower()
        ev_title = ""
        ev_desc = ""
        l1, l2 = None, None

        if self.session and hasattr(self.session, "nav"):
            try:
                srv = self.session.nav.getCurrentService()
                info = srv and srv.info()
                if not ch_name and info:
                    ch_name = (info.getName() or "").lower()
                event = info and info.getEvent(0)
                if event:
                    ev_title = (event.getEventName() or "").lower()
                    ev_desc = (event.getShortDescription() or "").lower()
                    genre_data = getattr(event, "getGenreData", lambda: None)()
                    if genre_data:
                        l1 = getattr(genre_data, "getLevel1", lambda: None)()
                        l2 = getattr(genre_data, "getLevel2", lambda: None)()
                    if l1 is None and hasattr(event, "getGenre"):
                        g = event.getGenre()
                        if g:
                            l1 = (g & 0xF0) >> 4
                            l2 = g & 0x0F
            except Exception:
                pass

        full_text = f"{ch_name} {ev_title} {ev_desc}".lower()

        # 1. Very specific channel name brandings
        nature_ch = ['love nature', 'nat geo', 'national geographic', 'animal planet', 'wild']
        history_ch = ['history', 'viasat history', 'tarikh', 'تاريخ']
        science_ch = ['discovery', 'science', 'viasat explore', 'sci-fi', 'quest']
        kids_ch = ['cartoon network', 'disney', 'nickelodeon', 'boomerang', 'spacetoon', 'براعم', 'اطفال', 'أطفال', 'كرتون', 'junior', 'cbeebies']
        music_ch = ['mtv', 'vh1', 'melody', 'rotana clip', 'موسيقى', 'اغاني', 'أغاني', 'trace urban']
        cooking_ch = ['cooking', 'food network', 'travel channel', 'kitchen', 'fatafeat', 'chef', 'فتافيت']
        religious_ch = ['quran', 'sunnah', 'islam', 'iqraa', 'resalah', 'قرآن', 'سنة', 'رسالة', 'اقرأ']
        news_ch = ['aljazeera', 'al jazeera', 'alarabiya', 'al arabiya', 'sky news', 'euronews', 'france 24', 'alhadath', 'al hadath', 'i24', 'cnbc', 'bloomberg', 'bbc news', 'cnn']
        sport_ch = ['bein sport', 'eurosport', 'polsat sport', 'supersport', 'alkass', 'kora', 'arena sport', '5sport', 'sport 5', '5plus', '5live', '5gold', '5stars']

        if any(k in ch_name for k in nature_ch):
            return "nature"
        if any(k in ch_name for k in history_ch):
            return "history"
        if any(k in ch_name for k in science_ch):
            return "science"
        if any(k in ch_name for k in kids_ch):
            return "kids"
        if any(k in ch_name for k in music_ch):
            return "music"
        if any(k in ch_name for k in cooking_ch):
            return "cooking"
        if any(k in ch_name for k in religious_ch):
            return "religious"
        if any(k in ch_name for k in news_ch):
            return "news"
        if any(k in ch_name for k in sport_ch):
            return "sport"

        # 2. EPG DVB content nibble and sub-nibble
        series_kws = ['season', 'episode', 'ep.', 's0', 's1', 's2', 'حلقة', 'الموسم', 'مسلسل', 'series']
        is_series_text = any(k in (ev_title + " " + ev_desc) for k in series_kws)

        if l1 in (1, 0x1):  # Movie / Drama
            if is_series_text or l2 == 5:
                return "series"
            return "movie"
        elif l1 in (2, 0x2):  # News
            if l2 == 3:
                return "documentary"
            if l2 == 4:
                return "talk"
            return "news"
        elif l1 in (3, 0x3):  # Show / Game show
            return "talk"
        elif l1 in (4, 0x4):  # Sport
            return "sport"
        elif l1 in (5, 0x5):  # Children / Youth
            return "kids"
        elif l1 in (6, 0x6):  # Music
            return "music"
        elif l1 in (7, 0x7):  # Arts / Culture
            if l2 == 3:
                return "religious"
            return "documentary"
        elif l1 in (8, 0x8):  # Social / Political
            return "talk"
        elif l1 in (9, 0x9):  # Education / Science / Factual / Documentary
            if l2 == 1:
                return "nature"
            if l2 in (2, 3):
                return "science"
            if any(k in full_text for k in ['wild', 'nature', 'animal', 'safari', 'ocean', 'species', 'طبيعة', 'حيوان']):
                return "nature"
            if any(k in full_text for k in ['history', 'war', 'empire', 'century', 'ancient', 'تاريخ', 'حضارة']):
                return "history"
            if any(k in full_text for k in ['space', 'tech', 'science', 'physics', 'ai', 'robot', 'علم', 'تقني', 'فضاء']):
                return "science"
            return "documentary"
        elif l1 in (10, 0xA):  # Leisure / Hobbies / Cooking / Travel
            return "cooking"

        # 3. Keywords in title/description and channel name
        if any(w in full_text for w in ['quran', 'sunnah', 'islam', 'prayer', 'sermon', 'قرآن', 'سنة', 'صلاة', 'خطبة', 'تفسير', 'إسلام']):
            return "religious"
        if any(w in full_text for w in ['recipe', 'cook', 'kitchen', 'chef', 'travel', 'cuisine', 'baking', 'طبخ', 'مطبخ', 'وصفة', 'أكلات', 'رحلات']):
            return "cooking"
        if any(w in full_text for w in ['cartoon', 'animation', 'kids', 'anime', 'كرتون', 'رسوم متحركة', 'أطفال']):
            return "kids"
        if any(w in full_text for w in ['concert', 'orchestra', 'symphony', 'album', 'songs', 'أغنية', 'حفل غنائي', 'موسيقى']):
            return "music"
        if any(w in full_text for w in ['wildlife', 'safari', 'animals', 'animal planet', 'ocean', 'species', 'planet earth', 'love nature', 'nat geo', 'طبيعة', 'حيوانات', 'كائنات برية']):
            return "nature"
        if any(w in full_text for w in ['ancient', 'dynasty', 'empire', 'archaeology', 'world war', 'medieval', 'تاريخ', 'حضارة', 'إمبراطورية', 'آثار']):
            return "history"
        if any(w in full_text for w in ['space', 'galaxy', 'physics', 'technology', 'algorithm', 'cosmos', 'quantum', 'علوم', 'فضاء', 'تكنولوجيا', 'تقنية']):
            return "science"
        if any(w in full_text for w in ['interview', 'podcast', 'talk show', 'debate', 'roundtable', 'حوار', 'لقاء', 'مناظرة', 'استوديو']):
            return "talk"
        if any(w in full_text for w in ['match', 'vs', 'league', 'cup', 'football', 'champions', 'tournament', 'referee', 'مباراة', 'دوري', 'كأس', 'بطولة', 'sport']):
            return "sport"
        if any(w in full_text for w in ['news', 'bulletin', 'press conference', 'parliament', 'breaking', 'أخبار', 'عاجل', 'نشرة']):
            return "news"
        if is_series_text or any(w in full_text for w in ['season', 'episode', 'series', 'مسلسل', 'دراما']):
            return "series"
        if any(w in full_text for w in ['movie', 'movies', 'film', 'cinema', 'premiere', 'hbo', 'action', 'فيلم', 'سينما']):
            return "movie"
        if any(w in full_text for w in ['documentary', 'investigation', 'doc', 'وثائقي', 'تحقيق']):
            return "documentary"

        return "general"

    def get_content_type_label(self, ctype=None):
        labels = {
            "auto": "تلقائي",
            "movie": "فيلم",
            "series": "مسلسل",
            "news": "أخبار",
            "sport": "رياضة",
            "documentary": "وثائقي",
            "history": "تاريخي",
            "nature": "طبيعة وحيوانات",
            "science": "علوم وتقنية",
            "kids": "أطفال وكرتون",
            "talk": "حواري",
            "music": "موسيقى",
            "cooking": "طبخ وسفر",
            "religious": "ديني",
            "general": "عام"
        }
        if ctype is None:
            ctype = self.detect_content_type()
        return labels.get(ctype, "عام")


    def update_content_type_and_context(self):
        """Update active glossary pack, AI style, and Whisper prompt from detected content type."""
        ctype = self.detect_content_type()
        self.current_content_type = ctype
        is_israeli = self._is_israeli_channel()
        is_israeli_sport = (ctype == "sport" and is_israeli)
        if hasattr(self, "glossary") and self.glossary:
            if hasattr(self.glossary, "apply_content_pack"):
                self.glossary.apply_content_pack(ctype, is_israeli=is_israeli_sport)
        if hasattr(self, "ai_engine") and self.ai_engine:
            self.ai_engine.content_type = ctype

        whisper_hints = {
            "sport": "מכבי חיפה, מכבי תל אביב, הפועל, בית\"ר, ליגת העל, כדורגל, שער, פנדל, צהוב, אדום, שופט, נבדל, VAR." if is_israeli_sport else "Match commentary, football, sports, players, tactics, stadium, referee, goal, league, championship, penalty, yellow card, red card.",
            "movie": "Natural cinematic dialogue, colloquial expressions, cinema movie subtitles, conversational speech.",
            "series": "Television drama series, episodic dialogue, casual conversation, recurring characters, emotional dialogue.",
            "news": "News broadcast, world politics, international affairs, economics, official statements, interviews, headlines.",
            "documentary": "Documentary narration, voiceover commentary, factual explanations, scientific and historical descriptions.",
            "history": "Historical documentary, historical events, ancient civilizations, empires, wars, historical figures, dates and places.",
            "nature": "Wildlife and nature documentary, animal behavior, natural habitats, ecology, species names, environmental narration.",
            "science": "Science and technology documentary, modern engineering, space exploration, physics, computing, innovations.",
            "kids": "Children cartoon, animated characters, playful tone, simple friendly dialogue, youth entertainment.",
            "talk": "Talk show, open discussion, panel debate, interviews, conversational banter, questions and answers.",
            "music": "Music show, musical performances, song titles, artist names, concert commentary, lyrics.",
            "cooking": "Cooking recipes, culinary travel, ingredients, preparation steps, food tasting, travel destinations.",
            "religious": "Religious sermons, spiritual reflections, theological terms, prayers, peaceful and respectful tone.",
            "general": "Natural dialogue, clear television subtitles, everyday conversational speech."
        }
        base_hint = whisper_hints.get(ctype, whisper_hints["general"])
        cfg = getattr(settings.config.plugins, "enigmatranslate", None)
        custom_hint = getattr(cfg.whisper_prompt, "value", "") if cfg and hasattr(cfg, "whisper_prompt") else ""
        self.active_whisper_prompt = f"{custom_hint}, {base_hint}".strip(", ") if custom_hint else base_hint

        # If movie or series, check for .srt subtitle sync
        if ctype in ("movie", "series"):
            self._check_movie_srt()

        return ctype

    def _extract_series_info(self, text):
        """Extract season and episode numbers from title/description."""
        if not text:
            return None, None, text
        m = re.search(r'[Ss](\d+)\s*[Ee](\d+)', text)
        if m:
            clean_t = re.sub(r'[Ss](\d+)\s*[Ee](\d+).*', '', text).strip(' -:_')
            return int(m.group(1)), int(m.group(2)), clean_t
        m = re.search(r'(\d+)[xX](\d+)', text)
        if m:
            clean_t = re.sub(r'(\d+)[xX](\d+).*', '', text).strip(' -:_')
            return int(m.group(1)), int(m.group(2)), clean_t
        m = re.search(r'(?:season|الموسم)\s*(\d+).*?(?:episode|الحلقة|حلقة)\s*(\d+)', text, re.IGNORECASE)
        if m:
            clean_t = re.sub(r'(?:season|الموسم)\s*(\d+).*', '', text, flags=re.IGNORECASE).strip(' -:_')
            return int(m.group(1)), int(m.group(2)), clean_t
        m = re.search(r'(?:episode|الحلقة|حلقة|ep\.?)\s*(\d+)', text, re.IGNORECASE)
        if m:
            clean_t = re.sub(r'(?:episode|الحلقة|حلقة|ep\.?)\s*(\d+).*', '', text, flags=re.IGNORECASE).strip(' -:_')
            return 1, int(m.group(1)), clean_t
        return None, None, text

    def ensure_audio_pipeline(self):
        """Ensure audio translation pipeline is active if SRT is not engaged."""
        if getattr(self, "srt_synchronizer", None) is None:
            if not getattr(self, "tap_manager", None) and getattr(self, "running", False):
                try:
                    self.start()
                except Exception as e:
                    print(f"[EnigmaTranslate] ensure_audio_pipeline error: {e}")

    def get_current_epg_title(self):
        """Get event name from current service EPG."""
        if self.session and hasattr(self.session, "nav"):
            try:
                srv = self.session.nav.getCurrentService()
                info = srv and srv.info()
                event = info and info.getEvent(0)
                if event:
                    return event.getEventName() or ""
            except Exception:
                pass
        return ""

    def get_current_epg_event_id(self):
        """Get unique identifier for current EPG event (event_id or title+start)."""
        if self.session and hasattr(self.session, "nav"):
            try:
                srv = self.session.nav.getCurrentService()
                info = srv and srv.info()
                event = info and info.getEvent(0)
                if event:
                    eid = getattr(event, "getEventId", lambda: None)()
                    if eid:
                        return f"{self.current_service_ref}_{eid}"
                    btime = getattr(event, "getBeginTime", lambda: 0)()
                    ename = getattr(event, "getEventName", lambda: "")() or ""
                    return f"{self.current_service_ref}_{ename}_{btime}"
            except Exception:
                pass
        return f"{self.current_service_ref}_default"

    def is_vod_stream(self):
        """Check if current service is an IPTV VOD movie or stream."""
        if not self.current_service_ref:
            return False
        ref_str = str(self.current_service_ref).strip()
        parts = ref_str.split(":")
        if len(parts) >= 11:
            stype = parts[0]
            if stype in ("4097", "5001", "5002", "5003", "1"):
                url = urllib.parse.unquote(parts[10]).lower()
                if any(ext in url for ext in (".mp4", ".mkv", ".avi", "/movie/", "/vod/", "/series/")):
                    return True
        sname = str(self.current_service_name or "").strip()
        if re.search(r"\b(19\d{2}|20\d{2})\b", sname) and any(tag in sname.lower() for tag in ("1080", "720", "fhd", "uhd", "bluray", "web", "film", "movie", "مترجم")):
            return True
        return False

    def _check_movie_srt(self):
        is_vod = self.is_vod_stream()
        ctype = getattr(self, "current_content_type", "")
        if not is_vod and ctype not in ("movie", "series"):
            return

        dwell = time.time() - getattr(self, "service_start_time", 0.0)
        # On VOD, user starts the movie immediately; on live broadcast channel, wait 30s
        if not is_vod and dwell < 30.0:
            return

        year = None
        if is_vod:
            self.current_content_type = "movie"
            from .srt_sync import extract_vod_title_and_year
            raw_vod_name = self.current_service_name
            if not raw_vod_name and self.session and hasattr(self.session, "nav"):
                try:
                    srv = self.session.nav.getCurrentService()
                    if srv and srv.info():
                        raw_vod_name = srv.info().getName()
                except Exception:
                    pass
            title, year = extract_vod_title_and_year(raw_vod_name)
            print(f"[EnigmaTranslate] [VOD] Extracted movie title='{title}', year={year} from service name='{raw_vod_name}'")
        else:
            title = self.get_current_epg_title()
            if not title:
                try:
                    import urllib.request
                    sref = self.current_service_ref
                    if sref:
                        url = f"http://127.0.0.1/api/epgservicenow?sRef={sref}"
                        req = urllib.request.Request(url, headers={"User-Agent": "EnigmaTranslate/1.0"})
                        with urllib.request.urlopen(req, timeout=1.5) as resp:
                            d = json.loads(resp.read().decode("utf-8"))
                            events = d.get("events", [])
                            if events:
                                title = events[0].get("title", "")
                except Exception:
                    pass
            if not title:
                # Query Xtream provider for current program title on IPTV
                sref = self.current_service_ref
                if sref and ("http" in str(sref).lower() or "%3a" in str(sref).lower() or "%253a" in str(sref).lower()):
                    try:
                        from .srt_sync import fetch_xtream_short_epg
                        title = fetch_xtream_short_epg(sref)
                    except Exception:
                        pass

        if not title:
            return  # Never fallback to channel name on broadcast TV

        if title and title != getattr(self, "srt_active_movie", None) and not getattr(self, "srt_searching", False):
            self.srt_active_movie = title
            self.srt_searching = True
            threading.Thread(target=self._async_find_movie_srt, args=(title,), kwargs={"year": year}, daemon=True, name="ET_MovieSearch").start()

    def _async_find_movie_srt(self, title, year=None):
        gen_token = getattr(self, "_session_generation", 0)
        if not self.running:
            return
        self.srt_last_query = f"{title} ({year})" if year else title
        self.srt_last_result = "جاري البحث..."
        self.srt_last_reason = "جاري البحث"
        t_start = time.time()
        timeout_limit = 10.0
        ctype = getattr(self, "current_content_type", "movie")

        try:
            if not self.running or getattr(self, "_session_generation", 0) != gen_token:
                return
            from .srt_sync import TMDBClient, SubtitleProviderChain, get_cached_tmdb_srt, SRTSynchronizer
            tmdb = TMDBClient()
            movie = None
            chain = getattr(self, "chain", None)
            season, episode, clean_query = None, None, title

            if ctype == "series":
                season, episode, clean_query = self._extract_series_info(title)
                if hasattr(tmdb, "search_tv"):
                    movie = tmdb.search_tv(clean_query, engine_chain=chain)

            if not movie:
                if title.lower() in ("shpagim", "retaliation"):
                    movie = tmdb.search_movie("Absolution", year=2024, engine_chain=chain)
                if not movie:
                    movie = tmdb.search_movie(clean_query, year=year, engine_chain=chain)

            if time.time() - t_start > timeout_limit:
                try:
                    print(f"[EnigmaTranslate] SRT: Search exceeded 10s -> continuing with audio")
                except Exception:
                    pass
                self.ensure_audio_pipeline()
                self.gui_q.put(("toast_reason", "لا توجد ترجمة جاهزة: متابعة الترجمة الصوتية"))
                return

            self.srt_movie_info = movie
            if not movie:
                reason = "لم يُعثر على المسلسل في TMDB" if ctype == "series" else "لم يُعثر على الفيلم في TMDB"
                self.srt_last_result = "لم يُعثر على المسلسل" if ctype == "series" else "لم يُعثر على الفيلم"
                self.srt_last_reason = reason
                try:
                    print(f"[EnigmaTranslate] SRT: {reason} for '{title}' -> continuing with audio")
                except Exception:
                    pass
                self.ensure_audio_pipeline()
                self.gui_q.put(("toast_reason", f"لا توجد ترجمة جاهزة: {reason}"))
                return

            tmdb_id = movie.get("tmdb_id") or movie.get("id")
            # Requirement 2: Never download twice for the same movie (cache by TMDB ID)
            if tmdb_id:
                cached_en, cached_ar = get_cached_tmdb_srt(tmdb_id)
                if cached_en or cached_ar:
                    print(f"[EnigmaTranslate] SRT: Found local cache for TMDB ID {tmdb_id} (0 downloads needed)")
                    self.srt_synchronizer = SRTSynchronizer(en_cues=cached_en, ar_cues=cached_ar)
                    self.srt_synchronizer.locked = True
                    self.srt_synchronizer.in_ad_break = False
                    self.srt_synchronizer.anchor_live_time = time.time()
                    self.srt_synchronizer.anchor_cue_start = 0.0
                    self.srt_synchronizer.last_match_time = time.time()
                    self.srt_synchronizer.last_sample_time = time.time()
                    self.srt_active = True
                    self.pending_subs.clear()
                    try:
                        while not self.display_queue.empty():
                            self.display_queue.get_nowait()
                    except Exception:
                        pass
                    if self.osd:
                        self.osd.hide_subtitle()
                    self.srt_last_result = "تم التحميل من الذاكرة (0 تحميل)"
                    self.srt_last_reason = "تم تفعيل الترجمة المحفوظة للفيلم"
                    self.gui_q.put(("status", "تم تفعيل الترجمة المحفوظة للفيلم"))
                    return

            imdb_id = movie.get("imdb_id")
            prov_chain = SubtitleProviderChain()
            remaining_time = max(1.0, timeout_limit - (time.time() - t_start))

            candidates = prov_chain.search_best(
                title=clean_query,
                imdb_id=imdb_id,
                tmdb_id=tmdb_id,
                year=movie.get("year"),
                timeout=min(remaining_time, 6.0),
                media_type="episode" if (ctype == "series" or episode is not None) else "movie",
                season_number=season,
                episode_number=episode
            )

            if time.time() - t_start > timeout_limit:
                try:
                    print(f"[EnigmaTranslate] SRT: Search exceeded 10s -> continuing with audio translation")
                except Exception:
                    pass
                self.ensure_audio_pipeline()
                self.gui_q.put(("toast_reason", "لا توجد ترجمة جاهزة: متابعة الترجمة الصوتية"))
                return

            if not self.running or getattr(self, "_session_generation", 0) != gen_token:
                return

            self.srt_candidates = candidates
            if candidates:
                best = candidates[0]
                self.srt_last_result = f"تم العثور على {len(candidates)} ترجمة"
                self.srt_last_reason = "تم تفعيل الترجمة الجاهزة"
                if best.get("confidence", 0) >= 0.85:
                    try:
                        print(f"[EnigmaTranslate] SRT: High confidence ({best['confidence']:.2f}) -> auto-picking {best['label']}")
                    except Exception:
                        pass
                    self.gui_q.put(("srt_auto_pick", best))
                else:
                    try:
                        print(f"[EnigmaTranslate] SRT: Found {len(candidates)} candidates -> showing selection menu")
                    except Exception:
                        pass
                    self.gui_q.put(("srt_menu", candidates))
            else:
                reason = "لا توجد ملفات ترجمة متطابقة"
                self.srt_last_result = "لا توجد ملفات متطابقة"
                self.srt_last_reason = reason
                try:
                    print(f"[EnigmaTranslate] SRT: {reason} for '{title}' -> continuing with audio")
                except Exception:
                    pass
                self.ensure_audio_pipeline()
                self.gui_q.put(("toast_reason", f"لا توجد ترجمة جاهزة: {reason}"))
        except Exception as e:
            reason = "خطأ في الاتصال بقاعدة البيانات"
            self.srt_last_result = "خطأ في الاتصال"
            self.srt_last_reason = reason
            try:
                print(f"[EnigmaTranslate] SRT search error: {e} -> continuing with audio")
            except Exception:
                pass
            self.ensure_audio_pipeline()
            self.gui_q.put(("toast_reason", f"لا توجد ترجمة جاهزة: {reason}"))
        finally:
            self.srt_searching = False

    def _show_srt_menu(self, candidates):
        if not self.session:
            return
        try:
            from Screens.ChoiceBox import ChoiceBox
            items = []
            for c in candidates:
                items.append((c.get("label", "ترجمة"), c))
            items.append(("إلغاء واستخدام الترجمة الحية المباشرة", None))
            self.session.openWithCallback(
                self._on_srt_menu_choice,
                ChoiceBox,
                title="ترجمة جاهزة للفيلم",
                list=items
            )
        except Exception as e:
            print(f"[EnigmaTranslate] Failed opening SRT ChoiceBox: {e}")

    def _on_srt_menu_choice(self, choice):
        if choice and len(choice) > 1 and choice[1]:
            cand = choice[1]
            threading.Thread(target=self._async_download_and_activate_srt, args=(cand,), daemon=True, name="ET_SRTDownload").start()

    def _async_download_and_activate_srt(self, cand):
        gen_token = getattr(self, "_session_generation", 0)
        if not self.running:
            return
        try:
            from .srt_sync import (
                SubtitleProviderChain, parse_srt, pre_translate_english_cues,
                SRTSynchronizer, save_cached_tmdb_srt, BackgroundSRTTranslator
            )
            prov_chain = SubtitleProviderChain()
            en_cues = []
            ar_cues = []
            en_item = cand.get("en_item")
            ar_item = cand.get("ar_item")
            tmdb_id = (self.srt_movie_info or {}).get("tmdb_id") or (self.srt_movie_info or {}).get("id")

            # Option A (Best): EN only, translate immediate cues then translate rest in background
            if en_item or not ar_item:
                target_cand = dict(cand)
                if en_item:
                    target_cand["item"] = en_item
                en_srt = prov_chain.download_item(target_cand)
                if en_srt:
                    en_cues = parse_srt(en_srt)
                    print(f"[EnigmaTranslate] SRT: Option A - translating initial cues for {len(en_cues)} English cues...")
                    ar_cues = pre_translate_english_cues(en_cues, self.chain, limit=10)
            elif ar_item:
                # Option B / Fallback: Arabic only
                target_cand = dict(cand)
                target_cand["item"] = ar_item
                ar_srt = prov_chain.download_item(target_cand)
                if ar_srt:
                    ar_cues = parse_srt(ar_srt)

            # Never twice for the same movie: cache by TMDB ID
            if tmdb_id and (en_cues or ar_cues):
                if not self.running or getattr(self, "_session_generation", 0) != gen_token:
                    return
                save_cached_tmdb_srt(tmdb_id, en_cues=en_cues, ar_cues=ar_cues)

                self.srt_synchronizer = SRTSynchronizer(en_cues=en_cues, ar_cues=ar_cues)
                self.srt_synchronizer.locked = True
                self.srt_synchronizer.in_ad_break = False
                self.srt_synchronizer.anchor_live_time = time.time()
                self.srt_synchronizer.anchor_cue_start = 0.0
                self.srt_synchronizer.last_match_time = time.time()
                self.srt_synchronizer.last_sample_time = time.time()
                self.srt_active = True
                self.pending_subs.clear()
                try:
                    while not self.display_queue.empty():
                        self.display_queue.get_nowait()
                except Exception:
                    pass
                if self.osd:
                    self.osd.hide_subtitle()
                print(f"[EnigmaTranslate] SRT: Synchronizer loaded with {len(en_cues)} EN cues and {len(ar_cues)} AR cues.")
                self.gui_q.put(("status", "تم تفعيل الترجمة الجاهزة للفيلم بنجاح"))

                # Launch progressive background translation for remaining cues forward from current pos
                if en_cues and (len(ar_cues) < len(en_cues)):
                    if getattr(self, "srt_bg_translator", None):
                        try:
                            self.srt_bg_translator.stop()
                        except Exception:
                            pass
                    cur_pos = getattr(self.srt_synchronizer, "anchor_cue_start", 0.0) or 0.0
                    self.srt_bg_translator = BackgroundSRTTranslator(
                        en_cues=en_cues,
                        synchronizer=self.srt_synchronizer,
                        chain=self.chain,
                        tmdb_id=tmdb_id,
                        cur_pos=cur_pos,
                        batch_size=10
                    )
                    self.srt_bg_translator.start()
        except Exception as e:
            print(f"[EnigmaTranslate] SRT download/activation error: {e}")

    def _check_identify_movie_from_transcript(self):
        """Identify movie from transcript when there is no usable EPG title or EPG title failed TMDB."""
        if not self.running or not self.tap_manager:
            return
        if not self.get_effective_setting("identify_movie_audio"):
            return
        if getattr(self, "srt_synchronizer", None) and self.srt_synchronizer.locked:
            return
        if getattr(self, "srt_searching", False):
            return

        ch_name = str(self.current_service_name or "").lower()
        ctype = getattr(self, "current_content_type", "")
        is_movie_channel = any(k in ch_name for k in ("movie", "cinema", "film", "action", "hbo", "thriller", "drama", "osn", "showtime", "sky", "canal"))
        if ctype not in ("movie", "series", "auto", "") and not is_movie_channel and not self.is_vod_stream():
            return

        # Check EPG first: if EPG title exists and has not yet failed TMDB, wait for _check_movie_srt
        epg_title = self.get_current_epg_title()
        if epg_title and getattr(self, "srt_last_result", "") not in ("لم يُعثر على الفيلم", "لم يُعثر على المسلسل", "لا توجد ملفات متطابقة"):
            return

        start_t = getattr(self, "service_start_time", 0.0)
        block_hr = int(start_t // 3600) if start_t > 0 else int(time.time() // 3600)
        prog_ev = self.get_current_epg_event_id() or f"block_{block_hr}"
        prog_key = f"{self.current_service_ref}_{prog_ev}"

        # Check memory cache
        if hasattr(self, "identified_movie_cache") and prog_key in self.identified_movie_cache:
            cached = self.identified_movie_cache[prog_key]
            if cached and not self.srt_synchronizer:
                print(f"[EnigmaTranslate] [IDENTIFY] Activating cached movie '{cached['title']}' for {prog_key}")
                from .srt_sync import SRTSynchronizer
                self.srt_movie_info = cached.get("movie_info")
                self.srt_synchronizer = SRTSynchronizer(en_cues=cached["en_cues"], ar_cues=cached["ar_cues"])
                self.srt_synchronizer.locked = True
                self.srt_synchronizer.in_ad_break = False
                self.srt_synchronizer.anchor_live_time = time.time()
                self.srt_synchronizer.anchor_cue_start = 0.0
                self.srt_synchronizer.last_match_time = time.time()
                self.srt_synchronizer.last_sample_time = time.time()
                self.srt_active = True
                self.pending_subs.clear()
                try:
                    while not self.display_queue.empty():
                        self.display_queue.get_nowait()
                except Exception:
                    pass
                if self.osd:
                    self.osd.hide_subtitle()
                self.gui_q.put(("status", f"تم تفعيل الترجمة المحفوظة: {cached['title']}"))
                return

        now = time.time()
        if not hasattr(self, "identify_attempts_per_program"):
            self.identify_attempts_per_program = {}
        if not hasattr(self, "last_identify_attempt_time"):
            self.last_identify_attempt_time = {}

        attempts = self.identify_attempts_per_program.get(prog_key, 0)
        if attempts >= 2:
            return
        if attempts == 1:
            last_t = self.last_identify_attempt_time.get(prog_key, 0.0)
            if (now - last_t) < 600.0:
                return

        # Step 1: For IPTV, ask the Xtream provider for the current program title
        sref = self.current_service_ref
        if sref and ("http" in str(sref).lower() or "%3a" in str(sref).lower() or "%253a" in str(sref).lower()):
            from .srt_sync import fetch_xtream_short_epg
            xtream_title = fetch_xtream_short_epg(sref)
            if xtream_title:
                print(f"[EnigmaTranslate] [IDENTIFY] Step 1: Found Xtream EPG title '{xtream_title}'. Using directly for TMDB/SRT (no AI guessing).")
                self.srt_searching = True
                threading.Thread(target=self._async_find_movie_srt, args=(xtream_title,), daemon=True, name="ET_MovieSearch").start()
                return

        # Step 2: Better AI guessing (only if Step 1 gives nothing)
        # - Wait for at least 3 minutes AND at least 25 transcript lines (skip music/action with no speech)
        from .srt_sync import is_valid_speech_line, extract_character_names
        dialogue = getattr(self, "recent_english_dialogue", [])
        speech_dialogue = [(ts, txt) for (ts, txt) in dialogue if is_valid_speech_line(txt)]
        if len(speech_dialogue) < 25:
            return
        span = speech_dialogue[-1][0] - speech_dialogue[0][0]
        if span < 180.0:  # At least 3 minutes
            return

        char_names = extract_character_names(speech_dialogue)
        c_type = getattr(self, "current_content_type", "") or "movie"

        self.srt_searching = True
        print(f"[EnigmaTranslate] [IDENTIFY] Step 2: Triggering AI guessing from {len(speech_dialogue)} speech lines (span {span:.1f}s, {len(char_names)} characters detected) on '{self.current_service_name}'...")
        threading.Thread(
            target=self._async_identify_movie_from_transcript,
            args=(list(speech_dialogue), self.current_service_name, prog_key),
            kwargs={"content_type": c_type, "character_names": char_names},
            daemon=True,
            name="ET_MovieIdentify"
        ).start()

    def _record_identify_attempt(self, prog_key):
        if not hasattr(self, "identify_attempts_per_program"):
            self.identify_attempts_per_program = {}
        if not hasattr(self, "last_identify_attempt_time"):
            self.last_identify_attempt_time = {}
        curr = self.identify_attempts_per_program.get(prog_key, 0) + 1
        self.identify_attempts_per_program[prog_key] = curr
        self.last_identify_attempt_time[prog_key] = time.time()
        print(f"[EnigmaTranslate] [IDENTIFY] Attempt {curr}/2 recorded for {prog_key}. Next retry in 10 minutes.")

    def _async_identify_movie_from_transcript(self, transcript_lines, channel_name, prog_key, content_type="movie", character_names=None):
        try:
            from .srt_sync import (
                identify_movie_candidates_from_transcript,
                TMDBClient, SubtitleProviderChain, parse_srt,
                confirm_transcript_against_srt, pre_translate_english_cues,
                save_cached_tmdb_srt, SRTSynchronizer
            )
            full_text = " ".join([txt for (_, txt) in transcript_lines])[-1500:]
            raw_lines = [txt for (_, txt) in transcript_lines]

            print(f"[EnigmaTranslate] [IDENTIFY] Querying AI engine for movie from transcript ({len(full_text)} chars, chars={character_names}) on '{channel_name}'...")
            t0 = time.time()
            candidates = identify_movie_candidates_from_transcript(
                full_text,
                channel_name=channel_name,
                content_type=content_type,
                character_names=character_names
            )
            t_detect = time.time() - t0

            if not candidates:
                print(f"[EnigmaTranslate] [IDENTIFY] AI returned no confident candidates (unknown or < 0.5) in {t_detect:.1f}s.")
                self._record_identify_attempt(prog_key)
                return

            print(f"[EnigmaTranslate] [IDENTIFY] AI returned {len(candidates)} confident candidates in {t_detect:.1f}s: {candidates}")

            tmdb = TMDBClient()
            prov_chain = SubtitleProviderChain()
            confirmed = False

            for cand in candidates:
                title = cand.get("title", "")
                year = cand.get("year")
                if not title:
                    continue

                print(f"[EnigmaTranslate] [IDENTIFY] Checking candidate '{title}' ({year}) on TMDB...")
                movie = tmdb.search_movie(title, year=year, engine_chain=self.chain)
                if not movie:
                    movie = tmdb.search_tv(title, engine_chain=self.chain)
                if not movie:
                    print(f"[EnigmaTranslate] [IDENTIFY] Candidate '{title}' not found on TMDB.")
                    continue

                tmdb_id = movie.get("tmdb_id") or movie.get("id")
                imdb_id = movie.get("imdb_id")
                clean_title = movie.get("title") or title
                movie_year = movie.get("year") or year

                print(f"[EnigmaTranslate] [IDENTIFY] TMDB match: '{clean_title}' ({movie_year}), TMDB ID={tmdb_id}, IMDb={imdb_id}")

                sub_candidates = prov_chain.search_best(
                    title=clean_title,
                    imdb_id=imdb_id,
                    tmdb_id=tmdb_id,
                    year=movie_year,
                    timeout=10.0,
                    media_type="movie"
                )
                if not sub_candidates:
                    print(f"[EnigmaTranslate] [IDENTIFY] No subtitle candidates found for '{clean_title}'.")
                    continue

                best_sub = sub_candidates[0]
                en_srt = prov_chain.download_item(best_sub)
                if not en_srt:
                    print(f"[EnigmaTranslate] [IDENTIFY] Failed downloading SRT for '{clean_title}'.")
                    continue

                en_cues = parse_srt(en_srt)
                if not en_cues:
                    print(f"[EnigmaTranslate] [IDENTIFY] Empty SRT parsed for '{clean_title}'.")
                    continue

                match_ok, count, matched_indices, matched_times = confirm_transcript_against_srt(transcript_lines, en_cues, min_matches=4)
                if match_ok:
                    print(f"[EnigmaTranslate] [IDENTIFY] CONFIRMED! Matched {count} lines in order against '{clean_title}'!")
                    last_matched_cue_idx = matched_indices[-1] if matched_indices else 0
                    matched_cue = en_cues[last_matched_cue_idx]
                    anchor_t = matched_times[-1] if (matched_times and matched_times[-1] > 0) else time.time()

                    ar_cues = pre_translate_english_cues(en_cues, self.chain, limit=15, start_pos=matched_cue.start)
                    save_cached_tmdb_srt(tmdb_id, en_cues=en_cues, ar_cues=ar_cues)

                    if not hasattr(self, "identified_movie_cache"):
                        self.identified_movie_cache = {}
                    self.identified_movie_cache[prog_key] = {
                        "tmdb_id": tmdb_id,
                        "title": clean_title,
                        "year": movie_year,
                        "movie_info": movie,
                        "en_cues": en_cues,
                        "ar_cues": ar_cues
                    }

                    self.srt_movie_info = movie
                    self.srt_synchronizer = SRTSynchronizer(en_cues=en_cues, ar_cues=ar_cues)
                    self.srt_synchronizer.anchor_live_time = anchor_t
                    self.srt_synchronizer.anchor_cue_start = matched_cue.start
                    self.srt_synchronizer.locked = True
                    self.srt_synchronizer.in_ad_break = False
                    self.srt_synchronizer.consecutive_misses = 0
                    self.srt_synchronizer.last_match_time = time.time()
                    self.srt_synchronizer.last_sample_time = time.time()
                    self.srt_active = True

                    # Drain audio queues and stop pending audio STT subtitles
                    self.pending_subs.clear()
                    try:
                        while not self.display_queue.empty():
                            self.display_queue.get_nowait()
                    except Exception:
                        pass
                    if self.osd:
                        self.osd.hide_subtitle()

                    toast_msg = f"تم التعرف على الفيلم: {clean_title}"
                    print(f"[EnigmaTranslate] [IDENTIFY] Switching to verified movie: '{clean_title}' (detected in {t_detect:.1f}s)")
                    self.gui_q.put(("status", toast_msg))
                    self.gui_q.put(("toast_reason", toast_msg))

                    if len(ar_cues) < len(en_cues):
                        from .srt_sync import BackgroundSRTTranslator
                        if getattr(self, "srt_bg_translator", None):
                            try:
                                self.srt_bg_translator.stop()
                            except Exception:
                                pass
                        self.srt_bg_translator = BackgroundSRTTranslator(
                            synchronizer=self.srt_synchronizer,
                            en_cues=en_cues,
                            chain=self.chain,
                            tmdb_id=tmdb_id,
                            cur_pos=matched_cue.start
                        )
                        self.srt_bg_translator.start()

                    confirmed = True
                    break
                else:
                    print(f"[EnigmaTranslate] [IDENTIFY] Candidate '{clean_title}' failed confirmation ({count}/4 matches). Trying next candidate...")

            if not confirmed:
                print(f"[EnigmaTranslate] [IDENTIFY] No candidate confirmed. Staying on audio STT.")
                self._record_identify_attempt(prog_key)

        except Exception as e:
            print(f"[EnigmaTranslate] [IDENTIFY] Identification error: {e}")
            self._record_identify_attempt(prog_key)
        finally:
            self.srt_searching = False

    def get_real_picture_delay(self):
        """Read the real picture delay from the player (timeshift play position vs live, or IPTV relay bridge).
        
        If timeshift/relay is not active, real delay = 0, so show cues at live time.
        """
        if getattr(self, "relay_active", False) and getattr(self, "current_bridge_sec", 0.0) > 0:
            return float(self.current_bridge_sec)

        try:
            from Screens.InfoBar import InfoBar
            ib = InfoBar.instance if InfoBar else None
            is_ts = False
            if ib:
                if hasattr(ib, "isTimeshiftActive"):
                    is_ts = bool(ib.isTimeshiftActive())
                elif hasattr(ib, "timeshift_active"):
                    is_ts = bool(ib.timeshift_active)
                elif hasattr(ib, "timeshift_enabled"):
                    is_ts = bool(ib.timeshift_enabled)

            if not is_ts:
                return 0.0

            if self.session and hasattr(self.session, "nav"):
                service = self.session.nav.getCurrentService()
                seek = service and service.seek()
                if seek:
                    pos = seek.getPlayPosition()
                    length = seek.getLength()
                    if isinstance(pos, tuple) and len(pos) >= 2 and pos[0] == 0:
                        cur_pts = pos[1]
                        if isinstance(length, tuple) and len(length) >= 2 and length[0] == 0:
                            live_pts = length[1]
                            delay_sec = (live_pts - cur_pts) / 90000.0
                            if delay_sec >= 0.5:
                                return float(delay_sec)
        except Exception:
            pass
        return 0.0

    def _disable_time_bridge_for_srt(self):
        """Disable Time-Bridge and return to live during ad break so 14s jump is invisible."""
        if getattr(self, "is_encrypted", False):
            # On encrypted channels, timeshift buffer is the only safe audio source.
            # Must stay bridged to keep timeshift recording active without touching 8001.
            print("[EnigmaTranslate] [SRT] Encrypted channel -> Staying bridged during ad break to preserve safe timeshift audio source.")
            return
        try:
            self._unpause_time_bridge()
            from Screens.InfoBar import InfoBar
            ib = InfoBar.instance if InfoBar else None
            if ib:
                if hasattr(ib, "stopTimeshift"):
                    ib.stopTimeshift()
                elif hasattr(ib, "timeshiftStop"):
                    ib.timeshiftStop()
            self.current_bridge_sec = 0.0
            self.target_bridge_sec = 0.0
            print("[EnigmaTranslate] [SRT] Ad break -> Returned to live broadcast (invisible jump, bridge disabled).")
        except Exception as e:
            print(f"[EnigmaTranslate] [SRT] Error returning to live during ad break: {e}")

    def is_stt_sample_needed(self):
        """Check if an audio chunk should be transcribed by Groq STT (throttled in SRT mode)."""
        sync = getattr(self, "srt_synchronizer", None)
        if not sync or not sync.locked:
            return True  # Normal audio mode or waiting for initial anchor -> transcribe
        req_interval = 10.0 if (sync.in_ad_break or sync.consecutive_misses > 0) else 60.0
        return (time.time() - getattr(sync, "last_sample_time", 0.0)) >= (req_interval - 1.0)

    def show_usage_pill(self):
        """Show usage pill on screen: متبقي اليوم: X.X ساعة"""
        try:
            from .stt import get_groq_usage_pill_text
            self.show_status(get_groq_usage_pill_text(), duration=3.0)
        except Exception:
            pass

    def _kill_leftover_ffmpeg(self):
        """Kill leftover ffmpeg processes to release tuner immediately."""
        try:
            import subprocess
            subprocess.run(["pkill", "-9", "-f", "ffmpeg.*127\\.0\\.0\\.1"], timeout=1.0)
        except Exception:
            pass

    def _handle_callback_error(self, err=None, context="_on_gui_tick"):
        """Safely handle error in GUI timer/event callbacks: log, stop translation, notify user."""
        try:
            print(f"[EnigmaTranslate] [ERROR] GUI callback error in {context}: {err}")
            import traceback
            traceback.print_exc()
        except Exception:
            pass

        try:
            self.stop()
        except Exception as stop_err:
            print(f"[EnigmaTranslate] Error stopping controller after callback error: {stop_err}")

        # Disable for this session only; do NOT modify cfg.enabled or call cfg.save()!
        self.session_disabled = True

        try:
            self.show_status("تم إيقاف الترجمة بسبب خطأ", duration=4.0)
        except Exception as toast_err:
            print(f"[EnigmaTranslate] Failed to show error toast: {toast_err}")

    def get_effective_setting(self, key):
        """Return channel-profile override or global config value."""
        sref = self.current_service_ref
        if key == "no_timeshift_playback":
            if sref and sref in getattr(self, "runtime_no_ts_playback_channels", set()):
                return True
        elif key == "bridge":
            if sref and hasattr(self, "channel_bridges") and sref in self.channel_bridges:
                return self.channel_bridges[sref]

        prof = self.channel_profiles.get(sref, {}) if sref else {}
        val = None
        if key in prof:
            val = prof[key]
        else:
            cfg = getattr(settings.config.plugins, "enigmatranslate", None)
            if cfg is not None:
                try:
                    elem = getattr(cfg, key, None)
                except Exception:
                    elem = None
                if elem is not None:
                    # NEVER use hasattr on config elements (properties execute).
                    # Read values via elem.value and convert safely.
                    try:
                        val = elem.value
                    except Exception:
                        val = elem

        if key == "src_lang":
            # If global src_lang is stuck on 'he' from a previous Hebrew channel test,
            # don't inherit 'he' onto non-Hebrew channels without a profile
            v = val if val else "auto"
            if v in ("he", "heb"):
                cname = (self.current_service_name or "").upper()
                if "SPORT" not in cname and "5" not in cname and "ISRAEL" not in cname:
                    return "auto"
            return v

        if key == "delay" or key == "timeout":
            return settings.parse_delay_to_seconds(val)

        if key == "content_type":
            return val if val else "auto"

        if key == "ignore_native_subs":
            if prof and "ignore_native_subs" in prof and prof["ignore_native_subs"] is not None:
                return bool(prof["ignore_native_subs"])
            cfg = getattr(settings.config.plugins, "enigmatranslate", None)
            return bool(getattr(getattr(cfg, "ignore_native_subs", None), "value", False)) if cfg else False

        if key == "bridge":
            # Per-channel profile can explicitly turn it on or off
            if prof and "bridge" in prof and prof["bridge"] is not None:
                return bool(prof["bridge"])

            cfg = getattr(settings.config.plugins, "enigmatranslate", None)
            if cfg and getattr(getattr(cfg, "bridge", None), "value", False):
                return True

            bridge_auto = getattr(getattr(cfg, "bridge_auto", None), "value", True) if cfg else True
            if bridge_auto:
                active_tap = self.tap_manager.active_kind if self.tap_manager else None
                configured_source = self.get_effective_setting("source")
                is_audio = (active_tap == "audio") or (configured_source == "audio") or (configured_source == "auto" and not getattr(self, "channel_has_text_subs", False)) or getattr(self, "is_encrypted", False)
                if is_audio and self.is_timeshift_disk_available():
                    return True
            return False

        if key == "bridge_sec":
            if prof and "bridge_sec" in prof and prof["bridge_sec"] is not None:
                try:
                    return float(prof["bridge_sec"])
                except Exception:
                    pass
            if getattr(self, "current_service_ref", None) and self.current_service_ref in getattr(self, "channel_bridges", {}):
                return float(self.channel_bridges[self.current_service_ref])
            if getattr(self, "current_bridge_sec", None):
                return float(self.current_bridge_sec)
            cfg = getattr(settings.config.plugins, "enigmatranslate", None)
            val = getattr(getattr(cfg, "bridge_sec", None), "value", 14) if cfg else 14
            try:
                return float(val)
            except Exception:
                return 14.0

        return val

    def is_timeshift_disk_available(self):
        """Check whether a timeshift directory / disk is present, writable, and has >= 500MB free."""
        try:
            from Components.config import config
            ts_cfg = getattr(getattr(config, "usage", None), "timeshift_path", None)
            ts_path = getattr(ts_cfg, "value", None) if ts_cfg is not None else None
        except Exception:
            ts_path = None

        candidates = [
            ts_path,
            "/media/hdd/timeshift",
            "/media/hdd",
            "/media/usb/timeshift",
            "/media/usb",
            "/media/mmc/timeshift",
            "/media/mmc"
        ]
        for p in candidates:
            if not p or not os.path.exists(p):
                continue
            try:
                stat = os.statvfs(p)
                free_mb = (stat.f_bavail * stat.f_frsize) / (1024 * 1024)
                if free_mb >= 500:
                    return True
            except Exception:
                continue
        return False

    def _calc_percentile_90(self, data):
        """Calculate 90th percentile of data points."""
        if not data:
            return 10.0
        s = sorted(data)
        idx = (len(s) - 1) * 0.9
        low = int(math.floor(idx))
        high = int(math.ceil(idx))
        weight = idx - low
        return s[low] * (1.0 - weight) + s[high] * weight

    def _calc_percentile_95(self, data):
        """Calculate 95th percentile of data points."""
        if not data:
            return 4.0
        s = sorted(data)
        idx = (len(s) - 1) * 0.95
        low = int(math.floor(idx))
        high = int(math.ceil(idx))
        weight = idx - low
        return s[low] * (1.0 - weight) + s[high] * weight

    def is_mid_sentence(self):
        """Return True if a subtitle line is currently displayed on OSD or pending."""
        if self.osd and getattr(self.osd, "is_active", False):
            return True
        if self.pending_subs:
            return True
        return False

    def show_status(self, msg, duration=5.0, force=False):
        """Display transient status toast or OSD message."""
        try:
            self._ensure_osd()
            if self.toast:
                self.toast.show_status(msg, duration=duration, force=force)
            elif self.osd:
                self.osd.show_status(msg, duration=duration, force=force)
        except Exception as e:
            print(f"[EnigmaTranslate] show_status failed: {e}")

    def get_current_pill_message(self):
        """Construct status pill string reflecting current mode and metrics."""
        try:
            if getattr(self, "native_sub_active", False):
                return "ترجمة القناة الأصلية"
            if getattr(self, "channel_has_dvb_subs", False) or (getattr(self, "tap_manager", None) and getattr(self.tap_manager, "active_kind", "") == "dvb_sub"):
                return "ترجمة القناة (DVB)"
            if getattr(self, "channel_has_teletext_subs", False) or (getattr(self, "tap_manager", None) and getattr(self.tap_manager, "active_kind", "") == "teletext"):
                return "تيليتكست"
            if getattr(self, "srt_synchronizer", None) and self.srt_synchronizer.locked:
                return "ترجمة جاهزة"

            ctype_lbl = self.get_content_type_label()
            real_delay = getattr(self, "_cached_real_pic_delay", 0.0)
            user_nudge = float(self.get_effective_setting("delay") or 0.0)
            nudge_str = f" ({user_nudge:+.1f}s)" if abs(user_nudge) > 0.01 else ""
            delay_str = f"{real_delay:.1f}s{nudge_str}"
            try:
                from .stt import get_stt_status_pill_text
                stt_info = get_stt_status_pill_text()
                return f"ترجمة صوتية · {stt_info} · {delay_str}"
            except Exception:
                return f"ترجمة صوتية · {ctype_lbl} · {delay_str}"
        except Exception:
            return "ترجمة صوتية"

    def show_transient_status(self, reason="", custom_msg=None, duration=5.0, force=False):
        """Show status pill transiently for 5s (on start, zap, mode change, important state, or INFO)."""
        msg = custom_msg or self.get_current_pill_message()
        self.show_status(msg, duration=duration, force=force)

    def trigger_info_status(self):
        """Called when user presses INFO while translation is on: shows status pill for 5s."""
        if not self.running or not getattr(settings.config.plugins.enigmatranslate.enabled, "value", True):
            return
        self.show_transient_status(reason="info_key", duration=5.0, force=True)

    def _install_info_key_hook(self):
        """Hook INFO key during active translation to show transient status pill for 5s."""
        try:
            from Screens.InfoBarGenerics import InfoBarEPG
            if not hasattr(InfoBarEPG, "_orig_enigma_translate_InfoPressed"):
                InfoBarEPG._orig_enigma_translate_InfoPressed = getattr(InfoBarEPG, "InfoPressed", None)

                def _hooked_InfoPressed(ib_self):
                    try:
                        ctrl = Controller.get_instance()
                        if ctrl and ctrl.running and getattr(settings.config.plugins.enigmatranslate.enabled, "value", True):
                            ctrl.trigger_info_status()
                    except Exception:
                        pass
                    orig = getattr(InfoBarEPG, "_orig_enigma_translate_InfoPressed", None)
                    if orig:
                        return orig(ib_self)

                InfoBarEPG.InfoPressed = _hooked_InfoPressed

            if hasattr(InfoBarEPG, "showDefaultINFO") and not hasattr(InfoBarEPG, "_orig_enigma_translate_showDefaultINFO"):
                InfoBarEPG._orig_enigma_translate_showDefaultINFO = getattr(InfoBarEPG, "showDefaultINFO", None)

                def _hooked_showDefaultINFO(ib_self):
                    try:
                        ctrl = Controller.get_instance()
                        if ctrl and ctrl.running and getattr(settings.config.plugins.enigmatranslate.enabled, "value", True):
                            ctrl.trigger_info_status()
                    except Exception:
                        pass
                    orig = getattr(InfoBarEPG, "_orig_enigma_translate_showDefaultINFO", None)
                    if orig:
                        return orig(ib_self)

                InfoBarEPG.showDefaultINFO = _hooked_showDefaultINFO
        except Exception as e:
            print(f"[EnigmaTranslate] Info key hook error: {e}")

    def _install_quick_button_hook(self):
        """Hook quick button (SUBTITLE / TEXT / HELP) according to config.plugins.enigmatranslate.quick_button."""
        try:
            from Screens.InfoBarGenerics import InfoBarSubtitleSupport, InfoBarTeletextPlugin

            # 1. InfoBarSubtitleSupport: short press toggles on/off with toast, long press opens original subtitle selection
            if not hasattr(InfoBarSubtitleSupport, "_orig_enigma_translate_subtitleSelection"):
                InfoBarSubtitleSupport._orig_enigma_translate_subtitleSelection = getattr(InfoBarSubtitleSupport, "subtitleSelection", None)
                InfoBarSubtitleSupport._orig_enigma_translate_toggleDefaultSubtitles = getattr(InfoBarSubtitleSupport, "toggleDefaultSubtitles", None)

                def _hooked_subtitleSelection(ib_self):
                    ctrl = Controller.get_instance()
                    cfg_quick = getattr(settings.config.plugins.enigmatranslate, "quick_button", None)
                    quick_val = cfg_quick.value if cfg_quick else "subtitle"
                    if ctrl and quick_val == "subtitle":
                        ctrl.on_subtitle_button_pressed()
                        return
                    orig = getattr(InfoBarSubtitleSupport, "_orig_enigma_translate_subtitleSelection", None)
                    if orig:
                        return orig(ib_self)

                def _open_original_subtitles(ib_self):
                    orig_sub = getattr(InfoBarSubtitleSupport, "_orig_enigma_translate_subtitleSelection", None)
                    res = orig_sub(ib_self) if orig_sub else None
                    if not res and getattr(ib_self, "session", None):
                        try:
                            from Screens.AudioSelection import SubtitleSelection
                            ib_self.session.open(SubtitleSelection, ib_self)
                        except Exception:
                            pass

                def _hooked_toggleDefaultSubtitles(ib_self):
                    ctrl = Controller.get_instance()
                    cfg_quick = getattr(settings.config.plugins.enigmatranslate, "quick_button", None)
                    quick_val = cfg_quick.value if cfg_quick else "subtitle"
                    if ctrl and quick_val == "subtitle":
                        _open_original_subtitles(ib_self)
                        return
                    orig = getattr(InfoBarSubtitleSupport, "_orig_enigma_translate_toggleDefaultSubtitles", None)
                    if orig:
                        return orig(ib_self)

                InfoBarSubtitleSupport.subtitleSelection = _hooked_subtitleSelection
                InfoBarSubtitleSupport.toggleDefaultSubtitles = _hooked_toggleDefaultSubtitles

            # 2. InfoBarTeletextPlugin for KEY_TEXT:
            if hasattr(InfoBarTeletextPlugin, "startTeletext") and not hasattr(InfoBarTeletextPlugin, "_orig_enigma_translate_startTeletext"):
                InfoBarTeletextPlugin._orig_enigma_translate_startTeletext = getattr(InfoBarTeletextPlugin, "startTeletext", None)

                def _hooked_startTeletext(ib_self):
                    ctrl = Controller.get_instance()
                    cfg_quick = getattr(settings.config.plugins.enigmatranslate, "quick_button", None)
                    quick_val = cfg_quick.value if cfg_quick else "subtitle"
                    if ctrl and quick_val == "text":
                        ctrl.toggle_with_toast()
                        return
                    orig = getattr(InfoBarTeletextPlugin, "_orig_enigma_translate_startTeletext", None)
                    if orig:
                        return orig(ib_self)

                InfoBarTeletextPlugin.startTeletext = _hooked_startTeletext

            # 3. ButtonSetup if present on image (OpenATV / OpenPLi / OpenViX):
            try:
                from Screens.ButtonSetup import InfoBarButtonSetup
                if hasattr(InfoBarButtonSetup, "ButtonSetupGlobal") and not hasattr(InfoBarButtonSetup, "_orig_enigma_translate_ButtonSetupGlobal"):
                    InfoBarButtonSetup._orig_enigma_translate_ButtonSetupGlobal = getattr(InfoBarButtonSetup, "ButtonSetupGlobal", None)

                    def _hooked_ButtonSetupGlobal(ib_self, key):
                        ctrl = Controller.get_instance()
                        cfg_quick = getattr(settings.config.plugins.enigmatranslate, "quick_button", None)
                        quick_val = cfg_quick.value if cfg_quick else "subtitle"
                        if ctrl:
                            if quick_val == "subtitle":
                                if key == "subtitle":
                                    ctrl.on_subtitle_button_pressed()
                                    return
                                elif key == "subtitle_long":
                                    orig_sub = getattr(InfoBarSubtitleSupport, "_orig_enigma_translate_subtitleSelection", None)
                                    if orig_sub:
                                        return orig_sub(ib_self)
                            elif quick_val == "text" and key in ("text", "teletext"):
                                ctrl.toggle_with_toast()
                                return
                            elif quick_val == "help" and key in ("displayHelp", "help"):
                                ctrl.toggle_with_toast()
                                return

                        orig = getattr(InfoBarButtonSetup, "_orig_enigma_translate_ButtonSetupGlobal", None)
                        if orig:
                            return orig(ib_self, key)

                    InfoBarButtonSetup.ButtonSetupGlobal = _hooked_ButtonSetupGlobal
            except Exception:
                pass

            # 4. HelpMenu / HelpableScreen for KEY_HELP:
            try:
                from Screens.HelpMenu import HelpableScreen
                if hasattr(HelpableScreen, "showHelp") and not hasattr(HelpableScreen, "_orig_enigma_translate_showHelp"):
                    HelpableScreen._orig_enigma_translate_showHelp = getattr(HelpableScreen, "showHelp", None)

                    def _hooked_showHelp(ib_self):
                        ctrl = Controller.get_instance()
                        cfg_quick = getattr(settings.config.plugins.enigmatranslate, "quick_button", None)
                        quick_val = cfg_quick.value if cfg_quick else "subtitle"
                        if ctrl and quick_val == "help":
                            ctrl.toggle_with_toast()
                            return
                        orig = getattr(HelpableScreen, "_orig_enigma_translate_showHelp", None)
                        if orig:
                            return orig(ib_self)

                    HelpableScreen.showHelp = _hooked_showHelp
            except Exception:
                pass

            # 5. Quick subtitle sync keys: < / > (KEY_PREVIOUS / KEY_NEXT) and << / >> (KEY_REWIND / KEY_FORWARD)
            try:
                from Screens.InfoBarGenerics import InfoBarChannelSelection, InfoBarSeek
                from .osd import is_other_screen_open

                def _is_sync_key_allowed(key_type):
                    ctrl = Controller.get_instance()
                    if not ctrl or not ctrl.running:
                        return False
                    if is_other_screen_open(getattr(ctrl, "session", None)):
                        return False
                    cfg_sync = getattr(settings.config.plugins.enigmatranslate, "sync_keys", None)
                    mode = cfg_sync.value if cfg_sync else "<>"
                    if mode == "off":
                        return False
                    if key_type == "<>" and mode in ("<>", "both"):
                        return True
                    if key_type == "rew_ff" and mode in ("rew_ff", "both"):
                        return True
                    return False

                if hasattr(InfoBarChannelSelection, "historyBack") and not hasattr(InfoBarChannelSelection, "_orig_enigma_translate_historyBack"):
                    InfoBarChannelSelection._orig_enigma_translate_historyBack = getattr(InfoBarChannelSelection, "historyBack", None)

                    def _hooked_historyBack(ib_self):
                        if _is_sync_key_allowed("<>"):
                            ctrl = Controller.get_instance()
                            if ctrl:
                                ctrl.on_sync_key_event(earlier=True)
                                return
                        orig = getattr(InfoBarChannelSelection, "_orig_enigma_translate_historyBack", None)
                        if orig:
                            return orig(ib_self)

                    InfoBarChannelSelection.historyBack = _hooked_historyBack

                if hasattr(InfoBarChannelSelection, "historyNext") and not hasattr(InfoBarChannelSelection, "_orig_enigma_translate_historyNext"):
                    InfoBarChannelSelection._orig_enigma_translate_historyNext = getattr(InfoBarChannelSelection, "historyNext", None)

                    def _hooked_historyNext(ib_self):
                        if _is_sync_key_allowed("<>"):
                            ctrl = Controller.get_instance()
                            if ctrl:
                                ctrl.on_sync_key_event(earlier=False)
                                return
                        orig = getattr(InfoBarChannelSelection, "_orig_enigma_translate_historyNext", None)
                        if orig:
                            return orig(ib_self)

                    InfoBarChannelSelection.historyNext = _hooked_historyNext

                if hasattr(InfoBarSeek, "seekBack") and not hasattr(InfoBarSeek, "_orig_enigma_translate_seekBack"):
                    InfoBarSeek._orig_enigma_translate_seekBack = getattr(InfoBarSeek, "seekBack", None)

                    def _hooked_seekBack(ib_self):
                        if _is_sync_key_allowed("rew_ff"):
                            ctrl = Controller.get_instance()
                            if ctrl:
                                ctrl.on_sync_key_event(earlier=True)
                                return
                        orig = getattr(InfoBarSeek, "_orig_enigma_translate_seekBack", None)
                        if orig:
                            return orig(ib_self)

                    InfoBarSeek.seekBack = _hooked_seekBack

                if hasattr(InfoBarSeek, "seekFwd") and not hasattr(InfoBarSeek, "_orig_enigma_translate_seekFwd"):
                    InfoBarSeek._orig_enigma_translate_seekFwd = getattr(InfoBarSeek, "seekFwd", None)

                    def _hooked_seekFwd(ib_self):
                        if _is_sync_key_allowed("rew_ff"):
                            ctrl = Controller.get_instance()
                            if ctrl:
                                ctrl.on_sync_key_event(earlier=False)
                                return
                        orig = getattr(InfoBarSeek, "_orig_enigma_translate_seekFwd", None)
                        if orig:
                            return orig(ib_self)

                    InfoBarSeek.seekFwd = _hooked_seekFwd
            except Exception as e:
                print(f"[EnigmaTranslate] Sync keys hook error: {e}")

        except Exception as e:
            print(f"[EnigmaTranslate] Quick button hook error: {e}")

    def _do_enable_native_sub(self, track):
        infobar = getattr(self.session, "infobar", None)
        if not infobar:
            try:
                from Screens.InfoBar import InfoBar
                infobar = InfoBar.instance
            except Exception:
                pass
        if not infobar and self.session:
            for d in getattr(self.session, "dialog_stack", []):
                if hasattr(d, "enableSubtitle"):
                    infobar = d
                    break

        if not infobar:
            print("[EnigmaTranslate] [NATIVE SUB] No infobar found")
            return False

        # Ensure subtitle_window has an active GUI instance before calling enableSubtitles
        sub_win = getattr(infobar, "subtitle_window", None)
        if sub_win:
            if getattr(sub_win, "instance", None) is None:
                try:
                    sub_win.show()
                except Exception as e:
                    print(f"[EnigmaTranslate] [NATIVE SUB] sub_win.show error: {e}")

        activated = False
        if hasattr(infobar, "enableSubtitle"):
            try:
                infobar.enableSubtitle(track)
                activated = True
            except Exception as e:
                print(f"[EnigmaTranslate] [NATIVE SUB] Error in infobar.enableSubtitle: {e}")

        if activated:
            self.plugin_enabled_track = track
            self.native_sub_active = True
            if getattr(self, "tap_manager", None):
                try:
                    self.tap_manager.stop()
                    self.tap_manager = None
                except Exception:
                    pass
            if self.osd:
                self.osd.hide_subtitle()
            is_dvb = (isinstance(track, (list, tuple)) and len(track) >= 1 and track[0] == 0) or "dvb" in str(track).lower()
            if is_dvb:
                self.show_status("ترجمة القناة (DVB)", duration=4.0, force=True)
            else:
                self.show_status("ترجمة القناة الأصلية", duration=4.0, force=True)
            print(f"[EnigmaTranslate] [NATIVE SUB] Successfully enabled native track: {track}")
            self._start_native_render_watchdog()
            return True
        return False

    def _start_native_render_watchdog(self):
        try:
            from enigma import eTimer
            if not hasattr(self, "_native_render_timer") or not self._native_render_timer:
                self._native_render_timer = eTimer()
                self._native_render_timer.callback.append(self._on_native_render_check)
            self._native_render_timer.start(6000, True)
        except Exception:
            pass

    def _on_native_render_check(self):
        if not getattr(self, "native_sub_active", False):
            return
        infobar = getattr(self.session, "infobar", None)
        sub_win = getattr(infobar, "subtitle_window", None) if infobar else None
        is_shown = getattr(sub_win, "shown", False) if sub_win else False
        if not is_shown:
            self.audio_fallback_reason = "مسار ترجمة القناة الأصلية لم يظهر خلال 6 ثوانٍ"
            print(f"[EnigmaTranslate] [NATIVE SUB] Native dst_lang track did not render within 6s -> Falling back to Teletext / STT! Reason: {self.audio_fallback_reason}")
            self._disable_native_sub()
            self.ignored_epg_event = self.get_current_epg_event_id()
            self.native_sub_active = False
            self.plugin_enabled_track = None
            self.stop()
            self.start(force_audio=False)

    def _disable_native_sub(self):
        """Disable any active native subtitle in Enigma2 player."""
        if hasattr(self, "_native_render_timer") and self._native_render_timer:
            try:
                self._native_render_timer.stop()
            except Exception:
                pass
        infobar = getattr(self.session, "infobar", None)
        if not infobar:
            try:
                from Screens.InfoBar import InfoBar
                infobar = InfoBar.instance
            except Exception:
                pass
        if not infobar and self.session:
            for d in getattr(self.session, "dialog_stack", []):
                if hasattr(d, "enableSubtitle"):
                    infobar = d
                    break
        if infobar:
            try:
                if hasattr(infobar, "enableSubtitle"):
                    infobar.enableSubtitle(None)
                sub_win = getattr(infobar, "subtitle_window", None)
                if sub_win:
                    sub_win.hide()
                print("[EnigmaTranslate] [NATIVE SUB] Native subtitle track disabled.")
            except Exception as e:
                print(f"[EnigmaTranslate] [NATIVE SUB] _disable_native_sub error: {e}")

    def _suppress_native_subtitles(self):
        """Hide the channel's own DVB subtitle overlay while ours is shown (no overlap)."""
        try:
            infobar = getattr(self.session, "infobar", None)
            if not infobar and self.session:
                for d in getattr(self.session, "dialog_stack", []):
                    if hasattr(d, "enableSubtitle"):
                        infobar = d
                        break
            if infobar:
                cur_selected = getattr(infobar, "selected_subtitle", None)
                if cur_selected and cur_selected != getattr(self, "plugin_enabled_track", None):
                    self.suppressed_native_sub_track = cur_selected
                    print(f"[EnigmaTranslate] [OVERLAP FIX] Suppressing channel DVB subtitle overlay: {cur_selected}")
                if hasattr(infobar, "enableSubtitle") and not getattr(self, "native_sub_active", False):
                    infobar.enableSubtitle(None)
                sub_win = getattr(infobar, "subtitle_window", None)
                if sub_win and not getattr(self, "native_sub_active", False):
                    sub_win.hide()
        except Exception as e:
            print(f"[EnigmaTranslate] _suppress_native_subtitles error: {e}")

    def on_subtitle_button_pressed(self):
        """Handle short SUBTITLE press."""
        # 1. IPTV Relay check: if IPTV channel (4097/5001/5002) and iptv_relay setting is ON, toggle relay (Phase 1)
        cfg_relay = getattr(getattr(settings.config.plugins, "enigmatranslate", None), "iptv_relay", None)
        relay_setting = getattr(cfg_relay, "value", "on") if cfg_relay else "on"

        is_iptv = is_iptv_service(self.current_service_ref)
        parts = str(self.current_service_ref or "").split(":")
        stype = parts[0] if parts else ""
        if stype in ("4097", "5001", "5002"):
            is_iptv = True

        if is_iptv and relay_setting == "on":
            return self.toggle_iptv_relay()

        # If native sub is active, switch to next translated priority (teletext > DVB > SRT > audio) for this programme
        if getattr(self, "native_sub_active", False):
            print("[EnigmaTranslate] SUBTITLE pressed while native track active -> Switching to translated subtitles for current programme.")
            self._disable_native_sub()
            self.ignored_epg_event = self.get_current_epg_event_id()
            self.native_sub_active = False
            self.plugin_enabled_track = None
            self.stop()
            self.show_status("جاري تشغيل الترجمة الفورية…", duration=3.0, force=True)
            self.start()
            return True
        return self.toggle_with_toast()

    def on_sync_key_event(self, earlier=False):
        """Handle quick subtitle sync key event with repeat detection and 0.8s long-press reset."""
        if not self.running:
            return

        now = time.time()
        last_time = getattr(self, "_sync_key_last_time", 0.0)
        last_earlier = getattr(self, "_sync_key_last_earlier", None)
        delta = now - last_time

        if delta > 0.55 or (last_earlier is not None and last_earlier != earlier):
            # Manual new tap
            self._sync_key_press_start = now
            self._sync_key_last_time = now
            self._sync_key_last_earlier = earlier
            self._sync_repeat_count = 0
            self._sync_key_reset_triggered = False
            self.nudge_sync(earlier=earlier, reset=False)
        else:
            # Rapid repeat burst (remote key held down)
            self._sync_key_last_time = now
            self._sync_repeat_count = getattr(self, "_sync_repeat_count", 0) + 1
            hold_dur = now - getattr(self, "_sync_key_press_start", now)
            if hold_dur >= 0.8 and not getattr(self, "_sync_key_reset_triggered", False):
                self._sync_key_reset_triggered = True
                self.nudge_sync(reset=True)

    def nudge_sync(self, earlier=False, reset=False):
        """Quick manual subtitle sync adjustment from remote control (±0.5s or reset)."""
        if not self.running:
            return

        sref = self.current_service_ref
        if not sref:
            return

        cur_delay = float(self.get_effective_setting("delay") or 0.0)
        srt_mode = bool(getattr(self, "srt_synchronizer", None) and self.srt_synchronizer.locked)

        if reset:
            new_delay = 0.0
            bridge_adjusted = False
        elif srt_mode:
            # In SRT mode: change offset directly
            new_delay = round(cur_delay - 0.5 if earlier else cur_delay + 0.5, 1)
            bridge_adjusted = False
        else:
            # Audio STT mode:
            if not earlier:
                # "later" just delays cues
                new_delay = round(cur_delay + 0.5, 1)
                bridge_adjusted = False
            else:
                # "earlier":
                if cur_delay > 0.0:
                    new_delay = round(cur_delay - 0.5, 1)
                    bridge_adjusted = False
                else:
                    ttx_mode = bool(self.tap_manager and getattr(self.tap_manager, "active_kind", "") == "teletext")
                    bridge_allowed = bool(
                        (self.get_effective_setting("bridge") or (getattr(self, "relay_active", False) and getattr(self, "current_bridge_sec", 0.0) > 0))
                        and not self.get_effective_setting("no_timeshift_playback")
                        and not ttx_mode
                    )
                    if bridge_allowed:
                        if getattr(self, "relay_active", False):
                            if hasattr(self, "relay_mgr") and self.relay_mgr and getattr(self.relay_mgr, "delay_buffer", None):
                                self.relay_mgr.delay_buffer.target_delay_sec += 0.5
                                self.relay_mgr.target_delay_sec += 0.5
                            self.current_bridge_sec += 0.5
                            self.target_bridge_sec += 0.5
                            if hasattr(self, "channel_bridges"):
                                self.channel_bridges[sref] = self.current_bridge_sec
                                self._save_channel_bridges()
                            new_delay = round(cur_delay - 0.5, 1)
                            bridge_adjusted = True
                        else:
                            self._apply_bridge_delta(0.5)
                            self.current_bridge_sec += 0.5
                            self.target_bridge_sec += 0.5
                            if hasattr(self, "channel_bridges"):
                                self.channel_bridges[sref] = self.current_bridge_sec
                                self._save_channel_bridges()
                            new_delay = round(cur_delay - 0.5, 1)
                            bridge_adjusted = True
                    else:
                        self.show_transient_status(custom_msg="الترجمة: لا يمكن التقديم أكثر", duration=2.5, force=True)
                        return

        # Save per channel automatically
        self.channel_profiles.setdefault(sref, {})["delay"] = f"{new_delay:.1f}"
        self.save_profiles()

        # Update global config selection if matching choice exists
        cfg = getattr(settings.config.plugins, "enigmatranslate", None)
        if cfg and hasattr(cfg, "delay"):
            try:
                cfg.delay.value = settings.delay_to_choice(new_delay)
            except Exception:
                pass

        # Apply to pending cues in Audio STT mode
        if not srt_mode:
            delta = -0.5 if earlier else 0.5
            if reset:
                delta = -cur_delay
            if not bridge_adjusted and delta != 0:
                now = time.time()
                for s in self.pending_subs:
                    s["display_at"] = max(now, s.get("display_at", now) + delta)
        else:
            self._last_srt_text = None

        # Show toast: "الترجمة: +1.0 ث" (Latin numbers wrapped in isolates)
        if abs(new_delay) < 0.01:
            num_str = "0.0"
        elif new_delay > 0:
            num_str = f"+{new_delay:.1f}"
        else:
            num_str = f"{new_delay:.1f}"

        toast_msg = f"الترجمة: \u2066\u200e{num_str}\u2069\u200e ث"
        self.show_transient_status(custom_msg=toast_msg, duration=2.5, force=True)
        print(f"[EnigmaTranslate] [SYNC NUDGE] earlier={earlier} reset={reset} delay={new_delay:.1f}s toast='{toast_msg}'")

    def check_native_subtitles(self):
        """Smart priority per channel: check if a subtitle track exists in dst_lang."""
        if not self.session:
            return False

        # Per-channel setting: "تجاهل ترجمة القناة" (always use our translation)
        if self.get_effective_setting("ignore_native_subs"):
            print(f"[EnigmaTranslate] [NATIVE SUB] 'ignore_native_subs' is active for '{self.current_service_name}' -> Skipping native subtitles.")
            return False

        # Remember audio override until EPG event changes
        cur_ev = self.get_current_epg_event_id()
        if getattr(self, "ignored_epg_event", None) and self.ignored_epg_event == cur_ev:
            print(f"[EnigmaTranslate] [NATIVE SUB] Native track ignored for current programme ({cur_ev}) -> Skipping native subtitles.")
            return False

        dst_lang = (self.get_effective_setting("dst_lang") or "ar").lower()
        target_codes = {
            "ar": ["ara", "ar", "arabic"],
            "en": ["eng", "en", "english"],
            "tr": ["tur", "tr", "turkish"],
            "fr": ["fra", "fre", "fr", "french"],
            "de": ["deu", "ger", "de", "german"],
            "es": ["spa", "es", "spanish"]
        }
        match_codes = target_codes.get(dst_lang, [dst_lang])

        print(f"[EnigmaTranslate] [NATIVE SUB SCAN] Scanning tracks for service '{self.current_service_name}' ({self.current_service_ref}) - dst_lang='{dst_lang}' (matching={match_codes})")

        infobar = getattr(self.session, "infobar", None)
        if not infobar:
            for d in getattr(self.session, "dialog_stack", []):
                if hasattr(d, "enableSubtitle"):
                    infobar = d
                    break

        service = self.session.nav.getCurrentService() if self.session and self.session.nav else None
        sub_handler = None
        if service:
            if hasattr(service, "subtitle"):
                try:
                    sub_handler = service.subtitle()
                except Exception:
                    pass
            if not sub_handler and hasattr(service, "subtitles"):
                try:
                    sub_handler = service.subtitles()
                except Exception:
                    pass

        sub_list = []
        if sub_handler and hasattr(sub_handler, "getSubtitleList"):
            try:
                sub_list = sub_handler.getSubtitleList() or []
            except Exception:
                sub_list = []

        if not sub_list and infobar and hasattr(infobar, "getCurrentServiceSubtitle"):
            try:
                sh = infobar.getCurrentServiceSubtitle()
                if sh and hasattr(sh, "getSubtitleList"):
                    sub_list = sh.getSubtitleList() or []
            except Exception:
                sub_list = []

        if not sub_list and self.current_service_ref and not getattr(self, "is_encrypted", False):
            try:
                stream_port = getattr(settings.config.plugins.enigmatranslate.stream_port, "value", 8001)
                url = f"http://127.0.0.1:{stream_port}/{self.current_service_ref}"
                res = subprocess.run(
                    ["ffprobe", "-v", "error", "-select_streams", "s",
                     "-show_entries", "stream=index,codec_name,id:stream_tags=language",
                     "-of", "json", "-probesize", "500000", "-analyzeduration", "1000000", url],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=2.5, text=True
                )
                data = json.loads(res.stdout)
                for s in data.get("streams", []):
                    lang = (s.get("tags", {}).get("language") or "").lower()
                    codec = s.get("codec_name", "")
                    pid_hex = s.get("id", "0")
                    pid = int(pid_hex, 16) if str(pid_hex).startswith("0x") else int(pid_hex)
                    sub_type = 1 if "teletext" in codec else 0
                    sub_list.append((sub_type, pid, 1, 1, lang))
            except Exception:
                pass

        print(f"[EnigmaTranslate] [NATIVE SUB SCAN] Found {len(sub_list)} tracks: {sub_list}")

        self.channel_has_text_subs = any(isinstance(t, (list, tuple)) and len(t) >= 1 and t[0] == 1 for t in sub_list)

        matched_track = None
        for track in sub_list:
            t_lang = ""
            if isinstance(track, (list, tuple)) and len(track) >= 5:
                t_lang = str(track[4]).lower()
            elif hasattr(track, "getLanguage"):
                try:
                    t_lang = str(track.getLanguage() or "").lower()
                except Exception:
                    pass
            elif hasattr(track, "language"):
                t_lang = str(track.language).lower()
            elif hasattr(track, "getDescription"):
                try:
                    t_lang = str(track.getDescription() or "").lower()
                except Exception:
                    pass
            if not t_lang and isinstance(track, (list, tuple)):
                t_lang = " ".join(str(x).lower() for x in track)

            if any(mc in t_lang for mc in match_codes):
                matched_track = track
                break

        if matched_track is not None:
            print(f"[EnigmaTranslate] [NATIVE SUB DECISION] Matched native track: {matched_track} in dst_lang='{dst_lang}' -> Enabling native subtitle, bypassing taps.")
            if threading.current_thread() is threading.main_thread():
                return self._do_enable_native_sub(matched_track)
            else:
                self.gui_q.put(("enable_native_sub", matched_track))
                self.native_sub_active = True
                return True
        else:
            print(f"[EnigmaTranslate] [NATIVE SUB DECISION] No native track matching dst_lang='{dst_lang}' found in {sub_list} -> Proceeding to taps.")

        return False

    def get_best_audio_track_index(self):
        """Find and return best audio track index (original language: eng/qaa/qor/original)."""
        tracks = []
        # Method 1: Web API getaudiotracks
        try:
            import urllib.request
            import xml.etree.ElementTree as ET
            req = urllib.request.Request("http://127.0.0.1/web/getaudiotracks", headers={"User-Agent": "EnigmaTranslate/1.0"})
            with urllib.request.urlopen(req, timeout=1.5) as resp:
                root = ET.fromstring(resp.read())
                for i, tr in enumerate(root.findall(".//e2audiotrack")):
                    desc = tr.findtext("e2audiotrackdescription") or ""
                    act = (tr.findtext("e2audiotrackactive") or "").lower() == "true"
                    pid = tr.findtext("e2audiotrackpid") or ""
                    tracks.append({"index": i, "desc": desc, "active": act, "pid": pid})
        except Exception:
            pass

        # Method 2: C++ API fallback if Web API returned nothing
        if not tracks and self.session and hasattr(self.session, "nav"):
            try:
                srv = self.session.nav.getCurrentService()
                audio = srv and srv.audioTracks()
                if audio:
                    n = audio.getNumberOfTracks()
                    for i in range(n):
                        info = audio.getTrackInfo(i)
                        desc = f"{info.getDescription()} ({info.getLanguage()})"
                        tracks.append({"index": i, "desc": desc, "active": False, "pid": ""})
            except Exception:
                pass

        if not tracks:
            print("[EnigmaTranslate] Audio track list: None detected -> using default track 0")
            return 0

        track_logs = [f"{t['index']}:{t['desc']}" for t in tracks]
        chosen_idx = 0
        chosen_desc = tracks[0]["desc"]

        # 1. Search for original-language track
        orig_kw = ["eng", "english", "qaa", "qor", "original", "org", "und"]
        matched = False
        for t in tracks:
            d_lower = t["desc"].lower()
            if any(k in d_lower for k in orig_kw):
                chosen_idx = t["index"]
                chosen_desc = t["desc"]
                matched = True
                break

        # 2. If no original-language track matched, check if an active track exists
        if not matched:
            for t in tracks:
                if t["active"]:
                    chosen_idx = t["index"]
                    chosen_desc = t["desc"]
                    break

        print(f"[EnigmaTranslate] Audio track list: {', '.join(track_logs)} -> selected track {chosen_idx} ({chosen_desc})")
        return chosen_idx

    def start(self, force_audio=False):
        """Start translation capture and worker threads guarded by crash shield."""
        is_iptv = is_iptv_service(self.current_service_ref)
        try:
            self._start_internal(force_audio=force_audio)
        except Exception as e:
            print(f"[EnigmaTranslate] [CRASH SHIELD] Unhandled exception in start(): {e}")
            if is_iptv or is_iptv_service(self.current_service_ref):
                self.show_status("تعذر تشغيل الترجمة لقناة IPTV هذه", duration=4.0)
            self.stop()

    def _start_internal(self, force_audio=False):
        """Internal worker to start translation capture and pipeline."""
        if getattr(self, "session_disabled", False):
            print("[EnigmaTranslate] Controller.start() skipped - translation disabled for this session.")
            return

        print(f"[EnigmaTranslate] Controller.start() called - running={self.running}, service='{self.current_service_name}' ({self.current_service_ref})")
        if self.running:
            return

        if not self.current_service_ref and self.session:
            try:
                ref = self.session.nav.getCurrentlyPlayingServiceReference()
                if ref:
                    self.current_service_ref = ref.toString()
                    service = self.session.nav.getCurrentService()
                    if service:
                        info = service.info()
                        self.current_service_name = info.getName() if info else ""
            except Exception:
                pass

        if not self.current_service_ref:
            return

        is_iptv = is_iptv_service(self.current_service_ref)

        self.start_time = time.time()
        self.pmt_sub_checked = False
        self.audio_track_settled = False

        self.load_profiles()
        service = self.session.nav.getCurrentService() if self.session and self.session.nav else None
        self.is_encrypted = is_service_encrypted(service=service, service_ref=self.current_service_ref)

        # Priority 1: Check if channel has native subtitle in dst_lang (e.g. 'ara')
        if not force_audio and self.check_native_subtitles():
            print("[EnigmaTranslate] Native subtitle activated in dst_lang. Plugin translation taps bypassed.")
            self.running = True
            return

        # Smart source selection on start: probe channel tracks first
        mode = self.get_effective_setting("source") or "auto"
        has_ttx = False
        ttx_pid, ttx_page, ttx_lang = None, 888, "dut"
        has_dvb_sub = False
        dvb_sub_pid, dvb_sub_lang = None, "cro"

        if not is_iptv and not force_audio:
            if mode in ("auto", "teletext"):
                has_ttx, ttx_pid, ttx_page, ttx_lang = self.detect_teletext_info()
            if mode in ("auto", "dvb_sub"):
                has_dvb_sub, dvb_sub_pid, dvb_sub_lang = self.detect_dvb_sub_info()

            if has_ttx and has_dvb_sub and mode == "auto":
                ttx_l = str(ttx_lang or "").lower()
                dvb_l = str(dvb_sub_lang or "").lower()
                cfg_src = (self.get_effective_setting("src_lang") or "auto").lower()
                if cfg_src in (dvb_l, "cro", "hrv") and cfg_src not in (ttx_l, "dut"):
                    has_ttx = False
                elif ttx_l in ("est", "und") and dvb_l in ("hrv", "cro", "eng", "srp"):
                    has_ttx = False

        has_srt = bool(getattr(self, "srt_synchronizer", None) and self.srt_synchronizer.locked and not force_audio)

        # Priority: native target-language sub > teletext > foreign DVB-SUB > SRT > audio
        chosen_source = "audio"
        toast_msg = "ترجمة صوتية"

        if has_ttx and not force_audio:
            chosen_source = "teletext"
            self.channel_has_teletext_subs = True
            self.channel_has_dvb_subs = False
            self.teletext_pid = ttx_pid
            self.teletext_page = ttx_page
            self.teletext_lang = ttx_lang
            self.current_bridge_sec = 0.0
            self.target_bridge_sec = 0.0
            toast_msg = "تيليتكست"
            print(f"[EnigmaTranslate] [SOURCE SELECT] Teletext page {ttx_page} (PID {ttx_pid}, lang '{ttx_lang}') active -> 0 bridge delay.")
        elif has_dvb_sub and not force_audio:
            chosen_source = "dvb_sub"
            self.channel_has_dvb_subs = True
            self.channel_has_teletext_subs = False
            self.dvb_sub_pid = dvb_sub_pid
            self.dvb_sub_lang = dvb_sub_lang
            saved_b = self.channel_bridges.get(self.current_service_ref) if hasattr(self, "channel_bridges") else None
            if saved_b is not None and float(saved_b) >= 4.0:
                self.current_bridge_sec = max(5.0, min(8.0, float(saved_b)))
            else:
                self.current_bridge_sec = 6.0
            self.target_bridge_sec = self.current_bridge_sec
            toast_msg = "ترجمة القناة (DVB)"
            print(f"[EnigmaTranslate] [SOURCE SELECT] DVB subtitle PID {dvb_sub_pid} (lang '{dvb_sub_lang}') active -> Time-Bridge {self.current_bridge_sec:.1f}s.")
        elif has_srt:
            chosen_source = "srt"
            self.channel_has_dvb_subs = False
            self.channel_has_teletext_subs = False
            toast_msg = "ترجمة جاهزة"
            print("[EnigmaTranslate] [SOURCE SELECT] SRT subtitle active.")
        else:
            chosen_source = "audio"
            self.channel_has_dvb_subs = False
            self.channel_has_teletext_subs = False
            toast_msg = "ترجمة صوتية"
            reasons = []
            if force_audio:
                reasons.append("طلب ترجمة صوتية مباشرة (force_audio)")
            if is_iptv:
                reasons.append("بث IPTV بدون قنوات ترجمة DVB")
            if not has_ttx and not is_iptv:
                reasons.append("لا توجد صفحات تيليتكست")
            if not has_dvb_sub and not is_iptv:
                reasons.append("لا توجد مسارات ترجمة DVB-SUB في PMT")
            if not has_srt:
                reasons.append("لا يوجد ملف SRT متزامن")
            self.audio_fallback_reason = " · ".join(reasons) if reasons else "المصدر الافتراضي"
            print(f"[EnigmaTranslate] [SOURCE SELECT] Audio STT active. Reason: {self.audio_fallback_reason}")

        # Show the toast of the REAL source: "ترجمة القناة (DVB)" / "تيليتكست" / "ترجمة جاهزة" / "ترجمة صوتية". Never announce audio when another source is used.
        self.show_status(toast_msg, duration=4.0, force=True)

        # Timeshift and audio/subtitle source setup for encrypted channels
        timeshift_file = None
        if self.is_encrypted:
            print(f"[EnigmaTranslate] Service '{self.current_service_name}' is ENCRYPTED. Selected source: {chosen_source}")
            no_ts_playback = bool(self.get_effective_setting("no_timeshift_playback"))
            if chosen_source == "teletext" or no_ts_playback or not self.get_effective_setting("bridge"):
                self.current_bridge_sec = 0.0
                self.target_bridge_sec = 0.0
                try:
                    from Screens.InfoBar import InfoBar
                    ib = InfoBar.instance if InfoBar else None
                    ts = ib.getTimeshift() if (ib and hasattr(ib, "getTimeshift")) else None
                    if ts and hasattr(ts, "isTimeshiftActive") and ts.isTimeshiftActive():
                        if ib and hasattr(ib, "stopTimeshift"):
                            ib.stopTimeshift()
                    if self.session and hasattr(self.session, "nav"):
                        self.session.nav.pause(False)
                except Exception:
                    pass
                self._start_background_timeshift()
                timeshift_file = find_active_timeshift_file()
                if not timeshift_file:
                    timeshift_file = self._start_background_recording()
            elif chosen_source == "dvb_sub":
                if self.is_timeshift_disk_available() and not self.is_channel_paused:
                    self._engage_time_bridge(bridge_sec=self.current_bridge_sec)
                timeshift_file = find_active_timeshift_file()
            elif self.is_timeshift_disk_available():
                if not self.is_channel_paused:
                    self._engage_time_bridge()
                timeshift_file = find_active_timeshift_file()

            # For audio STT mode only: verify timeshift buffer exists
            if chosen_source == "audio" and not (timeshift_file and os.path.exists(timeshift_file) and os.path.getsize(timeshift_file) > 0):
                if threading.current_thread() is threading.main_thread():
                    poll_count = getattr(self, "_ts_poll_count", 0)
                    if poll_count < 10:
                        self._ts_poll_count = poll_count + 1
                        try:
                            from enigma import eTimer
                            if not hasattr(self, "_ts_poll_timer") or not self._ts_poll_timer:
                                self._ts_poll_timer = eTimer()
                                self._ts_poll_timer.callback.append(lambda: self.start(force_audio=force_audio))
                            self._ts_poll_timer.start(500, True)
                            return
                        except Exception:
                            pass
                else:
                    for _ in range(10):
                        timeshift_file = getattr(self, "bg_record_file", None) or find_active_timeshift_file()
                        if timeshift_file and os.path.exists(timeshift_file) and os.path.getsize(timeshift_file) > 0:
                            break
                        time.sleep(0.3)

            self._ts_poll_count = 0

            if chosen_source == "audio" and not timeshift_file:
                print("[EnigmaTranslate] Encrypted channel with no safe source -> Audio capture disabled to protect softcam.")
                self.show_status("قناة مشفرة: الترجمة الصوتية غير متاحة", duration=5.0)
                if self.toast:
                    self.toast.show_status("قناة مشفرة: الترجمة الصوتية غير متاحة", duration=5.0)
                self.running = False
                return
            else:
                if chosen_source in ("dvb_sub", "teletext"):
                    stream_port = getattr(settings.config.plugins.enigmatranslate.stream_port, "value", 8001)
                    url = serviceref_to_stream_url(self.current_service_ref, port=stream_port)
                else:
                    url = ""
        else:
            is_iptv = is_iptv_service(self.current_service_ref)
            if is_iptv:
                # The IPTV relay must NEVER start by itself.
                # Only on_subtitle_button_pressed -> toggle_iptv_relay can start it.
                if getattr(self, "relay_active", False):
                    url = ""
                else:
                    cfg_elem = getattr(getattr(settings.config.plugins, "enigmatranslate", None), "iptv_relay", None)
                    relay_opt = getattr(cfg_elem, "value", "on") if cfg_elem else "on"
                    if relay_opt == "on":
                        print("[EnigmaTranslate] [IPTV] IPTV relay only starts via SUBTITLE press. Ignoring generic start.")
                        return
                    else:
                        print(f"[EnigmaTranslate] [IPTV] IPTV relay is disabled ('{relay_opt}') -> direct playback without relay.")
                        parts = str(self.current_service_ref or "").split(":")
                        raw_f10 = parts[10] if len(parts) >= 11 else ""
                        from .iptv_relay import parse_enigma2_stream_url
                        clean_u, _ = parse_enigma2_stream_url(raw_f10)
                        url = clean_u
            else:
                stream_port = getattr(settings.config.plugins.enigmatranslate.stream_port, "value", 8001)
                url = serviceref_to_stream_url(self.current_service_ref, port=stream_port)

        self.running = True

        # Clear queues
        while not self.raw_q.empty():
            try:
                self.raw_q.get_nowait()
            except Exception:
                break
        while not self.gui_q.empty():
            try:
                self.gui_q.get_nowait()
            except Exception:
                break

        self.context_lines.clear()

        self.update_content_type_and_context()
        mode = self.get_effective_setting("source") or "auto"
        src_lang = self.get_effective_setting("src_lang") or "auto"
        stt_engine = self.get_effective_setting("stt_engine") or "vosk"
        stt_chunk_sec = self.get_effective_setting("stt_chunk_sec") or getattr(
            settings.config.plugins.enigmatranslate.stt_chunk_sec, "value", 10
        )
        whisper_prompt = self.get_effective_setting("whisper_prompt")
        if not whisper_prompt:
            whisper_prompt = getattr(self, "active_whisper_prompt", None)
        sub_index = getattr(settings.config.plugins.enigmatranslate.sub_index, "value", 0)
        vosk_dir = getattr(settings.config.plugins.enigmatranslate.vosk_dir, "value", "/etc/enigma2/enigmatranslate/vosk")
        ffmpeg_bin = getattr(settings.config.plugins.enigmatranslate.ffmpeg, "value", "ffmpeg")

        # Hide native subtitle overlay to prevent overlap while our translation runs
        self._suppress_native_subtitles()

        try:
            audio_idx = 0 if is_iptv else self.get_best_audio_track_index()
            self.tap_manager = TapManager(
                stream_url=url,
                mode=mode,
                src_lang=src_lang,
                sub_index=sub_index,
                audio_track_idx=audio_idx,
                vosk_dir=vosk_dir,
                ffmpeg_bin=ffmpeg_bin,
                status_cb=self._on_tap_status,
                safe_mode_getter=lambda: self.safe_mode_active,
                stt_engine=stt_engine,
                chunk_sec=stt_chunk_sec,
                prompt=whisper_prompt,
                native_sub_checker=self.check_native_subtitles,
                has_text_subs=getattr(self, "channel_has_text_subs", False),
                sample_needed_getter=self.is_stt_sample_needed,
                timeshift_file=timeshift_file,
                is_encrypted=self.is_encrypted,
                teletext_pid=ttx_pid,
                teletext_page=ttx_page,
                has_teletext_subs=has_ttx,
                has_dvb_subs=has_dvb_sub,
                dvb_sub_pid=dvb_sub_pid,
                dvb_sub_lang=dvb_sub_lang,
                on_clear_cb=self._on_dvb_or_ttx_clear
            )
            self.tap_manager.raw_q = self.raw_q
            self.tap_manager.start()
        except Exception as e:
            print(f"[EnigmaTranslate] [CRASH SHIELD] Error starting tap manager: {e}")
            if is_iptv:
                self.show_status("تعذر تشغيل الترجمة لقناة IPTV هذه", duration=4.0)
            self.running = False
            return

        # Start translator thread
        self.translator_stop_event.clear()
        self.translator_thread = threading.Thread(target=self._translator_worker, daemon=True, name="ET_Translator")
        self.translator_thread.start()

        # Handle Time-Bridge if enabled or DVB-SUB, not IPTV, not teletext, and not already engaged
        if not is_iptv and not has_ttx and mode != "teletext" and not self.get_effective_setting("no_timeshift_playback") and (self.get_effective_setting("bridge") or has_dvb_sub) and not self.is_channel_paused:
            self._engage_time_bridge()

        # Ensure OSD is active
        self._ensure_osd()

        # Requirement 3: Keep playback watchdog active in every mode throughout the session
        self._start_playback_watchdog()

    def _prompt_iptv_second_connection(self, provider_key):
        """Ask user once if second IPTV connection is allowed for this provider, guaranteed on GUI main thread."""
        def _do_open():
            if not self.session:
                return
            try:
                from Screens.MessageBox import MessageBox
                msg = "فتح اتصال ثانٍ قد يقطع البث إذا اشتراكك يسمح باتصال واحد. متابعة؟"
                self.session.openWithCallback(
                    lambda confirmed: self._on_iptv_second_conn_choice(provider_key, confirmed),
                    MessageBox,
                    msg,
                    MessageBox.TYPE_YESNO
                )
            except Exception as e:
                print(f"[EnigmaTranslate] [IPTV CRASH SHIELD] Failed to open IPTV confirmation prompt: {e}")
                self.show_status("تعذر فتح تأكيد IPTV", duration=3.0)

        try:
            from enigma import eTimer
            self._iptv_timer = eTimer()
            self._iptv_timer.callback.append(_do_open)
            self._iptv_timer.start(50, True)
        except Exception:
            try:
                from twisted.internet import reactor
                reactor.callFromThread(_do_open)
            except Exception:
                _do_open()

    def _on_iptv_second_conn_choice(self, provider_key, confirmed):
        """Callback from MessageBox for IPTV second connection choice."""
        try:
            settings.set_iptv_policy(provider_key, bool(confirmed))
            if confirmed:
                print(f"[EnigmaTranslate] [IPTV] User allowed second connection for '{provider_key}'")
                self.start(force_audio=True)
            else:
                print(f"[EnigmaTranslate] [IPTV] User denied second connection for '{provider_key}'")
                self.show_status("تم إلغاء فتح اتصال ثانٍ لحماية البث", duration=4.0)
        except Exception as e:
            print(f"[EnigmaTranslate] [IPTV CRASH SHIELD] Error handling user choice: {e}")
            self.show_status("تعذر حفظ خيار IPTV", duration=3.0)

    def get_effective_display_duration(self, text="", natural_dur=None):
        """Calculate display duration respecting user setting.
        
        Options:
        - 'auto': current length-based formula (or segment natural duration)
        - '1', '2', '3', '4', '5', '6', '8': fixed minimum seconds (stays at least that long unless next line arrives)
        - 'until_next': holds line until the next line replaces it (virtually infinite timer)
        """
        setting_val = str(self.get_effective_setting("sub_duration") or "auto").strip()
        if setting_val == "until_next":
            return 3600.0

        if natural_dur is not None and natural_dur > 0:
            calc_dur = max(MIN_DURATION, min(MAX_DURATION, natural_dur))
        else:
            calc_dur = max(MIN_DURATION, min(MAX_DURATION, len(text) / DEFAULT_CPS)) if text else 3.0

        if setting_val == "auto" or not setting_val:
            return calc_dur

        try:
            min_sec = float(setting_val)
            return max(calc_dur, min_sec)
        except (ValueError, TypeError):
            return calc_dur

    def _on_dvb_or_ttx_clear(self, pts_or_page=None):
        """Called when a clear segment or page erase arrives (empty page = hide)."""
        bridge = getattr(self, "current_bridge_sec", 0.0)
        now = time.time()
        nominal_hide_at = now + bridge
        self.gui_q.put(("hide_subtitle_at", nominal_hide_at))

    def _on_teletext_clear(self, page):
        self._on_dvb_or_ttx_clear(page)

    def detect_dvb_sub_info(self, timeshift_file=None):
        """Auto-detect DVB subtitle track (PMT tag 0x59 or Enigma2 subtitle track type 0)."""
        candidates = []
        cfg_src = (self.get_effective_setting("src_lang") or "auto").lower()

        def rate_track(pid, lang):
            l = str(lang or "").lower().strip()
            score = 10
            if cfg_src not in ("auto", "") and (cfg_src == l or cfg_src in l or l in cfg_src):
                score = 200
            elif l in ("hrv", "cro", "hr"):
                score = 120
            elif l in ("srp", "sr", "bos", "bs"):
                score = 100
            elif l in ("eng", "en"):
                score = 90
            elif l in ("deu", "ger", "de", "fra", "fre", "fr", "ita", "it", "spa", "es"):
                score = 70
            elif l:
                score = 40
            return (score, pid, l or "cro")

        # 1. Check Enigma2 current service subtitle track list
        try:
            service = self.session.nav.getCurrentService() if (self.session and hasattr(self.session, "nav")) else None
            sub_h = service.subtitle() if (service and hasattr(service, "subtitle")) else None
            if sub_h and hasattr(sub_h, "getSubtitleList"):
                tracks = sub_h.getSubtitleList() or []
                for t in tracks:
                    # Type 0 is DVB Subtitle
                    t_type = getattr(t, "type", None) or (t.getType() if hasattr(t, "getType") else None)
                    if t_type is None and isinstance(t, (list, tuple)) and len(t) >= 1:
                        t_type = t[0]
                    if t_type == 0:
                        t_pid = getattr(t, "pid", None) or (t.getPid() if hasattr(t, "getPid") else None)
                        if t_pid is None and isinstance(t, (list, tuple)) and len(t) >= 2:
                            t_pid = t[1]
                        t_lang = getattr(t, "language", None) or (t.getLanguage() if hasattr(t, "getLanguage") else None)
                        if not t_lang and isinstance(t, (list, tuple)) and len(t) >= 5:
                            t_lang = t[4]
                        if t_pid:
                            candidates.append(rate_track(t_pid, t_lang))
        except Exception:
            pass

        if candidates:
            candidates.sort(key=lambda x: x[0], reverse=True)
            best = candidates[0]
            return True, best[1], best[2]

        # 2. Check PMT descriptor tag 0x59 from timeshift file if available
        source_path = timeshift_file if (timeshift_file and os.path.isfile(timeshift_file)) else None
        if source_path:
            try:
                from .dvb_subtitles import parse_pmt_dvb_sub_descriptors
                sz = os.path.getsize(source_path)
                read_sz = min(sz, 4 * 1024 * 1024)
                with open(source_path, "rb") as f:
                    f.seek(max(0, sz - read_sz))
                    chunk = f.read(read_sz)
                pos = 0
                while pos <= len(chunk) - 188:
                    if chunk[pos] != 0x47:
                        pos += 1
                        continue
                    pkt = chunk[pos : pos + 188]
                    pos += 188
                    b1 = pkt[1]
                    pusi = bool(b1 & 0x40)
                    afc = (pkt[3] & 0x30) >> 4
                    if afc in (0, 2):
                        continue
                    p_off = 4
                    if afc == 3:
                        p_off = 5 + pkt[4]
                        if p_off >= 188:
                            continue
                    if pusi:
                        ptr = pkt[p_off]
                        p_off += 1 + ptr
                        if p_off < len(pkt) and pkt[p_off] == 0x02:
                            res = parse_pmt_dvb_sub_descriptors(pkt[p_off:])
                            if res:
                                rated = [rate_track(r["pid"], r.get("lang", "cro")) for r in res]
                                rated.sort(key=lambda x: x[0], reverse=True)
                                return True, rated[0][1], rated[0][2]
            except Exception:
                pass

        return False, None, None

    def detect_teletext_info(self, timeshift_file=None):
        """Auto-detect Teletext PID and subtitle page (PMT type 2/5) with manual page override."""
        cfg = getattr(settings.config.plugins, "enigmatranslate", None)
        manual_page_val = getattr(cfg.teletext_page, "value", "auto") if cfg else "auto"
        manual_page = None
        if manual_page_val and str(manual_page_val).strip() not in ("auto", ""):
            try:
                manual_page = int(manual_page_val)
            except Exception:
                manual_page = None

        detected_pid = None
        detected_page = manual_page
        detected_lang = "dut"

        # 1. Check Enigma2 Web API /web/getcurrent for e2txtpid
        try:
            import urllib.request
            import xml.etree.ElementTree as ET
            req = urllib.request.Request("http://127.0.0.1/web/getcurrent", headers={"User-Agent": "EnigmaTranslate/1.0"})
            with urllib.request.urlopen(req, timeout=1.0) as resp:
                root = ET.fromstring(resp.read().decode("utf-8", "ignore"))
                txt_elem = root.find(".//e2txtpid")
                if txt_elem is not None and txt_elem.text and txt_elem.text.strip().isdigit():
                    pid_val = int(txt_elem.text.strip())
                    if pid_val > 0:
                        detected_pid = pid_val
        except Exception:
            pass

        # 2. Check PMT teletext descriptor (tag 0x56) from timeshift file
        source_path = timeshift_file if (timeshift_file and os.path.isfile(timeshift_file)) else None
        if source_path:
            try:
                sz = os.path.getsize(source_path)
                read_sz = min(sz, 6 * 1024 * 1024)
                with open(source_path, "rb") as f:
                    f.seek(max(0, sz - read_sz))
                    chunk = f.read(read_sz)
                
                pos = 0
                pmt_sessions = {}
                while pos <= len(chunk) - 188:
                    if chunk[pos] != 0x47:
                        pos += 1
                        continue
                    pkt = chunk[pos : pos + 188]
                    pos += 188
                    b1, b2 = pkt[1], pkt[2]
                    pid = ((b1 & 0x1F) << 8) | b2
                    pusi = (b1 & 0x40) >> 6
                    afc = (pkt[3] & 0x30) >> 4
                    if afc in (0, 2):
                        continue
                    p_off = 4
                    if afc == 3:
                        p_off = 5 + pkt[4]
                        if p_off >= 188:
                            continue
                    if pusi:
                        ptr = pkt[p_off]
                        p_off += 1 + ptr
                        if p_off < len(pkt) and pkt[p_off] == 0x02:
                            sec_len = ((pkt[p_off + 1] & 0x0F) << 8) | pkt[p_off + 2]
                            total_needed = 3 + sec_len
                            pmt_data = bytearray(pkt[p_off:])
                            if len(pmt_data) >= total_needed:
                                from .teletext import parse_pmt_teletext_descriptors
                                descs = parse_pmt_teletext_descriptors(bytes(pmt_data[:total_needed]))
                                for d in descs:
                                    if d.get("is_subtitle"):
                                        detected_pid = d.get("pid", detected_pid)
                                        if detected_page is None:
                                            detected_page = d.get("page", 888)
                                        detected_lang = d.get("lang", detected_lang)
                                        break
                                if detected_pid and detected_page:
                                    break
                            else:
                                pmt_sessions[pid] = (pmt_data, total_needed)
                    elif pid in pmt_sessions:
                        pmt_data, total_needed = pmt_sessions[pid]
                        pmt_data.extend(pkt[p_off:])
                        if len(pmt_data) >= total_needed:
                            del pmt_sessions[pid]
                            from .teletext import parse_pmt_teletext_descriptors
                            descs = parse_pmt_teletext_descriptors(bytes(pmt_data[:total_needed]))
                            for d in descs:
                                if d.get("is_subtitle"):
                                    detected_pid = d.get("pid", detected_pid)
                                    if detected_page is None:
                                        detected_page = d.get("page", 888)
                                    detected_lang = d.get("lang", detected_lang)
                                    break
                            if detected_pid and detected_page:
                                break
            except Exception as e:
                print(f"[EnigmaTranslate] detect_teletext_info PMT error: {e}")

        if detected_pid and detected_page:
            return True, detected_pid, detected_page, detected_lang
        if manual_page:
            return True, detected_pid or 4329, manual_page, "dut"

        return False, None, manual_page or 888, "dut"

    def _kill_ffmpeg_fast(self):
        """Kill ffmpeg: terminate immediately, then kill after 0.5s in background."""
        try:
            import subprocess
            subprocess.run(["pkill", "-15", "-f", "ffmpeg"], timeout=0.2, capture_output=True)
        except Exception:
            pass

        def _bg_kill():
            time.sleep(0.5)
            try:
                import subprocess
                subprocess.run(["pkill", "-9", "-f", "ffmpeg"], timeout=0.2, capture_output=True)
            except Exception:
                pass
        threading.Thread(target=_bg_kill, daemon=True, name="ET_FfmpegKillFallback").start()

    def _stop_all_plugin_timers(self):
        """Stop all eTimers started by the plugin."""
        timer_names = [
            "_playback_watchdog_timer",
            "iptv_bridge_timer",
            "_relay_failsafe_timer",
            "_iptv_restore_timer",
            "_iptv_timer",
            "descramble_timer",
            "settle_timer",
            "disk_monitor_timer",
            "_native_render_timer",
            "_ts_poll_timer",
            "bridge_timer",
            "bridge_adj_timer",
        ]
        for name in timer_names:
            tm = getattr(self, name, None)
            if tm:
                try:
                    tm.stop()
                except Exception:
                    pass
        if getattr(self, "osd", None) and getattr(self.osd, "hide_timer", None):
            try:
                self.osd.hide_timer.stop()
            except Exception:
                pass
        if getattr(self, "toast", None) and getattr(self.toast, "status_timer", None):
            try:
                self.toast.status_timer.stop()
            except Exception:
                pass

    def _verify_and_log_stop_complete(self, elapsed_ms):
        """Check that no ffmpeg process and no plugin worker thread is left."""
        t_deadline = time.time() + 0.05
        leftover_threads = 0
        while time.time() < t_deadline:
            active_worker_threads = [
                t for t in threading.enumerate()
                if t.is_alive() and t != threading.main_thread()
                and t.name != "EnigmaTranslateWeb"
                and t.name != "ET_BgDiskPurge"
                and t.name != "ET_FfmpegKillFallback"
                and (t.name.startswith("ET_") or "EnigmaTranslate" in t.name or "Tap" in t.name or "SRT" in t.name)
            ]
            leftover_threads = len(active_worker_threads)
            if leftover_threads == 0:
                break
            time.sleep(0.01)

        leftover_ffmpeg = 0
        try:
            import subprocess
            res = subprocess.run(["pgrep", "-c", "-f", "ffmpeg"], capture_output=True, text=True, timeout=0.2)
            if res.returncode == 0 and res.stdout.strip().isdigit():
                leftover_ffmpeg = int(res.stdout.strip())
        except Exception:
            pass

        print(f"[EnigmaTranslate] stop complete: {elapsed_ms} ms, threads={leftover_threads}, ffmpeg={leftover_ffmpeg}")

    def stop(self, is_shutdown=False):
        """Fast, complete stop under 1 second in strict order:
        1. hide OSD
        2. restore picture (IPTV: replay original ref; satellite: leave plugin timeshift silently)
        3. signal all workers to stop
        4. kill ffmpeg (terminate, then kill after 0.5 s)
        5. close relay sockets
        6. stop all eTimers
        7. background thread for buffer/disk purge & cache writes
        8. check & log stop complete
        """
        t_start = time.time()
        self.running = False
        self._session_generation = getattr(self, "_session_generation", 0) + 1

        # 1. Hide OSD
        try:
            if self.osd:
                self.osd.hide_subtitle()
        except Exception:
            pass
        try:
            if self.toast:
                self.toast.hide_status()
        except Exception:
            pass
        if getattr(self, "plugin_enabled_track", None) is not None:
            try:
                infobar = getattr(self.session, "infobar", None)
                if not infobar and self.session:
                    for d in getattr(self.session, "dialog_stack", []):
                        if hasattr(d, "enableSubtitle"):
                            infobar = d
                            break
                if infobar and hasattr(infobar, "enableSubtitle"):
                    cur_selected = getattr(infobar, "selected_subtitle", None)
                    if cur_selected == self.plugin_enabled_track:
                        infobar.enableSubtitle(None)
            except Exception:
                pass
            self.plugin_enabled_track = None
            self.native_sub_active = False

        if getattr(self, "suppressed_native_sub_track", None) is not None:
            try:
                infobar = getattr(self.session, "infobar", None)
                if not infobar and self.session:
                    for d in getattr(self.session, "dialog_stack", []):
                        if hasattr(d, "enableSubtitle"):
                            infobar = d
                            break
                if infobar and hasattr(infobar, "enableSubtitle"):
                    print(f"[EnigmaTranslate] [OVERLAP FIX] Restoring suppressed native subtitle track: {self.suppressed_native_sub_track}")
                    infobar.enableSubtitle(self.suppressed_native_sub_track)
            except Exception as e:
                print(f"[EnigmaTranslate] Restore native subtitle error: {e}")
            self.suppressed_native_sub_track = None

        if hasattr(self, "pending_subs") and hasattr(self.pending_subs, "clear"):
            self.pending_subs.clear()
        if hasattr(self, "gui_q"):
            while not self.gui_q.empty():
                try:
                    self.gui_q.get_nowait()
                except Exception:
                    break

        # 2. Restore picture
        # IPTV: replay original ref
        orig_ref = getattr(self, "original_iptv_service_ref", None) or getattr(self, "_relay_orig_ref", None)
        self.original_iptv_service_ref = None
        self._relay_orig_ref = None
        self.relay_active = False
        self.switching_to_relay = False

        if orig_ref and not is_shutdown:
            self.ignore_nav_events_until = time.time() + 5.0
            if self.session and hasattr(self.session, "nav"):
                try:
                    from enigma import eServiceReference
                    sref_obj = eServiceReference(orig_ref)
                except Exception:
                    sref_obj = orig_ref
                try:
                    print(f"[EnigmaTranslate] [RESTORE] Replaying original ref: {orig_ref}")
                    self.session.nav.playService(sref_obj)
                    if hasattr(self, "_start_iptv_restore_verification"):
                        self._start_iptv_restore_verification(orig_ref)
                except Exception as e_res:
                    print(f"[EnigmaTranslate] [RESTORE] Error restoring original ref: {e_res}")

        # Satellite: leave plugin's own timeshift silently
        if getattr(self, "plugin_started_timeshift", False):
            try:
                self._stop_plugin_timeshift_no_dialog(purge_disk_async=True)
            except Exception as e_ts:
                print(f"[EnigmaTranslate] [RESTORE] Error stopping plugin timeshift: {e_ts}")

        try:
            self._stop_background_recording()
        except Exception:
            pass

        # 3. Signal all workers to stop (no join() on GUI thread)
        if getattr(self, "translator_stop_event", None):
            self.translator_stop_event.set()
        if hasattr(self, "raw_q"):
            try:
                self.raw_q.put_nowait((time.time(), None))
            except Exception:
                pass
        self.translator_thread = None

        if getattr(self, "tap_manager", None):
            try:
                self.tap_manager.stop()
            except Exception:
                pass
            self.tap_manager = None

        if getattr(self, "srt_bg_translator", None):
            try:
                self.srt_bg_translator.stop()
                self.srt_bg_translator = None
            except Exception:
                pass
        self.srt_synchronizer = None
        self.srt_active_movie = None
        self.srt_searching = False
        self.srt_active = False
        self._last_srt_text = None

        # 4. Kill ffmpeg (terminate, then kill after 0.5s in background)
        self._kill_ffmpeg_fast()

        # 5. Close relay sockets
        try:
            from .iptv_relay import IPTVRelayManager
            IPTVRelayManager.get_instance().stop_relay()
        except Exception:
            pass

        if getattr(self, "relay_ffmpeg_q", None):
            try:
                from .iptv_relay import IPTVRelayManager
                IPTVRelayManager.get_instance().unsubscribe_ffmpeg(self.relay_ffmpeg_q)
            except Exception:
                pass
            self.relay_ffmpeg_q = None

        # 6. Stop all eTimers
        self._stop_all_plugin_timers()

        # 7. Buffer/disk purge and cache writes run in background thread AFTER picture is restored
        cache_ref = getattr(self, "cache", None)
        def _bg_purge_and_cache():
            try:
                clean_temp_disk_files()
            except Exception:
                pass
            try:
                self._cleanup_our_timeshift_files()
            except Exception:
                pass
            if cache_ref:
                try:
                    cache_ref.save()
                except Exception:
                    pass
        threading.Thread(target=_bg_purge_and_cache, daemon=True, name="ET_BgDiskPurge").start()

        # 8. Check leftover threads and ffmpeg, log stop time
        elapsed_ms = int((time.time() - t_start) * 1000)
        self._verify_and_log_stop_complete(elapsed_ms)

    def toggle(self):
        """Toggle translation on/off (or IPTV relay on IPTV channels)."""
        cfg_relay = getattr(getattr(settings.config.plugins, "enigmatranslate", None), "iptv_relay", None)
        relay_setting = getattr(cfg_relay, "value", "on") if cfg_relay else "on"
        is_iptv = is_iptv_service(self.current_service_ref)
        parts = str(self.current_service_ref or "").split(":")
        stype = parts[0] if parts else ""
        if stype in ("4097", "5001", "5002"):
            is_iptv = True

        if is_iptv and relay_setting == "on":
            return self.toggle_iptv_relay()

        cfg = settings.config.plugins.enigmatranslate
        cfg.enabled.value = not cfg.enabled.value
        cfg.enabled.save()
        print(f"[EnigmaTranslate] Controller.toggle() called -> enabled={cfg.enabled.value}")
        if cfg.enabled.value:
            self.start()
        else:
            self.stop()
        return cfg.enabled.value

    def toggle_with_toast(self):
        """Toggle translation on/off with a toast."""
        cfg_relay = getattr(getattr(settings.config.plugins, "enigmatranslate", None), "iptv_relay", None)
        relay_setting = getattr(cfg_relay, "value", "on") if cfg_relay else "on"
        is_iptv = is_iptv_service(self.current_service_ref)
        parts = str(self.current_service_ref or "").split(":")
        stype = parts[0] if parts else ""
        if stype in ("4097", "5001", "5002"):
            is_iptv = True

        if is_iptv and relay_setting == "on":
            return self.toggle_iptv_relay()

        is_on = self.toggle()
        msg = "الترجمة: تشغيل" if is_on else "الترجمة: إيقاف"
        self.show_status(msg, duration=3.0, force=True)
        return is_on

    def reload(self):
        """Reload configuration, resize cache, and refresh OSD."""
        self.cache.maxsize = getattr(settings.config.plugins.enigmatranslate.cache_size, "value", 2000)
        self.ai_engine.provider = getattr(settings.config.plugins.enigmatranslate.ai_provider, "value", "gemini")
        self.ai_engine.tier = getattr(settings.config.plugins.enigmatranslate.ai_model_tier, "value", "balanced")
        self.ai_engine.models_dict = settings.get_ai_models()
        self.ai_engine.cap = getattr(settings.config.plugins.enigmatranslate.ai_cap, "value", 1000)
        self.ai_engine.context_len = getattr(settings.config.plugins.enigmatranslate.ai_context, "value", 2)
        self.ai_engine.style = getattr(settings.config.plugins.enigmatranslate.ai_style, "value", "natural")
        self.update_content_type_and_context()
        if self.osd:
            self.osd.apply_style()

    def _ensure_osd(self):
        if self.session:
            if self.osd is None:
                try:
                    from .osd import EnigmaTranslateOSD
                    self.osd = self.session.instantiateDialog(EnigmaTranslateOSD)
                except Exception:
                    pass
            if self.toast is None:
                try:
                    from .osd import EnigmaTranslateToast
                    self.toast = self.session.instantiateDialog(EnigmaTranslateToast)
                    if self.osd:
                        self.osd._toast = self.toast
                except Exception:
                    pass

    def _on_tap_status(self, status):
        self.last_status_message = status
        if status == "iptv_single_conn_refusal":
            msg = "اشتراك IPTV يسمح باتصال واحد، فعّل وسيط IPTV من الإعدادات"
            self.gui_q.put(("toast_reason", msg))
            self.show_status(msg, duration=6.0, force=True)
            self.stop()
            return
        elif status == "ffmpeg_audio_failed_after_retries":
            msg = "تعذر استخراج صوت القناة للترجمة"
            self.gui_q.put(("toast_reason", msg))
            self.show_status(msg, duration=5.0, force=True)
            return
        elif status == "stt_error_retry" or "error" in str(status).lower() or "submit_error" in str(status).lower():
            # Requirement 6: Raw engine errors must not show as toasts.
            # Show one Arabic toast: "تعذّر التعرف على الصوت، جاري إعادة المحاولة" and keep details in the log.
            print(f"[EnigmaTranslate] [STT STATUS ERROR] {status}")
            self._unpause_time_bridge()
            now = time.time()
            if now - getattr(self, "_last_stt_err_toast", 0) > 8.0:
                self._last_stt_err_toast = now
                msg = "تعذّر التعرف على الصوت، جاري إعادة المحاولة"
                self.gui_q.put(("toast_reason", msg))
            return
        elif status == "auto_switching_to_audio":
            if self.get_effective_setting("bridge") and not self.is_channel_paused:
                self._engage_time_bridge()
        elif status == "stt_fallback_cloudflare":
            self.gui_q.put(("toast_reason", "تم التحويل إلى Cloudflare"))
        elif status == "stt_fallback_gemini":
            self.gui_q.put(("toast_reason", "تم التحويل إلى Gemini"))
        elif status == "stt_fallback_speechmatics":
            self.gui_q.put(("toast_reason", "تم التحويل إلى Speechmatics"))
        elif status == "stt_fallback_deepgram":
            self.gui_q.put(("toast_reason", "تم التحويل إلى Deepgram"))
        elif status == "stt_fallback_assemblyai":
            self.gui_q.put(("toast_reason", "تم التحويل إلى AssemblyAI"))
        elif status == "stt_fallback_blocked_low_credit":
            self.gui_q.put(("toast_reason", "رصيد المحركات البديلة غير كافٍ (أقل من $1)"))
        else:
            self.gui_q.put(("status", status))

    def _start_background_recording(self):
        """Start a background recording of current service via RecordTimerEntry or eDVBServiceRecord on the same tuner/demux.
        
        Writes descrambled TS to /media/hdd/enigmatranslate/tmp without touching live playback.
        Zero pauseService, zero switchToTimeshift, zero seeking, zero extra ECM session.
        """
        if getattr(self, "bg_record_entry", None) or getattr(self, "bg_record_service", None):
            return self.bg_record_file

        tmp_dir = "/media/hdd/enigmatranslate/tmp"
        if not os.path.exists("/media/hdd"):
            tmp_dir = "/tmp/enigmatranslate/tmp"
        try:
            os.makedirs(tmp_dir, exist_ok=True)
            for f in glob.glob(os.path.join(tmp_dir, "bg_record_*.ts*")):
                try:
                    os.remove(f)
                except Exception:
                    pass
        except Exception:
            pass

        # Resolve service ref safely
        try:
            from enigma import eServiceReference
            ref = eServiceReference(self.current_service_ref) if isinstance(self.current_service_ref, str) else self.current_service_ref
        except Exception:
            ref = self.current_service_ref

        now = int(time.time())

        # Method 1: RecordTimerEntry via nav.RecordTimer
        try:
            if self.session and hasattr(self.session, "nav") and hasattr(self.session.nav, "RecordTimer"):
                from RecordTimer import RecordTimerEntry
                rec_path = os.path.join(tmp_dir, f"bg_record_{now}.ts")
                entry = RecordTimerEntry(
                    ref,
                    begin=now,
                    end=now + 86400,
                    name=f"bg_record_{now}",
                    description="EnigmaTranslate background tap",
                    eit=-1,
                    disabled=False,
                    justplay=False,
                    afterEvent=0,
                    dirname=tmp_dir + "/"
                )
                entry.dontSave = True
                conflicts = self.session.nav.RecordTimer.record(entry)
                if conflicts is None:
                    self.bg_record_entry = entry
                    self.bg_record_file = rec_path
                    print(f"[EnigmaTranslate] [BG RECORD] RecordTimer active for '{self.current_service_name}' -> {self.bg_record_file}")
                    return self.bg_record_file
                else:
                    print(f"[EnigmaTranslate] [BG RECORD] RecordTimer conflicts: {conflicts}")
        except Exception as e:
            print(f"[EnigmaTranslate] [BG RECORD] RecordTimer method error: {e}")

        # Method 2: Direct eDVBServiceRecord
        try:
            if self.session and hasattr(self.session, "nav"):
                rec_srv = self.session.nav.recordService(ref)
                if rec_srv:
                    rec_path = os.path.join(tmp_dir, f"bg_record_{now}.ts")
                    prep_res = rec_srv.prepare(
                        rec_path,
                        now,
                        now + 86400,
                        -1,
                        "EnigmaTranslate",
                        "",
                        "",
                        True,
                        False
                    )
                    if prep_res == 0:
                        start_res = rec_srv.start()
                        if start_res == 0:
                            self.bg_record_service = rec_srv
                            self.bg_record_file = rec_path
                            print(f"[EnigmaTranslate] [BG RECORD] Started background recording on '{self.current_service_name}' -> {self.bg_record_file}")
                            return self.bg_record_file
                        else:
                            print(f"[EnigmaTranslate] [BG RECORD] rec_srv.start() returned {start_res}")
                    else:
                        print(f"[EnigmaTranslate] [BG RECORD] rec_srv.prepare() returned {prep_res}")
                    try:
                        self.session.nav.stopRecordService(rec_srv)
                    except Exception:
                        pass
        except Exception as e:
            print(f"[EnigmaTranslate] [BG RECORD] Exception starting background recording: {e}")

        return None

    def _stop_background_recording(self):
        """Stop background recording and delete temporary files."""
        if getattr(self, "bg_record_entry", None):
            try:
                if self.session and hasattr(self.session, "nav") and hasattr(self.session.nav, "RecordTimer"):
                    self.session.nav.RecordTimer.removeEntry(self.bg_record_entry)
                    print("[EnigmaTranslate] [BG RECORD] Removed RecordTimer entry.")
            except Exception as e:
                print(f"[EnigmaTranslate] [BG RECORD] Stop RecordTimer entry error: {e}")
            self.bg_record_entry = None

        if getattr(self, "bg_record_service", None):
            try:
                self.bg_record_service.stop()
                if self.session and hasattr(self.session, "nav"):
                    self.session.nav.stopRecordService(self.bg_record_service)
                print("[EnigmaTranslate] [BG RECORD] Stopped background recording.")
            except Exception as e:
                print(f"[EnigmaTranslate] [BG RECORD] Stop error: {e}")
            self.bg_record_service = None

        if getattr(self, "bg_record_file", None):
            fpath = self.bg_record_file
            self.bg_record_file = None
            try:
                for cand in glob.glob(fpath + "*"):
                    os.remove(cand)
            except Exception:
                pass

        try:
            tmp_dir = "/media/hdd/enigmatranslate/tmp"
            if os.path.exists(tmp_dir):
                for f in glob.glob(os.path.join(tmp_dir, "bg_record_*")):
                    try:
                        os.remove(f)
                    except Exception:
                        pass
        except Exception:
            pass
        clean_temp_disk_files()

    def _on_disk_monitor_tick(self):
        """Keep a rolling ~2-minute buffer and enforce a hard cap of 2 GB on background recording/timeshift."""
        try:
            # 1. Rolling ~2-minute buffer (250 MB max tail) on active background recording
            rec_file = getattr(self, "bg_record_file", None)
            if rec_file and os.path.isfile(rec_file):
                # 250 MB corresponds to ~2 minutes of 4K 18-20 Mbps TS stream
                punch_hole_in_file(rec_file, 250 * 1024 * 1024)

            # 2. Hard cap of 2 GB on tmp directory
            tmp_dir = "/media/hdd/enigmatranslate/tmp"
            if os.path.isdir(tmp_dir):
                total_bytes = 0
                for fname in os.listdir(tmp_dir):
                    fpath = os.path.join(tmp_dir, fname)
                    if os.path.isfile(fpath):
                        try:
                            total_bytes += os.path.getsize(fpath)
                        except Exception:
                            pass
                if total_bytes > 2 * 1024 * 1024 * 1024:
                    print(f"[EnigmaTranslate] [DISK] Hard cap 2 GB reached ({total_bytes} bytes). Pruning temporary files...")
                    if rec_file and os.path.isfile(rec_file):
                        punch_hole_in_file(rec_file, 100 * 1024 * 1024)
        except Exception as e:
            print(f"[EnigmaTranslate] [DISK] Monitor error: {e}")

    def _hook_infobar_timeshift(self):
        """Hook InfoBar.checkTimeshiftRunning to intercept zap/stop on plugin-initiated timeshift without dialog."""
        try:
            from Screens.InfoBar import InfoBar
            ib = InfoBar.instance if InfoBar else None
            if ib and hasattr(ib, "checkTimeshiftRunning"):
                if "_et_checkTimeshiftRunning_orig" not in getattr(ib, "__dict__", {}):
                    orig_check = ib.checkTimeshiftRunning
                    ib._et_checkTimeshiftRunning_orig = orig_check

                    def _et_checkTimeshiftRunning(returnFunction, *args, **kwargs):
                        if getattr(self, "plugin_started_timeshift", False):
                            print("[EnigmaTranslate] [TIMESHIFT] Zap/exit detected while plugin timeshift active -> stopping without prompt")
                            self._stop_plugin_timeshift_no_dialog()
                            if returnFunction:
                                returnFunction(True)
                            return
                        return orig_check(returnFunction, *args, **kwargs)

                    ib.checkTimeshiftRunning = _et_checkTimeshiftRunning
        except Exception as e:
            print(f"[EnigmaTranslate] _hook_infobar_timeshift error: {e}")

    def _cleanup_our_timeshift_files(self):
        """Delete temporary timeshift and background recording files created by the plugin."""
        clean_temp_disk_files()
        try:
            from Screens.InfoBar import InfoBar
            ib = InfoBar.instance if InfoBar else None
            if ib and hasattr(ib, "eraseTimeshiftFile"):
                try:
                    ib.eraseTimeshiftFile()
                except Exception:
                    pass
        except Exception:
            pass

        try:
            ts_dir = "/media/hdd/timeshift"
            try:
                from Components.config import config
                ts_dir = config.usage.timeshift_path.value
            except (AttributeError, KeyError, Exception):
                pass
            if ts_dir and os.path.isdir(ts_dir):
                now = time.time()
                for pat in ("timeshift.*", "pts_livebuffer_*"):
                    for f in glob.glob(os.path.join(ts_dir, pat)):
                        try:
                            mtime = os.path.getmtime(f)
                            if (now - mtime) < 3600:
                                os.remove(f)
                        except Exception:
                            pass
        except Exception as e:
            print(f"[EnigmaTranslate] _cleanup_our_timeshift_files error: {e}")

    def _stop_plugin_timeshift_no_dialog(self, purge_disk_async=False):
        """Stop timeshift started by the plugin programmatically without showing any dialog, and clean up files."""
        if not getattr(self, "plugin_started_timeshift", False):
            return
        self.plugin_started_timeshift = False
        print("[EnigmaTranslate] [TIMESHIFT] Stopping plugin-initiated timeshift (no dialog, no save)...")

        saved_check_ts = None
        saved_fav_action = None
        flag_file = os.path.join(getattr(settings, "DATA_DIR", "/etc/enigma2/enigmatranslate"), "ts_bypass.json")

        try:
            try:
                from Components.config import config
                try:
                    saved_check_ts = config.usage.check_timeshift.value
                    config.usage.check_timeshift.value = False
                except (AttributeError, KeyError):
                    saved_check_ts = None
                try:
                    saved_fav_action = config.timeshift.favoriteSaveAction.value
                    config.timeshift.favoriteSaveAction.value = "noSave"
                except (AttributeError, KeyError):
                    saved_fav_action = None
            except Exception as e:
                print(f"[EnigmaTranslate] bypass config error: {e}")

            # Write leftover flag file so setting is restored even on abrupt termination / crash
            if saved_check_ts is not None or saved_fav_action is not None:
                try:
                    os.makedirs(os.path.dirname(flag_file), exist_ok=True)
                    with open(flag_file, "w", encoding="utf-8") as f:
                        json.dump({
                            "saved_check_ts": saved_check_ts,
                            "saved_fav_action": saved_fav_action,
                            "time": time.time()
                        }, f)
                except Exception as e_flag:
                    print(f"[EnigmaTranslate] [TIMESHIFT] Could not write bypass flag: {e_flag}")

            try:
                from Screens.InfoBar import InfoBar
                ib = InfoBar.instance if InfoBar else None
                if ib:
                    if hasattr(ib, "save_current_timeshift"):
                        ib.save_current_timeshift = False
                    if hasattr(ib, "saveTimeshiftActions"):
                        try:
                            ib.saveTimeshiftActions("noSave", None)
                        except Exception as e:
                            print(f"[EnigmaTranslate] saveTimeshiftActions error: {e}")

                    if hasattr(ib, "ptsStop"):
                        ib.ptsStop = True
                    if hasattr(ib, "stopTimeshift"):
                        try:
                            ib.stopTimeshift()
                        except Exception as e:
                            print(f"[EnigmaTranslate] ib.stopTimeshift error: {e}")

                    ts = ib.getTimeshift() if hasattr(ib, "getTimeshift") else None
                    if ts and hasattr(ts, "isTimeshiftEnabled") and ts.isTimeshiftEnabled():
                        if hasattr(ts, "stopTimeshift"):
                            try:
                                ts.stopTimeshift()
                            except Exception as e:
                                print(f"[EnigmaTranslate] ts.stopTimeshift error: {e}")
            except Exception as e:
                print(f"[EnigmaTranslate] _stop_plugin_timeshift_no_dialog inner error: {e}")
        finally:
            try:
                from Components.config import config
                if saved_check_ts is not None:
                    try:
                        config.usage.check_timeshift.value = saved_check_ts
                        print(f"[EnigmaTranslate] [TIMESHIFT] check_timeshift restored ({saved_check_ts})")
                    except (AttributeError, KeyError):
                        pass
                if saved_fav_action is not None:
                    try:
                        config.timeshift.favoriteSaveAction.value = saved_fav_action
                    except (AttributeError, KeyError):
                        pass
            except Exception as e_rest:
                print(f"[EnigmaTranslate] [TIMESHIFT] Error restoring config in finally: {e_rest}")

            try:
                if os.path.isfile(flag_file):
                    os.remove(flag_file)
            except Exception:
                pass

        try:
            self._unpause_time_bridge()
        except Exception:
            pass

        try:
            self._stop_background_recording()
        except Exception:
            pass

        if not purge_disk_async:
            self._cleanup_our_timeshift_files()

    def _start_background_timeshift(self):
        """Start timeshift recording in background without pausing playback (descrambled audio/teletext source)."""
        if is_iptv_service(self.current_service_ref):
            return
        try:
            from Screens.InfoBar import InfoBar
            ib = InfoBar.instance if InfoBar else None
            service = self.session.nav.getCurrentService() if (self.session and hasattr(self.session, "nav")) else None
            ts = service.timeshift() if (service and hasattr(service, "timeshift")) else None
            if not ts and ib and hasattr(ib, "getTimeshift"):
                ts = ib.getTimeshift()

            is_recording = False
            if ts and hasattr(ts, "isTimeshiftEnabled"):
                try:
                    is_recording = bool(ts.isTimeshiftEnabled())
                except Exception:
                    is_recording = False

            if not is_recording:
                self._hook_infobar_timeshift()
                self.plugin_started_timeshift = True
                if ib and hasattr(ib, "activatePermanentTimeshift"):
                    print(f"[EnigmaTranslate] [TIMESHIFT] Calling ib.activatePermanentTimeshift() for background recording on '{self.current_service_name}'")
                    ib.activatePermanentTimeshift()
                elif ts and hasattr(ts, "startTimeshift"):
                    print(f"[EnigmaTranslate] [TIMESHIFT] Calling ts.startTimeshift() for background recording on '{self.current_service_name}'")
                    res = ts.startTimeshift()
                    print(f"[EnigmaTranslate] [TIMESHIFT] ts.startTimeshift() result: {res}")
            else:
                self.plugin_started_timeshift = False
                print(f"[EnigmaTranslate] [TIMESHIFT] Background timeshift recording is already active on '{self.current_service_name}'")
        except Exception as e:
            print(f"[EnigmaTranslate] [TIMESHIFT] Background timeshift error: {e}")

    def _engage_time_bridge(self, force=False, bridge_sec=None):
        """Time-Bridge: pause live TV via InfoBar timeshift, unpause after bridge_sec."""
        if is_iptv_service(self.current_service_ref):
            print(f"[EnigmaTranslate] [BRIDGE] IPTV service ({self.current_service_ref}) does not support timeshift bridge -> skipping")
            self.current_bridge_sec = 0.0
            return
        if not force and not self.is_encrypted and not self.get_effective_setting("bridge"):
            return

        if self.get_effective_setting("no_timeshift_playback"):
            print(f"[EnigmaTranslate] [BRIDGE] '{self.current_service_name}' marked 'no_timeshift_playback' -> Skipping time bridge")
            self.current_bridge_sec = 0.0
            self._notify_no_bridge_once()
            return

        if self.is_channel_paused:
            return

        if bridge_sec is not None:
            bridge_sec = float(bridge_sec)
        else:
            # Check saved per-channel bridge first, or p90 latency, or config (default 14.0 for audio, 2.5 for DVB-SUB)
            is_dvb_sub = getattr(self, "channel_has_dvb_subs", False) or (getattr(self, "tap_manager", None) and getattr(self.tap_manager, "active_kind", "") == "dvb_sub")
            saved_bridge = self.channel_bridges.get(self.current_service_ref) if hasattr(self, "channel_bridges") else None
            if is_dvb_sub:
                if saved_bridge is not None and isinstance(saved_bridge, (int, float)) and float(saved_bridge) >= 4.0:
                    bridge_sec = max(5.0, min(8.0, float(saved_bridge)))
                    print(f"[EnigmaTranslate] [BRIDGE] [DVB-SUB] Using saved channel bridge {bridge_sec:.1f}s for '{self.current_service_name}'")
                elif hasattr(self, "dvb_turnarounds") and len(self.dvb_turnarounds) >= 2:
                    p95 = self._calc_percentile_95(self.dvb_turnarounds)
                    bridge_sec = max(5.0, min(8.0, round(p95 + 1.0, 1)))
                    print(f"[EnigmaTranslate] [BRIDGE] [DVB-SUB] Using p95 bridge {bridge_sec:.1f}s for '{self.current_service_name}'")
                else:
                    bridge_sec = 6.0
                    print(f"[EnigmaTranslate] [BRIDGE] [DVB-SUB] Using initial bridge 6.0s for '{self.current_service_name}'")
            elif saved_bridge is not None:
                bridge_sec = max(8.0, min(16.0, float(saved_bridge)))
                print(f"[EnigmaTranslate] [BRIDGE] Using saved channel bridge {bridge_sec:.1f}s for '{self.current_service_name}'")
            elif hasattr(self, "recent_latencies") and len(self.recent_latencies) >= 3:
                p90 = self._calc_percentile_90(self.recent_latencies)
                bridge_sec = max(8.0, min(16.0, round(p90 + 0.5, 1)))
            else:
                cfg_sec = self.get_effective_setting("bridge_sec")
                bridge_sec = max(8.0, min(16.0, float(cfg_sec or 14.0)))

        self.current_bridge_sec = bridge_sec
        self.target_bridge_sec = bridge_sec
        self.is_channel_paused = True
        self.bridge_paused_time = time.time()
        self.bridge_max_sec = bridge_sec + 3.0
        self.bridge_remaining_sec = int(round(bridge_sec))
        self.bridge_checked_growth = False

        self.bridge_initial_file = find_active_timeshift_file()
        self.bridge_initial_size = 0
        if self.bridge_initial_file and os.path.exists(self.bridge_initial_file):
            try:
                self.bridge_initial_size = os.path.getsize(self.bridge_initial_file)
            except Exception:
                self.bridge_initial_size = 0

        if self.current_service_ref and hasattr(self, "channel_bridges"):
            self.channel_bridges[self.current_service_ref] = bridge_sec
            self._save_channel_bridges()

        print(f"[EnigmaTranslate] [BRIDGE] Engaging Time-Bridge for {bridge_sec:.1f}s on '{self.current_service_name}'")

        try:
            from Screens.InfoBar import InfoBar
            ib = InfoBar.instance if InfoBar else None
            if ib:
                ts = ib.getTimeshift() if hasattr(ib, "getTimeshift") else None
                ts_active = False
                if ts and hasattr(ts, "isTimeshiftActive"):
                    try:
                        ts_active = bool(ts.isTimeshiftActive())
                    except Exception:
                        ts_active = False
                elif hasattr(ib, "timeshiftEnabled"):
                    try:
                        ts_active = bool(ib.timeshiftEnabled())
                    except Exception:
                        ts_active = False

                if hasattr(ib, "activateTimeshiftEndAndPause") and not ts_active:
                    print("[EnigmaTranslate] [BRIDGE] Calling ib.activateTimeshiftEndAndPause() to enter timeshift & pause")
                    self._hook_infobar_timeshift()
                    self.plugin_started_timeshift = True
                    ib.activateTimeshiftEndAndPause()
                elif hasattr(ib, "pauseService"):
                    print("[EnigmaTranslate] [BRIDGE] Calling ib.pauseService() to pause timeshift")
                    ib.pauseService()
                elif not ts_active and hasattr(ib, "startTimeshift"):
                    print("[EnigmaTranslate] [BRIDGE] Calling ib.startTimeshift() to start buffer")
                    self._hook_infobar_timeshift()
                    self.plugin_started_timeshift = True
                    ib.startTimeshift()
                elif self.session and hasattr(self.session, "nav"):
                    self.session.nav.pause(True)

            self.show_status(f"جاري تجهيز الترجمة… {self.bridge_remaining_sec}", duration=2.0, force=True)

            from enigma import eTimer
            if hasattr(self, "bridge_timer") and self.bridge_timer:
                try:
                    self.bridge_timer.stop()
                except Exception:
                    pass
            self.bridge_timer = eTimer()
            self.bridge_timer.callback.append(self._on_bridge_tick)
            self.bridge_timer.start(1000, False)
        except Exception as e:
            print(f"[EnigmaTranslate] [BRIDGE] Failed to engage bridge: {e}")
            self._unpause_time_bridge()

    def _on_bridge_tick(self):
        """Tick every 1 second during bridge buffer creation."""
        try:
            if not self.is_channel_paused:
                if hasattr(self, "bridge_timer") and self.bridge_timer:
                    try:
                        self.bridge_timer.stop()
                    except Exception:
                        pass
                    self.bridge_timer = None
                return

            elapsed = time.time() - getattr(self, "bridge_paused_time", time.time())
            max_allowed = getattr(self, "bridge_max_sec", 17.0)

            # Hard fail-safe 1: Never stay paused longer than bridge_sec + 3s
            if elapsed >= max_allowed:
                print(f"[EnigmaTranslate] [BRIDGE] Hard watchdog limit reached ({elapsed:.1f}s >= {max_allowed:.1f}s) -> Forcing unpause")
                self._unpause_time_bridge()
                self.show_status("جاري تشغيل الترجمة الصوتية…", duration=3.0, force=True)
                return

            # Fail-safe 2: If after 5s timeshift buffer isn't growing -> unpause immediately, disable bridge for channel
            if elapsed >= 5.0 and not getattr(self, "bridge_checked_growth", False):
                self.bridge_checked_growth = True
                cur_file = find_active_timeshift_file()
                cur_size = 0
                if cur_file and os.path.exists(cur_file):
                    try:
                        cur_size = os.path.getsize(cur_file)
                    except Exception:
                        cur_size = 0

                init_size = getattr(self, "bridge_initial_size", 0)
                init_file = getattr(self, "bridge_initial_file", None)

                # Buffer must exist and have grown
                is_growing = (cur_file is not None) and (cur_size > init_size or (cur_file != init_file and cur_size > 0))
                is_dvb_sub = getattr(self, "channel_has_dvb_subs", False) or (getattr(self, "tap_manager", None) and getattr(self.tap_manager, "active_kind", "") == "dvb_sub")
                if not is_growing and not is_dvb_sub:
                    print(f"[EnigmaTranslate] [BRIDGE] Timeshift buffer NOT growing after 5s (init={init_size}, cur={cur_size}) -> Aborting bridge for '{self.current_service_name}'")
                    self._unpause_time_bridge()
                    if self.current_service_ref:
                        self.channel_bridges[self.current_service_ref] = False
                        self._save_channel_bridges()
                    self.show_status("التايم شيفت غير متاح لهذه القناة", duration=5.0, force=True)
                    if self.is_encrypted:
                        self.stop()
                    return

            # Countdown update
            self.bridge_remaining_sec = getattr(self, "bridge_remaining_sec", 1) - 1
            if self.bridge_remaining_sec > 0:
                self.show_status(f"جاري تجهيز الترجمة… {self.bridge_remaining_sec}", duration=2.0, force=True)
            else:
                self._unpause_time_bridge()
                if getattr(self, "channel_has_dvb_subs", False) or (getattr(self, "tap_manager", None) and getattr(self.tap_manager, "active_kind", "") == "dvb_sub"):
                    self.show_status("ترجمة القناة (DVB)", duration=3.0, force=True)
                elif getattr(self, "channel_has_teletext_subs", False) or (getattr(self, "tap_manager", None) and getattr(self.tap_manager, "active_kind", "") == "teletext"):
                    self.show_status("تيليتكست", duration=3.0, force=True)
                elif getattr(self, "srt_active", False):
                    self.show_status("ترجمة جاهزة", duration=3.0, force=True)
                else:
                    self.show_status("ترجمة صوتية", duration=3.0, force=True)

        except Exception as e:
            print(f"[EnigmaTranslate] [BRIDGE] Error in _on_bridge_tick: {e}")
            self._unpause_time_bridge()

    def _unpause_time_bridge(self):
        """Unpause video/audio safely and cancel any pending bridge timer."""
        try:
            if hasattr(self, "bridge_timer") and self.bridge_timer:
                try:
                    self.bridge_timer.stop()
                except Exception:
                    pass
                self.bridge_timer = None

            if hasattr(self, "bridge_adj_timer") and self.bridge_adj_timer:
                try:
                    self.bridge_adj_timer.stop()
                except Exception:
                    pass
                self.bridge_adj_timer = None

            try:
                from Screens.InfoBar import InfoBar
                ib = InfoBar.instance if InfoBar else None
                if ib:
                    if hasattr(ib, "unPauseService"):
                        try:
                            ib.unPauseService()
                        except Exception:
                            pass
                    if hasattr(ib, "seekstate") and hasattr(ib, "SEEK_STATE_PLAY"):
                        if getattr(ib, "seekstate", None) != getattr(ib, "SEEK_STATE_PLAY"):
                            try:
                                ib.setSeekState(ib.SEEK_STATE_PLAY)
                            except Exception:
                                pass
                if self.session and hasattr(self.session, "nav"):
                    try:
                        if not is_iptv_service(getattr(self, "current_service_ref", None)):
                            self.session.nav.pause(False)
                    except Exception:
                        pass
            except Exception:
                pass
            finally:
                if getattr(self, "is_channel_paused", False):
                    self.is_channel_paused = False
                    sec = getattr(self, "current_bridge_sec", 0.0)
                    print(f"[EnigmaTranslate] [BRIDGE] Time-Bridge active. Delay={sec:.1f}s")
                    self._start_playback_watchdog()
        except Exception as e:
            self._handle_callback_error(e, "_unpause_time_bridge")

    def _start_playback_watchdog(self):
        """Start or reset the periodic watchdog that verifies playback advances every 2 s throughout the session."""
        self._watchdog_last_pos = self._get_play_position()
        self._watchdog_last_advance_time = time.time()
        self._watchdog_stalled_since = None
        try:
            from enigma import eTimer
            if not hasattr(self, "_playback_watchdog_timer") or not self._playback_watchdog_timer:
                self._playback_watchdog_timer = eTimer()
                self._playback_watchdog_timer.callback.append(self._on_playback_watchdog_tick)
            else:
                try:
                    self._playback_watchdog_timer.stop()
                except Exception:
                    pass
            # Repeating timer every 2000 ms (2.0 s)
            self._playback_watchdog_timer.start(2000, False)
        except Exception:
            pass

    def _stop_playback_watchdog(self):
        """Stop the periodic playback watchdog."""
        if hasattr(self, "_playback_watchdog_timer") and self._playback_watchdog_timer:
            try:
                self._playback_watchdog_timer.stop()
            except Exception:
                pass
        self._watchdog_last_pos = None
        self._watchdog_last_advance_time = None
        self._watchdog_stalled_since = None

    def _schedule_playback_verification(self):
        """Compatibility wrapper for tests and unpause verification."""
        self._start_playback_watchdog()

    def _get_displayed_pts(self):
        """Get the 33-bit 90kHz PTS of the video currently displayed on screen."""
        latest_pts = getattr(self, "latest_stream_pts", None)
        latest_time = getattr(self, "latest_stream_time", None)

        if latest_pts is None and hasattr(self, "tap_manager") and self.tap_manager:
            tap = getattr(self.tap_manager, "current_tap", None)
            if tap and hasattr(tap, "latest_stream_pts"):
                latest_pts = getattr(tap, "latest_stream_pts", None)
                latest_time = getattr(tap, "latest_stream_time", None)

        if latest_pts is None or latest_time is None:
            return None

        now = time.time()
        elapsed_sec = max(0.0, now - latest_time)
        stream_pts = (int(latest_pts) + int(round(elapsed_sec * 90000))) & 0x1FFFFFFFF

        delay_pts = 0
        try:
            from Screens.InfoBar import InfoBar
            ib = InfoBar.instance if InfoBar else None
            service = self.session.nav.getCurrentService() if (self.session and hasattr(self.session, "nav")) else None
            seek = service.seek() if service else None
            if not seek and ib:
                seek = ib.getSeek() if hasattr(ib, "getSeek") else None
            if not seek and ib:
                ts_svc = getattr(ib, "timeshift_service", None)
                if ts_svc and hasattr(ts_svc, "seek"):
                    seek = ts_svc.seek()

            if seek:
                pos = seek.getPlayPosition()
                length = seek.getLength()
                if isinstance(pos, tuple) and pos[0] == 0:
                    real_pts = pos[1]
                    if real_pts is not None and real_pts > 0:
                        return real_pts & 0x1FFFFFFFF
                if isinstance(pos, tuple) and pos[0] == 0 and isinstance(length, tuple) and length[0] == 0:
                    p = pos[1]
                    l = length[1]
                    if l is not None and p is not None and l >= p:
                        delay_pts = l - p
        except Exception:
            pass

        if delay_pts <= 0 and getattr(self, "is_channel_paused", False):
            bridge_sec = getattr(self, "current_bridge_sec", 0.0) or 2.5
            delay_pts = int(round(bridge_sec * 90000))
        elif delay_pts <= 0 and getattr(self, "current_bridge_sec", 0.0) > 0:
            bridge_sec = float(self.current_bridge_sec)
            delay_pts = int(round(bridge_sec * 90000))

        displayed_pts = (stream_pts - delay_pts) & 0x1FFFFFFFF
        return displayed_pts

    def _get_play_position(self):
        return self._get_displayed_pts()

    def _pts_diff(self, pts1, pts2):
        """Calculate signed difference (pts1 - pts2) in 90kHz units with 33-bit wraparound."""
        d = (int(pts1) - int(pts2)) & 0x1FFFFFFFF
        if d >= 0x100000000:
            d -= 0x200000000
        return d

    def _process_dvb_sub_cues(self, now, other_open):
        """Process DVB-SUB cues and clear events synchronized to displayed video PTS."""
        disp_pts = self._get_displayed_pts()
        if disp_pts is None:
            return

        # 1. Process dvb_clear events
        clear_events = [s for s in self.pending_subs if s.get("kind") == "dvb_clear"]
        for ev in clear_events:
            clear_pts = ev.get("pts_raw")
            if clear_pts is None:
                clear_pts = int(round(ev.get("pts", 0.0) * 90000)) & 0x1FFFFFFFF
            else:
                clear_pts = int(clear_pts) & 0x1FFFFFFFF
            diff_clear = self._pts_diff(disp_pts, clear_pts)
            if diff_clear >= 0:
                if self.osd:
                    self.osd.hide_subtitle()
                if ev in self.pending_subs:
                    self.pending_subs.remove(ev)
                print(f"[EnigmaTranslate] [DVB-SUB CLEAR EXEC] disp_pts={disp_pts} clear_pts={clear_pts} diff={diff_clear/90000.0:+.2f}s")
            elif diff_clear < -90000 * 30:
                if ev in self.pending_subs:
                    self.pending_subs.remove(ev)

        # 2. Check pending DVB-SUB cues
        dvb_cues = [s for s in self.pending_subs if s.get("kind") == "dvb_sub"]
        if not dvb_cues:
            return

        to_drop = []
        due_cues = []
        for cue in dvb_cues:
            cue_pts = cue.get("cue_pts")
            if cue_pts is None:
                cue_pts = int(round(cue.get("pts", 0.0) * 90000)) & 0x1FFFFFFFF
            else:
                cue_pts = int(cue_pts) & 0x1FFFFFFFF

            page_timeout = float(cue.get("page_timeout", cue.get("duration", 4.0)) or 4.0)
            timeout_pts = int(round(page_timeout * 90000))
            cue_end_pts = (cue_pts + timeout_pts) & 0x1FFFFFFFF

            diff_to_start = self._pts_diff(disp_pts, cue_pts)
            diff_to_end = self._pts_diff(disp_pts, cue_end_pts)

            # If a cue is late, show it for its FULL page timeout (until the next page/clear), never shorten it.
            if diff_to_start > 90000 * 8.0:
                to_drop.append((cue, cue_pts, cue_end_pts, diff_to_end))
            elif diff_to_start >= 0:
                due_cues.append((cue, cue_pts, cue_end_pts, page_timeout, diff_to_start, diff_to_end))

        for cue, c_pts, end_pts, late in to_drop:
            if cue in self.pending_subs:
                self.pending_subs.remove(cue)
            print(f"[EnigmaTranslate] [DVB-SUB DROP BACKLOG] cue_pts={c_pts} end_pts={end_pts} disp_pts={disp_pts} late={late/90000.0:.2f}s text='{cue.get('orig')}'")

        if not due_cues or other_open:
            return

        # Sort due cues by cue_pts ascending relative to disp_pts
        due_cues.sort(key=lambda x: self._pts_diff(x[1], disp_pts))
        # The latest due cue is the active one on screen
        cue_to_show, cue_pts, cue_end_pts, page_timeout, diff_to_start, diff_to_end = due_cues[-1]

        # Drop superseded older cues
        for older in due_cues[:-1]:
            if older[0] in self.pending_subs:
                self.pending_subs.remove(older[0])
            print(f"[EnigmaTranslate] [DVB-SUB SUPERSEDED] Dropping cue_pts={older[1]} superseded by cue_pts={cue_pts}")

        if cue_to_show in self.pending_subs:
            self.pending_subs.remove(cue_to_show)

        # Show duration: If a cue is late, show it for its FULL page timeout (until the next page/clear), never shorten it.
        show_duration = float(page_timeout)

        # Requirement 4: Log 10 cues: cue_pts, displayed_pts at show, show duration, original page timeout.
        if not hasattr(self, "dvb_sub_cue_count"):
            self.dvb_sub_cue_count = 0
            self.dvb_sub_logged_cues = []
        self.dvb_sub_cue_count += 1

        lateness_sec = round(diff_to_start / 90000.0, 3)
        cue_log = {
            "cue_num": self.dvb_sub_cue_count,
            "cue_pts": cue_pts,
            "displayed_pts": disp_pts,
            "show_duration": round(show_duration, 2),
            "original_page_timeout": round(page_timeout, 2),
            "diff_sec": lateness_sec,
            "orig": cue_to_show.get("orig", ""),
            "trans": cue_to_show.get("trans", "")
        }
        self.dvb_sub_logged_cues.append(cue_log)

        print(f"[EnigmaTranslate] [DVB-SUB TIMING #{self.dvb_sub_cue_count}] cue_pts={cue_pts} displayed_pts={disp_pts} show_duration={show_duration:.2f}s original_page_timeout={page_timeout:.2f}s diff={lateness_sec:+.3f}s orig='{cue_to_show.get('orig')}' trans='{cue_to_show.get('trans')}'")

        self._ensure_osd()
        if self.osd:
            self.osd.display_subtitle(
                trans_text=cue_to_show["trans"],
                orig_text=cue_to_show["orig"],
                duration=show_duration
            )

    def _on_playback_watchdog_tick(self):
        """Verify every 2 s that playback is advancing in every mode. On stall > 3 s, recover to live."""
        if not self.running:
            self._stop_playback_watchdog()
            return

        # Do not check stall while intentionally paused for countdown or user pause
        if self.is_channel_paused:
            self._watchdog_last_advance_time = time.time()
            self._watchdog_stalled_since = None
            return

        # IPTV relay streams (eServiceMP3 HTTP) do not report advancing seek positions
        if getattr(self, "relay_active", False):
            return

        # Safeguard: In DVB-SUB mode, timeshift playback is intentionally delayed by Time-Bridge
        if getattr(self, "channel_has_dvb_subs", False) or (getattr(self, "tap_manager", None) and getattr(self.tap_manager, "active_kind", "") == "dvb_sub"):
            return

        # Safeguard: In teletext mode, ensure viewer stays on LIVE playback and NEVER in timeshift playback
        if getattr(self, "channel_has_teletext_subs", False) or (getattr(self, "tap_manager", None) and self.tap_manager.active_kind == "teletext"):
            try:
                from Screens.InfoBar import InfoBar
                ib = InfoBar.instance if InfoBar else None
                ts = ib.getTimeshift() if (ib and hasattr(ib, "getTimeshift")) else None
                ts_active = False
                if ts and hasattr(ts, "isTimeshiftActive"):
                    ts_active = bool(ts.isTimeshiftActive())
                if ts_active:
                    print(f"[EnigmaTranslate] [PLAYBACK WATCHDOG] Teletext mode: timeshift playback detected -> Forcing return to live!")
                    if ib and hasattr(ib, "stopTimeshift"):
                        ib.stopTimeshift()
                    if self.session and hasattr(self.session, "nav"):
                        self.session.nav.pause(False)
            except Exception:
                pass

        cur_pos = self._get_play_position()
        now = time.time()

        if cur_pos is not None and self._watchdog_last_pos is not None:
            # Over 2s at 90kHz, normal playback advances ~180,000 ticks.
            # Require at least 0.2s (18,000 ticks) of advance.
            delta_ticks = cur_pos - self._watchdog_last_pos
            if delta_ticks >= 18000:
                self._watchdog_last_pos = cur_pos
                self._watchdog_last_advance_time = now
                self._watchdog_stalled_since = None
            else:
                if self._watchdog_stalled_since is None:
                    self._watchdog_stalled_since = now
                stall_sec = now - self._watchdog_stalled_since
                print(f"[EnigmaTranslate] [PLAYBACK] Playback stall detected on '{self.current_service_name}' ({stall_sec:.1f}s, cur={cur_pos}, last={self._watchdog_last_pos})")
                if stall_sec >= 3.0:
                    print(f"[EnigmaTranslate] [PLAYBACK] Stall over 3.0s on '{self.current_service_name}' -> Switching to live and marking channel 'no timeshift playback'!")
                    self._watchdog_stalled_since = None
                    self._watchdog_last_pos = None
                    self._fallback_to_live_no_bridge()
        elif cur_pos is not None:
            self._watchdog_last_pos = cur_pos
            self._watchdog_last_advance_time = now
            self._watchdog_stalled_since = None

    def _check_playback_advancing(self):
        """Check once if playback advanced or trigger watchdog tick."""
        self._on_playback_watchdog_tick()

    def _fallback_to_live_no_bridge(self):
        """Stop timeshift playback, return to live, and mark channel as no timeshift playback without re-zapping."""
        if self.current_service_ref:
            if not hasattr(self, "runtime_no_ts_playback_channels"):
                self.runtime_no_ts_playback_channels = set()
            self.runtime_no_ts_playback_channels.add(self.current_service_ref)
            self.channel_bridges[self.current_service_ref] = False
            self._save_channel_bridges()

        self.current_bridge_sec = 0.0
        self.is_channel_paused = False
        self._watchdog_last_pos = None
        self._watchdog_stalled_since = None

        # Return to live without re-zapping
        try:
            from Screens.InfoBar import InfoBar
            ib = InfoBar.instance if InfoBar else None
            if ib:
                if hasattr(ib, "switchToLive"):
                    try:
                        ib.switchToLive()
                    except Exception:
                        pass
                elif hasattr(ib, "stopTimeshift"):
                    try:
                        ib.stopTimeshift()
                    except Exception:
                        pass
        except Exception as e:
            print(f"[EnigmaTranslate] [PLAYBACK] Return to live error: {e}")

        self._notify_no_bridge_once()

        self._notify_no_bridge_once()

    def _notify_no_bridge_once(self):
        if not hasattr(self, "_no_bridge_warned_channels"):
            self._no_bridge_warned_channels = set()
        if self.current_service_ref not in self._no_bridge_warned_channels:
            self._no_bridge_warned_channels.add(self.current_service_ref)
            self.show_status("هذه القناة لا تدعم تأخير الصورة؛ الترجمة متأخرة قليلاً", duration=6.0, force=True)

    def _disable_time_bridge_for_srt(self):
        if self.is_encrypted:
            print("[EnigmaTranslate] [SRT] Encrypted channel -> Staying bridged during ad break to preserve safe timeshift audio source.")
            return
        if self.current_bridge_sec > 0:
            print("[EnigmaTranslate] [SRT] Ad break -> Disabling Time-Bridge and returning to live.")
            self._unpause_time_bridge()
            self.current_bridge_sec = 0.0


    def _apply_bridge_delta(self, delta):
        """Temporarily pause playback for delta seconds to lengthen timeshift buffer."""
        try:
            self.is_channel_paused = True
            from Screens.InfoBar import InfoBar
            ib = InfoBar.instance if InfoBar else None
            if ib and hasattr(ib, "pauseService"):
                ib.pauseService()
            elif self.session and hasattr(self.session, "nav"):
                self.session.nav.pause(True)

            from enigma import eTimer
            if hasattr(self, "bridge_adj_timer") and self.bridge_adj_timer:
                try:
                    self.bridge_adj_timer.stop()
                except Exception:
                    pass
            self.bridge_adj_timer = eTimer()
            self.bridge_adj_timer.callback.append(self._unpause_time_bridge)
            self.bridge_adj_timer.start(int(delta * 1000), True)
            print(f"[EnigmaTranslate] [BRIDGE] Pausing {delta:.1f}s to adjust bridge to {self.current_bridge_sec:.1f}s")
        except Exception as e:
            print(f"[EnigmaTranslate] [BRIDGE] Failed to pause for bridge adjustment: {e}")
            self._unpause_time_bridge()

    def _process_batch_dvb_cues(self, captured_times, batch):
        """Translate DVB-SUB cues concurrently/in batch and emit to gui_q."""
        if not batch or self.translator_stop_event.is_set() or not self.running:
            return

        cfg = settings.config.plugins.enigmatranslate
        eng_order = (cfg.eng1.value, cfg.eng2.value, cfg.eng3.value)
        timeout = cfg.timeout.value[0] if isinstance(cfg.timeout.value, list) else cfg.timeout.value
        ai_when = cfg.ai_when.value
        ai_prov = cfg.ai_provider.value
        ai_key = settings.get_api_key(ai_prov)
        if self.safe_mode_active:
            eng_order = tuple(e for e in eng_order if e not in ("ai", "argos"))

        dst = self.get_effective_setting("dst_lang") or "ar"

        # Check if multiple items can be batch-translated together
        texts = [p.get("text", "").strip() for p in batch]
        translations = []
        if len(texts) > 1 and all(texts):
            sub_lang = batch[0].get("orig_lang", "auto")
            src = sub_lang if sub_lang not in ("auto", None, "") else (self.get_effective_setting("src_lang") or "auto")
            joined = " \n---\n ".join(texts)
            ctx = TranslationContext(context_lines=self.context_lines)
            try:
                res = self.chain.translate(joined, src, dst, eng_order=eng_order, timeout=timeout, ai_when=ai_when, ai_key=ai_key, ctx=ctx)
                parts = [p.strip() for p in res.split("---")]
                if len(parts) == len(texts):
                    translations = parts
            except Exception:
                pass

        if len(translations) != len(texts):
            translations = []
            for item in batch:
                ready_text = item.get("text", "").strip()
                sub_lang = item.get("orig_lang", "auto")
                src = sub_lang if sub_lang not in ("auto", None, "") else (self.get_effective_setting("src_lang") or "auto")
                ctx = TranslationContext(context_lines=self.context_lines)
                try:
                    t = self.chain.translate(ready_text, src, dst, eng_order=eng_order, timeout=timeout, ai_when=ai_when, ai_key=ai_key, ctx=ctx)
                    translations.append(t.strip())
                except Exception as e:
                    print(f"[EnigmaTranslate] [DVB-SUB TRANS ERR] {e}")
                    translations.append("")

        now = time.time()
        for idx, raw_payload in enumerate(batch):
            display_trans = translations[idx] if idx < len(translations) else ""
            if not display_trans:
                continue

            captured_time = captured_times[idx] if idx < len(captured_times) else now
            ready_text = raw_payload.get("text", "").strip()
            sub_dur = float(raw_payload.get("duration", 0.0) or 0.0)
            page_timeout = sub_dur if (sub_dur > 0 and sub_dur < 30) else 4.0
            cue_pts = float(raw_payload.get("pts", 0.0) or 0.0)
            cue_pts_raw = raw_payload.get("pts_raw")
            if cue_pts_raw is None:
                cue_pts_raw = int(round(cue_pts * 90000)) & 0x1FFFFFFFF
            else:
                cue_pts_raw = int(cue_pts_raw) & 0x1FFFFFFFF

            turnaround = max(0.1, now - captured_time)
            if not hasattr(self, "dvb_turnarounds"):
                self.dvb_turnarounds = []
            self.dvb_turnarounds.append(turnaround)
            if len(self.dvb_turnarounds) > 20:
                self.dvb_turnarounds.pop(0)

            p95 = self._calc_percentile_95(self.dvb_turnarounds)
            required_b = round(p95 + 1.0, 1)
            target_b = max(3.0, min(14.0, required_b))
            self.target_bridge_sec = target_b
            if self.current_service_ref and hasattr(self, "channel_bridges"):
                self.channel_bridges[self.current_service_ref] = target_b
                self._save_channel_bridges()

            print(f"[EnigmaTranslate] [DVB-SUB TIMING MEASURE] turnaround={turnaround:.2f}s (p95={p95:.2f}s) -> target_b={target_b:.1f}s current_b={self.current_bridge_sec:.1f}s")
            if self.current_bridge_sec < (target_b - 0.3):
                delta = target_b - self.current_bridge_sec
                self.current_bridge_sec = target_b
                self._apply_bridge_delta(delta)

            print(f"[EnigmaTranslate] [CUE QUEUE] [DVB-SUB] cue_pts={cue_pts_raw} ({cue_pts:.3f}s) page_timeout={page_timeout:.1f}s orig='{ready_text}' trans='{display_trans}'")
            if not self.translator_stop_event.is_set() and self.running:
                self.gui_q.put(("subtitle", {
                    "kind": "dvb_sub",
                    "cue_pts": cue_pts_raw,
                    "page_timeout": page_timeout,
                    "duration": page_timeout,
                    "orig_duration": sub_dur,
                    "trans": display_trans,
                    "orig": ready_text,
                    "audio_ts": captured_time,
                    "display_at": 0.0,
                    "real_delay": turnaround
                }))

    def _translator_worker(self):
        """Worker thread pulling captured text/segments from raw_q and translating them."""
        while not self.translator_stop_event.is_set():
            try:
                item = self.raw_q.get(timeout=0.5)
                captured_time, raw_payload = item
                if not raw_payload:
                    continue

                is_dvb_sub = False
                sub_dur = 0.0
                sub_lang = "auto"

                if isinstance(raw_payload, dict):
                    kind = raw_payload.get("kind")
                    if kind == "dvb_clear":
                        clear_pts = float(raw_payload.get("pts", 0.0) or 0.0)
                        clear_pts_raw = raw_payload.get("pts_raw")
                        if clear_pts_raw is None:
                            clear_pts_raw = int(round(clear_pts * 90000)) & 0x1FFFFFFFF
                        else:
                            clear_pts_raw = int(clear_pts_raw) & 0x1FFFFFFFF
                        print(f"[EnigmaTranslate] [DVB-SUB CLEAR] Scheduled clear at pts={clear_pts_raw} ({clear_pts:.3f}s)")
                        self.gui_q.put(("dvb_clear", {"pts": clear_pts, "pts_raw": clear_pts_raw}))
                        continue
                    elif kind == "dvb_sub":
                        batch = [raw_payload]
                        captured_times = [captured_time]
                        while not self.raw_q.empty() and len(batch) < 5:
                            try:
                                nxt = self.raw_q.get_nowait()
                                if isinstance(nxt[1], dict) and nxt[1].get("kind") == "dvb_sub":
                                    captured_times.append(nxt[0])
                                    batch.append(nxt[1])
                                else:
                                    self.raw_q.put_nowait(nxt)
                                    break
                            except Exception:
                                break
                        threading.Thread(target=self._process_batch_dvb_cues, args=(captured_times, batch), daemon=True, name="ET_DVBTrans").start()
                        continue
                    else:
                        # Whisper segment with precise timestamps!
                        seg_start = float(raw_payload.get("start", 0.0))
                        seg_end = float(raw_payload.get("end", 0.0))
                        chunk_stream_start = float(raw_payload.get("chunk_stream_start", captured_time))
                        stt_lat = int(raw_payload.get("latency_ms", 0))
                        if stt_lat > 0:
                            self.last_stt_latency_ms = stt_lat
                            if not self.latency_history or (time.time() - getattr(self, "_last_stt_lat_recorded", 0.0) >= 3.0):
                                self.latency_history.append(stt_lat)
                                self._last_stt_lat_recorded = time.time()
                                if len(self.latency_history) > 20:
                                    self.latency_history.pop(0)
                        ready_text = raw_payload.get("text", "").strip()
                        is_segment = True
                        self.last_audio_segment_time = time.time()
                        if not ready_text:
                            continue
                else:
                    raw_text = str(raw_payload).strip()
                    if not raw_text:
                        continue
                    ready_text, _ = self.fragment_merger.feed(raw_text, now=time.time())
                    if not ready_text:
                        continue
                    seg_start = 0.0
                    seg_end = 0.0
                    chunk_stream_start = captured_time
                    is_segment = False
                    self.last_audio_segment_time = time.time()
            except queue.Empty:
                flush_tail = self.fragment_merger.flush(now=time.time())
                if flush_tail:
                    captured_time = time.time() - 3.0
                    chunk_stream_start = captured_time
                    ready_text = flush_tail
                    seg_start = 0.0
                    seg_end = 0.0
                    is_segment = False
                    is_dvb_sub = False
                else:
                    continue

            # Record recent dialogue for movie identification from audio
            if ready_text:
                speech_time = (chunk_stream_start + seg_start) if is_segment else chunk_stream_start
                if not hasattr(self, "recent_english_dialogue"):
                    self.recent_english_dialogue = []
                self.recent_english_dialogue.append((speech_time, ready_text))
                if len(self.recent_english_dialogue) > 150:
                    self.recent_english_dialogue.pop(0)

            # Feed to SRT synchronizer if active
            if getattr(self, "srt_synchronizer", None) and ready_text:
                try:
                    speech_time = (chunk_stream_start + seg_start) if is_segment else chunk_stream_start
                    sync = self.srt_synchronizer
                    req_interval = 10.0 if (sync.in_ad_break or sync.consecutive_misses > 0) else 60.0
                    time_since_sample = time.time() - getattr(sync, "last_sample_time", 0.0)

                    # Only initial anchor waits for Whisper; keep re-anchoring every 60 s, or every 10 s if miss/ads
                    if not sync.locked or time_since_sample >= (req_interval - 1.0):
                        was_locked = sync.locked
                        matched = sync.feed_speech_segment(ready_text, speech_time)
                        if matched and not was_locked:
                            print("[EnigmaTranslate] [SRT] First anchor achieved! Keeping Time-Bridge until first ad break.")
                            self.gui_q.put(("srt_first_anchor", None))
                        elif matched:
                            print(f"[EnigmaTranslate] [SRT] Re-anchored (sample ok). Err={sync.last_sync_error:.2f}s Speed={sync.speed:.3f}x")
                        else:
                            print(f"[EnigmaTranslate] [SRT] Sample miss ({sync.consecutive_misses}/2). Next sample in 10s.")

                    if getattr(sync, "movie_ended", False) or not sync.locked:
                        print("[EnigmaTranslate] [SRT] Movie ended / unlocked -> returning to audio STT.")
                        self.srt_synchronizer = None
                        self.srt_active = False
                        self.gui_q.put(("status", "انتهى الفيلم: العودة إلى الترجمة الصوتية"))
                        self.gui_q.put(("toast_reason", "انتهى الفيلم: العودة إلى الترجمة الصوتية"))
                    elif sync.locked:
                        # Synchronizer is locked on SRT cues; SRT drives OSD subtitles
                        continue
                except Exception as srt_err:
                    print(f"[EnigmaTranslate] SRT feed error: {srt_err}")

            if is_dvb_sub:
                src = sub_lang if sub_lang not in ("auto", None, "") else (self.get_effective_setting("src_lang") or "auto")
            else:
                src = self.get_effective_setting("src_lang") or "auto"
            dst = self.get_effective_setting("dst_lang") or "ar"

            from .engines import normalize_lang
            norm_src = normalize_lang(src)
            norm_dst = normalize_lang(dst)

            # Skip translation if src and dst are the same
            if norm_src == norm_dst and norm_src != "auto":
                display_trans = ready_text
            elif is_segment and raw_payload.get("translation") and dst == "ar":
                display_trans = str(raw_payload.get("translation")).strip()
                if getattr(self, "glossary", None):
                    display_trans = self.glossary.apply_to_translation(display_trans, orig_text=ready_text)
                self.total_translated += 1
                self.context_lines.append(ready_text)
                if len(self.context_lines) > 5:
                    self.context_lines.pop(0)
            else:
                cfg = settings.config.plugins.enigmatranslate
                eng_order = (cfg.eng1.value, cfg.eng2.value, cfg.eng3.value)
                timeout = cfg.timeout.value[0] if isinstance(cfg.timeout.value, list) else cfg.timeout.value
                ai_when = cfg.ai_when.value
                ai_prov = cfg.ai_provider.value
                ai_key = settings.get_api_key(ai_prov)

                if self.safe_mode_active:
                    eng_order = tuple(e for e in eng_order if e not in ("ai", "argos"))

                # Context lines for AI translation (keep previous segments as context)
                ctx = TranslationContext(context_lines=self.context_lines)

                try:
                    display_trans = self.chain.translate(
                        ready_text, src, dst,
                        eng_order=eng_order,
                        timeout=timeout,
                        ai_when=ai_when,
                        ai_key=ai_key,
                        ctx=ctx
                    )
                    self.total_translated += 1
                    self.latency_history.append(self.chain.last_latency_ms)
                    if len(self.latency_history) > 20:
                        self.latency_history.pop(0)

                    if ctx.detected and src == "auto":
                        self.detected_lang = ctx.detected

                    # Store in context lines for future AI sentences
                    self.context_lines.append(ready_text)
                    if len(self.context_lines) > 5:
                        self.context_lines.pop(0)

                except Exception as e:
                    self.last_status_message = f"error: {e}"
                    print(f"[EnigmaTranslate] [TRANSLATE ERROR] text='{ready_text}': {e}")
                    display_trans = ""

            if display_trans:
                now = time.time()
                active_tap = getattr(self.tap_manager, "active_kind", "") if getattr(self, "tap_manager", None) else ""

                try:
                    user_delay = float(self.get_effective_setting("delay") or 0.0)
                except Exception:
                    user_delay = 0.0

                bridge_active = bool(self.get_effective_setting("bridge")) or bool(getattr(self, "relay_active", False) and getattr(self, "current_bridge_sec", 0.0) > 0) or is_dvb_sub
                bridge = self.current_bridge_sec if (bridge_active and active_tap not in ("sub", "teletext")) else 0.0

                # Log bridge value per channel
                print(f"[EnigmaTranslate] [BRIDGE] channel='{self.current_service_name}' active={bridge_active} bridge={bridge:.1f}s")

                turnaround = (now - (chunk_stream_start + seg_start)) if is_segment else (now - chunk_stream_start)
                real_delay = turnaround
                self.channel_delays[self.current_service_ref] = turnaround
                if is_segment or is_dvb_sub:
                    self.recent_latencies.append(turnaround)
                    if len(self.recent_latencies) > 20:
                        self.recent_latencies.pop(0)
                    if is_dvb_sub:
                        if not hasattr(self, "dvb_turnarounds"):
                            self.dvb_turnarounds = []
                        self.dvb_turnarounds.append(turnaround)
                        if len(self.dvb_turnarounds) > 20:
                            self.dvb_turnarounds.pop(0)

                        p95 = self._calc_percentile_95(self.dvb_turnarounds)
                        # Time-Bridge for DVB must be >= p95 of (OCR + translate) time measured from subtitle arrival, + 1 s margin. Measure it, save per channel.
                        required_b = round(p95 + 1.0, 1)
                        target_b = max(5.0, min(14.0, required_b))
                        self.target_bridge_sec = target_b
                        if self.current_service_ref and hasattr(self, "channel_bridges"):
                            self.channel_bridges[self.current_service_ref] = target_b
                            self._save_channel_bridges()

                        print(f"[EnigmaTranslate] [DVB-SUB TIMING MEASURE] turnaround={turnaround:.2f}s (p95={p95:.2f}s) -> target_b={target_b:.1f}s current_b={self.current_bridge_sec:.1f}s")
                        if self.current_bridge_sec < (target_b - 0.3):
                            delta = target_b - self.current_bridge_sec
                            self.current_bridge_sec = target_b
                            self._apply_bridge_delta(delta)

                audio_ts = (chunk_stream_start + seg_start) if is_segment else chunk_stream_start
                nominal_display_at = audio_ts + bridge + user_delay
                late_by = now - nominal_display_at

                if active_tap == "teletext":
                    display_at = now
                    duration = self.get_effective_display_duration(display_trans)
                    diff = 0.0
                    print(f"[EnigmaTranslate] [CUE QUEUE] audio_ts={audio_ts:.2f} scheduled={display_at:.2f} (in 0.00s) duration={duration:.1f}s orig='{ready_text}' trans='{display_trans}'")
                elif is_dvb_sub:
                    page_timeout = sub_dur if (sub_dur > 0 and sub_dur < 30) else 4.0
                    duration = page_timeout
                    print(f"[EnigmaTranslate] [CUE QUEUE] [DVB-SUB] cue_pts={cue_pts_raw} ({cue_pts:.3f}s) page_timeout={page_timeout:.1f}s orig='{ready_text}' trans='{display_trans}'")
                    if not self.translator_stop_event.is_set() and self.running:
                        self.gui_q.put(("subtitle", {
                            "kind": "dvb_sub",
                            "cue_pts": cue_pts_raw,
                            "page_timeout": page_timeout,
                            "duration": duration,
                            "orig_duration": sub_dur,
                            "trans": display_trans,
                            "orig": ready_text,
                            "audio_ts": chunk_stream_start,
                            "display_at": 0.0,
                            "real_delay": real_delay
                        }))
                    continue
                else:
                    if is_segment:
                        seg_dur = seg_end - seg_start
                        natural_dur = seg_dur if seg_dur > 0 else (len(display_trans) / DEFAULT_CPS)
                        duration = self.get_effective_display_duration(display_trans, natural_dur=natural_dur)
                    else:
                        duration = self.get_effective_display_duration(display_trans)

                    # Requirement 3: If a cue is late, still show it (do not drop) unless it is more than 5 s late.
                    if bridge > 0 and late_by > 5.0:
                        self.stats_dropped_segments += 1
                        print(f"[EnigmaTranslate] [CUE DROP] audio_ts={audio_ts:.2f} scheduled={nominal_display_at:.2f} now={now:.2f} late_by={late_by:.2f}s (>5.0s) reason=late_over_5s orig='{ready_text}' trans='{display_trans}'")
                        continue

                    if bridge <= 0.0 or late_by > 0.0:
                        display_at = now
                        diff = late_by
                        print(f"[EnigmaTranslate] [CUE LATE-SHOW] audio_ts={audio_ts:.2f} scheduled={nominal_display_at:.2f} actual_scheduled={display_at:.2f} diff=+{diff:.2f}s duration={duration:.1f}s orig='{ready_text}' trans='{display_trans}'")
                    else:
                        display_at = nominal_display_at
                        diff = now - display_at
                        print(f"[EnigmaTranslate] [CUE QUEUE] audio_ts={audio_ts:.2f} scheduled={display_at:.2f} (in {-diff:.2f}s) duration={duration:.1f}s orig='{ready_text}' trans='{display_trans}'")

                if self.translator_stop_event.is_set() or not self.running:
                    continue

                self.gui_q.put(("subtitle", {
                    "audio_ts": audio_ts,
                    "scheduled_at": nominal_display_at,
                    "display_at": display_at,
                    "duration": duration,
                    "trans": display_trans,
                    "orig": ready_text,
                    "real_delay": real_delay
                }))

    def _on_gui_tick(self):
        """Called every 200ms on the main GUI thread to safely update UI widgets."""
        try:
            if not self.running:
                while hasattr(self, "gui_q") and not self.gui_q.empty():
                    try:
                        self.gui_q.get_nowait()
                    except Exception:
                        break
                if hasattr(self, "pending_subs"):
                    self.pending_subs.clear()
                return
            # 1. Check CPU load for safe mode
            if getattr(settings.config.plugins.enigmatranslate.safe_mode, "value", True):
                cpu, _ = get_system_load()
                limit = getattr(settings.config.plugins.enigmatranslate.cpu_limit, "value", 80)
                self.safe_mode_active = (cpu > limit)

            # Check for external commands (e.g. taking screenshots, remote automation)
            if os.path.exists("/tmp/enigmatranslate_cmd"):
                try:
                    with open("/tmp/enigmatranslate_cmd", "r", encoding="utf-8") as cf:
                        cmd = cf.read().strip()
                    os.remove("/tmp/enigmatranslate_cmd")
                    if cmd.startswith("open_dock:"):
                        parts = cmd.split(":")
                        tab_idx = int(parts[1])
                        focus_card = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else None
                        dock_pos = parts[3] if len(parts) > 3 else (parts[2] if len(parts) > 2 and not parts[2].isdigit() else None)
                        from .ui import EnigmaTranslateDock
                        if self.session:
                            for d in list(getattr(self.session, "dialog_stack", [])):
                                if d.__class__.__name__ == "EnigmaTranslateDock":
                                    d.close()
                            dock = self.session.open(EnigmaTranslateDock)
                            dock.tab_index = tab_idx
                            if focus_card is not None:
                                dock.focus_area = "cards"
                                dock.card_index = focus_card
                            if dock_pos and hasattr(dock, "instance") and dock.instance:
                                try:
                                    from enigma import ePoint
                                    dock.instance.move(ePoint(110, 50 if dock_pos == "top" else 820))
                                except Exception:
                                    pass
                            self.active_dock = dock
                            dock.update_ui()
                    elif cmd == "close_dock":
                        if getattr(self, "active_dock", None):
                            try:
                                self.active_dock.close()
                            except Exception:
                                pass
                            self.active_dock = None
                        if self.session:
                            dlgs = list(getattr(self.session, "dialog_stack", [])) + ([self.session.current_dialog] if getattr(self.session, "current_dialog", None) else [])
                            for d in dlgs:
                                if d.__class__.__name__ in ("EnigmaTranslateDock", "EnigmaTranslateWebDialog", "ChoiceBox"):
                                    try:
                                        d.close()
                                    except Exception:
                                        pass
                    elif cmd == "open_web_dialog":
                        if self.session:
                            from .ui import EnigmaTranslateWebDialog
                            self.session.open(EnigmaTranslateWebDialog)
                    elif cmd == "open_health":
                        if self.session:
                            from .ui import HealthScreen
                            self.session.open(HealthScreen)
                    elif cmd == "close_health":
                        if self.session:
                            dlgs = list(getattr(self.session, "dialog_stack", [])) + ([self.session.current_dialog] if getattr(self.session, "current_dialog", None) else [])
                            for d in dlgs:
                                if d.__class__.__name__ == "HealthScreen":
                                    try:
                                        d.close()
                                    except Exception:
                                        pass
                    elif cmd.startswith("cycle_card:"):
                        delta = int(cmd.split(":")[1])
                        dock = getattr(self, "active_dock", None)
                        if not dock and self.session:
                            dlgs = list(getattr(self.session, "dialog_stack", [])) + ([self.session.current_dialog] if getattr(self.session, "current_dialog", None) else [])
                            for d in dlgs:
                                if d.__class__.__name__ == "EnigmaTranslateDock":
                                    dock = d
                                    break
                        if dock:
                            dock.adjust_card_value(delta)
                            print(f"[EnigmaTranslate] IPC cycle_card:{delta} applied to {dock.card_index}")
                    elif cmd == "open_choicebox":
                        dock = getattr(self, "active_dock", None)
                        if not dock and self.session:
                            dlgs = list(getattr(self.session, "dialog_stack", [])) + ([self.session.current_dialog] if getattr(self.session, "current_dialog", None) else [])
                            for d in dlgs:
                                if d.__class__.__name__ == "EnigmaTranslateDock":
                                    dock = d
                                    break
                        if dock:
                            tabs = dock.get_tabs_data()
                            card = tabs[dock.tab_index]["cards"][dock.card_index]
                            dock.open_choicebox(card)
                            print(f"[EnigmaTranslate] IPC open_choicebox opened for {card.get('label')}")
                    elif cmd == "show_test_line":
                        self.show_test_line()
                    elif cmd == "toggle":
                        self.toggle_with_toast()
                    elif cmd == "start":
                        self.start()
                    elif cmd == "relay_dropped":
                        self.stop_iptv_relay(restore_playback=True, reason="upstream_dropped")
                        self.show_status("وسيط IPTV: انقطع البث من المصدر", duration=4.0, force=True)
                    elif cmd == "iptv_refusal":
                        self._on_tap_status("iptv_single_conn_refusal")
                except Exception as ce:
                    print(f"[EnigmaTranslate] Command dispatch error: {ce}")

            # 2. Check if another screen (Menu, EPG, ChannelSelection, etc.) is open
            from .osd import is_other_screen_open, is_channel_selection_open, get_dialog_class_name
            other_open = is_other_screen_open(self.session)
            ch_sel_open = is_channel_selection_open(self.session)

            # Tuner reservation fix & IPTV Relay stop on channel list open
            if ch_sel_open and not getattr(self, "ch_sel_was_open", False):
                self.ch_sel_was_open = True
                print("[EnigmaTranslate] [TUNER] ChannelSelection opened -> releasing 8001 stream & killing ffmpeg")
                if getattr(self, "relay_active", False):
                    print("[EnigmaTranslate] [RELAY] ChannelSelection opened -> stopping relay and replaying original ref")
                    self.stop_iptv_relay(restore_playback=True, reason="channel_list_open")
                    self.show_status("وسيط IPTV: متوقف (قائمة القنوات)", duration=2.5, force=True)
                if self.tap_manager:
                    self.tap_manager.stop()
                    self.tap_manager = None
                self._kill_leftover_ffmpeg()
            elif not ch_sel_open and getattr(self, "ch_sel_was_open", False):
                self.ch_sel_was_open = False
                print("[EnigmaTranslate] [TUNER] ChannelSelection closed")
                if (getattr(self, "running", False) or self._is_channel_auto_start(self.current_service_ref)) and not getattr(self, "session_disabled", False):
                    print("[EnigmaTranslate] [TUNER] Restarting taps for active service")
                    self._start_settle_timer()

            if other_open:
                if self.osd and getattr(self.osd, "is_active", False):
                    self.osd.hide_subtitle()
                if self.toast and getattr(self.toast, "is_active", False):
                    self.toast.hide_status()

            # 3. Drain GUI queue into pending_subs
            now = time.time()

            ttx_mode = bool(getattr(self, "channel_has_teletext_subs", False) or (getattr(self, "tap_manager", None) and self.tap_manager.active_kind == "teletext") or self.get_effective_setting("source") == "teletext")
            bridge_allowed = bool((self.get_effective_setting("bridge") or (getattr(self, "relay_active", False) and getattr(self, "current_bridge_sec", 0.0) > 0)) and not self.get_effective_setting("no_timeshift_playback") and not ttx_mode)

            # Requirement 2: Recompute bridge length every 2 minutes (120s) - audio bridge mode only
            if bridge_allowed and (now - getattr(self, "last_bridge_recompute", 0)) >= 120.0:
                self.last_bridge_recompute = now
                if hasattr(self, "recent_latencies") and len(self.recent_latencies) >= 3:
                    p90 = self._calc_percentile_90(self.recent_latencies)
                    new_target = max(8.0, min(16.0, round(p90 + 0.5, 1)))
                    if abs(new_target - self.current_bridge_sec) >= 0.5:
                        self.target_bridge_sec = new_target
                        print(f"[EnigmaTranslate] [BRIDGE] Recomputed bridge target={self.target_bridge_sec:.1f}s (p90={p90:.2f}s over {len(self.recent_latencies)} segments)")

            srt_active = bool(getattr(self, "srt_synchronizer", None) and self.srt_synchronizer.locked)

            # Change bridge length: only when dock is closed, never mid-sentence, never in teletext mode
            # If growing, only during silence (>= 3.0s after last speech) and max 2s at a time
            # Requirement 4: If latency grows while playing on IPTV relay, do NOT re-buffer live; just save the new N for this channel for next time.
            if bridge_allowed and not srt_active and getattr(self, "target_bridge_sec", None) and abs(self.target_bridge_sec - self.current_bridge_sec) >= 0.5:
                if getattr(self, "relay_active", False):
                    if self.current_service_ref and hasattr(self, "channel_bridges"):
                        if self.channel_bridges.get(self.current_service_ref) != self.target_bridge_sec:
                            print(f"[EnigmaTranslate] [RELAY BRIDGE] Latency updated to {self.target_bridge_sec:.1f}s. Saved for next time (no live re-buffering).")
                            self.channel_bridges[self.current_service_ref] = self.target_bridge_sec
                            self._save_channel_bridges()
                elif not getattr(self, "dock_open", False) and not self.is_mid_sentence():
                    delta = self.target_bridge_sec - self.current_bridge_sec
                    if delta > 0:
                        is_silence = (now - getattr(self, "last_audio_segment_time", 0)) >= 3.0
                        if is_silence:
                            grow_delta = min(2.0, delta)
                            new_bridge = self.current_bridge_sec + grow_delta
                            print(f"[EnigmaTranslate] [BRIDGE] Lengthening bridge by {grow_delta:.1f}s to {new_bridge:.1f}s during silence (dock closed, not mid-sentence)")
                            self.current_bridge_sec = new_bridge
                            if self.current_service_ref and hasattr(self, "channel_bridges"):
                                self.channel_bridges[self.current_service_ref] = self.current_bridge_sec
                                self._save_channel_bridges()
                            self._apply_bridge_delta(grow_delta)
                    else:
                        print(f"[EnigmaTranslate] [BRIDGE] Shortening bridge target to {self.target_bridge_sec:.1f}s (dock closed, not mid-sentence)")
                        self.current_bridge_sec = self.target_bridge_sec
                        if self.current_service_ref and hasattr(self, "channel_bridges"):
                            self.channel_bridges[self.current_service_ref] = self.current_bridge_sec
                            self._save_channel_bridges()
            if self.running and (now - getattr(self, "_last_pts_debug", 0.0)) >= 2.0:
                self._last_pts_debug = now
                try:
                    service = self.session.nav.getCurrentService() if self.session else None
                    seek = service.seek() if service else None
                    pos = seek.getPlayPosition() if seek else None
                    length = seek.getLength() if seek else None
                    disp_pts = self._get_displayed_pts()
                    print(f"[EnigmaTranslate] [DEBUG PTS] disp_pts={disp_pts} stream_pts={getattr(self, 'latest_stream_pts', None)} pos={pos} length={length}")
                except Exception as e:
                    print(f"[EnigmaTranslate] [DEBUG PTS ERR] {e}")

            while not self.gui_q.empty():
                try:
                    cmd, data = self.gui_q.get_nowait()
                except Exception:
                    break

                if cmd == "subtitle":
                    self.pending_subs.append(data)
                    if data.get("kind") == "dvb_sub":
                        c_pts = data.get("cue_pts")
                        if c_pts is not None:
                            self.latest_stream_pts = c_pts
                            self.latest_stream_time = now
                elif cmd == "dvb_clear":
                    c_pts = data.get("pts_raw")
                    if c_pts is not None:
                        self.latest_stream_pts = c_pts
                        self.latest_stream_time = now
                    self.pending_subs.append({
                        "kind": "dvb_clear",
                        "pts_raw": data.get("pts_raw", 0),
                        "pts": data.get("pts", 0.0)
                    })
                elif cmd == "hide_subtitle_at":
                    self.pending_subs.append({"display_at": data, "kind": "hide"})
                elif cmd == "hide_subtitle":
                    if self.osd:
                        self.osd.hide_subtitle()
                elif cmd == "status":
                    if not other_open:
                        self._ensure_osd()
                        if self.toast:
                            self.toast.show_status(data)
                        elif self.osd:
                            self.osd.show_status(data)
                elif cmd == "toast_reason":
                    if not other_open:
                        self._ensure_osd()
                        if self.toast:
                            self.toast.show_status(data, duration=5.0)
                        elif self.osd:
                            self.osd.show_status(data, duration=5.0)
                elif cmd == "enable_native_sub":
                    self._do_enable_native_sub(data)
                elif cmd == "srt_auto_pick":
                    cand = data
                    if self.toast:
                        self.toast.show_status(f"ترجمة جاهزة للفيلم: {cand.get('label')}", duration=3.5)
                    threading.Thread(target=self._async_download_and_activate_srt, args=(cand,), daemon=True, name="ET_SRTDownload").start()
                elif cmd == "srt_menu":
                    self._show_srt_menu(data)
                elif cmd == "srt_first_anchor":
                    pass  # Keep bridge until first ad break to avoid jumping 14s mid-movie

            # If programme changed while native subs were ignored for previous programme, reset override
            cur_ev = self.get_current_epg_event_id()
            if getattr(self, "ignored_epg_event", None) and self.ignored_epg_event != cur_ev:
                print(f"[EnigmaTranslate] EPG programme changed from '{self.ignored_epg_event}' to '{cur_ev}' -> Resetting native sub override.")
                self.ignored_epg_event = None
                if not self.get_effective_setting("ignore_native_subs"):
                    if self.check_native_subtitles():
                        self.stop()

            # Check native subtitles once after PMT settle (2.0s) if not active yet
            if self.running and not getattr(self, "native_sub_active", False) and not getattr(self, "pmt_sub_checked", False) and (now - getattr(self, "start_time", 0)) >= 2.0:
                self.pmt_sub_checked = True
                if self.check_native_subtitles():
                    print("[EnigmaTranslate] Native subtitle activated during PMT settle.")

            # Check and update audio track once after PMT settle (2.0s) to ensure original track is chosen
            if self.running and not getattr(self, "audio_track_settled", False) and (now - getattr(self, "start_time", 0)) >= 2.0:
                self.audio_track_settled = True
                best_idx = self.get_best_audio_track_index()
                if self.tap_manager and getattr(self.tap_manager, "audio_track_idx", 0) != best_idx:
                    print(f"[EnigmaTranslate] Audio track update after PMT settle: switching to track {best_idx}")
                    self.tap_manager.set_audio_track(best_idx)

            # 1. Process DVB subtitles synchronized to displayed video PTS
            self._process_dvb_sub_cues(now, other_open)

            # 2. Show due audio / teletext subtitle whose display_at <= now
            if getattr(self, "srt_synchronizer", None) and self.srt_synchronizer.locked:
                self.pending_subs.clear()
                due_subs = []
            else:
                due_subs = [s for s in self.pending_subs if s.get("kind") not in ("dvb_sub", "dvb_clear") and s.get("display_at", 0) <= now]
            if due_subs:
                stack = getattr(self.session, "dialog_stack", []) if self.session else []
                stack_names = [get_dialog_class_name(d) for d in stack]
                cur_name = get_dialog_class_name(getattr(self.session, "current_dialog", None)) if self.session else ""
                print(f"[EnigmaTranslate] [OSD CHECK] Line due (other_open={other_open}) - current_dialog='{cur_name}', dialog_stack={stack_names}")

            if due_subs and not other_open:
                # Sort due subtitles by display_at and show the earliest one
                due_subs.sort(key=lambda s: s.get("display_at", 0))
                sub_to_show = due_subs[0]
                if sub_to_show in self.pending_subs:
                    self.pending_subs.remove(sub_to_show)

                if sub_to_show.get("kind") == "hide":
                    if self.osd:
                        self.osd.hide_subtitle()
                else:
                    actual_show = now
                    sched = sub_to_show.get("scheduled_at", sub_to_show.get("display_at", actual_show))
                    actual_jitter = actual_show - sched
                    self.stats_sync_errors.append(abs(actual_jitter))

                    print(f"[EnigmaTranslate] [CUE SHOW] audio_ts={sub_to_show.get('audio_ts', 0.0):.2f} scheduled={sched:.2f} actual={actual_show:.2f} jitter={actual_jitter:+.2f}s orig='{sub_to_show['orig']}' trans='{sub_to_show['trans']}' duration={sub_to_show['duration']}s")

                    # Space out any subsequent pending subtitles that are already due (min gap for rapid bursts, never blocking replacement)
                    sub_dur = sub_to_show.get("duration", 2.5)
                    min_gap = min(sub_dur, 1.2)
                    next_min_time = now + min_gap
                    for s in self.pending_subs:
                        if s.get("kind") not in ("dvb_sub", "dvb_clear") and s.get("display_at", 0) < next_min_time:
                            s["display_at"] = next_min_time
                            next_min_time += min(s.get("duration", 2.0), 1.2)

                    self._ensure_osd()
                    if self.osd:
                        self.osd.display_subtitle(
                            trans_text=sub_to_show["trans"],
                            orig_text=sub_to_show["orig"],
                            duration=sub_to_show["duration"]
                        )
                user_nudge = float(self.get_effective_setting("delay") or 0.0)
                pill_mode = getattr(settings.config.plugins.enigmatranslate.status_pill, "value", "auto")
                if pill_mode == "always" and self.toast and sub_to_show.get("real_delay"):
                    nudge_str = f" ({user_nudge:+.1f}s)" if abs(user_nudge) > 0.01 else ""
                    delay_str = f"{sub_to_show['real_delay']:.1f}s{nudge_str}"
                    ctype_lbl = self.get_content_type_label()
                    try:
                        from .stt import get_stt_status_pill_text
                        stt_info = get_stt_status_pill_text()
                        pill_msg = f"EN→AR · {stt_info} · {delay_str}"
                    except Exception:
                        pill_msg = f"EN→AR · STT · {ctype_lbl} · {delay_str}"
                    self.toast.show_status(pill_msg, duration=2.5)

            # Check movie/series SRT if content type is movie/series and no synchronizer loaded yet
            if getattr(self, "current_content_type", "") in ("movie", "series") and getattr(self, "srt_synchronizer", None) is None:
                if (now - getattr(self, "_last_srt_check_time", 0.0)) >= 4.0 and not getattr(self, "srt_searching", False):
                    self._last_srt_check_time = now
                    self._check_movie_srt()

            # Check identify movie from transcript when no EPG title / not found on TMDB
            if getattr(self, "srt_synchronizer", None) is None and not getattr(self, "srt_searching", False):
                if (now - getattr(self, "_last_identify_check_time", 0.0)) >= 5.0:
                    self._last_identify_check_time = now
                    self._check_identify_movie_from_transcript()

            # SubRip (.srt) subtitle display and ad blanking logic
            if getattr(self, "srt_synchronizer", None) and self.srt_synchronizer.locked:
                if getattr(self.srt_synchronizer, "movie_ended", False) or not self.srt_synchronizer.locked:
                    print("[EnigmaTranslate] [SRT] Movie ended -> unlocking SRT and returning to audio STT.")
                    self.srt_synchronizer = None
                    self.srt_active = False
                    self.gui_q.put(("status", "انتهى الفيلم: العودة إلى الترجمة الصوتية"))
                    self.gui_q.put(("toast_reason", "انتهى الفيلم: العودة إلى الترجمة الصوتية"))
                else:
                    if not getattr(self, "_srt_mode_announced", False):
                        self._srt_mode_announced = True
                        self.show_transient_status(custom_msg="EN→AR · ترجمة جاهزة", duration=5.0)
                    if not other_open:
                        if self.srt_synchronizer.in_ad_break:
                            # Return to live during first ad break so 14s jump is invisible!
                            if self.current_bridge_sec > 0:
                                self._disable_time_bridge_for_srt()
                            if self.osd and getattr(self.osd, "is_active", False):
                                self.osd.hide_subtitle()
                    else:
                        # Requirement 1: Read real picture delay from player every 2s
                        if (now - getattr(self, "_last_pic_delay_check", 0.0)) >= 2.0:
                            self._last_pic_delay_check = now
                            self._cached_real_pic_delay = self.get_real_picture_delay()
                        real_delay = getattr(self, "_cached_real_pic_delay", 0.0)
                        user_delay = float(self.get_effective_setting("delay") or 0.0)
                        disp_time = (now - real_delay) - user_delay
                        cue = self.srt_synchronizer.get_current_subtitle(disp_time)
                        if cue:
                            ar_text, en_text = cue
                            if getattr(self, "_last_srt_text", None) != ar_text:
                                self._last_srt_text = ar_text
                                self._ensure_osd()
                                if self.osd:
                                    dur = self.get_effective_display_duration(ar_text)
                                    self.osd.display_subtitle(trans_text=ar_text, orig_text=en_text, duration=dur)
                        pill_mode = getattr(settings.config.plugins.enigmatranslate.status_pill, "value", "auto")
                        if pill_mode == "always" and self.toast and (now - getattr(self, "_last_srt_toast_time", 0)) >= 5.0:
                            self._last_srt_toast_time = now
                            self.toast.show_status("EN→AR · ترجمة جاهزة", duration=2.5)


        except Exception as e:
            self._handle_callback_error(e, "_on_gui_tick")

    def show_test_line(self):
        """Trigger a test subtitle line for display testing."""
        self._ensure_osd()
        if self.osd:
            dur = self.get_effective_display_duration("سيوجّه رئيس الوزراء كلمة إلى الأمة الليلة.")
            self.osd.display_subtitle(
                trans_text="سيوجّه رئيس الوزراء كلمة إلى الأمة الليلة.",
                orig_text="The prime minister will address the nation tonight.",
                duration=dur,
                force=True
            )
