# -*- coding: utf-8 -*-
# Author: Ahmad Al-Qaisi
"""Local IPTV Relay Server.

Guarantees only ONE upstream connection exists to the IPTV provider.
Both the Enigma2 player and EnigmaTranslate taps (audio/subs) connect to
this local relay (http://127.0.0.1:<port>/...).
Supports both MPEG-TS live streams (multicast fan-out buffer) and HLS (.m3u8).
"""

import collections
import http.client
import http.cookiejar
import http.server
import logging
import os
import queue
import re
import socket
import socketserver
import threading
import time
import urllib.parse
import urllib.request

logger = logging.getLogger("EnigmaTranslate.iptv_relay")

RELAY_PORT = 18088
TS_PACKET_SIZE = 188
CHUNK_SIZE = 188 * 348    # 65,424 bytes (exact multiple of 188 TS packets)
MAX_QUEUE_CHUNKS = 100   # ~6.5 MB buffer per client

DEFAULT_BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/145.0.0.0 Safari/537.36"
)


class UpstreamRejectedError(Exception):
    """Raised when upstream server returns an error status (401, 403, 429)."""
    def __init__(self, status, reason, headers=None):
        super().__init__(f"Upstream rejected with HTTP {status}: {reason}")
        self.status = status
        self.reason = reason
        self.headers = headers or {}


def xtream_prefer_ts(url):
    """For Xtream live URLs, prefer the .ts form (/live/user/pass/id.ts), not m3u8."""
    # Match /live/user/pass/id.m3u8 or /user/pass/id.m3u8
    m = re.match(r'^(https?://[^/]+(?:/[^/]+)*?/(?:live/)?[^/]+/[^/]+/\d+)\.m3u8(\?.*)?$', url, re.IGNORECASE)
    if m:
        query = m.group(2) or ""
        return f"{m.group(1)}.ts{query}"
    # Match /live/user/pass/id (without extension)
    m2 = re.match(r'^(https?://[^/]+(?:/[^/]+)*?/(?:live/)?[^/]+/[^/]+/\d+)$', url, re.IGNORECASE)
    if m2:
        return f"{m2.group(1)}.ts"
    return url


def parse_enigma2_stream_url(raw):
    """Extract clean URL and headers (#User-Agent=..., #Referer=..., etc.) from Enigma2 URL or service ref."""
    headers = {
        "User-Agent": DEFAULT_BROWSER_UA,
        "Accept": "*/*",
        "Connection": "keep-alive",
    }
    # Check XStreamity useragent setting if present
    try:
        from Components.config import config
        try:
            ua = str(config.plugins.xstreamity.useragent.value).strip()
            if ua:
                headers["User-Agent"] = ua
        except (AttributeError, KeyError):
            pass
    except Exception:
        pass

    raw_str = str(raw or "").strip()

    # If full service reference string passed (e.g. 4097:0:1:...:http%3a//...:NAME), extract field 10
    parts = raw_str.split(":")
    if len(parts) >= 11 and parts[0] in ("4097", "5001", "5002", "5003", "1"):
        url_part = ":".join(parts[10:-1]) if len(parts) > 11 else parts[10]
    else:
        url_part = raw_str

    # Unquote any percentage encoding (%253a -> %3a, etc.)
    url_decoded = urllib.parse.unquote(url_part)
    # Decode %3a -> : for scheme and host
    url_decoded = re.sub(r'%3a', ':', url_decoded, flags=re.IGNORECASE)

    clean_url = url_decoded
    if "#" in url_decoded:
        clean_url, fragment = url_decoded.split("#", 1)
        for part in fragment.replace("&", "#").split("#"):
            if "=" in part:
                k, v = part.split("=", 1)
                k_clean = k.strip()
                v_clean = urllib.parse.unquote(v.strip())
                if k_clean.lower() in ("user-agent", "useragent"):
                    headers["User-Agent"] = v_clean
                elif k_clean.lower() == "referer":
                    headers["Referer"] = v_clean
                elif k_clean.lower() == "cookie":
                    headers["Cookie"] = v_clean
                else:
                    headers[k_clean] = v_clean

    clean_url = xtream_prefer_ts(clean_url.strip())
    return clean_url, headers


def wait_for_socket_close(provider_host, port=80, timeout=1.5):
    """Wait until active TCP connections to the provider host close."""
    t_start = time.time()
    try:
        remote_ip = socket.gethostbyname(provider_host)
        parts = [int(p) for p in remote_ip.split(".")]
        hex_ip = f"{parts[3]:02X}{parts[2]:02X}{parts[1]:02X}{parts[0]:02X}".upper()
    except Exception:
        hex_ip = None

    while time.time() - t_start < timeout:
        found_active = False
        for tcp_path in ("/proc/net/tcp", "/proc/net/tcp6"):
            if not os.path.exists(tcp_path):
                continue
            try:
                with open(tcp_path, "r") as f:
                    for line in f.readlines()[1:]:
                        p = line.strip().split()
                        if len(p) >= 4 and p[3] == "01":  # TCP_ESTABLISHED
                            rem = p[2].upper()
                            if hex_ip and hex_ip in rem:
                                found_active = True
                                break
            except Exception:
                pass
            if found_active:
                break

        if not found_active:
            print(f"[EnigmaTranslate] [RELAY] Upstream socket to {provider_host} confirmed CLOSED.")
            return True
        time.sleep(0.1)

    print(f"[EnigmaTranslate] [RELAY] Socket wait timeout ({timeout}s). Proceeding.")
    return False


def parse_ts_packet_header(pkt):
    """Return (pid, pusi, afc) from a 188-byte TS packet."""
    if len(pkt) < 4 or pkt[0] != 0x47:
        return None, False, 0
    pusi = (pkt[1] & 0x40) != 0
    pid = ((pkt[1] & 0x1F) << 8) | pkt[2]
    afc = (pkt[3] >> 4) & 0x03
    return pid, pusi, afc


def is_ts_video_keyframe(pkt, video_pid=None):
    """Detect if 188-byte TS packet starts a video keyframe (IDR/SPS/VPS/Sequence header or RAI flag)."""
    if len(pkt) < 188 or pkt[0] != 0x47:
        return False
    pid, pusi, afc = parse_ts_packet_header(pkt)
    if video_pid is not None and pid != video_pid:
        return False
    if not pusi:
        return False

    # Check adaptation field for random_access_indicator
    pay_start = 4
    if afc in (0x02, 0x03):
        af_len = pkt[4]
        if af_len > 0 and len(pkt) > 5:
            if (pkt[5] & 0x40) != 0:  # RAI flag
                return True
        pay_start = 5 + af_len

    if pay_start >= 188 - 4:
        return False

    # Scan PES payload for NAL unit start codes
    p = pkt[pay_start:]
    # PES start code: 00 00 01 <stream_id: E0..EF>
    if len(p) >= 9 and p[0] == 0 and p[1] == 0 and p[2] == 1:
        pes_header_data_len = p[8]
        pes_pay_start = 9 + pes_header_data_len
        if pes_pay_start < len(p):
            pes_data = p[pes_pay_start:]
            p_len = len(pes_data)
            for i in range(p_len - 4):
                if pes_data[i] == 0 and pes_data[i + 1] == 0:
                    nal_start = -1
                    if pes_data[i + 2] == 1:
                        nal_start = i + 3
                    elif pes_data[i + 2] == 0 and i + 4 < p_len and pes_data[i + 3] == 1:
                        nal_start = i + 4
                    if 0 < nal_start < p_len:
                        nal_b = pes_data[nal_start]
                        # H.264: 5=IDR, 7=SPS, 8=PPS
                        h264_type = nal_b & 0x1F
                        if h264_type in (5, 7):
                            return True
                        # H.265: 19=IDR_W_RADL, 20=IDR_N_LP, 32=VPS, 33=SPS
                        h265_type = (nal_b >> 1) & 0x3F
                        if h265_type in (19, 20, 32, 33):
                            return True
                        # MPEG-2 sequence header
                        if nal_b == 0xB3:
                            return True
    return False


class RelayHTTPHandler(http.server.BaseHTTPRequestHandler):

    """Handles local client requests from Enigma2 player and audio/sub taps."""

    def log_message(self, format, *args):
        pass

    def do_GET(self):
        relay_mgr = IPTVRelayManager.get_instance()
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        req_headers = {k: v for k, v in self.headers.items()}
        print(f"[EnigmaTranslate] [RELAY DEBUG] GET {path} from {self.client_address}: Range={req_headers.get('Range')}, Connection={req_headers.get('Connection')}, Headers={req_headers}")

        if path == "/live.ts" or path.startswith("/live"):
            self._handle_ts_stream(relay_mgr)
        elif path.endswith(".m3u8"):
            self._handle_hls_playlist(relay_mgr, parsed)
        elif path.startswith("/hls/segment"):
            self._handle_hls_segment(relay_mgr, parsed)
        else:
            self.send_error(404, "Not Found")

    def _handle_ts_stream(self, relay_mgr):
        """Stream raw MPEG-TS or audio stream to subscriber."""
        buf_len = len(relay_mgr.delay_buffer.ram_queue) if (relay_mgr.delay_buffer and not relay_mgr.delay_buffer.use_disk) else (len(relay_mgr.delay_buffer.disk_index) if relay_mgr.delay_buffer else 0)
        buf_sec = relay_mgr.get_buffered_duration()
        client_q = relay_mgr.subscribe_ts()
        if not client_q:
            self.send_error(502, "Upstream stream unavailable")
            return

        print(f"[EnigmaTranslate] [RELAY] Player connected to /live.ts (delay={relay_mgr.target_delay_sec:.1f}s, buffered={buf_sec:.1f}s, chunks={buf_len}, player_aligned={relay_mgr.player_aligned})")
        bytes_sent = 0
        try:
            self.send_response(200)
            self.send_header("Content-Type", "video/mp2t")
            self.send_header("Cache-Control", "no-cache, no-store")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Connection", "close")
            self.end_headers()

            while relay_mgr.is_running:
                try:
                    chunk = client_q.get(timeout=2.0)
                    if chunk is None:
                        break
                    self.wfile.write(chunk)
                    bytes_sent += len(chunk)
                    relay_mgr.bytes_sent_to_player += len(chunk)
                except queue.Empty:
                    if not relay_mgr.is_upstream_alive():
                        break
                    continue
        except (BrokenPipeError, ConnectionResetError) as e:
            print(f"[EnigmaTranslate] [RELAY] Player connection reset/broken: {e}")
        except Exception as e:
            print(f"[EnigmaTranslate] [RELAY] Client write error: {e}")
        finally:
            print(f"[EnigmaTranslate] [RELAY] Player disconnected from /live.ts (this conn sent {bytes_sent} bytes). Total sent to all players: {relay_mgr.bytes_sent_to_player}")
            relay_mgr.unsubscribe_ts(client_q)


    def _handle_hls_playlist(self, relay_mgr, parsed):
        content = relay_mgr.get_hls_playlist()
        if content is None:
            self.send_error(502, "Failed to fetch HLS playlist")
            return
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.apple.mpegurl")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def _handle_hls_segment(self, relay_mgr, parsed):
        qs = urllib.parse.parse_qs(parsed.query)
        seg_url = qs.get("url", [None])[0]
        if not seg_url:
            self.send_error(400, "Missing segment URL")
            return

        seg_data = relay_mgr.get_hls_segment(seg_url)
        if seg_data is None:
            self.send_error(502, "Failed to fetch segment")
            return

        self.send_response(200)
        self.send_header("Content-Type", "video/mp2t")
        self.send_header("Content-Length", str(len(seg_data)))
        self.end_headers()
        self.wfile.write(seg_data)


class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class DelayedTSBuffer:
    """Delay buffer holding N seconds of TS stream for the player.

    Uses RAM if (N * bitrate <= 32 MB and buffered_bytes <= 32 MB),
    otherwise spills to a rolling file on /media/hdd/enigmatranslate/tmp/.
    Always cuts at 188-byte TS packet boundaries.
    """

    def __init__(self, target_delay_sec=14.0, max_ram_bytes=96 * 1024 * 1024):
        self.target_delay_sec = max(0.0, float(target_delay_sec))
        self.max_ram_bytes = int(max_ram_bytes)
        self.lock = threading.Lock()

        # RAM storage: deque of (arrival_time, bytes)
        self.ram_queue = collections.deque()
        self.ram_bytes = 0

        # Stream metrics
        self.start_time = None
        self.total_bytes_in = 0
        self.bitrate = 0.0  # bytes/sec

        # Disk storage fallback
        self.use_disk = False
        self.disk_file_path = None
        self.disk_write_file = None
        self.disk_read_file = None
        self.disk_index = collections.deque()  # (arrival_time, offset, length)
        self.disk_write_offset = 0
        self.disk_bytes = 0

    def push(self, chunk):
        """Append aligned TS chunk with current timestamp."""
        if not chunk:
            return
        now = time.time()
        with self.lock:
            if self.start_time is None:
                self.start_time = now
            self.total_bytes_in += len(chunk)
            elapsed = now - self.start_time
            if elapsed >= 1.0:
                self.bitrate = self.total_bytes_in / elapsed

            est_needed = self.target_delay_sec * self.bitrate if self.bitrate > 0 else 0
            if not self.use_disk:
                if (est_needed > self.max_ram_bytes) or (self.ram_bytes + len(chunk) > self.max_ram_bytes):
                    self._switch_to_disk()

            if self.use_disk:
                self._write_to_disk(now, chunk)
            else:
                self.ram_queue.append((now, chunk))
                self.ram_bytes += len(chunk)

    def _switch_to_disk(self):
        try:
            target_dir = "/media/hdd/enigmatranslate/tmp"
            if not os.path.isdir(target_dir):
                target_dir = "/tmp/enigmatranslate/tmp"
            os.makedirs(target_dir, exist_ok=True)
            self.disk_file_path = os.path.join(
                target_dir, f"iptv_bridge_{os.getpid()}_{int(time.time())}.ts"
            )
            self.disk_write_file = open(self.disk_file_path, "wb", buffering=0)
            self.disk_read_file = open(self.disk_file_path, "rb", buffering=0)
            self.disk_write_offset = 0
            self.disk_bytes = 0

            # Drain existing RAM queue into the disk file
            while self.ram_queue:
                ts, c = self.ram_queue.popleft()
                self._write_to_disk(ts, c)
            self.ram_bytes = 0
            self.use_disk = True
            print(f"[EnigmaTranslate] [RELAY BRIDGE] Stream required disk buffer ({self.bitrate/1024/1024*8:.1f} Mbps) -> {self.disk_file_path}")
        except Exception as e:
            print(f"[EnigmaTranslate] [RELAY BRIDGE] Failed to switch to disk: {e}; remaining in RAM")
            self.use_disk = False

    def _write_to_disk(self, ts, chunk):
        if not self.disk_write_file:
            return
        offset = self.disk_write_offset
        self.disk_write_file.write(chunk)
        self.disk_write_offset += len(chunk)
        self.disk_bytes += len(chunk)
        self.disk_index.append((ts, offset, len(chunk)))

        # Rolling buffer rule on disk: if file exceeds 150 MB, punch hole in the front
        if self.disk_write_offset > 150 * 1024 * 1024 and self.disk_index:
            oldest_offset = self.disk_index[0][1]
            if oldest_offset > 50 * 1024 * 1024:
                punch_len = (oldest_offset // 4096) * 4096
                self._punch_hole(punch_len)

    def _punch_hole(self, punch_len):
        if not self.disk_file_path or punch_len <= 0 or not self.disk_write_file:
            return
        try:
            import ctypes
            libc = ctypes.CDLL(None)
            fd = self.disk_write_file.fileno()
            # FALLOC_FL_PUNCH_HOLE (0x02) | FALLOC_FL_KEEP_SIZE (0x01) = 0x03
            if hasattr(libc, "fallocate64"):
                libc.fallocate64.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int64, ctypes.c_int64]
                libc.fallocate64(fd, 3, 0, punch_len)
            elif hasattr(libc, "fallocate"):
                libc.fallocate.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int64, ctypes.c_int64]
                libc.fallocate(fd, 3, 0, punch_len)
        except Exception:
            pass

    def pop_ready(self):
        """Pop the oldest chunk from buffer."""
        now = time.time()
        with self.lock:
            if not self.use_disk:
                if not self.ram_queue:
                    return None
                oldest_ts, _ = self.ram_queue[0]
                if now - oldest_ts >= (self.target_delay_sec - 1.0):
                    ts, chunk = self.ram_queue.popleft()
                    self.ram_bytes -= len(chunk)
                    return chunk
                return None
            else:
                if not self.disk_index:
                    return None
                oldest_ts, offset, length = self.disk_index[0]
                if now - oldest_ts >= (self.target_delay_sec - 1.0):
                    self.disk_index.popleft()
                    try:
                        self.disk_read_file.seek(offset)
                        data = self.disk_read_file.read(length)
                        if not data:
                            return None
                        self.disk_bytes -= len(data)
                        return data
                    except Exception as e:
                        print(f"[EnigmaTranslate] [RELAY BRIDGE] Disk read error: {e}")
                        return None
                return None


    def get_buffered_duration(self):
        """Return how many seconds of stream data are currently buffered."""
        now = time.time()
        with self.lock:
            if not self.use_disk:
                if not self.ram_queue:
                    return 0.0
                return max(0.0, now - self.ram_queue[0][0])
            else:
                if not self.disk_index:
                    return 0.0
                return max(0.0, now - self.disk_index[0][0])

    def close(self):
        """Clean up all memory and disk buffer files."""
        with self.lock:
            self.ram_queue.clear()
            self.ram_bytes = 0
            if self.disk_write_file:
                try:
                    self.disk_write_file.close()
                except Exception:
                    pass
                self.disk_write_file = None
            if self.disk_read_file:
                try:
                    self.disk_read_file.close()
                except Exception:
                    pass
                self.disk_read_file = None
            if self.disk_file_path and os.path.exists(self.disk_file_path):
                try:
                    os.remove(self.disk_file_path)
                    print(f"[EnigmaTranslate] [RELAY BRIDGE] Purged buffer file: {self.disk_file_path}")
                except Exception:
                    pass
                self.disk_file_path = None
            self.disk_index.clear()
            self.use_disk = False


class IPTVRelayManager:
    """Singleton manager controlling the local relay and single upstream connection."""

    _instance = None
    _lock = threading.Lock()

    def __init__(self):
        self.port = RELAY_PORT
        self.server = None
        self.server_thread = None
        self.upstream_url = None
        self.upstream_headers = {}
        self.is_running = False

        # TS streaming & Time-Bridge delay buffer
        self.target_delay_sec = 0.0
        self.delay_buffer = None
        self.delay_dispatcher_thread = None
        self.subscribers = set()
        self.ffmpeg_subscribers = set()
        self.subscribers_lock = threading.Lock()
        self.upstream_thread = None
        self.upstream_resp = None
        self.upstream_alive = False
        self.header_cache = bytearray()
        self.bytes_received = 0
        self.bytes_sent_to_player = 0
        self.last_data_time = 0.0
        self.last_error = None

        # Clean stream alignment & PAT/PMT caching
        self.cached_pat_pkt = None
        self.cached_pmt_pkt = None
        self.pmt_pid = None
        self.video_pid = None
        self.player_aligned = False
        self.alignment_buffer = bytearray()

        # Cookie jar and opener
        self.cookie_jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.cookie_jar),
            urllib.request.HTTPRedirectHandler()
        )

        # HLS caching
        self.hls_cache = {}
        self.hls_cache_lock = threading.Lock()

        # Drop notification callback (background thread only, safe callback)
        self.drop_callback = None

    @classmethod
    def get_instance(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

    def set_drop_callback(self, cb):
        """Set callback to notify when upstream drops after all retries fail."""
        self.drop_callback = cb

    def _notify_drop(self, reason):
        if self.drop_callback:
            try:
                self.drop_callback(reason)
            except Exception as e:
                print(f"[EnigmaTranslate] [RELAY] Drop callback error: {e}")

    def start_relay(self, raw_url, delay_sec=0.0):
        """Ensure local server is running, parse headers, and start upstream reader."""
        self._ensure_server_started()
        clean_url, headers = parse_enigma2_stream_url(raw_url)
        self.upstream_url = clean_url
        self.upstream_headers = headers
        self.is_running = True
        self.bytes_received = 0
        self.bytes_sent_to_player = 0
        self.last_data_time = time.time()
        self.last_error = None
        self.target_delay_sec = max(0.0, float(delay_sec))
        self.cached_pat_pkt = None
        self.cached_pmt_pkt = None
        self.pmt_pid = None
        self.video_pid = None
        self.player_aligned = False
        self.alignment_buffer.clear()


        if self.delay_buffer:
            self.delay_buffer.close()
            self.delay_buffer = None

        if self.target_delay_sec > 0:
            self.delay_buffer = DelayedTSBuffer(target_delay_sec=self.target_delay_sec)
            self.delay_dispatcher_thread = threading.Thread(target=self._delay_dispatcher_worker, daemon=True, name="ET_RelayDispatcher")
            self.delay_dispatcher_thread.start()
            print(f"[EnigmaTranslate] [RELAY] Initialized Time-Bridge delay buffer for {self.target_delay_sec:.1f}s")
        else:
            self.delay_buffer = None

        # Start upstream worker immediately so buffer fills before player connects
        self._start_upstream_worker()

        url_lower = clean_url.lower()
        if ".m3u8" in url_lower:
            return f"http://127.0.0.1:{self.port}/live.m3u8"
        return f"http://127.0.0.1:{self.port}/live.ts"

    def get_buffered_duration(self):
        """Return how many seconds of stream data are currently buffered in the delay buffer."""
        if self.delay_buffer:
            return self.delay_buffer.get_buffered_duration()
        return 0.0

    def wait_for_initial_data(self, min_bytes=131072, timeout=5.0):
        """Wait until at least min_bytes (128 KB) arrives so GStreamer typefindelement succeeds."""
        t_start = time.time()
        while time.time() - t_start < timeout:
            if self.bytes_received >= min_bytes:
                print(f"[EnigmaTranslate] [RELAY] Initial data ready ({self.bytes_received} bytes in {time.time()-t_start:.2f}s)")
                return True
            if self.last_error:
                print(f"[EnigmaTranslate] [RELAY] Upstream failed while waiting: {self.last_error}")
                return False
            time.sleep(0.05)
        print(f"[EnigmaTranslate] [RELAY] Initial data timeout (got {self.bytes_received} bytes)")
        return self.bytes_received > 0

    def _ensure_server_started(self):
        if self.server is not None:
            return

        for p in (RELAY_PORT, RELAY_PORT + 1, RELAY_PORT + 2, 0):
            try:
                self.server = ThreadingHTTPServer(("127.0.0.1", p), RelayHTTPHandler)
                self.port = self.server.server_address[1]
                break
            except Exception as e:
                print(f"[EnigmaTranslate] [RELAY] Port {p} busy: {e}")

        if not self.server:
            raise RuntimeError("Could not bind local relay server on any port")

        self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.server_thread.start()
        print(f"[EnigmaTranslate] [RELAY] Local relay server listening on 127.0.0.1:{self.port}")

    def stop_relay(self):
        """Close upstream connection within 2s and clear active subscribers."""
        self.is_running = False
        self._close_upstream()
        if self.delay_buffer:
            self.delay_buffer.close()
            self.delay_buffer = None
        self.target_delay_sec = 0.0
        self.player_aligned = False
        self.alignment_buffer.clear()
        self.bytes_sent_to_player = 0

        with self.subscribers_lock:
            for q in list(self.subscribers):
                try:
                    q.put_nowait(None)
                except Exception:
                    pass
            self.subscribers.clear()

            for fq in list(self.ffmpeg_subscribers):
                try:
                    fq.put_nowait(None)
                except Exception:
                    pass
            self.ffmpeg_subscribers.clear()

        with self.hls_cache_lock:
            self.hls_cache.clear()
        print("[EnigmaTranslate] [RELAY] Relay stopped, upstream closed within 2s.")

    def subscribe_ts(self):
        """Add new subscriber for TS stream. Reuses running upstream without reopening."""
        with self.subscribers_lock:
            q = queue.Queue(maxsize=MAX_QUEUE_CHUNKS)
            # Pre-feed only cached PAT/PMT packets (376 bytes) so GStreamer typefind succeeds immediately
            # Do NOT send header_cache (which contains old video data from t=0) to avoid looping scenes
            header_data = bytearray()
            if self.cached_pat_pkt:
                header_data.extend(self.cached_pat_pkt)
            if self.cached_pmt_pkt:
                header_data.extend(self.cached_pmt_pkt)
            if header_data:
                try:
                    q.put_nowait(bytes(header_data))
                except Exception:
                    pass

            self.subscribers.add(q)
            self.last_data_time = time.time()

            # Ensure delay dispatcher is running if in Time-Bridge mode
            if self.target_delay_sec > 0 and self.delay_buffer:
                if not self.delay_dispatcher_thread or not self.delay_dispatcher_thread.is_alive():
                    self.delay_dispatcher_thread = threading.Thread(target=self._delay_dispatcher_worker, daemon=True, name="ET_RelayDispatcher")
                    self.delay_dispatcher_thread.start()

            # Reuse existing upstream if alive
            if not self.upstream_alive or not self.upstream_thread or not self.upstream_thread.is_alive():
                self._start_upstream_worker()
            return q

    def unsubscribe_ts(self, q):
        """Remove subscriber."""
        with self.subscribers_lock:
            self.subscribers.discard(q)
            if not self.subscribers and not self.ffmpeg_subscribers:
                threading.Thread(target=self._idle_upstream_cleanup, daemon=True).start()

    def _delay_dispatcher_worker(self):
        """Worker thread releasing delayed TS blocks to player subscribers with clean start."""
        self.player_aligned = False
        self.alignment_buffer.clear()

        while self.is_running:
            if self.target_delay_sec <= 0 or not self.delay_buffer:
                time.sleep(0.05)
                continue


            with self.subscribers_lock:
                has_subscribers = bool(self.subscribers)

            if not has_subscribers:
                # Still buffering before playService; do not pop chunks yet!
                time.sleep(0.02)
                continue

            ready_chunk = self.delay_buffer.pop_ready()
            if not ready_chunk:
                time.sleep(0.005)
                continue

            try:
                # If player stream is not yet aligned to a clean start (Video Keyframe/PUSI)
                if not self.player_aligned:
                    self.alignment_buffer.extend(ready_chunk)
                    clean_offset = -1
                    vpid = self.video_pid

                    # Scan alignment_buffer for video keyframe with PUSI
                    buf_len = len(self.alignment_buffer)
                    num_pkts = buf_len // 188
                    for i in range(num_pkts):
                        pkt = self.alignment_buffer[i * 188:(i + 1) * 188]
                        if vpid is not None and is_ts_video_keyframe(pkt, vpid):
                            clean_offset = i * 188
                            print(f"[EnigmaTranslate] [RELAY BRIDGE] Found clean video keyframe on PID {vpid} at packet {i}")
                            break

                    # Fallback 1: any video packet with PUSI=1
                    if clean_offset < 0:
                        for i in range(num_pkts):
                            pkt = self.alignment_buffer[i * 188:(i + 1) * 188]
                            pid, pusi, _ = parse_ts_packet_header(pkt)
                            if (vpid is None or pid == vpid) and pusi:
                                clean_offset = i * 188
                                print(f"[EnigmaTranslate] [RELAY BRIDGE] Fallback: aligned at video PUSI packet {i}")
                                break

                    # Fallback 2: packet 0 if buffer has whole packets
                    if clean_offset < 0 and buf_len >= 188:
                        clean_offset = 0
                        print("[EnigmaTranslate] [RELAY BRIDGE] Fallback: aligned at packet 0")

                    if clean_offset >= 0:
                        header_pkts = bytearray()
                        if self.cached_pat_pkt:
                            header_pkts.extend(self.cached_pat_pkt)
                        if self.cached_pmt_pkt:
                            header_pkts.extend(self.cached_pmt_pkt)

                        burst = bytes(header_pkts) + bytes(self.alignment_buffer[clean_offset:])
                        self.alignment_buffer.clear()
                        self.player_aligned = True
                        print(f"[EnigmaTranslate] [RELAY BRIDGE] Clean player feed start aligned! Dispatched initial burst with PAT+PMT ({len(burst)} bytes, PAT={bool(self.cached_pat_pkt)}, PMT={bool(self.cached_pmt_pkt)})")

                        with self.subscribers_lock:
                            for q in list(self.subscribers):
                                try:
                                    q.put_nowait(burst)
                                except queue.Full:
                                    try:
                                        q.get_nowait()
                                        q.put_nowait(burst)
                                    except Exception:
                                        pass
                        continue
                    else:
                        continue


                # Player is aligned: stream directly
                with self.subscribers_lock:
                    for q in list(self.subscribers):
                        try:
                            q.put_nowait(ready_chunk)
                        except queue.Full:
                            try:
                                q.get_nowait()
                                q.put_nowait(ready_chunk)
                            except Exception:
                                pass
            except Exception as e:
                print(f"[EnigmaTranslate] [RELAY BRIDGE] Dispatcher error: {e}")


            if not self.subscribers and not self.ffmpeg_subscribers:
                threading.Thread(target=self._idle_upstream_cleanup, daemon=True).start()



    def subscribe_ffmpeg(self, maxsize_mb=4):
        """Subscribe FFmpeg with a bounded queue (~4 MB).
        
        Player feed has strict priority. If FFmpeg queue is full, data is dropped.
        """
        max_chunks = max(10, int((maxsize_mb * 1024 * 1024) / CHUNK_SIZE))
        with self.subscribers_lock:
            q = queue.Queue(maxsize=max_chunks)
            if self.header_cache:
                try:
                    q.put_nowait(bytes(self.header_cache))
                except Exception:
                    pass
            self.ffmpeg_subscribers.add(q)
            self.last_data_time = time.time()
            if not self.upstream_alive or not self.upstream_thread or not self.upstream_thread.is_alive():
                self._start_upstream_worker()
            return q

    def unsubscribe_ffmpeg(self, q):
        """Remove FFmpeg subscriber and unblock feeder."""
        with self.subscribers_lock:
            self.ffmpeg_subscribers.discard(q)
            try:
                q.put_nowait(None)
            except Exception:
                pass
            if not self.subscribers and not self.ffmpeg_subscribers:
                threading.Thread(target=self._idle_upstream_cleanup, daemon=True).start()

    def _idle_upstream_cleanup(self):
        time.sleep(5.0)
        with self.subscribers_lock:
            if not self.subscribers and not self.ffmpeg_subscribers:
                print("[EnigmaTranslate] [RELAY] No active subscribers -> closing single upstream connection.")
                self._close_upstream()

    def _start_upstream_worker(self):
        self._close_upstream()
        self.upstream_alive = True
        self.upstream_thread = threading.Thread(target=self._upstream_worker, daemon=True, name="ET_RelayUpstream")
        self.upstream_thread.start()

    def _upstream_worker(self):
        """Single upstream connection worker with 3-retry backoff reconnect."""
        if not self.upstream_url:
            self.upstream_alive = False
            return

        max_retries = 3
        backoff_delays = [0.5, 1.0, 2.0]
        retry_count = 0

        while self.is_running and self.upstream_alive:
            print(f"[EnigmaTranslate] [RELAY] Connecting SINGLE upstream (try {retry_count + 1}) to {self.upstream_url}")
            print(f"[EnigmaTranslate] [RELAY] Request Headers: {self.upstream_headers}")

            try:
                req = urllib.request.Request(self.upstream_url, headers=self.upstream_headers)
                resp = self.opener.open(req, timeout=30.0)
                self.upstream_resp = resp

                status = getattr(resp, "status", getattr(resp, "code", 200))
                reason = getattr(resp, "reason", "OK")
                headers_dict = dict(resp.headers)
                print(f"[EnigmaTranslate] [RELAY] Upstream status: HTTP {status} {reason}")

                if status in (401, 403, 429):
                    print(f"[EnigmaTranslate] [RELAY] Upstream REJECTED with HTTP {status}!")
                    self.last_error = f"HTTP {status} {reason}"
                    break

                # Reset retry counter on receiving stream
                retry_count = 0
                self.header_cache.clear()
                upstream_ts_buffer = bytearray()

                while self.upstream_alive and self.is_running:
                    r = self.upstream_resp
                    if not r:
                        break
                    try:
                        if hasattr(r, "read1"):
                            raw_chunk = r.read1(CHUNK_SIZE)
                        else:
                            raw_chunk = r.read(CHUNK_SIZE)
                    except http.client.IncompleteRead as ir:
                        raw_chunk = ir.partial
                    except Exception as e_read:
                        print(f"[EnigmaTranslate] [RELAY] r.read error: {e_read!r}")
                        break
                    if not raw_chunk:
                        print("[EnigmaTranslate] [RELAY] Upstream stream ended (EOF).")
                        break

                    self.bytes_received += len(raw_chunk)
                    self.last_data_time = time.time()

                    upstream_ts_buffer.extend(raw_chunk)

                    # 1. Align buffer start to 0x47 sync byte
                    sync_idx = 0
                    buf_len = len(upstream_ts_buffer)
                    while sync_idx <= buf_len - 188:
                        if upstream_ts_buffer[sync_idx] == 0x47:
                            break
                        sync_idx += 1
                    if sync_idx > 0:
                        del upstream_ts_buffer[:sync_idx]
                        buf_len = len(upstream_ts_buffer)

                    # 2. Extract whole 188-byte packets
                    emit_bytes = (buf_len // 188) * 188
                    if emit_bytes <= 0:
                        continue

                    ts_block = bytes(upstream_ts_buffer[:emit_bytes])
                    del upstream_ts_buffer[:emit_bytes]

                    # Parse packets for PAT (PID 0) and PMT to find video PID and cache header packets
                    block_len = len(ts_block)
                    for pkt_idx in range(0, block_len, 188):
                        pkt = ts_block[pkt_idx:pkt_idx + 188]
                        if len(pkt) < 188 or pkt[0] != 0x47:
                            continue
                        pid, pusi, afc = parse_ts_packet_header(pkt)
                        if pid == 0:  # PAT
                            self.cached_pat_pkt = bytes(pkt)
                            try:
                                pay_off = 4
                                if afc in (0x02, 0x03):
                                    pay_off = 5 + pkt[4]
                                if pusi and pay_off < 188:
                                    pay_off += 1 + pkt[pay_off]
                                if pay_off + 8 < 188 and pkt[pay_off] == 0x00:
                                    sec_len = ((pkt[pay_off + 1] & 0x0F) << 8) | pkt[pay_off + 2]
                                    pos = pay_off + 8
                                    end_pos = min(188 - 4, pay_off + 3 + sec_len)
                                    while pos + 4 <= end_pos:
                                        p_num = (pkt[pos] << 8) | pkt[pos + 1]
                                        p_pid = ((pkt[pos + 2] & 0x1F) << 8) | pkt[pos + 3]
                                        if p_num != 0:
                                            self.pmt_pid = p_pid
                                            break
                                        pos += 4
                            except Exception:
                                pass
                        elif self.pmt_pid is not None and pid == self.pmt_pid:  # PMT
                            self.cached_pmt_pkt = bytes(pkt)
                            try:
                                pay_off = 4
                                if afc in (0x02, 0x03):
                                    pay_off = 5 + pkt[4]
                                if pusi and pay_off < 188:
                                    pay_off += 1 + pkt[pay_off]
                                if pay_off + 12 < 188 and pkt[pay_off] == 0x02:
                                    sec_len = ((pkt[pay_off + 1] & 0x0F) << 8) | pkt[pay_off + 2]
                                    prog_info_len = ((pkt[pay_off + 10] & 0x0F) << 8) | pkt[pay_off + 11]
                                    pos = pay_off + 12 + prog_info_len
                                    end_pos = min(188 - 4, pay_off + 3 + sec_len)
                                    while pos + 5 <= end_pos:
                                        stype = pkt[pos]
                                        elem_pid = ((pkt[pos + 1] & 0x1F) << 8) | pkt[pos + 2]
                                        es_info_len = ((pkt[pos + 3] & 0x0F) << 8) | pkt[pos + 4]
                                        # Video stream types: MPEG1, MPEG2, H264, H265, AVS, VC1
                                        if stype in (0x01, 0x02, 0x1B, 0x24, 0x42, 0xEA):
                                            if self.video_pid != elem_pid:
                                                self.video_pid = elem_pid
                                                print(f"[EnigmaTranslate] [RELAY] Detected Video PID {self.video_pid} (stream_type 0x{stype:02X})")
                                            break
                                        pos += 5 + es_info_len
                            except Exception:
                                pass

                    # Retain initial 256KB for header cache
                    if len(self.header_cache) < 256 * 1024:
                        self.header_cache.extend(ts_block)

                    # 1. FFmpeg audio feed: IMMEDIATELY (no delay, bounded queue ~4 MB)
                    with self.subscribers_lock:
                        if self.ffmpeg_subscribers:
                            for fq in list(self.ffmpeg_subscribers):
                                try:

                                    fq.put_nowait(ts_block)
                                except queue.Full:
                                    try:
                                        fq.get_nowait()
                                        fq.put_nowait(ts_block)
                                    except Exception:
                                        pass

                    # 2. Player feed:
                    if self.target_delay_sec <= 0.0 or not self.delay_buffer:
                        # Phase 2: feed player immediately
                        with self.subscribers_lock:
                            for q in list(self.subscribers):
                                try:
                                    q.put_nowait(ts_block)
                                except queue.Full:
                                    try:
                                        q.get_nowait()
                                        q.put_nowait(ts_block)
                                    except Exception:
                                        pass
                    else:
                        # Phase 3: feed delay buffer of N seconds
                        self.delay_buffer.push(ts_block)

            except urllib.error.HTTPError as he:
                status = getattr(he, "code", getattr(he, "status", 0))
                reason = getattr(he, "reason", "HTTP Error")
                print(f"[EnigmaTranslate] [RELAY] Upstream HTTP error: HTTP {status} {reason}")
                if status in (401, 403, 429):
                    self.last_error = f"HTTP {status} {reason}"
                    break
                self.last_error = f"HTTP {status} {reason}"
            except urllib.error.URLError as ue:
                print(f"[EnigmaTranslate] [RELAY] Upstream URL error: {ue.reason}")
                self.last_error = f"Connection error: {ue.reason}"
            except Exception as e:
                print(f"[EnigmaTranslate] [RELAY] Upstream exception: {e}")
                self.last_error = str(e)
            finally:
                if self.upstream_resp:
                    try:
                        self.upstream_resp.close()
                    except Exception:
                        pass
                    self.upstream_resp = None

            if not self.is_running or not self.upstream_alive:
                break

            # Upstream dropped unexpectedly -> reconnect with backoff (max 3 tries)
            retry_count += 1
            if retry_count <= max_retries:
                delay = backoff_delays[retry_count - 1]
                print(f"[EnigmaTranslate] [RELAY] Upstream dropped. Reconnecting in {delay}s (attempt {retry_count}/{max_retries})...")
                t_end = time.time() + delay
                while time.time() < t_end and self.is_running and self.upstream_alive:
                    time.sleep(0.1)
            else:
                print(f"[EnigmaTranslate] [RELAY] All {max_retries} reconnect attempts failed.")
                self.upstream_alive = False
                self._notify_drop(self.last_error or "Stream disconnected")
                break

        self.upstream_alive = False
        print("[EnigmaTranslate] [RELAY] Upstream worker stopped.")

    def _close_upstream(self):
        self.upstream_alive = False
        resp = self.upstream_resp
        self.upstream_resp = None
        if resp:
            try:
                # Find and shutdown underlying socket to abort blocking read immediately
                sock = getattr(resp, "sock", None)
                if not sock:
                    fp = getattr(resp, "fp", None)
                    raw = getattr(fp, "raw", None) if fp else None
                    sock = getattr(raw, "_sock", None)
                if sock:
                    try:
                        sock.shutdown(socket.SHUT_RDWR)
                    except Exception:
                        pass
                    try:
                        sock.close()
                    except Exception:
                        pass
            except Exception:
                pass
            try:
                resp.close()
            except Exception:
                pass

    def is_upstream_alive(self):
        return self.upstream_alive

    # --- HLS support ---
    def get_hls_playlist(self):
        if not self.upstream_url:
            return None
        try:
            req = urllib.request.Request(self.upstream_url, headers=self.upstream_headers)
            with self.opener.open(req, timeout=6.0) as resp:
                text = resp.read().decode("utf-8", errors="replace")

            lines = text.splitlines()
            rewritten = []
            base_url = self.upstream_url.rsplit("/", 1)[0] + "/"

            for line in lines:
                line_str = line.strip()
                if line_str and not line_str.startswith("#"):
                    full_seg_url = urllib.parse.urljoin(base_url, line_str)
                    quoted_seg = urllib.parse.quote(full_seg_url, safe="")
                    rewritten.append(f"http://127.0.0.1:{self.port}/hls/segment?url={quoted_seg}")
                else:
                    rewritten.append(line)

            return "\n".join(rewritten).encode("utf-8")
        except Exception as e:
            print(f"[EnigmaTranslate] [RELAY] Failed to fetch HLS playlist: {e}")
            return None

    def get_hls_segment(self, seg_url):
        now = time.time()
        with self.hls_cache_lock:
            if seg_url in self.hls_cache:
                data, ts = self.hls_cache[seg_url]
                return data

        try:
            req = urllib.request.Request(seg_url, headers=self.upstream_headers)
            with self.opener.open(req, timeout=8.0) as resp:
                data = resp.read()

            with self.hls_cache_lock:
                self.hls_cache[seg_url] = (data, now)
                if len(self.hls_cache) > 10:
                    oldest_key = min(self.hls_cache.keys(), key=lambda k: self.hls_cache[k][1])
                    del self.hls_cache[oldest_key]
            return data
        except Exception as e:
            print(f"[EnigmaTranslate] [RELAY] Failed to fetch HLS segment: {e}")
            return None
