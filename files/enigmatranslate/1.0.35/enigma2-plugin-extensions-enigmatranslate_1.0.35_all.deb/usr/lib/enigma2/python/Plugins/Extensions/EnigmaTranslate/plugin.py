# -*- coding: utf-8 -*-
# Author: Ahmad Al-Qaisi
"""Enigma Translate plugin entry point and descriptors."""

import os
import sys
from . import settings, VERSION
from .core import Controller, restore_leftover_timeshift_bypass

PLUGIN_NAME = "Enigma Translate"
PLUGIN_DESC = "Live translation of foreign TV channels (subtitles and audio)"
PLUGIN_ICON = "plugin.png"
PLUGIN_AUTHOR = "Ahmad Al-Qaisi"


def get_image_info():
    """Detect image name and version across OpenATV, OpenPLi, OpenViX, Egami, BlackHole."""
    name, version = "Enigma2", "unknown"
    # 1. Try boxbranding (OpenATV / Egami)
    try:
        import boxbranding
        if hasattr(boxbranding, "getImageDistro"):
            name = str(boxbranding.getImageDistro() or name)
        if hasattr(boxbranding, "getImageVersion"):
            version = str(boxbranding.getImageVersion() or version)
        return name, version
    except Exception:
        pass

    # 2. Try Components.About (OpenViX / OpenPLi / etc.)
    try:
        from Components.About import about
        if hasattr(about, "getImageVersionString"):
            version = str(about.getImageVersionString() or version)
        if hasattr(about, "getImageDistro"):
            name = str(about.getImageDistro() or name)
        elif hasattr(about, "getEnigmaVersionString") and name == "Enigma2":
            e_ver = str(about.getEnigmaVersionString() or "")
            if e_ver:
                name = e_ver
    except Exception:
        pass

    # 3. Parse /etc/image-version (universal OE-Alliance fallback)
    try:
        if os.path.isfile("/etc/image-version"):
            with open("/etc/image-version", "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    line = line.strip()
                    if line.lower().startswith("creator="):
                        name = line.split("=", 1)[1].strip()
                    elif line.lower().startswith("version="):
                        version = line.split("=", 1)[1].strip()
                    elif line.lower().startswith("distro=") and name == "Enigma2":
                        name = line.split("=", 1)[1].strip()
    except Exception:
        pass

    # 4. Parse /etc/issue (universal Linux fallback)
    if name == "Enigma2" and os.path.isfile("/etc/issue"):
        try:
            with open("/etc/issue", "r", encoding="utf-8", errors="ignore") as f:
                issue = f.readline().strip()
                if issue:
                    name = issue.replace("\\n", "").replace("\\l", "").strip()
        except Exception:
            pass

    return name, version


# Startup log: image name + version, Python version, plugin version
_img_name, _img_ver = get_image_info()
_py_ver = sys.version.split()[0]
print(f"[EnigmaTranslate] Startup: image={_img_name} {_img_ver}, python={_py_ver}, plugin=v{VERSION}")
print(f"[EnigmaTranslate] version {VERSION} loaded")

try:
    from Plugins.Plugin import PluginDescriptor
    from Screens.MessageBox import MessageBox
    HAS_ENIGMA = True
except ImportError:
    HAS_ENIGMA = False
    class PluginDescriptor:
        WHERE_EXTENSIONSMENU = 1
        WHERE_PLUGINMENU = 2
        WHERE_SESSIONSTART = 3
        WHERE_MENU = 4
        def __init__(self, **kwargs):
            self.kwargs = kwargs

# Register plugin icon for Enigma2 main menu (OpenATV 7.x, OpenPLi, OpenViX)
try:
    from Screens.Menu import menuicons
    _icon_full_path = os.path.join(os.path.dirname(__file__), PLUGIN_ICON)
    if os.path.isfile(_icon_full_path):
        menuicons["enigmatranslate"] = _icon_full_path
except Exception:
    pass


def session_start(reason, session=None, **kwargs):
    """Called on session startup to hook events and create Controller singleton."""
    _s_img_name, _s_img_ver = get_image_info()
    _s_py_ver = sys.version.split()[0]
    print(f"[EnigmaTranslate] Startup: image={_s_img_name} {_s_img_ver}, python={_s_py_ver}, plugin=v{VERSION} (session_start reason={reason})")
    print(f"[EnigmaTranslate] version {VERSION} loaded (session_start reason={reason})")
    if reason == 0 and session:
        # Log service played at boot and who requested it
        try:
            from Components.config import config
            last_srv = getattr(getattr(config, "tv", None), "lastservice", None)
            last_val = last_srv.value if last_srv else "none"
            print(f"[EnigmaTranslate] [BOOT] Service played at boot: '{last_val}' (requested by Enigma2 InfoBar from config.tv.lastservice)")
        except Exception as e:
            print(f"[EnigmaTranslate] [BOOT] Error reading boot service: {e}")

        try:
            restore_leftover_timeshift_bypass()
        except Exception:
            pass

        ctrl = Controller.instance(session)
        if hasattr(ctrl, "_install_quick_button_hook"):
            ctrl._install_quick_button_hook()
        cfg = settings.config.plugins.enigmatranslate
        # Default: nothing starts on boot/zap. Only SUBTITLE or explicit channel auto-start starts it.
    elif reason == 1:
        print("[EnigmaTranslate] [SHUTDOWN] Enigma2 shutdown received. Cleaning up all plugin resources without delay...")
        ctrl = Controller.get_instance()
        if ctrl:
            if getattr(ctrl, "relay_active", False):
                ctrl.stop_iptv_relay(restore_playback=False, reason="shutdown")
            ctrl.stop()


def main(session, **kwargs):
    """Open settings dock."""
    from .ui import EnigmaTranslateDock
    session.open(EnigmaTranslateDock)


def main_menu(menuid):
    """Entry point for Enigma2 main menu (OpenATV 7.x / OpenPLi)."""
    if menuid == "mainmenu":
        return [(PLUGIN_NAME, main, "enigmatranslate", 45)]
    return []


def toggle_translation(session, **kwargs):
    """Quick toggle translation on/off from extensions menu."""
    ctrl = Controller.instance(session)
    is_on = ctrl.toggle()
    state_ar = "مفعّلة" if is_on else "متوقفة"
    if HAS_ENIGMA:
        session.open(MessageBox, f"ترجمة Enigma Translate: {state_ar}", MessageBox.TYPE_INFO, timeout=2)


def Plugins(**kwargs):
    """Return Enigma2 PluginDescriptors."""
    descriptors = [
        # Session start hook (autostart)
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=session_start
        ),
        # Main extensions menu entry
        PluginDescriptor(
            name=PLUGIN_NAME,
            description=PLUGIN_DESC,
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            icon=PLUGIN_ICON,
            fnc=main
        ),
        # Quick toggle entry in extensions menu
        PluginDescriptor(
            name="Enigma Translate: On/Off",
            description="Toggle live subtitle translation on/off",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=toggle_translation
        ),
        # Plugin browser menu entry
        PluginDescriptor(
            name=PLUGIN_NAME,
            description=PLUGIN_DESC,
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon=PLUGIN_ICON,
            fnc=main
        ),
        # Main menu entry (OpenATV 7.x and OpenPLi)
        PluginDescriptor(
            name=PLUGIN_NAME,
            description=PLUGIN_DESC,
            where=PluginDescriptor.WHERE_MENU,
            icon=PLUGIN_ICON,
            fnc=main_menu
        )
    ]
    return descriptors

