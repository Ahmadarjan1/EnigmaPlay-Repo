# -*- coding: utf-8 -*-
# Author: Ahmad Al-Qaisi
"""SubRip (.srt) subtitle synchronization for on-air movies.


Finds movies via TMDB (EPG title -> original title, year, IMDb ID),
downloads matched AR + EN .srt via OpenSubtitles REST API v1,
fuzzy-matches live Groq Whisper speech to compute live offset and speed (23.976/25 fps),
displays Arabic cues, blanks during ads (>45s mismatch), and re-anchors on movie resumption.
"""

import os
import re
import json
import time
import base64
import difflib
import urllib.request
import urllib.parse
import urllib.error
import threading
from datetime import datetime

from . import settings

# Subtitle cache directories
HDD_CACHE_DIR = "/media/hdd/enigmatranslate/srt"
FALLBACK_CACHE_DIR = "/etc/enigma2/enigmatranslate/srt"
USAGE_FILE = "/etc/enigma2/enigmatranslate/srt_usage.json"


def get_srt_cache_dir():
    if os.path.isdir("/media/hdd"):
        d = HDD_CACHE_DIR
    else:
        d = FALLBACK_CACHE_DIR
    os.makedirs(d, exist_ok=True)
    return d


def get_daily_usage(source="opensubtitles"):
    """Get downloads today for a specific provider."""
    today = datetime.now().strftime("%Y-%m-%d")
    if os.path.isfile(USAGE_FILE):
        try:
            with open(USAGE_FILE, "r", encoding="utf-8") as f:
                d = json.load(f)
                if d.get("date") == today:
                    if source in d:
                        return d.get(source, 0)
                    if source == "opensubtitles":
                        return d.get("downloads", 0)
        except Exception:
            pass
    return 0


def increment_usage(source="opensubtitles"):
    """Increment download count today for a specific provider."""
    today = datetime.now().strftime("%Y-%m-%d")
    d = {}
    if os.path.isfile(USAGE_FILE):
        try:
            with open(USAGE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if data.get("date") == today:
                    d = data
        except Exception:
            pass
    d["date"] = today
    if "downloads" in d and "opensubtitles" not in d:
        d["opensubtitles"] = d["downloads"]
    d[source] = d.get(source, 0) + 1
    d["downloads"] = d.get("opensubtitles", 0)
    try:
        os.makedirs(os.path.dirname(USAGE_FILE), exist_ok=True)
        with open(USAGE_FILE, "w", encoding="utf-8") as f:
            json.dump(d, f)
    except Exception:
        pass


def get_all_sources_usage():
    """Return dictionary of today's downloads and limits across all providers."""
    return {
        "opensubtitles": {"today": get_daily_usage("opensubtitles"), "limit": 20},
        "subdl": {"today": get_daily_usage("subdl"), "limit": 60},
        "podnapisi": {"today": get_daily_usage("podnapisi"), "limit": "∞"}
    }


def extract_srt_from_bytes(data):
    """Extract .srt file content from raw bytes or zip archive (SubDL/Podnapisi return zip)."""
    if not data:
        return b""
    if data.startswith(b"PK\x03\x04"):
        try:
            import zipfile
            import io
            with zipfile.ZipFile(io.BytesIO(data)) as zf:
                for name in zf.namelist():
                    if name.lower().endswith(".srt"):
                        return zf.read(name)
        except Exception as e:
            print(f"[EnigmaTranslate] SRT zip extract error: {e}")
    return data


def cues_to_srt(cues):
    """Serialize list of SRTCue objects back into standard SRT text format."""
    lines = []
    for c in cues:
        lines.append(str(c.index))
        s_h = int(c.start // 3600)
        s_m = int((c.start % 3600) // 60)
        s_s = c.start % 60
        e_h = int(c.end // 3600)
        e_m = int((c.end % 3600) // 60)
        e_s = c.end % 60
        time_line = f"{s_h:02d}:{s_m:02d}:{s_s:06.3f}".replace(".", ",") + " --> " + f"{e_h:02d}:{e_m:02d}:{e_s:06.3f}".replace(".", ",")
        lines.append(time_line)
        lines.append(c.text)
        lines.append("")
    return "\n".join(lines)


def get_cached_tmdb_srt(tmdb_id):
    """Retrieve pre-translated or downloaded cues cached by TMDB ID."""
    if not tmdb_id:
        return None, None
    d = get_srt_cache_dir()
    en_path = os.path.join(d, f"tmdb_{tmdb_id}_en.srt")
    ar_path = os.path.join(d, f"tmdb_{tmdb_id}_ar.srt")
    en_cues = []
    ar_cues = []
    if os.path.isfile(en_path) and os.path.getsize(en_path) > 10:
        try:
            with open(en_path, "rb") as f:
                en_cues = parse_srt(f.read())
        except Exception:
            pass
    if os.path.isfile(ar_path) and os.path.getsize(ar_path) > 10:
        try:
            with open(ar_path, "rb") as f:
                ar_cues = parse_srt(f.read())
        except Exception:
            pass
    if en_cues or ar_cues:
        return en_cues, ar_cues
    return None, None


def save_cached_tmdb_srt(tmdb_id, en_cues=None, ar_cues=None, en_text=None, ar_text=None):
    """Cache downloaded and pre-translated cues by TMDB ID so movie is never downloaded twice."""
    if not tmdb_id:
        return
    d = get_srt_cache_dir()
    try:
        if en_text:
            with open(os.path.join(d, f"tmdb_{tmdb_id}_en.srt"), "w", encoding="utf-8") as f:
                f.write(en_text if isinstance(en_text, str) else decode_srt_content(en_text))
        elif en_cues:
            with open(os.path.join(d, f"tmdb_{tmdb_id}_en.srt"), "w", encoding="utf-8") as f:
                f.write(cues_to_srt(en_cues))

        if ar_text:
            with open(os.path.join(d, f"tmdb_{tmdb_id}_ar.srt"), "w", encoding="utf-8") as f:
                f.write(ar_text if isinstance(ar_text, str) else decode_srt_content(ar_text))
        elif ar_cues:
            with open(os.path.join(d, f"tmdb_{tmdb_id}_ar.srt"), "w", encoding="utf-8") as f:
                f.write(cues_to_srt(ar_cues))
        print(f"[EnigmaTranslate] SRT: Cached subtitles for TMDB ID {tmdb_id} to disk.")
    except Exception as e:
        print(f"[EnigmaTranslate] SRT: Failed caching tmdb srt: {e}")


class SRTCue:
    __slots__ = ("index", "start", "end", "text")

    def __init__(self, index, start, end, text):
        self.index = int(index)
        self.start = float(start)
        self.end = float(end)
        self.text = str(text).strip()

    def __repr__(self):
        return f"<SRTCue #{self.index} {self.start:.2f}->{self.end:.2f} {self.text[:20]}>"


def parse_srt_timestamp(ts):
    """Convert '01:23:45,678' or '01:23:45.678' to seconds float."""
    ts = ts.strip().replace(",", ".")
    parts = ts.split(":")
    if len(parts) == 3:
        h, m, s = parts
        return float(h) * 3600.0 + float(m) * 60.0 + float(s)
    elif len(parts) == 2:
        m, s = parts
        return float(m) * 60.0 + float(s)
    return 0.0


def decode_srt_content(content):
    """Detect SRT encoding properly (UTF-8 with or without BOM, else cp1256) without mojibake."""
    if not isinstance(content, (bytes, bytearray)):
        if isinstance(content, str):
            return content.lstrip("\ufeff")
        return str(content)

    # 1. UTF-8 with BOM
    if content.startswith(b"\xef\xbb\xbf"):
        try:
            return content.decode("utf-8-sig")
        except UnicodeDecodeError:
            pass

    # 2. UTF-8 without BOM (strict)
    try:
        return content.decode("utf-8")
    except UnicodeDecodeError:
        pass

    # 3. Fallback to cp1256 (Windows Arabic)
    try:
        return content.decode("cp1256")
    except UnicodeDecodeError:
        pass

    # 4. Final safety fallback
    return content.decode("utf-8", errors="replace")


def parse_srt(content):
    """Parse SRT text string or bytes into list of SRTCue objects."""
    if isinstance(content, (bytes, bytearray)):
        content = decode_srt_content(content)
    elif isinstance(content, str):
        content = content.lstrip("\ufeff")

    # Normalize line endings
    content = content.replace("\r\n", "\n").replace("\r", "\n")
    blocks = re.split(r"\n\s*\n", content.strip())
    cues = []

    for block in blocks:
        lines = [line.strip() for line in block.split("\n") if line.strip()]
        if len(lines) < 2:
            continue

        # Find line with '-->'
        time_idx = -1
        for i, line in enumerate(lines[:3]):
            if "-->" in line:
                time_idx = i
                break

        if time_idx == -1:
            continue

        idx = lines[0] if time_idx > 0 and lines[0].isdigit() else str(len(cues) + 1)
        time_line = lines[time_idx]
        parts = time_line.split("-->")
        if len(parts) != 2:
            continue

        start_sec = parse_srt_timestamp(parts[0])
        end_sec = parse_srt_timestamp(parts[1])
        text_lines = lines[time_idx + 1 :]
        text = " ".join(text_lines)
        # Strip HTML/formatting tags like <i>, </i>, <font...>
        text = re.sub(r"<[^>]+>", "", text).strip()
        if text:
            cues.append(SRTCue(idx, start_sec, end_sec, text))

    return sorted(cues, key=lambda c: c.start)


def extract_vod_title_and_year(service_name, service_ref=None):
    """Extract clean movie title and 4-digit release year from VOD service name or metadata."""
    if not service_name:
        return "", None
    name = str(service_name).strip()

    # 1. Look for 4-digit year (1900-2099)
    year = None
    m_year = re.search(r"(?:[\[\(]?)(19\d{2}|20\d{2})(?:[\]\)]?)", name)
    if m_year:
        try:
            year = int(m_year.group(1))
        except (ValueError, TypeError):
            year = None

    # 2. Strip container extension (.mp4, .mkv, .avi, .ts, etc.)
    name = re.sub(r"\.(mp4|mkv|avi|ts|m3u8)$", "", name, flags=re.I)

    # 3. Replace dots and underscores with spaces
    name = name.replace(".", " ").replace("_", " ")

    # Strip year from title text if found so TMDB query is clean
    if year:
        name = re.sub(rf"\b{year}\b", " ", name)

    # Clean brackets, quality tags, and Arabic labels
    patterns = [
        r"\[.*?\]|\(.*?\)",
        r"\b(1080p|720p|480p|2160p|4k|uhd|fhd|hd|sd|hevc|h264|h265|x264|x265|aac|ac3|dts|bluray|web-dl|webrip|brrip|hdtv|remux)\b",
        r"\b(multi-subs|multi|sub|subbed|dubbed|dub|dual|complete)\b",
        r"\b(الفيلم|فيلم|مترجم|مدبلج|حصرياً|حصريا|نسخة|أصلية|سينما)\b",
    ]
    for p in patterns:
        name = re.sub(p, " ", name, flags=re.I)

    # Clean non-alphanumeric except hyphen/quote
    name = re.sub(r"[^\w\s\-\']", " ", name)
    clean_title = re.sub(r"\s+", " ", name).strip()
    return clean_title, year


def clean_movie_title(raw_title):
    """Strip channel metadata, quality tags, and episode text from EPG title."""
    if not raw_title:
        return ""
    t = raw_title
    # Remove bracketed/parenthesized years, ratings, codecs
    t = re.sub(r"\[.*?\]|\(.*?\)", " ", t)
    # Remove typical TV/rip keywords
    patterns = [
        r"\b(HD|FHD|UHD|4K|1080p|720p|576p|HEVC|H\.264|H\.265)\b",
        r"\b(Movie|Film|Cinema|Premiere|Action|Comedy|Drama|Thriller)\b",
        r"\b(Part\s*\d+|Episode\s*\d+|Season\s*\d+|Ep\.\s*\d+)\b",
        r"\b(الفيلم|فيلم|مترجم|مدبلج|حصرياً|سينما)\b"
    ]
    for p in patterns:
        t = re.sub(p, " ", t, flags=re.IGNORECASE)
    t = re.sub(r"[^\w\s\-\']", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def normalize_speech(text):
    """Lowercase and strip punctuation for speech fuzzy matching."""
    if not text:
        return ""
    text = text.lower()
    text = re.sub(r"[^\w\s]", "", text)
    return " ".join(text.split())


class TMDBClient:
    """Find original movie title, release year, and IMDb ID via TMDB API."""

    BASE_URL = "https://api.themoviedb.org/3"

    def __init__(self, api_key=None):
        self.api_key = api_key or settings.get_api_key("tmdb")

    def search_movie(self, title, year=None, timeout=6.0, engine_chain=None):
        if not self.api_key:
            return None
        clean_t = clean_movie_title(title)
        if not clean_t:
            return None

        # Search across Hungarian, Czech, Croatian, Serbian, Slovak, and default English
        langs_to_try = ["hr-HR", "hu-HU", "cs-CZ", "sr-RS", "sk-SK", "en-US", ""]
        queries_to_try = [clean_t]
        if " " in clean_t:
            queries_to_try.append(clean_t.replace(" ", ""))

        all_candidates = []
        for q in queries_to_try:
            for lang in langs_to_try:
                params = {
                    "api_key": self.api_key,
                    "query": q,
                    "include_adult": "false"
                }
                if lang:
                    params["language"] = lang
                if year:
                    params["year"] = str(year)

                url = f"{self.BASE_URL}/search/movie?{urllib.parse.urlencode(params)}"
                req = urllib.request.Request(url, headers={"User-Agent": "EnigmaTranslate/1.0"})
                try:
                    with urllib.request.urlopen(req, timeout=timeout) as resp:
                        data = json.loads(resp.read().decode("utf-8"))
                        results = data.get("results", [])
                        for res in results:
                            all_candidates.append(res)
                except Exception:
                    pass

        if all_candidates:
            # Score candidate movies: popularity + recency bonus (broadcast TV airs modern cinema)
            def score_candidate(res):
                pop = float(res.get("popularity", 0.0) or 0.0)
                rel_date = res.get("release_date", "")
                y = int(rel_date.split("-")[0]) if rel_date and rel_date[:4].isdigit() else 1900
                bonus = 30.0 if y >= 2015 else (10.0 if y >= 2000 else 0.0)
                return pop + bonus

            all_candidates.sort(key=score_candidate, reverse=True)
            best = all_candidates[0]
            movie_id = best.get("id")
            orig_title = best.get("original_title") or best.get("title")
            rel_date = best.get("release_date", "")
            rel_year = rel_date.split("-")[0] if rel_date else ""
            imdb_id = self.get_imdb_id(movie_id, timeout=timeout)
            return {
                "tmdb_id": movie_id,
                "title": orig_title,
                "year": rel_year,
                "imdb_id": imdb_id,
                "overview": best.get("overview", "")
            }

        # If not found directly, translate the EPG title to English if chain is available
        if engine_chain:
            try:
                en_title = engine_chain.translate(clean_t, src="auto", dst="en", timeout=3.0)
                if en_title and en_title.lower() != clean_t.lower():
                    print(f"[EnigmaTranslate] SRT: Title '{clean_t}' translated to English '{en_title}' for TMDB")
                    res = self.search_movie(en_title, year=year, timeout=timeout, engine_chain=None)
                    if res:
                        return res
                    if " " in en_title:
                        res = self.search_movie(en_title.replace(" ", ""), year=year, timeout=timeout, engine_chain=None)
                        if res:
                            return res
            except Exception:
                pass

        return None

    def get_imdb_id(self, movie_id, timeout=5.0):
        if not self.api_key or not movie_id:
            return None
        url = f"{self.BASE_URL}/movie/{movie_id}/external_ids?api_key={self.api_key}"
        req = urllib.request.Request(url, headers={"User-Agent": "EnigmaTranslate/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return data.get("imdb_id")
        except Exception:
            return None

    def search_tv(self, title, timeout=5.0, engine_chain=None):
        if not self.api_key or not title:
            return None
        clean_t = clean_movie_title(title)
        params = {"api_key": self.api_key, "query": clean_t, "language": "en-US"}
        url = f"{self.BASE_URL}/search/tv?{urllib.parse.urlencode(params)}"
        req = urllib.request.Request(url, headers={"User-Agent": "EnigmaTranslate/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                results = data.get("results", [])
                if results:
                    show = results[0]
                    tv_id = show.get("id")
                    imdb_id = self.get_tv_imdb_id(tv_id, timeout=timeout)
                    return {
                        "id": tv_id,
                        "title": show.get("name") or show.get("original_name"),
                        "imdb_id": imdb_id,
                        "media_type": "tv"
                    }
        except Exception as e:
            print(f"[EnigmaTranslate] TMDB TV search error: {e}")
        return None

    def get_tv_imdb_id(self, tv_id, timeout=5.0):
        if not self.api_key or not tv_id:
            return None
        url = f"{self.BASE_URL}/tv/{tv_id}/external_ids?api_key={self.api_key}"
        req = urllib.request.Request(url, headers={"User-Agent": "EnigmaTranslate/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return data.get("imdb_id")
        except Exception:
            return None


class OpenSubtitlesClient:
    """Search and download .srt files via OpenSubtitles REST API v1."""

    BASE_URL = "https://api.opensubtitles.com/api/v1"

    def __init__(self, api_key=None, username=None, password=None, cache_dir=None):
        self.api_key = api_key or settings.get_api_key("opensubtitles")
        self.username = username or settings.get_api_key("opensubtitles_user")
        self.password = password or settings.get_api_key("opensubtitles_pass")
        self.token = None
        self.cache_dir = cache_dir or get_srt_cache_dir()

    def _get_daily_usage(self):
        return get_daily_usage("opensubtitles")

    def _increment_usage(self):
        increment_usage("opensubtitles")

    def login(self, timeout=6.0, force=False):
        if not self.api_key or not self.username or not self.password:
            return None
        token_cache_file = "/etc/enigma2/enigmatranslate/opensub_token.json"
        if not force and os.path.isfile(token_cache_file):
            try:
                with open(token_cache_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if time.time() - data.get("timestamp", 0) < 72000 and data.get("token"):
                        self.token = data["token"]
                        return self.token
            except Exception:
                pass

        url = f"{self.BASE_URL}/login"
        payload = json.dumps({"username": self.username, "password": self.password}).encode("utf-8")
        req = urllib.request.Request(url, data=payload, headers={
            "Api-Key": self.api_key,
            "Content-Type": "application/json",
            "User-Agent": "EnigmaTranslate v1.0"
        })
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                self.token = data.get("token")
                if self.token:
                    try:
                        os.makedirs(os.path.dirname(token_cache_file), exist_ok=True)
                        with open(token_cache_file, "w", encoding="utf-8") as f:
                            json.dump({"token": self.token, "timestamp": time.time()}, f)
                    except Exception:
                        pass
                return self.token
        except Exception as e:
            print(f"[EnigmaTranslate] OpenSubtitles login error: {e}")
            return None

    def _request_with_retry(self, req, timeout=8.0):
        """Execute request, automatically refreshing token on 401 error."""
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code == 401 and self.username and self.password:
                print("[EnigmaTranslate] OpenSubtitles token expired (401), refreshing token...")
                new_token = self.login(force=True)
                if new_token:
                    req.headers["Authorization"] = f"Bearer {new_token}"
                    with urllib.request.urlopen(req, timeout=timeout) as resp:
                        return json.loads(resp.read().decode("utf-8"))
            raise

    def search_subtitles(self, imdb_id=None, query=None, languages="ar,en", timeout=8.0, season_number=None, episode_number=None, media_type="movie"):
        if not self.api_key:
            return []

        results = []
        is_episode = (media_type == "episode" or episode_number is not None)
        sub_type = "episode" if is_episode else "movie"

        if imdb_id:
            raw_id = imdb_id[2:] if imdb_id.startswith("tt") else imdb_id
            params = {"languages": languages, "type": sub_type, "imdb_id": raw_id}
            if season_number is not None:
                params["season_number"] = season_number
            if episode_number is not None:
                params["episode_number"] = episode_number
            url = f"{self.BASE_URL}/subtitles?{urllib.parse.urlencode(params)}"
            headers = {"Api-Key": self.api_key, "User-Agent": "EnigmaTranslate v1.0"}
            if not self.token and self.username and self.password:
                self.login()
            if self.token:
                headers["Authorization"] = f"Bearer {self.token}"
            try:
                data = self._request_with_retry(urllib.request.Request(url, headers=headers), timeout=timeout)
                results.extend(data.get("data", []))
            except Exception as e:
                print(f"[EnigmaTranslate] OpenSubtitles search error (imdb): {e}")

        # If imdb_id search returned nothing or query is provided, search by query
        if query and not results:
            clean_q = clean_movie_title(query)
            q_list = [clean_q]
            if " " in clean_q:
                q_list.append(clean_q.replace(" ", ""))

            for cur_q in q_list:
                params = {"languages": languages, "type": sub_type, "query": cur_q}
                if season_number is not None:
                    params["season_number"] = season_number
                if episode_number is not None:
                    params["episode_number"] = episode_number
                url = f"{self.BASE_URL}/subtitles?{urllib.parse.urlencode(params)}"
                headers = {"Api-Key": self.api_key, "User-Agent": "EnigmaTranslate v1.0"}
                if not self.token and self.username and self.password:
                    self.login()
                if self.token:
                    headers["Authorization"] = f"Bearer {self.token}"
                try:
                    data = self._request_with_retry(urllib.request.Request(url, headers=headers), timeout=timeout)
                    matches = data.get("data", [])
                    if matches:
                        results.extend(matches)
                        break
                except Exception as e:
                    print(f"[EnigmaTranslate] OpenSubtitles search error (query '{cur_q}'): {e}")

        return results

    def group_candidates(self, sub_data):
        """Pair AR + EN subtitles from the same release and compute confidence."""
        if not sub_data:
            return []

        ar_items = []
        en_items = []
        for item in sub_data:
            attr = item.get("attributes", {})
            lang = attr.get("language")
            files = attr.get("files", [])
            file_id = files[0].get("file_id") if files else None
            if not file_id:
                continue
            entry = {
                "id": item.get("id"),
                "file_id": file_id,
                "language": lang,
                "release": attr.get("release", "") or attr.get("movie_name", ""),
                "fps": float(attr.get("fps", 0.0) or 0.0),
                "downloads": int(attr.get("download_count", 0)),
                "ratings": float(attr.get("ratings", 0.0) or 0.0)
            }
            if lang == "ar":
                ar_items.append(entry)
            elif lang == "en":
                en_items.append(entry)

        candidates = []

        # 1. Look for matching release names
        for ar in ar_items:
            best_en = None
            best_sim = 0.0
            ar_rel_clean = re.sub(r"[^\w]", "", ar["release"].lower())
            for en in en_items:
                en_rel_clean = re.sub(r"[^\w]", "", en["release"].lower())
                sim = difflib.SequenceMatcher(None, ar_rel_clean, en_rel_clean).ratio()
                if sim > best_sim:
                    best_sim = sim
                    best_en = en

            # Confidence score
            if best_en and best_sim >= 0.70:
                conf = min(0.98, 0.85 + (best_sim * 0.13))
                label = f"⭐ {ar['release'][:30]} (AR + EN)"
                candidates.append({
                    "type": "paired",
                    "confidence": conf,
                    "release": ar["release"],
                    "ar_item": ar,
                    "en_item": best_en,
                    "label": label
                })
            else:
                conf = min(0.80, 0.50 + min(0.30, ar["downloads"] / 1000.0))
                label = f"AR: {ar['release'][:30]} ({ar['downloads']} DL)"
                candidates.append({
                    "type": "ar_only",
                    "confidence": conf,
                    "release": ar["release"],
                    "ar_item": ar,
                    "en_item": best_en or (en_items[0] if en_items else None),
                    "label": label
                })

        # 2. Add EN-only releases if no Arabic at all
        if not ar_items and en_items:
            for en in en_items[:3]:
                conf = min(0.75, 0.45 + min(0.30, en["downloads"] / 1000.0))
                label = f"EN: {en['release'][:30]} (ترجمة آلية)"
                candidates.append({
                    "type": "en_only",
                    "confidence": conf,
                    "release": en["release"],
                    "ar_item": None,
                    "en_item": en,
                    "label": label
                })

        return sorted(candidates, key=lambda c: c["confidence"], reverse=True)

    def download_subtitle(self, file_id, timeout=10.0):
        """Download subtitle file respecting cache on /media/hdd and daily rate limit."""
        if not file_id:
            return None

        # 1. Use cached .srt files without counting a download or checking limits
        cached_file = os.path.join(self.cache_dir, f"{file_id}.srt")
        if os.path.isfile(cached_file) and os.path.getsize(cached_file) > 100:
            try:
                print(f"[EnigmaTranslate] SRT: Using cached file {file_id}.srt (no download counted)")
                with open(cached_file, "rb") as f:
                    return decode_srt_content(f.read())
            except Exception:
                pass

        # 2. Check daily limit (20 for logged in user, 5 for anon)
        limit = 20 if (self.username and self.password) else 5
        if self._get_daily_usage() >= limit:
            print(f"[EnigmaTranslate] OpenSubtitles daily limit reached ({limit}/day)")
            return None

        if not self.token and self.username and self.password:
            self.login()

        url = f"{self.BASE_URL}/download"
        payload = json.dumps({"file_id": int(file_id), "sub_format": "srt"}).encode("utf-8")
        headers = {
            "Api-Key": self.api_key,
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "EnigmaTranslate v1.0"
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        req = urllib.request.Request(url, data=payload, headers=headers)
        try:
            data = self._request_with_retry(req, timeout=timeout)
            link = data.get("link")
            if not link:
                return None

            # Download actual SRT content
            sub_req = urllib.request.Request(link, headers={"User-Agent": "EnigmaTranslate v1.0"})
            with urllib.request.urlopen(sub_req, timeout=timeout) as sub_resp:
                raw_bytes = sub_resp.read()
                self._increment_usage()

                # Save raw bytes to cache (keeps original text)
                try:
                    with open(cached_file, "wb") as f:
                        f.write(raw_bytes)
                except Exception:
                    pass

                return decode_srt_content(raw_bytes)
        except Exception as e:
            print(f"[EnigmaTranslate] OpenSubtitles download error: {e}")
            return None

    def get_status_summary(self):
        """Return diagnostic metrics for HealthScreen."""
        limit = 20 if (self.username and self.password) else 5
        used = self._get_daily_usage()
        rem = max(0, limit - used)
        logged_in = bool(self.token) or (bool(self.username and self.password))
        return {
            "api_key_ok": bool(self.api_key),
            "logged_in": logged_in,
            "username": self.username or "زائر",
            "downloads_today": used,
            "limit": limit,
            "remaining": rem
        }


class SubDLClient:
    """Search and download .srt files via SubDL REST API v1 using plain urllib."""
    BASE_URL = "https://api.subdl.com/api/v1/subtitles"
    DL_BASE = "https://dl.subdl.com"

    def __init__(self, api_key=None, cache_dir=None):
        self.api_key = api_key or settings.get_api_key("subdl")
        self.cache_dir = cache_dir or get_srt_cache_dir()

    def search_subtitles(self, title, imdb_id=None, tmdb_id=None, languages="en,ar", timeout=6.0, media_type="movie", season_number=None, episode_number=None):
        if not self.api_key:
            return []
        clean_q = clean_movie_title(title)
        params = {
            "api_key": self.api_key,
            "languages": languages,
            "type": "tv" if media_type == "episode" or season_number is not None else "movie"
        }
        if imdb_id:
            raw_id = imdb_id[2:] if imdb_id.startswith("tt") else imdb_id
            params["imdb_id"] = raw_id
        elif tmdb_id:
            params["tmdb_id"] = str(tmdb_id)
        elif clean_q:
            params["film_name"] = clean_q
        if season_number is not None:
            params["season_number"] = str(season_number)
        if episode_number is not None:
            params["episode_number"] = str(episode_number)

        url = f"{self.BASE_URL}?{urllib.parse.urlencode(params)}"
        req = urllib.request.Request(url, headers={"User-Agent": "EnigmaTranslate/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                sub_list = data.get("subtitles") or data.get("results") or []
                results = []
                for item in sub_list:
                    dl_url = item.get("url", "")
                    if dl_url and not dl_url.startswith("http"):
                        dl_url = self.DL_BASE + dl_url
                    lang = (item.get("lang") or item.get("language") or "").lower()
                    lang_code = "en" if "eng" in lang else ("ar" if "arab" in lang else "en")
                    results.append({
                        "source": "subdl",
                        "id": dl_url,
                        "url": dl_url,
                        "lang": lang_code,
                        "release": item.get("release_name") or item.get("name") or title,
                        "downloads": int(item.get("download_count") or item.get("downloads") or 0)
                    })
                return results
        except Exception as e:
            print(f"[EnigmaTranslate] SubDL search error: {e}")
            return []

    def download_subtitle(self, url, timeout=8.0):
        if not url:
            return None
        if get_daily_usage("subdl") >= 60:
            print("[EnigmaTranslate] SubDL daily limit reached (60/day)")
            return None
        req = urllib.request.Request(url, headers={"User-Agent": "EnigmaTranslate/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read()
                increment_usage("subdl")
                raw_srt = extract_srt_from_bytes(raw)
                return decode_srt_content(raw_srt)
        except Exception as e:
            print(f"[EnigmaTranslate] SubDL download error: {e}")
            return None


class PodnapisiClient:
    """Search and download .srt files via Podnapisi open XML/JSON endpoint using plain urllib."""
    BASE_URL = "https://www.podnapisi.net/subtitles/search/old"

    def __init__(self, cache_dir=None):
        self.cache_dir = cache_dir or get_srt_cache_dir()

    def search_subtitles(self, title, year=None, languages="en,ar", timeout=6.0, media_type="movie", season_number=None, episode_number=None):
        clean_q = clean_movie_title(title)
        if not clean_q:
            return []
        # Podnapisi language codes: 2=English, 43=Arabic
        lang_id = "2" if "en" in languages else "43"
        params = {
            "sXML": "1",
            "sK": clean_q,
            "sJ": lang_id
        }
        if year:
            params["sY"] = str(year)
        if season_number is not None:
            params["sTS"] = str(season_number)
        if episode_number is not None:
            params["sTE"] = str(episode_number)

        url = f"{self.BASE_URL}?{urllib.parse.urlencode(params)}"
        req = urllib.request.Request(url, headers={"User-Agent": "EnigmaTranslate/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw_xml = resp.read().decode("utf-8", errors="replace")
                return self._parse_xml_results(raw_xml, title)
        except Exception as e:
            print(f"[EnigmaTranslate] Podnapisi search error: {e}")
            return []

    def _parse_xml_results(self, raw_xml, title):
        import xml.etree.ElementTree as ET
        results = []
        try:
            root = ET.fromstring(raw_xml)
            for sub in root.findall(".//subtitle"):
                pid = sub.findtext("id")
                release = sub.findtext("release") or title
                dls = sub.findtext("downloads") or "0"
                if pid:
                    dl_url = f"https://www.podnapisi.net/subtitles/{pid}/download"
                    results.append({
                        "source": "podnapisi",
                        "id": pid,
                        "url": dl_url,
                        "lang": "en",
                        "release": release,
                        "downloads": int(dls) if dls.isdigit() else 0
                    })
        except Exception as e:
            print(f"[EnigmaTranslate] Podnapisi XML parse error: {e}")
        return results

    def download_subtitle(self, url, timeout=8.0):
        if not url:
            return None
        req = urllib.request.Request(url, headers={"User-Agent": "EnigmaTranslate/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read()
                increment_usage("podnapisi")
                raw_srt = extract_srt_from_bytes(raw)
                return decode_srt_content(raw_srt)
        except Exception as e:
            print(f"[EnigmaTranslate] Podnapisi download error: {e}")
            return None


class SubtitleProviderChain:
    """Unified search and download chain: OpenSubtitles -> SubDL -> Podnapisi."""

    def __init__(self):
        self.opensub = OpenSubtitlesClient()
        self.subdl = SubDLClient()
        self.podnapisi = PodnapisiClient()

    def search_best(self, title, imdb_id=None, tmdb_id=None, year=None, timeout=8.0, media_type="movie", season_number=None, episode_number=None):
        # 1. Try OpenSubtitles
        try:
            if self.opensub.api_key:
                os_stat = self.opensub.get_status_summary()
                if os_stat["remaining"] > 0:
                    raw = self.opensub.search_subtitles(
                        imdb_id=imdb_id, query=title, languages="en,ar",
                        timeout=timeout * 0.4, season_number=season_number,
                        episode_number=episode_number, media_type=media_type
                    )
                    cands = self.opensub.group_candidates(raw)
                    if cands:
                        for c in cands:
                            c["provider"] = "opensubtitles"
                        return cands
        except Exception as e:
            print(f"[EnigmaTranslate] OpenSubtitles chain error: {e}")

        # 2. Try SubDL
        try:
            if self.subdl.api_key and get_daily_usage("subdl") < 60:
                subdl_res = self.subdl.search_subtitles(
                    title=title, imdb_id=imdb_id, tmdb_id=tmdb_id,
                    languages="en,ar", timeout=timeout * 0.4,
                    media_type=media_type, season_number=season_number, episode_number=episode_number
                )
                if subdl_res:
                    cands = self._convert_to_candidates(subdl_res, "subdl")
                    if cands:
                        return cands
        except Exception as e:
            print(f"[EnigmaTranslate] SubDL chain error: {e}")

        # 3. Try Podnapisi (No API key needed)
        try:
            pod_res = self.podnapisi.search_subtitles(
                title=title, year=year, languages="en",
                timeout=timeout * 0.4, media_type=media_type,
                season_number=season_number, episode_number=episode_number
            )
            if pod_res:
                cands = self._convert_to_candidates(pod_res, "podnapisi")
                if cands:
                    return cands
        except Exception as e:
            print(f"[EnigmaTranslate] Podnapisi chain error: {e}")

        return []

    def _convert_to_candidates(self, results, provider_name):
        results.sort(key=lambda x: x.get("downloads", 0), reverse=True)
        candidates = []
        for item in results[:5]:
            is_ar = (item.get("lang") == "ar")
            conf = 0.85 if item.get("downloads", 0) > 100 else 0.75
            label = f"[{provider_name.upper()}] {item.get('release', '')[:30]}"
            candidates.append({
                "provider": provider_name,
                "type": "ar_only" if is_ar else "en_only",
                "confidence": conf,
                "release": item.get("release", ""),
                "en_item": None if is_ar else item,
                "ar_item": item if is_ar else None,
                "item": item,
                "label": label
            })
        return candidates

    def download_item(self, cand, timeout=8.0):
        prov = cand.get("provider", "opensubtitles")
        item = cand.get("en_item") or cand.get("ar_item") or cand.get("item")
        if not item:
            return None
        if prov == "opensubtitles":
            file_id = item.get("file_id") if isinstance(item, dict) else item
            return self.opensub.download_subtitle(file_id, timeout=timeout)
        elif prov == "subdl":
            url = item.get("url") if isinstance(item, dict) else item
            return self.subdl.download_subtitle(url, timeout=timeout)
        elif prov == "podnapisi":
            url = item.get("url") if isinstance(item, dict) else item
            return self.podnapisi.download_subtitle(url, timeout=timeout)
        return None




class SRTSynchronizer:
    """Fuzzy-matches Groq Whisper speech to English SRT cues to solve offset and speed drift.

    Detects commercials/ads (>45s mismatch), blanks OSD, and re-anchors on movie resume.
    """

    def __init__(self, en_cues=None, ar_cues=None):
        self.en_cues = en_cues or []
        self.ar_cues = ar_cues or []
        self.norm_en = [normalize_speech(c.text) for c in self.en_cues]

        # Sync state
        self.anchor_live_time = None
        self.anchor_cue_start = None
        self.speed = 1.0  # 1.0 (25 fps) or 1.04271 (23.976 -> 25 PAL drift)
        self.anchors_history = []  # list of (live_time, cue_start)
        self.last_match_time = 0.0
        self.last_sample_time = 0.0
        self.consecutive_misses = 0
        self.in_ad_break = False
        self.high_error_samples = 0
        self.locked = False
        self.movie_ended = False
        self.last_sync_error = 0.0

    def is_movie_ended(self, live_time):
        """Check if live timeline has exceeded the end of the movie cues."""
        if not self.en_cues and not self.ar_cues:
            return False
        if self.anchor_live_time is None or self.anchor_cue_start is None:
            return False
        movie_pos = self.anchor_cue_start + ((live_time - self.anchor_live_time) * self.speed)
        last_end = max((c.end for c in (self.en_cues or self.ar_cues)), default=0.0)
        return last_end > 0 and movie_pos > (last_end + 30.0)

    def feed_speech_segment(self, speech_text, live_time):
        """Compare speech window against English cues, solve offset, handle ads."""
        clean = normalize_speech(speech_text)
        self.last_sample_time = live_time

        if self.is_movie_ended(live_time):
            self.movie_ended = True
            self.locked = False
            self.in_ad_break = False
            print("[EnigmaTranslate] SRT: Movie ended (movie_pos past end of cues). Unlocking SRT and returning to audio STT.")
            return False

        if len(clean) < 6 or not self.norm_en:
            return False

        # Search around estimated position if already anchored, else scan all (and scan all if resuming from ad break)
        if self.anchor_live_time is not None and not self.in_ad_break:
            est_cue_time = self.anchor_cue_start + ((live_time - self.anchor_live_time) * self.speed)
            # Window of ±180 seconds around estimated position
            idx_start = max(0, self._find_cue_index_at(est_cue_time - 180.0))
            idx_end = min(len(self.norm_en), self._find_cue_index_at(est_cue_time + 180.0) + 1)
        else:
            idx_start = 0
            idx_end = len(self.norm_en)

        best_sim = 0.0
        best_idx = -1

        for i in range(idx_start, idx_end):
            cue_txt = self.norm_en[i]
            if not cue_txt:
                continue
            sim = difflib.SequenceMatcher(None, clean, cue_txt).ratio()
            # Also check substring match
            if clean in cue_txt or cue_txt in clean:
                sim = max(sim, 0.82)
            if sim > best_sim:
                best_sim = sim
                best_idx = i

        if best_sim >= 0.65 and best_idx != -1:
            matched_cue = self.en_cues[best_idx]
            self.last_match_time = live_time
            self.consecutive_misses = 0

            # Initial anchor or resuming from ad break -> anchor immediately
            if not self.locked or self.in_ad_break:
                if self.in_ad_break:
                    print(f"[EnigmaTranslate] SRT: Re-anchored on first match after ad break! Offset={matched_cue.start:.1f}s")
                self.anchor_live_time = live_time
                self.anchor_cue_start = matched_cue.start
                self.last_sync_error = 0.0
                self.high_error_samples = 0
                self.in_ad_break = False
                self.locked = True
                self.anchors_history.append((live_time, matched_cue.start))
                return True

            # Already locked during movie playback:
            old_est = self.anchor_cue_start + ((live_time - self.anchor_live_time) * self.speed)
            sync_err = old_est - matched_cue.start
            self.last_sync_error = abs(sync_err)

            # Requirement 2: Self-correct if sync error stays above 1s for 2 samples
            if abs(sync_err) > 1.0:
                self.high_error_samples += 1
                if self.high_error_samples >= 2:
                    print(f"[EnigmaTranslate] [SRT] Self-correcting sync offset by {-sync_err:.2f}s (error > 1s for 2 samples)")
                    self.anchor_cue_start = matched_cue.start
                    self.anchor_live_time = live_time
                    self.last_sync_error = 0.0
                    self.high_error_samples = 0
            else:
                self.high_error_samples = 0

            self.anchors_history.append((live_time, matched_cue.start))
            if len(self.anchors_history) > 20:
                self.anchors_history.pop(0)

            # Solve speed drift between film 23.976 fps and 25 fps PAL if multiple anchors
            if len(self.anchors_history) >= 2:
                t0_live, t0_cue = self.anchors_history[0]
                dt_live = live_time - t0_live
                dt_cue = matched_cue.start - t0_cue
                if dt_cue > 120.0 and dt_live > 120.0:
                    raw_speed = dt_live / dt_cue
                    # Snap to 1.04271 (film -> PAL) if close
                    if 1.025 <= raw_speed <= 1.060:
                        self.speed = 1.04271
                    elif 0.940 <= raw_speed <= 0.975:
                        self.speed = 0.95904
                    else:
                        self.speed = 1.0

            return True

        # Failed to match (miss)
        if self.locked and len(clean) >= 12:
            self.consecutive_misses += 1
            if self.consecutive_misses >= 2:
                if not self.in_ad_break:
                    print(f"[EnigmaTranslate] SRT: Ad break detected ({self.consecutive_misses} consecutive speech misses, ~20s). Blanking subtitles.")
                self.in_ad_break = True

        return False

    def feed_speech_activity(self, is_speech_active, live_time):
        """Option B: Audio speech activity (VAD voice onset/offset) alignment without text matching.

        Voice onset/offset timing has a sync error of ~0.8s - 1.5s due to background audio,
        music, sound effects, and dialogue pauses.
        """
        self.last_sample_time = live_time
        cues = self.ar_cues or self.en_cues
        if not cues:
            return False

        if self.anchor_live_time is not None:
            est_cue_time = self.anchor_cue_start + ((live_time - self.anchor_live_time) * self.speed)
            closest_cue = min(cues, key=lambda c: min(abs(c.start - est_cue_time), abs(c.end - est_cue_time)))
            onset_err = abs(closest_cue.start - est_cue_time)
            self.last_sync_error = onset_err
            if onset_err > 1.2:
                self.high_error_samples += 1
                if self.high_error_samples >= 3:
                    self.anchor_cue_start = closest_cue.start
                    self.anchor_live_time = live_time
                    self.high_error_samples = 0
            else:
                self.high_error_samples = 0
            return True
        else:
            if is_speech_active and cues:
                self.anchor_live_time = live_time
                self.anchor_cue_start = cues[0].start
                self.locked = True
                self.last_sync_error = 0.95
                return True
        return False

    def _find_cue_index_at(self, cue_time):
        for i, c in enumerate(self.en_cues):
            if c.start >= cue_time:
                return i
        return len(self.en_cues) - 1

    def get_current_subtitle(self, live_time):
        """Return (trans_arabic, orig_english) cue active at live_time, or None if in ads."""
        if not self.locked or self.in_ad_break or self.anchor_live_time is None:
            return None

        if self.is_movie_ended(live_time):
            self.movie_ended = True
            self.locked = False
            self.in_ad_break = False
            print("[EnigmaTranslate] SRT: Movie ended (movie_pos past end of cues). Unlocking SRT.")
            return None

        # Compute current position on movie timeline
        movie_pos = self.anchor_cue_start + ((live_time - self.anchor_live_time) * self.speed)

        # 1. Search full movie timeline (en_cues or ar_cues)
        all_cues = self.en_cues if self.en_cues else self.ar_cues
        matched_cue = None
        for c in all_cues:
            if c.start <= movie_pos <= c.end:
                matched_cue = c
                break

        if not matched_cue:
            return None

        # 2. Check if we have an Arabic translation for this cue
        if self.ar_cues:
            for ac in self.ar_cues:
                if ac.index == matched_cue.index or abs(ac.start - matched_cue.start) < 1.0:
                    orig_en = matched_cue.text if self.en_cues else ""
                    return ac.text, orig_en

        # 3. If translation not ready yet in ar_cues, fallback to English text so display never blanks!
        return matched_cue.text, matched_cue.text


# ============================================================================
# TMDB Disk Cache & Background Progressive SRT Translator
# ============================================================================

TMDB_CACHE_DIR = getattr(settings, "DATA_DIR", "/etc/enigma2/enigmatranslate") + "/tmdb_cache"


def get_cached_tmdb_srt(tmdb_id):
    """Load cached English and Arabic cues for a TMDB ID."""
    if not tmdb_id:
        return [], []
    cache_path = os.path.join(TMDB_CACHE_DIR, f"tmdb_{tmdb_id}.json")
    if not os.path.isfile(cache_path):
        return [], []
    try:
        with open(cache_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        en_cues = [SRTCue(c["idx"], c["start"], c["end"], c["text"]) for c in data.get("en_cues", [])]
        ar_cues = [SRTCue(c["idx"], c["start"], c["end"], c["text"]) for c in data.get("ar_cues", [])]
        return en_cues, ar_cues
    except Exception as e:
        print(f"[EnigmaTranslate] Failed reading TMDB cache {tmdb_id}: {e}")
        return [], []


def save_cached_tmdb_srt(tmdb_id, en_cues=None, ar_cues=None):
    """Save English and Arabic cues for a TMDB ID to disk cache."""
    if not tmdb_id:
        return False
    try:
        os.makedirs(TMDB_CACHE_DIR, exist_ok=True)
        cache_path = os.path.join(TMDB_CACHE_DIR, f"tmdb_{tmdb_id}.json")
        data = {}
        if os.path.isfile(cache_path):
            try:
                with open(cache_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                data = {}
        if en_cues is not None:
            data["en_cues"] = [{"idx": c.index, "start": c.start, "end": c.end, "text": c.text} for c in en_cues]
        if ar_cues is not None:
            data["ar_cues"] = [{"idx": c.index, "start": c.start, "end": c.end, "text": c.text} for c in ar_cues]
        data["updated_at"] = time.time()
        with open(cache_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print(f"[EnigmaTranslate] SRT: Cached subtitles for TMDB ID {tmdb_id} to disk.")
        return True
    except Exception as e:
        print(f"[EnigmaTranslate] Failed saving TMDB cache {tmdb_id}: {e}")
        return False


def pre_translate_english_cues(en_cues, chain, limit=15, start_pos=0.0):
    """Translate initial English cues to Arabic via engine chain for immediate playback around start_pos."""
    if not en_cues or not chain:
        return []
    forward_cues = [c for c in en_cues if c.start >= start_pos]
    target_cues = forward_cues[:limit] if forward_cues else en_cues[:limit]
    ar_cues = []
    for c in target_cues:
        try:
            trans = chain.translate(c.text, "en", "ar")
            if trans:
                ar_cues.append(SRTCue(c.index, c.start, c.end, trans))
        except Exception:
            pass
    return ar_cues


class BackgroundSRTTranslator:
    """Translates SRT cues in small batches in background from current position forward, pausing on 429."""

    def __init__(self, en_cues, synchronizer, chain, tmdb_id=None, cur_pos=0.0, batch_size=10):
        self.en_cues = list(en_cues or [])
        self.synchronizer = synchronizer
        self.chain = chain
        self.tmdb_id = tmdb_id
        self.cur_pos = float(cur_pos or 0.0)
        self.batch_size = max(1, int(batch_size))
        self._stop_event = threading.Event()
        self.thread = None

    def start(self):
        self.thread = threading.Thread(target=self._run, daemon=True, name="ET_BackgroundSRTTranslator")
        self.thread.start()

    def stop(self):
        self._stop_event.set()

    def _run(self):
        if not self.en_cues or not self.chain or not self.synchronizer:
            return

        print(f"[EnigmaTranslate] [SRT-BG] Started background translation of {len(self.en_cues)} cues around pos={self.cur_pos:.1f}s (TMDB ID {self.tmdb_id}).")

        # Map already translated cues
        known_indices = {c.index for c in (self.synchronizer.ar_cues or [])}

        # Filter untranslated cues
        untranslated = [c for c in self.en_cues if c.index not in known_indices]
        if not untranslated:
            print("[EnigmaTranslate] [SRT-BG] All cues already translated.")
            return

        # Sort: starting from current playback position forward, then backward
        forward_cues = [c for c in untranslated if c.start >= self.cur_pos]
        backward_cues = [c for c in untranslated if c.start < self.cur_pos]
        # Forward cues in timeline order; backward cues closest to current pos first
        backward_cues.sort(key=lambda c: c.start, reverse=True)
        ordered_cues = forward_cues + backward_cues

        # Process in batches
        for i in range(0, len(ordered_cues), self.batch_size):
            if self._stop_event.is_set():
                print("[EnigmaTranslate] [SRT-BG] Background translation stopped by user/zap.")
                break

            batch = ordered_cues[i : i + self.batch_size]
            batch_ar = []

            for cue in batch:
                if self._stop_event.is_set():
                    break
                retries = 0
                while retries < 3 and not self._stop_event.is_set():
                    try:
                        trans = self.chain.translate(cue.text, "en", "ar")
                        if trans:
                            batch_ar.append(SRTCue(cue.index, cue.start, cue.end, trans))
                        break
                    except Exception as e:
                        err_str = str(e).lower()
                        if "429" in err_str or "rate limit" in err_str or "too many requests" in err_str:
                            print(f"[EnigmaTranslate] [SRT-BG] Rate limit (429) hit: {e}. Pausing for 20.0s...")
                            for _ in range(40):
                                if self._stop_event.is_set():
                                    break
                                time.sleep(0.5)
                            retries += 1
                        else:
                            print(f"[EnigmaTranslate] [SRT-BG] Translation error on cue #{cue.index}: {e}")
                            break

            if batch_ar:
                # Merge into synchronizer
                ar_dict = {c.index: c for c in (self.synchronizer.ar_cues or [])}
                for c in batch_ar:
                    ar_dict[c.index] = c
                self.synchronizer.ar_cues = sorted(ar_dict.values(), key=lambda c: c.start)

                # Save progressive cache
                if self.tmdb_id:
                    save_cached_tmdb_srt(self.tmdb_id, en_cues=self.en_cues, ar_cues=self.synchronizer.ar_cues)

                print(f"[EnigmaTranslate] [SRT-BG] Progress: {len(self.synchronizer.ar_cues)}/{len(self.en_cues)} cues translated.")

            # Small delay between batches to stay under Google/free rate limits
            for _ in range(12):
                if self._stop_event.is_set():
                    break
                time.sleep(0.1)

        print("[EnigmaTranslate] [SRT-BG] Background translation finished.")


def parse_xtream_params(stream_url_or_ref):
    """Extract (scheme, host, username, password, stream_id) from stream URL or Enigma2 service ref.
    Returns (scheme, host, username, password, stream_id) or None.
    NEVER log the returned username or password.
    """
    if not stream_url_or_ref:
        return None
    raw = str(stream_url_or_ref).strip()
    url = urllib.parse.unquote(raw)
    url = re.sub(r"%3a", ":", url, flags=re.IGNORECASE)
    parts = url.split(":")
    if len(parts) >= 11 and parts[0] in ("4097", "5001", "5002", "5003", "1"):
        url = ":".join(parts[10:-1]) if len(parts) > 11 else parts[10]
        url = urllib.parse.unquote(url)

    m = re.search(r"(https?)://([^/]+)/(?:live/)?([^/]+)/([^/]+)/(\d+)(?:\.ts)?", url)
    if m:
        scheme, host, user, pwd, sid = m.groups()
        return scheme, host, user, pwd, sid
    return None


def fetch_xtream_short_epg(stream_url_or_ref, timeout=4.0):
    """Query Xtream provider for current program title using player_api.php get_short_epg.
    Returns clean decoded title string or "" if not found/empty.
    NEVER logs credentials.
    """
    params = parse_xtream_params(stream_url_or_ref)
    if not params:
        return ""
    scheme, host, user, pwd, sid = params
    query = urllib.parse.urlencode({
        "username": user,
        "password": pwd,
        "action": "get_short_epg",
        "stream_id": sid,
        "limit": "2"
    })
    api_url = f"{scheme}://{host}/player_api.php?{query}"
    try:
        req = urllib.request.Request(
            api_url,
            headers={
                "User-Agent": "IPTVSmartersPro",
                "Accept": "application/json"
            }
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status == 200:
                raw_bytes = resp.read()
                data = json.loads(raw_bytes.decode("utf-8", "ignore"))
                listings = data.get("epg_listings", []) if isinstance(data, dict) else []
                if not listings and isinstance(data, list):
                    listings = data
                now = time.time()
                for item in listings:
                    if not isinstance(item, dict):
                        continue
                    t_b64 = item.get("title", "")
                    if not t_b64:
                        continue
                    try:
                        title = base64.b64decode(t_b64).decode("utf-8", "ignore").strip()
                    except Exception:
                        title = str(t_b64).strip()
                    if not title:
                        continue
                    is_now = (item.get("now_playing") == 1 or str(item.get("now_playing")) == "1")
                    start_ts = item.get("start_timestamp")
                    stop_ts = item.get("stop_timestamp")
                    if not is_now and start_ts and stop_ts:
                        try:
                            is_now = (float(start_ts) <= now <= float(stop_ts))
                        except Exception:
                            pass
                    if is_now or len(listings) == 1:
                        title = re.sub(r"[\r\n\t]+", " ", title).strip()
                        print(f"[EnigmaTranslate] [XTREAM-EPG] Found current title from host={host}, stream_id={sid}: '{title}'")
                        return title
                if listings and isinstance(listings[0], dict):
                    t_b64 = listings[0].get("title", "")
                    try:
                        title = base64.b64decode(t_b64).decode("utf-8", "ignore").strip()
                        title = re.sub(r"[\r\n\t]+", " ", title).strip()
                        if title:
                            print(f"[EnigmaTranslate] [XTREAM-EPG] Found first listing title from host={host}, stream_id={sid}: '{title}'")
                            return title
                    except Exception:
                        pass
        print(f"[EnigmaTranslate] [XTREAM-EPG] No EPG listings found for host={host}, stream_id={sid}")
    except Exception as e:
        print(f"[EnigmaTranslate] [XTREAM-EPG] Request failed for host={host}, stream_id={sid}: {type(e).__name__}")
    return ""


def is_valid_speech_line(text):
    """Check if a transcript line contains actual speech dialogue (not just music/action/sound-effects)."""
    if not text:
        return False
    t = str(text).strip()
    clean = re.sub(r"\[.*?\]|\(.*?\)|[\*♪♫]", " ", t).strip()
    if not clean:
        return False
    noise_keywords = (
        "music", "applause", "cheering", "laughter", "laughing", "screaming",
        "screams", "groaning", "groans", "sighs", "sighing", "panting",
        "crying", "sobbing", "gasping", "gasps", "silence", "gunfire",
        "explosion", "instrumental", "theme song", "singing"
    )
    words = [w for w in re.split(r"\W+", clean) if w]
    if len(words) == 1 and words[0].lower() in noise_keywords:
        return False
    if len(words) == 1 and words[0].lower() in ("ah", "oh", "ugh", "uh", "um", "huh", "mm", "whoa", "hey", "shh"):
        return False
    letters = re.findall(r"[a-zA-Z]", clean)
    if len(letters) < 6:
        return False
    return True


def extract_character_names(transcript_lines):
    """Extract character names mentioned in dialogue (proper nouns, vocative addresses, honorifics)."""
    STOPWORDS = {
        "The", "This", "That", "There", "Here", "What", "When", "Where", "Why", "How",
        "Who", "Which", "Come", "Look", "Listen", "Wait", "Take", "Give", "Tell", "Help",
        "Let", "Make", "Think", "Know", "See", "Get", "Go", "Stop", "Run", "Please",
        "Yes", "No", "Well", "Right", "Okay", "Sure", "Maybe", "Never", "Always",
        "Good", "Great", "Bad", "Just", "Even", "Still", "Now", "Then", "Today",
        "Tomorrow", "Yesterday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
        "Saturday", "Sunday", "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December",
        "English", "American", "British", "French", "German", "Russian", "Arabic",
        "God", "Lord", "Sir", "Madam", "Mister", "Miss", "Missus", "Doctor", "Captain",
        "King", "Queen", "Prince", "Princess", "General", "Officer", "Agent", "Father", "Mother"
    }
    HONORIFICS = r"(?:Mr\.|Mrs\.|Ms\.|Dr\.|Captain|Lord|King|Queen|Princess|Prince|General|Officer|Agent|Detective|Commander)\s+([A-Z][a-z]{2,})"
    DIRECT_ADDRESS = r"(?:,\s*|\b(?:call me|I am|this is|name is|ask for)\s+)([A-Z][a-z]{2,})[,\.!?]"

    names = set()
    all_text = " ".join([txt if isinstance(txt, str) else str(txt[1]) for txt in transcript_lines])

    for m in re.finditer(HONORIFICS, all_text):
        name = m.group(1).strip()
        if name not in STOPWORDS and len(name) >= 3:
            names.add(name)

    for m in re.finditer(DIRECT_ADDRESS, all_text, re.IGNORECASE):
        name = m.group(1).strip()
        if name not in STOPWORDS and len(name) >= 3:
            names.add(name)

    mid_sentence_caps = re.findall(r"(?<=[a-z]\s)([A-Z][a-z]{2,})\b", all_text)
    from collections import Counter
    counts = Counter(mid_sentence_caps)
    for name, cnt in counts.items():
        if name not in STOPWORDS and cnt >= 2 and len(name) >= 3:
            names.add(name)

    return sorted(list(names))[:8]


def get_groq_identify_model():
    """Read Groq model for identification from ai_models.json with fallback."""
    try:
        models = settings.get_ai_models()
        groq_cfg = models.get("groq", {})
        model = groq_cfg.get("identify") or groq_cfg.get("best") or "qwen/qwen3.8-27b"
        if not model or "llama" in model.lower():
            model = "qwen/qwen3.8-27b"
        return model
    except Exception:
        return "qwen/qwen3.8-27b"


def _parse_candidate_json(text):
    """Extract and validate candidate JSON list from AI response.
    Ignores candidates with title 'unknown' or confidence < 0.5.
    """
    if not text:
        return []
    try:
        clean = text.strip()
        if "```" in clean:
            m = re.search(r"```(?:json)?(.*?)```", clean, re.DOTALL)
            if m:
                clean = m.group(1).strip()
        idx_start = clean.find("[")
        idx_end = clean.rfind("]")
        if idx_start != -1 and idx_end != -1:
            clean = clean[idx_start:idx_end + 1]
        data = json.loads(clean)
        if not isinstance(data, list):
            return []
        valid = []
        for it in data:
            if isinstance(it, dict) and "title" in it and it["title"]:
                t = str(it["title"]).strip()
                if not t or t.lower() in ("unknown", "n/a", "none"):
                    continue
                y = it.get("year")
                try:
                    y = int(y) if y else None
                except Exception:
                    y = None
                conf = it.get("confidence")
                try:
                    conf = float(conf) if conf is not None else 0.7
                except Exception:
                    conf = 0.5
                if conf < 0.5:
                    print(f"[EnigmaTranslate] [IDENTIFY] Ignoring candidate '{t}' below 0.5 confidence (conf={conf:.2f})")
                    continue
                valid.append({"title": t, "year": y, "confidence": conf})
        return valid[:3]
    except Exception as e:
        print(f"[EnigmaTranslate] [IDENTIFY] Candidate JSON parse error: {e}")
        return []


def identify_movie_candidates_from_transcript(transcript, channel_name="", content_type="movie", character_names=None, timeout=8.0):
    """Send dialogue transcript (~1500 chars), channel name, content type, and detected character names
    to AI engine (Groq LLM qwen/qwen3.8-27b, fallback Gemini text).

    Returns list of dicts: [{'title': str, 'year': int or None, 'confidence': float}, ...]
    Candidates with confidence < 0.5 or 'unknown' are filtered out.
    """
    if not transcript or len(transcript.strip()) < 30:
        return []

    clean_transcript = transcript.strip()[:1500]
    names_str = ", ".join(character_names) if character_names else "None detected"
    prompt = (
        f"You are an expert film and television identifier.\n"
        f"Based on the following dialogue transcript excerpt, detected character names, channel name, and content type from a TV broadcast, "
        f"identify what movie or TV series is currently playing.\n\n"
        f"Channel: {channel_name or 'Movie Channel'}\n"
        f"Content Type: {content_type or 'movie'}\n"
        f"Detected Character Names: {names_str}\n"
        f"Dialogue Transcript:\n\"\"\"\n{clean_transcript}\n\"\"\"\n\n"
        f"Instructions:\n"
        f"- Analyze character names and unique dialogue to identify the exact movie or TV show.\n"
        f"- If the dialogue is too generic, ambiguous, or you cannot identify the title with confidence, return:\n"
        f'  [ {{"title": "unknown", "confidence": 0.0}} ]\n'
        f"- Otherwise return a valid JSON array of up to 3 candidates with a confidence score between 0.0 and 1.0 (ordered from highest to lowest confidence).\n"
        f"Example format:\n"
        f'[\n'
        f'  {{"title": "The Scorpion King", "year": 2002, "confidence": 0.95}},\n'
        f'  {{"title": "The Mummy Returns", "year": 2001, "confidence": 0.50}}\n'
        f']\n'
        f"Do NOT include any commentary, explanations, markdown formatting, or code blocks. Return ONLY the raw JSON array."
    )

    # 1. Try Groq LLM (Read from ai_models.json with fallback to qwen/qwen3.8-27b)
    groq_key = settings.get_api_key("groq")
    if groq_key:
        primary_model = get_groq_identify_model()
        models = [primary_model]
        for fb in ("openai/gpt-oss-120b", "openai/gpt-oss-20b"):
            if fb not in models:
                models.append(fb)

        for model in models:
            try:
                url = "https://api.groq.com/openai/v1/chat/completions"
                payload = {
                    "model": model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.1
                }
                req = urllib.request.Request(
                    url,
                    data=json.dumps(payload).encode("utf-8"),
                    headers={
                        "Authorization": f"Bearer {groq_key}",
                        "Content-Type": "application/json",
                        "User-Agent": "EnigmaTranslate"
                    }
                )
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    if resp.status == 200:
                        data = json.loads(resp.read().decode("utf-8"))
                        choices = data.get("choices", [])
                        if choices:
                            raw_text = choices[0].get("message", {}).get("content", "")
                            cands = _parse_candidate_json(raw_text)
                            if cands:
                                print(f"[EnigmaTranslate] [IDENTIFY] Groq ({model}) returned {len(cands)} confident candidates: {cands}")
                                return cands
                            else:
                                print(f"[EnigmaTranslate] [IDENTIFY] Groq ({model}) returned no confident candidates (raw: {raw_text.strip()[:100]})")
                                return []
            except Exception as e:
                print(f"[EnigmaTranslate] [IDENTIFY] Groq ({model}) error: {e}")
                continue

    # 2. Fallback to Gemini text
    gemini_key = settings.get_api_key("gemini")
    if gemini_key:
        gem_models = ["gemini-2.0-flash", "gemini-1.5-flash"]
        for g_model in gem_models:
            try:
                url = f"https://generativelanguage.googleapis.com/v1beta/models/{g_model}:generateContent?key={gemini_key}"
                payload = {
                    "contents": [{"parts": [{"text": prompt}]}],
                    "generationConfig": {"temperature": 0.1}
                }
                req = urllib.request.Request(
                    url,
                    data=json.dumps(payload).encode("utf-8"),
                    headers={"Content-Type": "application/json", "User-Agent": "EnigmaTranslate"}
                )
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    if resp.status == 200:
                        data = json.loads(resp.read().decode("utf-8"))
                        candidates = data.get("candidates", [])
                        if candidates:
                            raw_text = candidates[0].get("content", {}).get("parts", [{}])[0].get("text", "")
                            cands = _parse_candidate_json(raw_text)
                            if cands:
                                print(f"[EnigmaTranslate] [IDENTIFY] Gemini ({g_model}) returned {len(cands)} confident candidates: {cands}")
                                return cands
                            else:
                                print(f"[EnigmaTranslate] [IDENTIFY] Gemini ({g_model}) returned no confident candidates (raw: {raw_text.strip()[:100]})")
                                return []
            except Exception as e:
                print(f"[EnigmaTranslate] [IDENTIFY] Gemini ({g_model}) error: {e}")
                continue

    return []


def confirm_transcript_against_srt(transcript_lines, en_cues, min_matches=4):
    """Fuzzy-match recent transcript lines against SRT cues in chronological order.

    Switch only if at least min_matches lines match in order.
    Returns (confirmed: bool, match_count: int, matched_indices: list, matched_times: list).
    """
    def normalize(s):
        return re.sub(r"[^\w\s]", "", str(s).lower()).strip()

    norm_cues = [(c.start, normalize(c.text)) for c in en_cues if len(normalize(c.text)) >= 3]

    norm_trans = []
    for item in transcript_lines:
        if isinstance(item, (tuple, list)):
            t_time, line = item[0], item[1]
        else:
            t_time, line = 0.0, item
        nt = normalize(line)
        if len(nt) >= 6 and len(nt.split()) >= 1:
            norm_trans.append((t_time, nt))

    if len(norm_trans) < min_matches or not norm_cues:
        return False, 0, [], []

    trans_span = max(60.0, norm_trans[-1][0] - norm_trans[0][0]) if norm_trans[-1][0] > 0 else 180.0
    max_cue_span = trans_span + 60.0

    candidates = []
    for t_idx, (t_time, t_text) in enumerate(norm_trans):
        for ci, (c_start, c_text) in enumerate(norm_cues):
            sim = 0.0
            if len(c_text) >= 12 and (t_text in c_text or c_text in t_text):
                sim = 0.90
            elif len(c_text) >= 6:
                sim = difflib.SequenceMatcher(None, t_text, c_text).ratio()
            if sim >= 0.70:
                candidates.append((t_idx, ci, sim, t_time, c_start))

    best_chain = []
    for i, c1 in enumerate(candidates):
        chain = [c1]
        curr_ci = c1[1]
        curr_ti = c1[0]
        start_c_time = c1[4]
        for c2 in candidates[i + 1:]:
            if c2[0] > curr_ti and c2[1] > curr_ci and (c2[4] - start_c_time) <= max_cue_span:
                chain.append(c2)
                curr_ti = c2[0]
                curr_ci = c2[1]
        if len(chain) > len(best_chain):
            best_chain = chain

    if len(best_chain) >= min_matches:
        matched_indices = [c[1] for c in best_chain]
        matched_times = [c[3] for c in best_chain]
        return True, len(best_chain), matched_indices, matched_times

    return False, len(best_chain), [c[1] for c in best_chain], [c[3] for c in best_chain]


