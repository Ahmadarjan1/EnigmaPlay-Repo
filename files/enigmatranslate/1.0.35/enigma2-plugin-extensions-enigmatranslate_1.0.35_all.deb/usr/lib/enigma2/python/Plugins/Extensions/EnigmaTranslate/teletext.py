# -*- coding: utf-8 -*-
# Author: Ahmad Al-Qaisi
"""Minimal EBU Teletext Subtitle Decoder in pure Python.


Decodes EBU Teletext over DVB TS / PES (ETS 300 706 / EN 300 472).
Extracts subtitle pages (e.g. Dutch page 888) with Hamming 8/4 correction,
odd parity verification, Latin G0 character mapping (including Dutch),
boxed/subtitle flag handling, and PMT descriptor auto-detection.
"""

import re

# Standard ETS 300 706 Hamming (8/4) Codewords
ENCODE_TABLE = {
    0x0: 0x15, 0x1: 0x02, 0x2: 0x49, 0x3: 0x5E,
    0x4: 0x64, 0x5: 0x73, 0x6: 0x38, 0x7: 0x2F,
    0x8: 0xD0, 0x9: 0xC7, 0xA: 0x8C, 0xB: 0x9B,
    0xC: 0xA1, 0xD: 0xB6, 0xE: 0xFD, 0xF: 0xEA
}

# Bit-reversal table (DVB teletext bytes are transmitted LSB first)
REV = [int(f"{i:08b}"[::-1], 2) for i in range(256)]

# Generate full 256-entry Hamming 8/4 decode table with 1-bit error correction
_DECODE_MAP = {}
for data_nibble, codeword in ENCODE_TABLE.items():
    _DECODE_MAP[codeword] = data_nibble
    for bit in range(8):
        mutated = codeword ^ (1 << bit)
        if mutated not in _DECODE_MAP:
            _DECODE_MAP[mutated] = data_nibble

# Fast direct lookup: received byte -> bit-reverse -> decode 4-bit nibble (or None if uncorrectable)
FAST_HAMMING = [_DECODE_MAP.get(REV[b], None) for b in range(256)]

# Dutch Latin G0 character replacements (ETS 300 706 Table 36)
DUTCH_G0_REPLACEMENTS = {
    0x23: "#",   # 0x23: pound / hash
    0x24: "$",   # 0x24: currency / dollar / fl
    0x40: "à",   # 0x40: a-grave
    0x5B: "ë",   # 0x5B: e-diaeresis
    0x5C: "é",   # 0x5C: e-acute
    0x5D: "ï",   # 0x5D: i-diaeresis
    0x5E: "^",   # 0x5E: circumflex
    0x5F: "#",   # 0x5F: hash
    0x60: "ù",   # 0x60: u-grave
    0x7B: "ä",   # 0x7B: a-diaeresis
    0x7C: "ö",   # 0x7C: o-diaeresis
    0x7D: "ü",   # 0x7D: u-diaeresis
    0x7E: "è",   # 0x7E: e-grave
}

# Default Latin G0 replacements (English)
ENGLISH_G0_REPLACEMENTS = {
    0x23: "£",
    0x24: "$",
    0x40: "@",
    0x5B: "«",
    0x5C: "½",
    0x5D: "»",
    0x5E: "^",
    0x5F: "_",
    0x60: "`",
    0x7B: "¼",
    0x7C: "||",
    0x7D: "¾",
    0x7E: "÷"
}


def decode_teletext_char(byte_val, national_charset="dutch"):
    """Decode a single teletext character byte with odd parity check and Latin G0 mapping."""
    rb = REV[byte_val]
    # Check odd parity (bit 7 is parity bit)
    if (bin(rb).count("1") % 2) != 1:
        return " "
    code = rb & 0x7F
    if code < 0x20:
        # Non-spacing attributes / control codes (0x0B Start Box, 0x0A End Box, colors, etc.)
        return " "

    if national_charset == "dutch":
        return DUTCH_G0_REPLACEMENTS.get(code, chr(code))
    elif national_charset == "english":
        return ENGLISH_G0_REPLACEMENTS.get(code, chr(code))
    return chr(code)


class TeletextDecoder:
    """Pure Python streaming EBU Teletext Decoder.
    
    Accepts raw TS packets or reassembled PES packets, parses teletext data units,
    accumulates subtitle lines for the target page, emits clean text lines when a page
    is ready, and signals clears when erased.
    """

    def __init__(self, target_page=888, teletext_pid=None, on_subtitle=None, on_clear=None, charset="dutch"):
        self.target_page = int(target_page) if target_page not in (None, "auto", "") else 888
        self.teletext_pid = int(teletext_pid) if teletext_pid is not None else None
        self.on_subtitle = on_subtitle
        self.on_clear = on_clear
        self.charset = charset or "dutch"

        # PES reassembly state
        self._pes_buf = bytearray()
        self._ts_sync_offset = 0

        # Page buffer: {page_num: {row_num: text_string}}
        self._pages = {}
        self._active_page = None
        self._last_emitted_text = {}
        self._last_emitted_time = 0.0

    def set_target_page(self, page):
        try:
            self.target_page = int(page) if page not in (None, "auto", "") else 888
        except Exception:
            self.target_page = 888

    def set_pid(self, pid):
        try:
            self.teletext_pid = int(pid) if pid is not None else None
        except Exception:
            pass

    def feed_ts_bytes(self, chunk):
        """Feed a chunk of TS bytes (arbitrary size). Returns list of emitted subtitle events."""
        if not chunk:
            return []
        events = []
        pos = 0
        total = len(chunk)

        # Sync to 0x47
        while pos <= total - 188:
            if chunk[pos] != 0x47:
                pos += 1
                continue
            # Double check next sync byte if possible
            if pos + 188 < total and chunk[pos + 188] != 0x47:
                pos += 1
                continue

            pkt = chunk[pos : pos + 188]
            pos += 188

            ev = self.feed_ts_packet(pkt)
            if ev:
                events.extend(ev)

        return events

    def feed_ts_packet(self, pkt):
        """Feed a single 188-byte TS packet. Returns list of emitted subtitle strings."""
        if len(pkt) != 188 or pkt[0] != 0x47:
            return []

        b1, b2, b3 = pkt[1], pkt[2], pkt[3]
        pid = ((b1 & 0x1F) << 8) | b2

        # If PID is known and does not match, ignore
        if self.teletext_pid is not None and pid != self.teletext_pid:
            return []

        pusi = (b1 & 0x40) >> 6
        afc = (b3 & 0x30) >> 4

        payload_offset = 4
        if afc in (0, 2):  # No payload
            return []
        if afc == 3:  # Adaptation field + payload
            adapt_len = pkt[4]
            payload_offset = 5 + adapt_len
            if payload_offset >= 188:
                return []

        payload = pkt[payload_offset:]
        events = []

        if pusi:
            if self._pes_buf:
                ev = self.feed_pes(self._pes_buf)
                if ev:
                    events.extend(ev)
            self._pes_buf = bytearray(payload)
        else:
            if self._pes_buf:
                self._pes_buf.extend(payload)

        return events

    def feed_pes(self, pes):
        """Parse reassembled PES packet. Returns list of emitted subtitle strings."""
        if len(pes) < 9:
            return []
        if pes[0] != 0 or pes[1] != 0 or pes[2] != 1:
            return []
        stream_id = pes[3]
        if stream_id != 0xBD:  # Private Stream 1 (Teletext / DVB subtitles)
            return []

        pes_header_data_len = pes[8]
        data_idx = 9 + pes_header_data_len
        if data_idx >= len(pes):
            return []

        data_id = pes[data_idx]
        if not (0x10 <= data_id <= 0x1F):
            return []

        events = []
        pos = data_idx + 1

        while pos + 46 <= len(pes):
            unit_id = pes[pos]
            unit_len = pes[pos + 1]
            if unit_len != 0x2C:  # 44 bytes
                pos += 2 + unit_len
                continue

            # unit_id 0x02 = teletext non-subtitle, 0x03 = teletext subtitle
            if unit_id not in (0x02, 0x03):
                pos += 2 + unit_len
                continue

            udata = pes[pos + 2 : pos + 46]
            pos += 46

            # udata[0] is field parity / line offset, udata[1] must be framing code 0xE4
            if udata[1] != 0xE4:
                continue

            h1 = FAST_HAMMING[udata[2]]
            h2 = FAST_HAMMING[udata[3]]
            if h1 is None or h2 is None:
                continue

            mag = h1 & 0x07
            if mag == 0:
                mag = 8
            row = ((h1 >> 3) & 1) | (h2 << 1)

            if row == 0:
                # Header Packet (row 0)
                pu = FAST_HAMMING[udata[4]]
                pt = FAST_HAMMING[udata[5]]
                if pu is None or pt is None:
                    continue
                page = (mag * 100) + (pt * 10) + pu

                # Control bits: C4 is Erase Page (bit 3 of decoded byte 7)
                ctrl_h = FAST_HAMMING[udata[7]]
                erase = bool(ctrl_h and (ctrl_h & 0x08))

                # Check if we should emit buffered subtitle for this page
                if page == self.target_page or self.target_page is None:
                    stored_rows = self._pages.get(page, {})
                    if stored_rows:
                        clean_lines = []
                        for r in sorted(stored_rows.keys()):
                            txt = stored_rows[r].strip()
                            if txt:
                                clean_lines.append(txt)
                        if clean_lines:
                            full_text = " ".join(clean_lines)
                            full_text = re.sub(r"\s+", " ", full_text).strip()
                            if full_text and full_text != self._last_emitted_text.get(page):
                                self._last_emitted_text[page] = full_text
                                events.append((page, full_text))
                                if self.on_subtitle:
                                    try:
                                        self.on_subtitle(full_text, page)
                                    except Exception:
                                        pass

                if erase:
                    self._pages[page] = {}
                    if page == self.target_page and self.on_clear:
                        try:
                            self.on_clear(page)
                        except Exception:
                            pass
                else:
                    if page not in self._pages:
                        self._pages[page] = {}

                self._active_page = page

            elif 1 <= row <= 24 and self._active_page:
                # Text row packet
                page = self._active_page
                if self.target_page is None or page == self.target_page:
                    chars = [decode_teletext_char(b, national_charset=self.charset) for b in udata[4:44]]
                    row_txt = "".join(chars).strip()
                    if row_txt:
                        if page not in self._pages:
                            self._pages[page] = {}
                        self._pages[page][row] = row_txt

        return events


def parse_pmt_teletext_descriptors(pmt_bytes):
    """Parse TS/PES PMT section bytes and extract Teletext descriptors.
    
    Returns list of dicts:
    [{'pid': int, 'lang': str, 'type': int, 'page': int, 'is_subtitle': bool}]
    """
    results = []
    if not pmt_bytes or len(pmt_bytes) < 12:
        return results

    try:
        # Table ID 0x02 is PMT
        table_id = pmt_bytes[0]
        if table_id != 0x02:
            return results

        sec_len = ((pmt_bytes[1] & 0x0F) << 8) | pmt_bytes[2]
        prog_info_len = ((pmt_bytes[10] & 0x0F) << 8) | pmt_bytes[11]
        es_idx = 12 + prog_info_len

        limit = min(len(pmt_bytes) - 4, 3 + sec_len)
        while es_idx + 5 <= limit:
            stype = pmt_bytes[es_idx]
            epid = ((pmt_bytes[es_idx + 1] & 0x1F) << 8) | pmt_bytes[es_idx + 2]
            es_info_len = ((pmt_bytes[es_idx + 3] & 0x0F) << 8) | pmt_bytes[es_idx + 4]
            desc_data = pmt_bytes[es_idx + 5 : es_idx + 5 + es_info_len]

            # Stream type 0x06 is PES private data (Teletext / DVB subtitles)
            if stype == 0x06:
                d_pos = 0
                while d_pos + 2 <= len(desc_data):
                    dtag = desc_data[d_pos]
                    dlen = desc_data[d_pos + 1]
                    dbytes = desc_data[d_pos + 2 : d_pos + 2 + dlen]
                    if dtag == 0x56:  # Teletext descriptor (EN 300 468)
                        t_pos = 0
                        while t_pos + 5 <= len(dbytes):
                            lang = dbytes[t_pos : t_pos + 3].decode("ascii", errors="ignore").lower()
                            ttype = (dbytes[t_pos + 3] >> 3) & 0x1F
                            tmag = dbytes[t_pos + 3] & 0x07
                            if tmag == 0:
                                tmag = 8
                            tpage_bcd = dbytes[t_pos + 4]
                            tpage_num = (tpage_bcd >> 4) * 10 + (tpage_bcd & 0x0F)
                            full_page = tmag * 100 + tpage_num
                            is_sub = (ttype in (2, 5))
                            results.append({
                                "pid": epid,
                                "lang": lang,
                                "type": ttype,
                                "page": full_page,
                                "is_subtitle": is_sub
                            })
                            t_pos += 5
                    d_pos += 2 + dlen
            es_idx += 5 + es_info_len
    except Exception:
        pass

    return results
